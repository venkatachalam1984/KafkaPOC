package com.ford.gvmsr.receiver.validator;

import com.ford.gvmsr.receiver.builder.validation.VilValidationChainBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.util.SplunkUtils;

@Component
public class VilValidationHandler {

    private final SplunkUtils splunkUtils;
    private final PropertiesConfig properties;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public VilValidationHandler(SplunkUtils splunkUtils, PropertiesConfig properties) {
	this.splunkUtils = splunkUtils;
	this.properties = properties;
    }

    public void applyVilValidations(final VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	VilValidationChainBuilder chain = new VilValidationChainBuilder();
	VilValidationSourceEnum[] validationSource = VilValidationSourceEnum.values();
	for (VilValidationSourceEnum vilValidationSourceEnum : validationSource) {
	    chain.applyValidation(vilValidationSourceEnum, receiverRequest);
	}
    }

}
