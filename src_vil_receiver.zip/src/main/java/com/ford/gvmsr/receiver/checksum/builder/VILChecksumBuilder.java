package com.ford.gvmsr.receiver.checksum.builder;

import com.ford.gvmsr.receiver.checksum.model.VILChecksum;
import com.ford.gvmsr.receiver.checksum.util.ChecksumUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class VILChecksumBuilder implements VILChecksum {

    public String vin,vilBody = null;

    @Autowired
    private ChecksumUtil checksumUtil;

    @Override
    public void setVIN(String vin) {
        this.vin = vin;
    }

    @Override
    public String getVIN() {
        return vin;
    }

    @Override
    public void setVILBody(String vilBody) {
        this.vilBody = vilBody;
    }

    @Override
    public String getVILBody() {
        return vilBody;
    }

    public String buildChecksum(String checksumType){
        String checksum = null;
        checksum = checksumUtil.buildChecksum(this,checksumType);
        return checksum;
    }


}
