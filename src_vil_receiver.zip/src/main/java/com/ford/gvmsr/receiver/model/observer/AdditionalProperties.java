package com.ford.gvmsr.receiver.model.observer;

import java.sql.Timestamp;

import com.ford.gvmsr.domain.modulestate.metadata.response.DerivedAssemblyResponseForNode;
import com.ford.gvmsr.domain.modulestate.metadata.response.ODLNetworkDetails;

public class AdditionalProperties {

    private DerivedAssemblyResponseForNode derivedAssemblyResponseForNode;
    private ODLNetworkDetails odlNetworkDetailsForNode;
    private String vscsVersionDesc;
    private Timestamp vscsVersionDate;

    public DerivedAssemblyResponseForNode getDerivedAssemblyResponseForNode() {
	return derivedAssemblyResponseForNode;
    }

    public void setDerivedAssemblyResponseForNode(DerivedAssemblyResponseForNode derivedAssemblyResponseForNode) {
	this.derivedAssemblyResponseForNode = derivedAssemblyResponseForNode;
    }

    public ODLNetworkDetails getOdlNetworkDetailsForNode() {
	return odlNetworkDetailsForNode;
    }

    public void setOdlNetworkDetailsForNode(ODLNetworkDetails odlNetworkDetailsForNode) {
	this.odlNetworkDetailsForNode = odlNetworkDetailsForNode;
    }

    public String getVscsVersionDesc() {
	return vscsVersionDesc;
    }

    public void setVscsVersionDesc(String vscsVersionDesc) {
	this.vscsVersionDesc = vscsVersionDesc;
    }

    public Timestamp getVscsVersionDate() {
	return vscsVersionDate;
    }

    public void setVscsVersionDate(Timestamp vscsVersionDate) {
	this.vscsVersionDate = vscsVersionDate;
    }

}
