package com.ford.gvmsr.receiver.metrics;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.receiver.config.PropertiesConfig;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.dropwizard.MetricsService;
import io.vertx.ext.healthchecks.CheckResult;
import io.vertx.ext.healthchecks.HealthCheckHandler;
import io.vertx.ext.healthchecks.HealthChecks;
import io.vertx.ext.healthchecks.Status;
import io.vertx.ext.web.Router;

@Component
public class VertxMetricsHandler extends AbstractVerticle {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    PropertiesConfig config;

    @Override
    public void start() {
	vertx.setPeriodic(config.getVertxMetricsHandlerIntervalMs(), handler -> {
	    JsonObject snapshot = null;
	    MetricsService service = MetricsService.create(vertx);
	    JsonObject metrics = service.getMetricsSnapshot(vertx.eventBus());
	    MetricsService metricsService = MetricsService.create(vertx);
	    if (metricsService != null) {
		snapshot = metricsService.getMetricsSnapshot(vertx);
		log.debug("Vertx metrics JSON- " + snapshot);
	    }
	});
	registerEventBusConsumer();
	loadEventBusProducer();
    }

    public void registerEventBusConsumer() {
	HealthChecks hc = HealthChecks.create(vertx);
	vertx.eventBus().consumer("health", message -> {
	    Future<CheckResult> checkResultFuture = hc.checkStatus();
	    checkResultFuture.onSuccess(message::reply).onFailure(err -> message.fail(0, err.getMessage()));
	});
    }

    public void loadEventBusProducer() {
	HealthCheckHandler handler = HealthCheckHandler.create(vertx);
	handler.register("eventbus", promise -> vertx.eventBus().request("health", "ping").onSuccess(msg -> {
	    promise.complete(Status.OK());
	}).onFailure(err -> {
	    promise.complete(Status.KO());
	}));
	Router router = Router.router(vertx);
	router.get("/health").handler(handler);
	vertx.createHttpServer().requestHandler(router).listen(8083);
    }
}
