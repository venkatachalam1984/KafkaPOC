package com.ford.gvmsr.receiver.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ford.gvmsr.receiver.entity.Vehicle;
import com.ford.gvmsr.receiver.repository.IVehicleRepository;

@Repository
public class VehicleRepository implements IVehicleRepository {

    static String findVehicleDetailsByVinAndVinHashQuery = "SELECT * FROM PGVMR04_VEH WHERE GVMR04_VIN_R = ? and GVMR04_VIN_HASH_R = ?";
    private final JdbcTemplate jdbcTemplate;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public VehicleRepository(DataSource dataSource) {
	this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public Optional<Vehicle> findByVinAndVinHash(String vin, Integer vinHashKey) {
	try {
	    Object[] param = new Object[] { vin, vinHashKey };
	    return jdbcTemplate.queryForObject(findVehicleDetailsByVinAndVinHashQuery, param, (rs, rowNum) -> Optional.of(mapVehicleResult(rs)));
	} catch (EmptyResultDataAccessException e) {
	    log.error("No record found in 04 table for vin - " + vin);
	} catch (Exception e) {
	    log.error("Exception while fetching from 04 table for vin-{}, cause-{} ", vin, e);
	}
	return Optional.empty();
    }

    private Vehicle mapVehicleResult(final ResultSet rs) throws SQLException {
	return Vehicle.builder().vinHash(rs.getInt("GVMR04_VIN_HASH_R")).vin(rs.getString("GVMR04_VIN_R"))
		.programCode(rs.getString("GVMR04_PROGRAM_C")).salesModelYear(rs.getFloat("GVMR04_SALES_MODEL_YEAR_C"))
		.createdUser(rs.getString("GVMR04_CREATE_USER_C")).createdTime(rs.getTimestamp("GVMR04_CREATE_S"))
		.build();
    }
}
