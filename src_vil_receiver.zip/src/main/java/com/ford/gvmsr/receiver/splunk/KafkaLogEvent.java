package com.ford.gvmsr.receiver.splunk;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class KafkaLogEvent {
    private String vin;
    private String topic;
    private long partition;
    private long currentOffset;
    private long endOffset;
    private long producedTime;
    private long consumedTime;
}
