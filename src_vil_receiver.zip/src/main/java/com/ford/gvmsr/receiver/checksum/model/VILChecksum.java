package com.ford.gvmsr.receiver.checksum.model;

public interface VILChecksum {

    public void setVIN(String vin);
    public String getVIN();
    public void setVILBody(String vilBody);
    public String getVILBody();
}
