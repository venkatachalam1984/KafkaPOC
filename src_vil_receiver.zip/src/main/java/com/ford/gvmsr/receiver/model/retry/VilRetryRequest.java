package com.ford.gvmsr.receiver.model.retry;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.SneakyThrows;

import java.util.List;

@Getter
public class VilRetryRequest {
    private String vin;
    private String traceId;
    private Long recordId;
    private List<String> nodeList;
    private String requestType;

    @SneakyThrows
    public String toString() {
        return new ObjectMapper().writeValueAsString(this);
    }
}
