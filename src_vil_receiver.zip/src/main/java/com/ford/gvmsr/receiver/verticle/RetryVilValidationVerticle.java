package com.ford.gvmsr.receiver.verticle;

import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.entity.VilMessage;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.VilRequest;
import com.ford.gvmsr.receiver.model.retry.VilRetryRequest;
import com.ford.gvmsr.receiver.repository.IVilMessageRepository;
import com.ford.gvmsr.receiver.repository.impl.VilMessageRepository;
import com.ford.gvmsr.receiver.util.BeanUtil;
import com.ford.gvmsr.receiver.util.VilUtils;
import com.ford.gvmsr.receiver.validator.PCMYValidationHandler;
import com.ford.gvmsr.receiver.validator.VilValidationHandler;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class RetryVilValidationVerticle extends AbstractVerticle {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private IVilMessageRepository vilMessageRepository;
    private VilValidationHandler vilValidationHandler;
    private PCMYValidationHandler pcmyValidationHandler;
    private PropertiesConfig properties;

    @Override
    public void start() {
        log.debug("Deployed RetryVilValidationVerticle verticle");
        vertx.eventBus().consumer(VilConstants.RETRY_VIL_VALIDATOR_VERTICLE, this::vilRetryValidationHandler);
        initializeDependentAutowiredBeans();
    }

    /**
     * Initialize dependent beans that uniquely matches the given object type, if
     * any.
     */
    private void initializeDependentAutowiredBeans() {
        this.vilMessageRepository = BeanUtil.getBean(vilMessageRepository, VilMessageRepository.class);
        this.vilValidationHandler = BeanUtil.getBean(vilValidationHandler, VilValidationHandler.class);
        this.properties = BeanUtil.getBean(properties, PropertiesConfig.class);
        this.pcmyValidationHandler = BeanUtil.getBean(pcmyValidationHandler, PCMYValidationHandler.class);
    }

    /**
     * Received VIL request will be validated by list of base validators (i.e)
     * History Validator, Duplicate Validator, JSON Constraint Validator, PCMY
     * validator. If VIL passed all the validations then will sent Domain Validator
     * Verticle
     *
     * @param message Message represents data shared through Event-Bus.
     */
    private void vilRetryValidationHandler(Message<Object> message) {
        VilMessage vilMessage = null;
        String payloadMessage = null;
        try {
            VilRetryRequest retryRequest = Json.decodeValue(message.body().toString(), VilRetryRequest.class);
            log.info("RetryVilValidationVerticle:received VIN={},recordId={}", retryRequest.getVin(), retryRequest.getRecordId());
            Optional<VilMessage> vilMessageOptional = vilMessageRepository.findById(retryRequest.getRecordId());
            if (vilMessageOptional.isPresent()) {
                vilMessage = vilMessageOptional.get();
                payloadMessage = vilMessage.getVilPayloadMessage();
            }
            VilRequest vilRequest = VilUtils.generateVilRequest(payloadMessage).setTraceId(vilMessage.getTraceId());
            VilReceiverRequest receiverRequest = new VilReceiverRequest(vilRequest, properties.getApplicationDIDs());
            receiverRequest.setRetryAllowedNodesList(retryRequest.getNodeList());
            pcmyValidationHandler.prepareIVSProgramId(receiverRequest);
            receiverRequest.setRetryVilFlagEnabled(Boolean.TRUE);
            receiverRequest.setRetryRequestType(retryRequest.getRequestType());
            receiverRequest.setVilMessageRecordId(retryRequest.getRecordId());
            vilValidationHandler.applyVilValidations(receiverRequest);
            pushToDomainStateValidator(retryRequest.getVin(), receiverRequest);
        } catch (Exception e) {
            log.error("Exception - " + e);
        }
    }

    /**
     * Send request to DOMAIN_STATE_VALIDATION_HANDLER through Vertx EventBus
     *
     * @param vin             Vehicle Identification Number is primary identification field
     * @param receiverRequest unique UUID to trace specific VIL request
     */
    private void pushToDomainStateValidator(String vin, VilReceiverRequest receiverRequest) {
        String domainValidatorAddr = VilConstants.DOMAIN_STATE_VALIDATION_HANDLER + VilUtils.getVinModHash(vin);
        log.info("Verticle name={}, for VIN={}", domainValidatorAddr, vin);
        vertx.eventBus().send(domainValidatorAddr, receiverRequest);
    }

}
