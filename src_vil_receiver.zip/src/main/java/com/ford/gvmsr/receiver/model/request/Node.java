
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "address", "ecuAcronym", "esn", "specificationCategory", "odlNetwork", "did",
	"pecificationCategory" })
public class Node {

    @NotNull(message = "Node - Address should not be null")
    @JsonProperty("address")
    private String address;

    @NotNull(message = "Node - EcuAcronym should not be null")
    @JsonProperty("ecuAcronym")
    private String ecuAcronym;

    @NotNull(message = "Node - Esn should not be null")
    @JsonProperty("esn")
    private String esn;

    @NotNull(message = "Node - SpecificationCategory should not be null")
    @JsonProperty("specificationCategory")
    private String specificationCategory;

    @NotNull(message = "Node - OdlNetwork should not be null")
    @JsonProperty("odlNetwork")
    private @Valid OdlNetwork odlNetwork;

    @Size(min = 1, message = "Node - DID List should not be empty")
    @JsonProperty("did")
    private @Valid List<Did> did = null;

    @JsonProperty("pecificationCategory")
    private String pecificationCategory;

    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("address")
    public String getAddress() {
	return address;
    }

    @JsonProperty("address")
    public void setAddress(String address) {
	this.address = address;
    }

    @JsonProperty("ecuAcronym")
    public String getEcuAcronym() {
	return ecuAcronym;
    }

    @JsonProperty("ecuAcronym")
    public void setEcuAcronym(String ecuAcronym) {
	this.ecuAcronym = ecuAcronym;
    }

    @JsonProperty("esn")
    public String getEsn() {
	return esn;
    }

    @JsonProperty("esn")
    public void setEsn(String esn) {
	this.esn = esn;
    }

    @JsonProperty("specificationCategory")
    public String getSpecificationCategory() {
	return specificationCategory;
    }

    @JsonProperty("specificationCategory")
    public void setSpecificationCategory(String specificationCategory) {
	this.specificationCategory = specificationCategory;
    }

    @JsonProperty("odlNetwork")
    public @Valid OdlNetwork getOdlNetwork() {
	return odlNetwork;
    }

    @JsonProperty("odlNetwork")
    public void setOdlNetwork(OdlNetwork odlNetwork) {
	this.odlNetwork = odlNetwork;
    }

    @JsonProperty("did")
    public List<Did> getDid() {
	return did;
    }

    @JsonProperty("did")
    public void setDid(List<Did> did) {
	this.did = did;
    }

    @JsonProperty("pecificationCategory")
    public String getPecificationCategory() {
	return pecificationCategory;
    }

    @JsonProperty("pecificationCategory")
    public void setPecificationCategory(String pecificationCategory) {
	this.pecificationCategory = pecificationCategory;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
    }

}
