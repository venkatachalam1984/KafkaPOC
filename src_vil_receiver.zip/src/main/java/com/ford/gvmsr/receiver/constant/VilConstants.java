package com.ford.gvmsr.receiver.constant;

public class VilConstants {

    public static final String PARTITION_KEY = "partitionKey";
    public static final String TRACE_ID_KEY = "traceId";
    public static final String VIL_MESSAGE_RECORD_ID = "recordId";
    public static final String VIN_KEY = "vin";
    public static final String TIMESTAMP_KEY = "timeStamp";
    public static final String RAW_VIL_KEY = "vilString";
    public static final String RECORD_KEY = "recordKey";
    public static final String PARTITION = "partition";
    public static final String OFFSET = "offset";
    public static final String REQUEST_TYPE = "requestType";

    // Verticle eventbus address
    public static final String KAFKA_REORDER_PRODUCER_VERTICLE = "reOrderKafkaProducer";
    public static final String DOWN_STREAM_PRODUCER_VERTICLE = "downStreamProducer";
    public static final String ENCODED_VIL_RECEIVER = "VilReqProcessor";
    public static final String LOG_VALIDATOR_PREFIX = "GVMSRLogValidator-";
    public static final String RETRY_VIL_VALIDATOR_VERTICLE = "RetryVilValidator";
    public static final String DOMAIN_STATE_VALIDATION_HANDLER = "moduleStateValidator";
    public static final String IVS_EXCEPTION_EVENT_PROC = "ivsExceptionEventProcessor";
    public static final String MODULE_STATE_OBSERVER_REQ_PROC = "observerRequestProcessor";
    public static final String DOMAIN_VALIDATION_RESP_PROC = "domainValidationResponseProc";

    public static final String VIL_TO_HEC_SPLUNK_SUCCESS = "Success";

    // Retry Request Status
    public static final String TYPE_SNAP_F = "VIL_SNAP_F_RETRY";
    public static final String TYPE_IVS_ERR = "VIL_IVS_ERROR_RETRY";
    // Splunk log levels
    public static final String LOG_TYPE_INFO = "info";
    public static final String LOG_TYPE_ERROR = "error";

    // DB & Splunk log status
    public static final String VIL_REQ_START = "VIL_RECV_START";
    public static final String RETRY_REQ_START = "VIL_RETRY_START";
    public static final String NEW_VIL = "NEW";
    public static final String RETRY_VIL = "RETRY";
    public static final String ORDERED_VIL = "ORDERED";
    public static final String DUPLICATE_VIL = "DUP_VIL";
    public static final String LATE_VIL = "LATE_VIL";
    public static final String DECODE_EXCEPTION_VIL = "VIL_DECD_F";
    public static final String VALIDATION_ERROR = "VVERROR";
    public static final String IN_DOMAIN_VAL = "IN_DVAL";

    // VIL Failure Status
    public static final String RUNTIME_FAILURE = "RTF";
    public static final String NO_PROGRAM_CODE = "NOPC";
    public static final String DOMAIN_VALIDATION_F = "DVF";
    public static final String INVALID_NODE = "INV_N";
    public static final String INVALID_VIL = "INVV";
    public static final String TO_SNAP_OBSERVER = "TO_SNAP";
    public static final String SNAP_FAILURE = "SNAP_F";
    public static final String RECV_END = "VIL_RECV_END";
    public static final String NULL_DOMAIN_VAL_RESP = "DVR_NULL";
    public static final String PARTIALLY_CMPTD = "PCMP";

    // Splunk VIL_Receiver sources
    public static final String KAFKA_TOPIC_LAG = "KAFKA_TOPIC_LAG";
    public static final String KAFKA_MESSAGE_QUEUE_DELAY = "KAFKA_MESSAGE_QUEUE_DELAY";
    public static final String ENCODED_VIL_PROC = "ENCODED_VIL_PROC";
    public static final String VIL_RETRY_CTLR = "VIL_RETRY_CTLR";
    public static final String GVMSR_LOG_CONSUMER = "GVMSR_LOG_CONSUMER";
    public static final String INDEXED_VIL_REQ_HANDLER = "INDEXED_WORKER_HANDLER";
    public static final String MODULE_INFO_NODE_PROCESSOR = "MODULE_INFO_NODE_PROC";
    public static final String OBSERVER_REQUEST_PROC = "OBSERVER_REQUEST_PROC";
    public static final String MODULE_STATE_REQUEST_BUILDER = "MODULE_STATE_REQ_BUILDER";
    public static final String DOMAIN_VAL_REQ_HANDLER = "DOMAIN_VAL_REQ_HANDLER";

    // Splunk VIL_Receiver source-types
    public static final String GVMSR_SOURCE_VIL = "VIL";
    public static final String SPLUNK_SOURCE_VIL_RECEIVER = "VIL_RECEIVER";
    public static final String RETURN_TYPE_VALIDATE_AND_PROCESS = "PROCESS";

    public static final String RAW_VIL = "rawVIL";

    // Status
    public static final String ERROR = "Error";

    public static final String RETURN_TYPE_VIL = "VIL";
    public static final String RETURN_TYPE_VALIDATE = "VALIDATE";

    // Error consts
    public static final String DID_RESPONSE_INVALID_CHAR_ERROR = "INVALID-CHAR-ERROR";
    public static final String DID_RESPONSE_PARSING_ERROR = "PARSING-ERROR";
    public static final String POSITIVE_RESPONSE_62 = "62";
    public static final String NEGATIVE_RESPONSE_7F = "7F";
    public static final String POSITIVE_RESPONSE_71 = "71";

    // DID error code
    public static final String F111_DID = "F111";
    public static final String F113_DID = "F113";

    // Common fields
    public static final String SOURCE_SYS_GVMS = "GVMS";
    public static final String SOURCE_SYS_GVMSR = "GVMSR";

    // VIL source
    public static final String ROLE_DESC_FENIX = "FENIX";

    // Role ID
    public static final String VIL_ROLE_ID = "VIL-GPH001";

    public static final String NODE_NOT_PRESENT_STATUS = "A011";
    public static final String NETWORK_MISMATCH_STATUS = "A014";
    public static final String DA_PASSED_STATUS = "VL01";
    public static final String DUPLICATE_DID_FOUND_STATUS = "DUP_DID";
    public static final String VALID_NODE_STATUS = "SNAP_C";

    public static final String CHECKSUM_CRC32="CRC32";
    public static final String KAFKA_TOPIC = "kafka_topic";
}
