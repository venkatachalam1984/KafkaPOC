package com.ford.gvmsr.receiver.repository.impl;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ford.gvmsr.receiver.repository.IIVSXmlVersionRepository;

@Repository
public class IVSXmlVersionRepository implements IIVSXmlVersionRepository {

    public final String findIvsXmlVersionByPCAndMY = "SELECT GVMR05_XML_VERSION_R FROM PGVMR05_XML_LAST_PRCS where GVMR05_PROGRAM_C=? and GVMR05_SALES_MODEL_YEAR_C=?";
    private final JdbcTemplate jdbcTemplate;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public IVSXmlVersionRepository(DataSource dataSource) {
	this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public int findXmlVersionByPCAndMY(String programCode, Float modelYear) {
	try {
	    Object[] param = new Object[] { programCode, modelYear };
	    return jdbcTemplate.queryForObject(findIvsXmlVersionByPCAndMY, param, (rs, rowNum) -> rs.getInt(1));
	} catch (EmptyResultDataAccessException e) {
	    log.error("No record found in 05 table for PC-{}, MY-{}", programCode, modelYear);
	} catch (Exception e) {
	    log.error("Exception while fetching from 05 table for PC-{}, MY-{}, cause-{} ", programCode, modelYear, e);
	}
	return 0;
    }

}
