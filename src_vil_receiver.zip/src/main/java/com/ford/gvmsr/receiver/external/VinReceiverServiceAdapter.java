package com.ford.gvmsr.receiver.external;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.exception.PCMYNotFoundException;
import com.ford.gvmsr.receiver.model.vinreceiver.VinReceiverRequest;
import com.ford.gvmsr.receiver.model.vinreceiver.VinReceiverResponse;
import com.ford.gvmsr.receiver.util.JsonUtils;
import com.ford.gvmsr.receiver.util.RestTemplateUtil;

@Component
public class VinReceiverServiceAdapter {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    PropertiesConfig propertiesConfig;

    public VinReceiverResponse getPCMYFromVinReceiver(String vin, String traceId)
	    throws PCMYNotFoundException, JsonProcessingException {
	String vinReceiverRequest = prepareVinReceiverRequest(vin, traceId);
	String vinReceiverResponse = RestTemplateUtil.post(propertiesConfig.getVinReceiverEndpoint(),
		vinReceiverRequest, null);
	log.debug("VinReceiver Response JSON- " + vinReceiverResponse);
	VinReceiverResponse receiverResponse = prepareVinReceiverResponseIfValid(vinReceiverResponse);
	if (receiverResponse == null)
	    throw new PCMYNotFoundException("PC and MY Not found for vin-" + vin);
	return receiverResponse;
    }

    private String prepareVinReceiverRequest(String vin, String traceId) throws JsonProcessingException {
	VinReceiverRequest vinReceiverRequest = VinReceiverRequest.builder().vin(vin).traceId(traceId).build();
	return JsonUtils.getJsonString(vinReceiverRequest);
    }

    private VinReceiverResponse prepareVinReceiverResponseIfValid(String inputJson) throws JsonProcessingException {
	VinReceiverResponse vinReceiverResponse = new ObjectMapper().readValue(inputJson, VinReceiverResponse.class);
	return (vinReceiverResponse.getErrorCode() == 0) ? vinReceiverResponse : null;
    }
}
