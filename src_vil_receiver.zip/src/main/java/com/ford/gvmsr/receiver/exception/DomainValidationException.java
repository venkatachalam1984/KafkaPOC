package com.ford.gvmsr.receiver.exception;

public class DomainValidationException extends Exception {

    public DomainValidationException(String message) {
        super(message);
    }

}
