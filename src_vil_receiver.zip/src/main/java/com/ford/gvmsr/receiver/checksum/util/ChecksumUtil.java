package com.ford.gvmsr.receiver.checksum.util;


import java.util.zip.CRC32;
import java.util.zip.Checksum;

import com.ford.gvmsr.receiver.checksum.model.VILChecksum;
import com.ford.gvmsr.receiver.constant.VilConstants;
import org.springframework.stereotype.Component;

@Component
public class ChecksumUtil {

    public String buildChecksum(VILChecksum vilChecksum, String checksumType) {
        String checksum = null;
        if(VilConstants.CHECKSUM_CRC32.equals(checksumType)){
            checksum = calculateCRC32Checksum(vilChecksum);
        }
        return checksum;
    }

    public String calculateCRC32Checksum(VILChecksum vilChecksum){
        byte[] bytes = vilChecksum.getVILBody().getBytes();
        Checksum checksum = new CRC32(); // java.util.zip.CRC32
        checksum.update(bytes, 0, bytes.length);
        return String.valueOf(checksum.getValue());
    }
}



