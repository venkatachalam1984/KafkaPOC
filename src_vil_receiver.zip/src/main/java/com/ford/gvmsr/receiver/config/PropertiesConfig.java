package com.ford.gvmsr.receiver.config;

import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;

@Configuration
@Getter
public class PropertiesConfig {

    @Value("${server.port}")
    int serverPort;
    @Value("${application.dids}")
    public Set<String> applicationDIDs;
    @Value("${vertx.kafka.producer.acks-config}")
    String kafkaProducerAcksConfig;
    @Value("${vertx.kafka.producer.request.timeout.ms}")
    int requestTimeOutMs;
    @Value("${vertx.kafka.producer.batch.size.bytes}")
    int producerBatchSizeInBytes;
    @Value("${vertx.kafka.producer.protocol-config}")
    String kafkaProducerProtocolConfig;
    @Value("${vertx.kafka.producer.gvmsr.bootstrap-servers}")
    String gvmsrProducerBrokerEndpoint;
    @Value("${vertx.kafka.producer.gvms.bootstrap-servers}")
    String downStreamProducerBrokerEndpoint;
    @Value("${vertx.controller.worker-verticle.instance-count}")
    int vertxControllerInstanceCount;

    @Value("${vertx.kafka.consumer.vil.topic}")
    String vilConsumerTopic;
    @Value("${vertx.kafka.consumer.vil.bootstrap-servers}")
    String vilKafkaBrokerEndpoints;
    @Value("${vertx.kafka.consumer.vil.protocol-config}")
    String vilProtocolConfig;
    @Value("${vertx.kafka.consumer.vil.retry.backoff.ms}")
    Integer retryBackOffInMs;
    @Value("${vertx.kafka.consumer.vil.auto.commit.interval.ms}")
    Integer autoCommitIntervalInMs;
    @Value("${vertx.kafka.consumer.vil.consumer-group}")
    String vilConsumerGroup;
    @Value("${vertx.kafka.consumer.vil.auto.offset.reset}")
    String vilOffsetResetMode;
    @Value("${vertx.kafka.consumer.vil.max.poll.records}")
    String vilMaxPollRecords;
    @Value("${vertx.kafka.consumer.vil.automatic-offset-commit}")
    boolean vilAutoCommitOffset;
    @Value("${vertx.kafka.consumer.vil.retry-count}")
    Integer vilKafkaRetryCount;

    @Value("${vertx.kafka.consumer.log.topic}")
    String logConsumerTopic;
    @Value("${vertx.kafka.consumer.log.bootstrap-servers}")
    String logKafkaBrokerEndpoints;
    @Value("${vertx.kafka.consumer.log.protocol-config}")
    String logProtocolConfig;
    @Value("${vertx.kafka.consumer.log.consumer-group}")
    String logConsumerGroup;
    @Value("${vertx.kafka.consumer.log.auto.offset.reset}")
    String logOffsetResetMode;
    @Value("${vertx.kafka.consumer.log.max.poll.records}")
    String logMaxPollRecords;
    @Value("${vertx.kafka.consumer.log.automatic-offset-commit}")
    boolean logAutoCommitOffset;
    @Value("${vertx.kafka.consumer.log.retry-count}")
    Integer logKafkaRetryCount;

    @Value("${vertx.kafka.producer.exception-events.topic}")
    String exceptionEventTopic;
    @Value("${vertx.kafka.consumer.module-state-observer.topic}")
    String moduleStateObserverTopic;
    @Value("${vertx.kafka.producer.givis.downstream-syncup-topic}")
    String downStreamSyncUpTopic;
    @Value("${vertx.configure.worker-verticle-count}")
    Integer workerVerticleCount;

    @Value("${redis.cache.enabled}")
    boolean cacheEnabled;
    @Value("${redis.vil.cache.enabled}")
    boolean RedisCacheEnabledForVIL;

    @Value("${vertx.eventbus.standard.execution-time.secs}")
    Integer vertxEventLoopExecutionTimeInSecs;
    @Value("${vertx.eventbus.worker.execution-time.secs}")
    Integer vertxWorkerExecutionTimeInSecs;
    @Value("${vertx.eventbus.standard.blocked-thread.check-interval}")
    Integer threadBlockedCheckInterval;
    @Value("${vertx.eventbus.common.warning.blocked.interval}")
    Integer vertxThreadExecutionLimit;

    @Value("${vertx.timer.kafka-partition-lag-metrics.interval.ms}")
    Long kafkaPartitionLagMetricsIntervalMs;
    @Value("${vertx.timer.vertx-metrics-handler.interval.ms}")
    Long vertxMetricsHandlerIntervalMs;

    @Value("${gvmsr.module-state-observer.url}")
    String moduleStateObserverEndpoint;
    @Value("${gvmsr.module-state-observer.rest.enabled}")
    boolean restEnabled;

    @Value("${vil_receiver.external.vin_receiver.rest.endpoint}")
    String vinReceiverEndpoint;

}
