package com.ford.gvmsr.receiver.builder;

import java.sql.Timestamp;
import java.util.*;

import com.ford.gvmsr.receiver.constant.VilConstants;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.domain.modulestate.model.request.ModuleNodeType;
import com.ford.gvmsr.domain.modulestate.model.request.ModuleSnapshotType;
import com.ford.gvmsr.domain.modulestate.model.request.ModuleStateRequest;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStateResponse;
import com.ford.gvmsr.receiver.model.observer.AdditionalProperties;
import com.ford.gvmsr.receiver.model.observer.SnapshotObserverRequest;
import com.ford.gvmsr.receiver.model.observer.VilHeader;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.VIL;

@Component
public class SnapObserverRequestBuilder {

    public SnapshotObserverRequest build(VilReceiverRequest request, Long recordKey,
										 List<String> validAddressNodeList, Timestamp timestamp) {
	Map<String, AdditionalProperties> additionalPropertiesMap = new HashMap<>();
	SnapshotObserverRequest snapshotObserverRequest = null;
	DomainStateResponse stateResponse = request.getStateResponse();
	if (!validAddressNodeList.isEmpty()) {
	    snapshotObserverRequest = new SnapshotObserverRequest();
	    snapshotObserverRequest.setInfoKey(stateResponse.getInfoKey());
	    snapshotObserverRequest.setRecordKey(recordKey);
	    snapshotObserverRequest.setRedisValue(stateResponse.getRedisValue());
	    // Build ModuleStateRequest
	    ModuleStateRequest moduleStateRequest = new ModuleStateRequest();
	    buildModuleStateRequest(stateResponse, moduleStateRequest, validAddressNodeList);
	    snapshotObserverRequest.setModuleStateRequest(moduleStateRequest);
	    // Build additional properties
	    buildAdditionalProperties(stateResponse, additionalPropertiesMap);
	    snapshotObserverRequest.setAdditionalPropertiesMap(additionalPropertiesMap);
	    buildVilHeaderProperties(request, snapshotObserverRequest);
		snapshotObserverRequest.setRequestType(request.isRetryVilFlagEnabled() ? VilConstants.RETRY_VIL : VilConstants.NEW_VIL);
		snapshotObserverRequest.setVilProcessedTime(timestamp);
	}
	return snapshotObserverRequest;
    }

    private void buildVilHeaderProperties(VilReceiverRequest request, SnapshotObserverRequest snapshotObserverRequest) {
	VilHeader vilHeader = new VilHeader();
	VIL vil = request.getVil();
	vilHeader.setSwumVersion(vil.getSwumVersion());
	vilHeader.setCampaignId(vil.getCampaignId());
	vilHeader.setDeploymentId(vil.getDeploymentId());
	vilHeader.setDtcList(vil.getDtcList());
	vilHeader.setManifestSchema(vil.getManifestSchema());
	vilHeader.setPolicyTable(vil.getPolicyTable());
	vilHeader.setRequestRole(vil.getRequestRole());
	vilHeader.setTimeStamp(vil.getTimeStamp());
	vilHeader.setTriggerType(vil.getTriggerType());
	vilHeader.setVilReason(vil.getVilReason());
	vilHeader.setVisVersion(vil.getVisVersion());
	snapshotObserverRequest.setVilHeader(vilHeader);
    }

    private void buildAdditionalProperties(DomainStateResponse stateResponse, Map<String, AdditionalProperties> props) {
	stateResponse.getDomainStatusTracker().forEach((nodeAddress, statusTracker) -> {
	    AdditionalProperties additionalProperties = new AdditionalProperties();
	    additionalProperties.setDerivedAssemblyResponseForNode(statusTracker.getDerivedAssemblyResponseForNode());
	    additionalProperties.setOdlNetworkDetailsForNode(statusTracker.getOdlNetworkDetailsForNode());
	    props.put(nodeAddress, additionalProperties);
	});
    }

    private void buildModuleStateRequest(DomainStateResponse stateResponse, ModuleStateRequest target,
	    List<String> validAddressNodeList) {
	ModuleStateRequest source = stateResponse.getModuleStateRequest();
	ModuleSnapshotType moduleSnapshotType = new ModuleSnapshotType();
	moduleSnapshotType.setModuleName(source.getModuleSnapshot().getModuleName());
	moduleSnapshotType.setVIN(source.getModuleSnapshot().getVIN());
	moduleSnapshotType.setRequestRole(source.getModuleSnapshot().getRequestRole());
	moduleSnapshotType.setFeatureCodes(source.getModuleSnapshot().getFeatureCodes());
	moduleSnapshotType.setNode(buildModuleInfoNodesList(stateResponse, validAddressNodeList));
	target.setTraceID(source.getTraceID());
	target.setModuleSnapshot(moduleSnapshotType);
    }

    private List<ModuleNodeType> buildModuleInfoNodesList(DomainStateResponse stateResponse,
	    List<String> validNodeAddressList) {
	List<ModuleNodeType> validNodeList = new ArrayList<>();
	if (Objects.nonNull(validNodeAddressList) && !validNodeAddressList.isEmpty()) {
	    stateResponse.getModuleStateRequest().getModuleSnapshot().getNode().stream()
		    .filter(moduleNodeType -> validNodeAddressList.contains(moduleNodeType.getAddress()))
		    .forEach(validNodeList::add);
	}
	return validNodeList;
    }

}
