package com.ford.gvmsr.receiver.exception;

public class VILDecodeException extends Exception {

    public VILDecodeException(String exception) {
	super(exception);
    }

}
