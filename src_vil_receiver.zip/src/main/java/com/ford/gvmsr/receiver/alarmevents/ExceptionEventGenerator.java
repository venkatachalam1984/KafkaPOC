package com.ford.gvmsr.receiver.alarmevents;

import java.util.*;
import java.util.stream.Collectors;

import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.domain.modulestate.metadata.request.DIDInfo;
import com.ford.gvmsr.domain.modulestate.metadata.response.DerivedAssemblyResponseForNode;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStateResponse;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStatusTracker;
import com.ford.gvmsr.receiver.alarmevents.builder.ExceptionEventBuilder;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;

@Component
public class ExceptionEventGenerator {

    final ExceptionEventBuilder eventBuilder;
    final PropertiesConfig configuration;
    private final String A011_WarningDesc = "Node is missing in ODL for the Program code and Model Year";
    private final String A014_WarningDesc = "VIL Node network type not matched with IVS ODL node network type";
    private final ExceptionHandler exceptionHandler;

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public ExceptionEventGenerator(ExceptionEventBuilder eventBuilder, PropertiesConfig configuration,
	    ExceptionHandler exceptionHandler) {
	this.eventBuilder = eventBuilder;
	this.configuration = configuration;
	this.exceptionHandler = exceptionHandler;
    }

    public ExceptionEventTO prepareExceptionEvent(VilReceiverRequest request) throws JsonProcessingException {
	String vin = request.getVin();
	String traceId = request.getTraceId();
	DomainStateResponse stateResponse = request.getStateResponse();
	ExceptionEventTO exceptionEventTO = new ExceptionEventTO();
	List<ExceptionEventHeaderTO> exceptionEventList = new ArrayList<>();
	Map<String, DomainStatusTracker> domainStatusTrackerMap = stateResponse.getDomainStatusTracker();
	List<String> associateNodes = fetchAssociateNodes(domainStatusTrackerMap);
	domainStatusTrackerMap.forEach((nodeAddress, domainStatusTracker) -> {
	    if (!Objects.isNull(associateNodes) && !associateNodes.contains(nodeAddress))
		createExceptionEvents(request, exceptionEventList, nodeAddress, domainStatusTracker);
	});
	exceptionEventTO.setExceptionEventHeaderTOList(exceptionEventList);
	return exceptionEventTO;
    }

    private List<String> fetchAssociateNodes(Map<String, DomainStatusTracker> domainStatusTrackerMap) {
	List<String> associateNodeList = domainStatusTrackerMap.values().stream()
		.filter(domainStatusTracker -> !Objects.isNull(domainStatusTracker.getAssociatedNodes()))
		.map(DomainStatusTracker::getAssociatedNodes).filter(list -> list.size() > 0)
		.flatMap(Collection::stream).collect(Collectors.toList());
	log.info("associateNodeList - " + associateNodeList);
	return associateNodeList;
    }

    private void createExceptionEvents(VilReceiverRequest request, List<ExceptionEventHeaderTO> exceptionEventList,
	    String nodeAddress, DomainStatusTracker domainStatusTracker) {
	if (!domainStatusTracker.isNodePresentInODL()) {
	    insertExceptionEventHeaderToList(request, nodeAddress, ExceptionEventConstants.A011_EVENT_CODE,
		    A011_WarningDesc, exceptionEventList, domainStatusTracker.getPartNumberDidList());
	}
	if (!domainStatusTracker.isODLNetworkMatched()) {
	    insertExceptionEventHeaderToList(request, nodeAddress, ExceptionEventConstants.A014_EVENT_CODE,
		    A014_WarningDesc, exceptionEventList, domainStatusTracker.getPartNumberDidList());
	}
	DerivedAssemblyResponseForNode daResponseForNode = domainStatusTracker.getDerivedAssemblyResponseForNode();
	if (!domainStatusTracker.isDAPassed() && Objects.nonNull(daResponseForNode)
		&& daResponseForNode.getWarningText().isBlank()) {
	    insertExceptionEventHeaderToList(request, nodeAddress, ExceptionEventConstants.VL01_EVENT_CODE,
		    domainStatusTracker.getWarningMessage(), exceptionEventList,
		    domainStatusTracker.getPartNumberDidList());
	}
	if (Objects.nonNull(daResponseForNode) && Strings.isNotBlank(daResponseForNode.getFasWarningText())) {
	    insertExceptionEventHeaderToList(request, nodeAddress, ExceptionEventConstants.VL01_EVENT_CODE,
		    domainStatusTracker.getWarningMessage(), exceptionEventList,
		    domainStatusTracker.getPartNumberDidList());
	}
    }

    public void insertExceptionEventHeaderToList(VilReceiverRequest request, String address, String eventCode,
	    String desc, List<ExceptionEventHeaderTO> exceptionEventList, List<DIDInfo> partNumberDidList) {
	try {
	    ExceptionEventHeaderTO failureEvent = eventBuilder.createExceptionEventHeaderToObject(request, address,
		    eventCode, desc, partNumberDidList);
	    log.info("failure event, node={}, error={}", address, desc);
	    failureEvent.setTraceId(request.getTraceId());
	    exceptionEventList.add(failureEvent);
	} catch (Exception e) {
	    exceptionHandler.logException(e, this.getClass().getSimpleName());
	}
    }

}
