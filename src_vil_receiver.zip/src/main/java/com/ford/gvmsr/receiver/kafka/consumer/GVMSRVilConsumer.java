package com.ford.gvmsr.receiver.kafka.consumer;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Properties;
import java.util.UUID;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.splunk.KafkaLogEvent;
import com.ford.gvmsr.receiver.util.SplunkUtils;
import com.ford.gvmsr.receiver.verticle.EncodedVilProcessorVerticle;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.DeliveryOptions;
import io.vertx.kafka.client.common.TopicPartition;
import io.vertx.kafka.client.consumer.KafkaConsumer;
import io.vertx.kafka.client.consumer.KafkaConsumerRecord;

@Component
public class GVMSRVilConsumer extends AbstractVerticle {

    final EncodedVilProcessorVerticle vilService;
    final PropertiesConfig config;
    final SplunkUtils splunkUtils;
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    KafkaConsumer<String, String> consumer = null;

    public GVMSRVilConsumer(PropertiesConfig config, EncodedVilProcessorVerticle vilService, SplunkUtils splunkUtils) {
	this.config = config;
	this.vilService = vilService;
	this.splunkUtils = splunkUtils;
    }

    /**
     * Vert.x calls this method when deploying the instance. Method calls Kafka
     * consumer instance creation and subscription handler methods.
     **/
    @Override
    public void start() {
	consumer = registerKafkaVilConsumer();
	subscribeToVILTopic(config.getVilConsumerTopic());
    }

    /**
     * Create a new KafkaConsumer instance
     *
     * @return an instance of the KafkaConsumer
     */
    private KafkaConsumer<String, String> registerKafkaVilConsumer() {
	Properties props = new Properties();
	props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getVilKafkaBrokerEndpoints());
	props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
	props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
	props.put(ConsumerConfig.GROUP_ID_CONFIG, config.getVilConsumerGroup());
	props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, config.getVilOffsetResetMode());
	props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, config.getVilMaxPollRecords());
	props.put(ConsumerConfig.RETRY_BACKOFF_MS_CONFIG, config.getRetryBackOffInMs());
	props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, config.getAutoCommitIntervalInMs());
	props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, config.isVilAutoCommitOffset());
	props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, config.getVilProtocolConfig());
	return KafkaConsumer.create(vertx, props);
    }

    /**
     * Subscribe to the given topic to get dynamically assigned partitions.
     *
     * @param topic topic to subscribe to
     **/
    public void subscribeToVILTopic(String topic) {
	consumer.handler(event -> processKafkaMessage(consumer, event));
	consumer.subscribe(topic, handler -> {
	    if (handler.succeeded()) {
		log.debug("Subscribed {} successfully", topic);
	    }
	});
    }

    /**
     * consume and push request to Encoded Vil Message handler verticle through
     * EventBus
     *
     * @param consumer KafkaConsumer instance
     * @param record   Kafka consumer record
     */
    private void processKafkaMessage(KafkaConsumer<String, String> consumer,
	    KafkaConsumerRecord<String, String> record) {
	int partition = record.partition();
	Long offset = record.offset();
	String traceId = UUID.randomUUID().toString();
	try {
	    log.debug("VIL:received by partition = {}, offset = {}, traceId = {} ,active thread = {}", partition,
		    offset, traceId, Thread.activeCount());
	    DeliveryOptions deliveryOptions = new DeliveryOptions().addHeader(VilConstants.TRACE_ID_KEY, traceId)
		    .addHeader(VilConstants.PARTITION, String.valueOf(partition))
		    .addHeader(VilConstants.OFFSET, String.valueOf(offset));
	    pushToEncodedVilMessageHandler(record, consumer, deliveryOptions);
	} catch (Exception e) {
	    log.error("VIL:received exception at VilConsumer =" + e.getMessage());
	}
    }

    /**
     * consume and push request to VIL service class through EventBus
     *
     * @param consumer        KafkaConsumer instance
     * @param record          Kafka consumer record
     * @param deliveryOptions Delivery options are used to configure message
     *                        delivery
     */
    private void pushToEncodedVilMessageHandler(KafkaConsumerRecord<String, String> record,
	    KafkaConsumer<String, String> consumer, DeliveryOptions deliveryOptions) {
	vertx.eventBus().request(VilConstants.ENCODED_VIL_RECEIVER, record.value(), deliveryOptions, handler -> {
	    if (handler.succeeded()) {
		postKafkaLogEvent(record);
		Boolean isRequestProcessed = (Boolean) handler.result().body();
		log.debug("Is VIL Request pushed to Log-receiver = " + isRequestProcessed);
		if (isRequestProcessed) {
		    consumer.commit(event -> {
			if (event.succeeded()) {
			    log.info("Commit success - " + record.offset());
			}
		    });
		} else {
		    resetToLastCommittedPosition(consumer, record);
		}
	    } else {
		log.error("EventBus handler exception = ", handler.cause());
	    }
	});
    }

    /**
     * Retry failed messages until VIL kafka retry count reaches
     *
     * @param consumer KafkaConsumer instance
     * @param record   Kafka consumer record
     */
    private void resetToLastCommittedPosition(KafkaConsumer<String, String> consumer,
	    KafkaConsumerRecord<String, String> record) {
	log.info("Calling Kafka retry for hash =" + record.value().hashCode());
	String hashValue = String.valueOf(record.value().hashCode());
	if (MDC.get(hashValue) == null)
	    MDC.put(hashValue, String.valueOf(0L));
	int retryIndex = Integer.parseInt(MDC.get(hashValue));
	if (retryIndex < config.getVilKafkaRetryCount()) {
	    log.info("Kafka retry for hash = {}, retryIndex = {} ", hashValue, retryIndex);
	    seekConsumerOffset(consumer, record.topic(), record.partition(), record.offset());
	    MDC.put(hashValue, String.valueOf(retryIndex + 1));
	} else {
	    log.info("Seek consumer is done!!");
	    consumer.commit(event -> {
		if (event.succeeded()) {
		    log.info("Commit success after retry - " + record.offset());
		}
	    });
	    MDC.remove(hashValue);
	}
    }

    /**
     * Overrides the fetch offsets that the consumer will use on the next poll
     *
     * @param consumer  KafkaConsumer instance
     * @param topic     kafka topic name
     * @param partition partition index
     * @param offset    offset to seek inside the topic partition
     */
    private void seekConsumerOffset(KafkaConsumer<String, String> consumer, String topic, int partition, Long offset) {
	consumer.seek(new TopicPartition(topic, partition), offset,
		event -> log.info("Seek consumer to read=" + topic + " Partition=" + partition + " offset=" + offset));
    }

    private void postKafkaLogEvent(KafkaConsumerRecord<String, String> record) {
	log.info("ReOrderedVIL:received Published TS={}, Consumed TS={}, Partition = {}",
		Instant.ofEpochMilli(record.timestamp()).toString(), Instant.now().toString(), record.partition());
	KafkaLogEvent kafkaLogEvent = KafkaLogEvent.builder().vin(null)
		.consumedTime(new Timestamp(System.currentTimeMillis()).getTime()).producedTime(record.timestamp())
		.topic(record.topic()).partition(record.partition()).build();
	splunkUtils.pushSplunkLogEvent(kafkaLogEvent, VilConstants.KAFKA_MESSAGE_QUEUE_DELAY);
    }

    public KafkaConsumer<String, String> getVilConsumer() {
	return consumer;
    }
}