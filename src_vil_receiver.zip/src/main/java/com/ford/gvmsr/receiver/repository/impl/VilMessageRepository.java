package com.ford.gvmsr.receiver.repository.impl;

import java.sql.*;
import java.time.Instant;
import java.util.Optional;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.entity.VilMessage;
import com.ford.gvmsr.receiver.repository.IVilMessageRepository;

@Repository
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class VilMessageRepository implements IVilMessageRepository {
	static String findProcessedTimeById = "SELECT GVMR02_PRCS_STAT_S FROM PGVMR02_VIL_MSG_PRCS WHERE GVMR02_VIL_MSG_K = ?";
	static String findByIdQuery = "SELECT * FROM PGVMR02_VIL_MSG_PRCS WHERE GVMR02_VIL_MSG_K = ?";
	static String findByVinAndStatusQuery = "SELECT * FROM PGVMR02_VIL_MSG_PRCS WHERE GVMR02_PRCS_STAT_C IN ('TO_SNAP','CMP','PCMP') AND GVMR02_VIN_R = ? ORDER BY GVMR02_LAST_UPDT_S DESC OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY";
	static String updateStatusAndPartitionKeyByIdQuery = "UPDATE PGVMR02_VIL_MSG_PRCS SET GVMR02_PRCS_STAT_C = ?,GVMR02_GVMSR_PARTITION_R = ?,"
			+ "GVMR02_GVMSR_OFFSET_R = ?,GVMR02_LAST_UPDT_USER_C = ?, GVMR02_LAST_UPDT_S = ? where GVMR02_VIL_MSG_K = ?";
	static String updateStatusByIdQuery = "UPDATE PGVMR02_VIL_MSG_PRCS SET GVMR02_PRCS_STAT_C = ?, GVMR02_LAST_UPDT_USER_C = ?, GVMR02_LAST_UPDT_S = ? "
			+ "WHERE GVMR02_VIL_MSG_K = ?";
	static String insertVilMessageQuery = "INSERT INTO PGVMR02_VIL_MSG_PRCS(GVMR02_RTSA_PARTITION_R,GVMR02_RTSA_OFFSET_R,GVMR02_MSG_CAPTURE_S,GVMR02_VIN_R,GVMR02_VIL_MSG_L,GVMR02_PRCS_STAT_C,GVMR02_PRCS_STAT_S,GVMR02_TRACE_D,GVMR02_CREATE_USER_C,GVMR02_CREATE_S,GVMR02_LAST_UPDT_USER_C,GVMR02_LAST_UPDT_S) "
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private final JdbcTemplate jdbcTemplate;

	public VilMessageRepository(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public Optional<Timestamp> findProcessedTimeById(Long recordId) {
		try {
			Object[] param = new Object[] { recordId };
			return jdbcTemplate.queryForObject(findProcessedTimeById, param,
					(rs, rowNum) -> Optional.ofNullable(rs.getTimestamp(1)));
		} catch (EmptyResultDataAccessException e) {
			log.error("No record found in 02 table for recordId-{}", recordId);
		} catch (Exception e) {
			log.error("Exception while fetching from 02 table for recordId-{}, cause-{}", recordId, e);
		}
		return Optional.empty();
	}

	@Override
	public Optional<VilMessage> findById(Long recordId) {
		try {
			Object[] param = new Object[] { recordId };
			return jdbcTemplate.queryForObject(findByIdQuery, param,
					(rs, rowNum) -> Optional.ofNullable(mapVilMessageEntity(rs)));
		} catch (EmptyResultDataAccessException e) {
			log.error("No record found in 02 table for recordId-{}", recordId);
		} catch (Exception e) {
			log.error("Exception while fetching from 02 table for recordId-{}, cause-{}", recordId, e);
		}
		return Optional.empty();
	}

	@Override
	public int updatePartitionAndOffsetAndStatusById(String status, Integer kafkaPartition, Long kafkaOffset, String recordId) {
		Timestamp currentTimeStamp = Timestamp.from(Instant.now());
		return this.jdbcTemplate.update(updateStatusAndPartitionKeyByIdQuery, status, kafkaPartition,
				kafkaOffset, VilConstants.SOURCE_SYS_GVMSR, currentTimeStamp, recordId);
	}

	@Override
	public int updateStatusById(String status, long recordId) {
		Timestamp currentTimeStamp = Timestamp.from(Instant.now());
		return this.jdbcTemplate.update(updateStatusByIdQuery, status, VilConstants.SOURCE_SYS_GVMSR,
				currentTimeStamp, recordId);
	}

	@Override
	public long save(VilMessage vilMessage) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(connection -> getPreparedStatement(vilMessage, insertVilMessageQuery, connection),
				keyHolder);
		return keyHolder.getKey().longValue();
	}

	private PreparedStatement getPreparedStatement(VilMessage vilMessage, String insertIntoSql,
												   java.sql.Connection connection) throws SQLException {
		PreparedStatement ps = connection.prepareStatement(insertIntoSql, Statement.RETURN_GENERATED_KEYS);
		ps.setInt(1, vilMessage.getPartitionKeyRTSA());
		ps.setInt(2, vilMessage.getOffsetKeyRTSA());
		ps.setTimestamp(3, vilMessage.getMessageCapturedTime());
		ps.setString(4, vilMessage.getVin());
		ps.setString(5, vilMessage.getVilPayloadMessage());
		ps.setString(6, vilMessage.getStatus());
		ps.setTimestamp(7, vilMessage.getProcessedTime());
		ps.setString(8, vilMessage.getTraceId());
		ps.setString(9, vilMessage.getCreatedUser());
		ps.setTimestamp(10, vilMessage.getCreatedTime());
		ps.setString(11, vilMessage.getLastUpdatedUser());
		ps.setTimestamp(12, vilMessage.getLastUpdatedTime());
		return ps;
	}

	private VilMessage mapVilMessageEntity(ResultSet rs) throws SQLException {
		return VilMessage.builder().vilMessageId(rs.getLong("GVMR02_VIL_MSG_K"))
				.vilPayloadMessage(rs.getString("GVMR02_VIL_MSG_L")).traceId(rs.getString("GVMR02_TRACE_D"))
				.vin(rs.getString("GVMR02_VIN_R")).partitionKeyRTSA(rs.getInt("GVMR02_RTSA_PARTITION_R"))
				.offsetKeyRTSA(rs.getInt("GVMR02_RTSA_OFFSET_R"))
				.partitionKeyGVMSR(rs.getInt("GVMR02_GVMSR_PARTITION_R"))
				.offsetKeyGVMSR(rs.getInt("GVMR02_GVMSR_OFFSET_R")).createdTime(rs.getTimestamp("GVMR02_MSG_CAPTURE_S"))
				.messageCapturedTime(rs.getTimestamp("GVMR02_PRCS_STAT_S"))
				.processedTime(rs.getTimestamp("GVMR02_PRCS_STAT_S")).status(rs.getString("GVMR02_PRCS_STAT_C"))
				.build();
	}
}
