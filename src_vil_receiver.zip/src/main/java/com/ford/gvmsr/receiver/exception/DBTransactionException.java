package com.ford.gvmsr.receiver.exception;

public class DBTransactionException extends Exception {

    public DBTransactionException(String message) {
	super(message);
    }

}
