
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.*;
import com.ford.gvmsr.receiver.constant.VilConstants;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "vin", "timeStamp", "source", "role", "encryptedVIL", "return", "rawVIL", "log", "ePocheTimeStamp",
	"additionalprops" })
public class VilRequest {

    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @NotNull(message = "VIN should not be null")
    @NotEmpty(message = "VIN should not be empty")
    @Length(min = 17, max = 17, message = "Invalid VIN Length")
    @JsonProperty("vin")
    private String vin;

    @JsonProperty("timeStamp")
    private String timeStamp;

    @NotNull(message = "VIL - Source should not be null")
    @NotEmpty(message = "VIL - Source should not be empty")
    @JsonProperty("source")
    private String source;

    @JsonProperty("role")
    private String role;

    @JsonProperty("encryptedVIL")
    private String encryptedVIL;

    @NotEmpty(message = "VIL - Return_type should not be empty")
    @NotNull(message = "VIL - Return_type should not be null")
    @JsonProperty("return")
    private String _return;

    @JsonProperty("rawVIL")
    private String rawVIL;

    @JsonProperty("log")
    private Log log;

    @JsonProperty("ePocheTimeStamp")
    private String ePocheTimeStamp;

    @JsonProperty("additionalprops")
    private Additionalprops additionalprops;

    private String traceId;

    @JsonProperty("vin")
    public String getVin() {
	return vin;
    }

    @JsonProperty("vin")
    public void setVin(String vin) {
	this.vin = vin;
    }

    @JsonProperty("timeStamp")
    public String getTimeStamp() {
	return timeStamp;
    }

    @JsonProperty("timeStamp")
    public void setTimeStamp(String timeStamp) {
	this.timeStamp = timeStamp;
    }

    @JsonProperty("source")
    public String getSource() {
	return source;
    }

    @JsonProperty("source")
    public void setSource(String source) {
	this.source = source;
    }

    @JsonProperty("role")
    public String getRole() {
	return role;
    }

    @JsonProperty("role")
    public void setRole(String role) {
	this.role = role;
    }

    @JsonProperty("encryptedVIL")
    public String getEncryptedVIL() {
	return encryptedVIL;
    }

    @JsonProperty("encryptedVIL")
    public void setEncryptedVIL(String encryptedVIL) {
	this.encryptedVIL = encryptedVIL;
    }

    @JsonProperty("return")
    public String getReturn() {
	return _return;
    }

    @JsonProperty("return")
    public void setReturn(String _return) {
	this._return = _return;
    }

    /*
     * @JsonProperty("rawVIL") public RawVIL getRawVIL() { return rawVIL; }
     * 
     * @JsonProperty("rawVIL") public void setRawVIL(RawVIL rawVIL) { this.rawVIL =
     * rawVIL; }
     */

    @JsonProperty("rawVIL")
    public String getRawVIL() {
	return rawVIL;
    }

    public void setRawVIL(String rawVIL) {
	this.rawVIL = rawVIL;
    }

    @JsonProperty("log")
    public Log getLog() {
	return log;
    }

    @JsonProperty("log")
    public void setLog(Log log) {
	this.log = log;
    }

    @JsonProperty("ePocheTimeStamp")
    public String getEPocheTimeStamp() {
	return ePocheTimeStamp;
    }

    @JsonProperty("ePocheTimeStamp")
    public void setEPocheTimeStamp(String ePocheTimeStamp) {
	this.ePocheTimeStamp = ePocheTimeStamp;
    }

    @JsonProperty("additionalprops")
    public Additionalprops getAdditionalprops() {
	return additionalprops;
    }

    @JsonProperty("additionalprops")
    public void setAdditionalprops(Additionalprops additionalprops) {
	this.additionalprops = additionalprops;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
    }

    public String getTraceId() {
	return traceId;
    }

    public VilRequest setTraceId(String traceId) {
	this.traceId = traceId;
	return this;
    }

    @AssertTrue(message = "Invalid Return Type")
    public boolean isReturnTypeValid() {
	return (!_return.equalsIgnoreCase(VilConstants.RETURN_TYPE_VIL))
		|| _return.equalsIgnoreCase(VilConstants.RETURN_TYPE_VALIDATE)
		|| _return.equalsIgnoreCase(VilConstants.RETURN_TYPE_VALIDATE_AND_PROCESS);
    }

    @Override
    public String toString() {
        return "VilRequest{" +
                " vin='" + vin + '\'' +
                ", traceId='" + traceId + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", source='" + source + '\'' +
                ", role='" + role + '\'' +
                ", encryptedVIL='" + encryptedVIL + '\'' +
                ", _return='" + _return + '\'' +
                ", rawVIL='" + rawVIL + '\'' +
                ", log=" + log +
                ", ePocheTimeStamp='" + ePocheTimeStamp + '\'' +
                ", additionalprops=" + additionalprops +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}
