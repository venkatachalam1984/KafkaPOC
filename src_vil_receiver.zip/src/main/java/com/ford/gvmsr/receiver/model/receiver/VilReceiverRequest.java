package com.ford.gvmsr.receiver.model.receiver;

import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.domain.modulestate.metadata.request.IVSProgramId;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStateResponse;
import com.ford.gvmsr.receiver.model.request.Node;
import com.ford.gvmsr.receiver.model.request.VIL;
import com.ford.gvmsr.receiver.model.request.VilRequest;
import com.ford.gvmsr.receiver.model.response.Error;
import com.ford.gvmsr.receiver.util.JsonUtils;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.google.common.base.Strings;

public class VilReceiverRequest {
    private final VilRequest vilRequest;
    private final Set<String> applicationDIDs;
    private final List<Error> errorList = new ArrayList<>();
    private VIL vil;
    private String vin;
    private String rawVil;
    private String traceId;
    private String timeStamp;
    private DomainStateResponse stateResponse;
    private Map<String, String> invalidModuleNodeTypeList = new HashMap<>();
    private Map<String, String> iVSFNodesList = new HashMap<>();
    private IVSProgramId ivsProgramId;
    private Boolean isActiveRecordPresent;
    private Boolean retryVilFlagEnabled;
    private String retryRequestType;
    private long vilMessageRecordId;
    private List<String> retryAllowedNodesList;

    public VilReceiverRequest(VilRequest vilRequest, Set<String> applicationDIDs) {
	this.vilRequest = vilRequest;
	this.applicationDIDs = applicationDIDs;
	setRawVil(getVil());
    }

    public VilRequest getVilRequest() {
	return vilRequest;
    }

    public VIL getVil() {
	try {
	    if (Objects.isNull(vil)) {
		vil = JsonUtils.getChildObject(vilRequest, VIL.class, VilConstants.RAW_VIL);
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
	return vil;
    }

    public String getVin() {
	if (Strings.isNullOrEmpty(vin))
	    vin = vilRequest.getVin();
	return vin;
    }

    public String getTraceId() {
	if (Strings.isNullOrEmpty(traceId))
	    traceId = vilRequest.getTraceId();
	return traceId;
    }

    public String getTimeStamp() {
	if (Strings.isNullOrEmpty(timeStamp))
	    timeStamp = vilRequest.getEPocheTimeStamp();
	return timeStamp;
    }

    public Set<String> getApplicationDIDs() {
	return applicationDIDs;
    }

    public List<Error> getErrorList() {
	return errorList;
    }

    public DomainStateResponse getStateResponse() {
	return stateResponse;
    }

    public void setStateResponse(DomainStateResponse stateResponse) {
	this.stateResponse = stateResponse;
    }

    public Map<String, String> getInvalidModuleNodeTypeList() {
	return invalidModuleNodeTypeList;
    }

    public IVSProgramId getIvsProgramId() {
	return ivsProgramId;
    }

    public void setIvsProgramId(IVSProgramId ivsProgramId) {
	this.ivsProgramId = ivsProgramId;
    }

    public Boolean isActiveRecordPresent() {
        return isActiveRecordPresent;
    }

    public void setActiveRecordPresent(Boolean recordPresent) {
        isActiveRecordPresent = recordPresent;
    }

    public long getVilMessageRecordId() {
        return vilMessageRecordId;
    }

    public void setVilMessageRecordId(long vilMessageRecordId) {
        this.vilMessageRecordId = vilMessageRecordId;
    }

    public String getRawVil() {
        return rawVil;
    }

    public void setRawVil(VIL vil) {
	List<Node> nodes = vil.getNodes();
	try {
	    this.rawVil = JsonUtils.getJsonString(nodes);
	} catch (JsonProcessingException e) {
	    e.printStackTrace();
	}
    }

    public Boolean isRetryVilFlagEnabled() {
        return retryVilFlagEnabled;
    }

    public void setRetryVilFlagEnabled(Boolean retryVilFlagEnabled) {
        this.retryVilFlagEnabled = retryVilFlagEnabled;
    }

    public List<String> getRetryAllowedNodesList() {
        return retryAllowedNodesList;
    }

    public void setRetryAllowedNodesList(List<String> retryAllowedNodesList) {
        this.retryAllowedNodesList = retryAllowedNodesList;
    }

    public String getRetryRequestType() {
        return retryRequestType;
    }

    public void setRetryRequestType(String retryRequestType) {
        this.retryRequestType = retryRequestType;
    }

    public Map<String, String> getIVSFNodesList() {
        return iVSFNodesList;
    }

    public void setIVSFNodesList(Map<String, String> iVSFNodesList) {
        this.iVSFNodesList = iVSFNodesList;
    }
}
