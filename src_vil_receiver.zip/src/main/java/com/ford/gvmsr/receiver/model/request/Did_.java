
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "didFormat",
    "didValue",
    "decodedResponse",
    "isConfig",
    "rawResponse",
    "decodedresponse"
})
public class Did_ {

    @JsonProperty("didFormat")
    private String didFormat;
    @JsonProperty("didValue")
    private String didValue;
    @JsonProperty("decodedResponse")
    private String decodedResponse;
    @JsonProperty("isConfig")
    private String isConfig;
    @JsonProperty("rawResponse")
    private String rawResponse;
    @JsonProperty("decodedresponse")
    private String decodedresponse;
    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("didFormat")
    public String getDidFormat() {
        return didFormat;
    }

    @JsonProperty("didFormat")
    public void setDidFormat(String didFormat) {
        this.didFormat = didFormat;
    }

    @JsonProperty("didValue")
    public String getDidValue() {
        return didValue;
    }

    @JsonProperty("didValue")
    public void setDidValue(String didValue) {
        this.didValue = didValue;
    }

    @JsonProperty("decodedResponse")
    public String getDecodedResponse() {
        return decodedResponse;
    }

    @JsonProperty("decodedResponse")
    public void setDecodedResponse(String decodedResponse) {
        this.decodedResponse = decodedResponse;
    }

    @JsonProperty("isConfig")
    public String getIsConfig() {
        return isConfig;
    }

    @JsonProperty("isConfig")
    public void setIsConfig(String isConfig) {
        this.isConfig = isConfig;
    }

    @JsonProperty("rawResponse")
    public String getRawResponse() {
        return rawResponse;
    }

    @JsonProperty("rawResponse")
    public void setRawResponse(String rawResponse) {
        this.rawResponse = rawResponse;
    }

    @JsonProperty("decodedresponse")
    public String getDecodedresponse() {
        return decodedresponse;
    }

    @JsonProperty("decodedresponse")
    public void setDecodedresponse(String decodedresponse) {
        this.decodedresponse = decodedresponse;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
