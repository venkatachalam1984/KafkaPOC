package com.ford.gvmsr.receiver.entity;

import java.sql.Timestamp;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FailedVILMessage {
    private Long id;
    private byte[] vilMessage;
    private String createdUser;
    private Timestamp createdTime;
}
