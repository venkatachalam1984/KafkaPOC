package com.ford.gvmsr.receiver.constant;

/**
 * Validation Enumeration.
 */
public enum VilValidationSourceEnum {
    VIL_HISTORY_VALIDATOR,
    VIL_DUPLICATION_VALIDATOR,
    VIL_CONSTRAINT_VALIDATOR,
    RAW_VIL_CONSTRAINT_VALIDATOR,
    VIL_REDUNDANT_VALIDATOR,
    VIL_RULE_VALIDATOR
}
