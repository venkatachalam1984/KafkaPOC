package com.ford.gvmsr.receiver.config;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.domain.modulestate.model.response.DomainStateResponse;
import com.ford.gvmsr.receiver.controller.VilReceiverController;
import com.ford.gvmsr.receiver.kafka.consumer.GVMSRVilConsumer;
import com.ford.gvmsr.receiver.kafka.consumer.ReOrderedVilConsumer;
import com.ford.gvmsr.receiver.kafka.producer.DownStreamMessageProducer;
import com.ford.gvmsr.receiver.kafka.producer.KafkaMessageProducer;
import com.ford.gvmsr.receiver.metrics.KafkaPartitionTopicLagMetricsHandler;
import com.ford.gvmsr.receiver.metrics.VertxMetricsHandler;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.retry.VilRetryRequest;
import com.ford.gvmsr.receiver.serialize.GenericCodec;
import com.ford.gvmsr.receiver.validator.VilValidationHandler;
import com.ford.gvmsr.receiver.verticle.*;

import io.vertx.core.DeploymentOptions;
import io.vertx.core.Verticle;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.ext.dropwizard.DropwizardMetricsOptions;

@Component
public class VerticleDeployerConfiguration {

    final RetryVilValidationVerticle retryVilValidationVerticle;
    final IVSExceptionEventHandler exceptionEventHandler;
    final GVMSRVilConsumer vilConsumer;
    final EncodedVilProcessorVerticle encodedVilProcessor;
    final KafkaMessageProducer kafkaMessageProducer;
    final ReOrderedVilConsumer reOrderedVilConsumer;
    final VilValidationHandler vilValidationHandler;
    final PropertiesConfig configuration;
    final VertxMetricsHandler vertxMetricsHandler;
    final KafkaPartitionTopicLagMetricsHandler kafkaConsumerLagHandler;
    final DownStreamMessageProducer downStreamMessageProducer;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private Vertx vertx = null;

    public VerticleDeployerConfiguration(GVMSRVilConsumer vilConsumer, VilValidationHandler vilValidationHandler,
	    ReOrderedVilConsumer reOrderedVilConsumer, EncodedVilProcessorVerticle encodedVilProcessor,
	    KafkaMessageProducer KafkaMessageProducer, PropertiesConfig configuration,
	    IVSExceptionEventHandler exceptionEventHandler, DownStreamMessageProducer downStreamMessageProducer,
	    KafkaPartitionTopicLagMetricsHandler kafkaConsumerLagHandler, VertxMetricsHandler vertxMetricsHandler,
	    RetryVilValidationVerticle retryVilValidationVerticle) {
	this.configuration = configuration;
	this.vilConsumer = vilConsumer;
	this.encodedVilProcessor = encodedVilProcessor;
	this.kafkaMessageProducer = KafkaMessageProducer;
	this.reOrderedVilConsumer = reOrderedVilConsumer;
	this.vilValidationHandler = vilValidationHandler;
	this.exceptionEventHandler = exceptionEventHandler;
	this.kafkaConsumerLagHandler = kafkaConsumerLagHandler;
	this.vertxMetricsHandler = vertxMetricsHandler;
	this.downStreamMessageProducer = downStreamMessageProducer;
	this.retryVilValidationVerticle = retryVilValidationVerticle;
    }

    @EventListener({ ApplicationReadyEvent.class })
    public void deployVilReceiverVerticles() {
	log.info("Active thread count before verticle deployment - " + Thread.activeCount());
	vertx = Vertx.vertx(prepareVertxConfig());
	deployStandardVerticles();
	deployWorkerVerticles();
	registerMessageCodec();
	registerVertxExceptionHandler();
	log.info("Active thread count after verticle deployment - " + Thread.activeCount());
    }

    public void deployStandardVerticles() {
	deployVerticle(vilConsumer);
	deployVerticle(reOrderedVilConsumer);
	deployVerticle(kafkaMessageProducer);
	deployVerticle(downStreamMessageProducer);
	deployVerticle(vertxMetricsHandler);
	deployVerticle(kafkaConsumerLagHandler);
	deployVerticle(retryVilValidationVerticle);
	deployVerticleWithClassName(VilReceiverController.class.getCanonicalName(),
		configuration.getVertxControllerInstanceCount());
    }

    private void deployWorkerVerticles() {
	deployEncodedVilProcessorWorkers();
	deployLogRequestValidationWorkers();
	deployDomainStateValidationWorkers();
	deployDomainStateResponseWorkers();
	deployModuleStateObserverWorkers();
	deployIVSExceptionEventWorkers();
    }

    private void registerMessageCodec() {
	vertx.eventBus().registerDefaultCodec(DomainStateResponse.class, new GenericCodec<>(DomainStateResponse.class));
	vertx.eventBus().registerDefaultCodec(VilReceiverRequest.class, new GenericCodec<>(VilReceiverRequest.class));
	vertx.eventBus().registerDefaultCodec(VilRetryRequest.class, new GenericCodec<>(VilRetryRequest.class));
    }

    private void deployEncodedVilProcessorWorkers() {
	deployWorkerVerticle(encodedVilProcessor, new DeploymentOptions().setWorker(true)
		.setWorkerPoolSize(configuration.getWorkerVerticleCount()).setWorkerPoolName("enc-wr"));
    }

    private void deployLogRequestValidationWorkers() {
	for (int i = 0; i < configuration.getWorkerVerticleCount(); i++) {
	    deployWorkerVerticle(new LogRequestValidationHandler(i),
		    new DeploymentOptions().setWorker(true).setWorkerPoolSize(1).setWorkerPoolName("vv-wr-" + i));
	}
    }

    private void deployDomainStateValidationWorkers() {
	for (int i = 0; i < configuration.getWorkerVerticleCount(); i++) {
	    deployWorkerVerticle(new ModuleStateValidationReqHandler(i),
		    new DeploymentOptions().setWorker(true).setWorkerPoolSize(1).setWorkerPoolName("dv-wr-" + i));
	}
    }

    private void deployDomainStateResponseWorkers() {
	for (int i = 0; i < configuration.getWorkerVerticleCount(); i++) {
	    deployWorkerVerticle(new ModuleStateValidationRespHandler(i),
		    new DeploymentOptions().setWorker(true).setWorkerPoolSize(1).setWorkerPoolName("dvr-wr-" + i));
	}
    }

    private void deployModuleStateObserverWorkers() {
	for (int i = 0; i < configuration.getWorkerVerticleCount(); i++) {
	    deployWorkerVerticle(new ModuleStateObserverReqHandler(i),
		    new DeploymentOptions().setWorker(true).setWorkerPoolSize(1).setWorkerPoolName("so-wr-" + i));
	}
    }

    private void deployIVSExceptionEventWorkers() {
	deployWorkerVerticle(exceptionEventHandler, new DeploymentOptions().setWorker(true)
		.setWorkerPoolSize(configuration.getWorkerVerticleCount()).setWorkerPoolName("exception_event_worker"));
    }

    public VertxOptions prepareVertxConfig() {
	VertxOptions options = new VertxOptions();
	DropwizardMetricsOptions metricsOptions = new DropwizardMetricsOptions();
	metricsOptions.setEnabled(true);
	options.setMetricsOptions(metricsOptions);
	options.setMaxEventLoopExecuteTime(configuration.getVertxEventLoopExecutionTimeInSecs());
	options.setMaxEventLoopExecuteTimeUnit(TimeUnit.SECONDS);
	options.setMaxWorkerExecuteTime(configuration.getVertxWorkerExecutionTimeInSecs());
	options.setMaxWorkerExecuteTimeUnit(TimeUnit.SECONDS);
	options.setBlockedThreadCheckInterval(configuration.getThreadBlockedCheckInterval());
	options.setBlockedThreadCheckIntervalUnit(TimeUnit.SECONDS);
	options.setWarningExceptionTime(configuration.getVertxThreadExecutionLimit());
	options.setWarningExceptionTimeUnit(TimeUnit.SECONDS);
	return options;
    }

    /**
     * Deploy a verticle instance that have created by spring ApplicationContext
     * class. Vert.x will assign the verticle a context and start the verticle. If
     * the deployment of vert.x instance is successful the handler will be printing
     * deployed class name.
     *
     * @param verticle the verticle instance to deploy
     */
    private void deployVerticle(Verticle verticle) {
	final String name = verticle.getClass().getCanonicalName();
	vertx.deployVerticle(verticle, completionHandler -> {
	    if (completionHandler.failed()) {
		log.error("Failed to deploy verticle = {}, Cause = {}", name, completionHandler.cause());
	    } else {
		log.debug("Deployed verticle = " + name);
	    }
	});
    }

    private void deployVerticleWithClassName(String className, int instanceCount) {
	vertx.deployVerticle(className, new DeploymentOptions().setInstances(instanceCount), completionHandler -> {
	    if (completionHandler.failed()) {
		log.error("Failed to deploy verticle = {}, Cause = {}", className, completionHandler.cause());
	    } else {
		log.debug("Deployed verticle = " + className);
	    }
	});
    }

    /**
     * Like {@link #deployVerticle(Verticle)} but DeploymentOptions are provided to
     * configure the worker verticle options.
     *
     * @param verticle the verticle instance to deploy
     * @param options  the deployment options.
     */
    private void deployWorkerVerticle(Verticle verticle, DeploymentOptions options) {
	final String name = verticle.getClass().getCanonicalName();
	vertx.deployVerticle(verticle, options, completionHandler -> {
	    if (completionHandler.failed()) {
		log.error("Failed to deploy worker verticle = {}, Reason = {}", name, completionHandler.cause());
		System.exit(1);
	    } else {
		log.debug("Deployed worker verticle = " + name);
	    }
	});
    }

    private void registerVertxExceptionHandler() {
	vertx.exceptionHandler(exception -> {
	    log.error("Global:Exception-" + exception.getCause().getMessage());
	});
    }
}
