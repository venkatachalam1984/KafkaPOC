package com.ford.gvmsr.receiver.builder;

import java.sql.Timestamp;
import java.time.Instant;

import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.entity.FailedVILMessage;
import com.ford.gvmsr.receiver.entity.VilMessage;
import com.ford.gvmsr.receiver.entity.VilMessageNodeIVSFError;
import com.ford.gvmsr.receiver.entity.VilMessageNodeStatus;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.util.VilUtils;

public class DBEntityBuilder {

    public static VilMessage buildPayloadEntity(String request, String traceId, String vin, String partitionKeyRTSA,
												String offsetKeyRTSA, Timestamp vilTimestamp) {
	Timestamp currentTimeStamp = Timestamp.from(Instant.now());
	VilMessage vilMessage = VilMessage.builder().vilPayloadMessage(request).traceId(traceId).vin(vin)
		.partitionKeyRTSA(Integer.valueOf(partitionKeyRTSA)).offsetKeyRTSA(Integer.valueOf(offsetKeyRTSA))
		.createdTime(currentTimeStamp).messageCapturedTime(vilTimestamp).processedTime(currentTimeStamp)
		.status(VilConstants.NEW_VIL).createdUser(VilConstants.SOURCE_SYS_GVMSR)
		.lastUpdatedUser(VilConstants.SOURCE_SYS_GVMSR).lastUpdatedTime(currentTimeStamp).build();
	return vilMessage;
    }

    public static VilMessageNodeStatus buildPayloadNodeStatusEntity(String nodeAddress, long vilMessageId,
	    String status) {
	Timestamp currentTimeStamp = Timestamp.from(Instant.now());
	VilMessageNodeStatus messageNodeStatus = VilMessageNodeStatus.builder().nodeAddress(nodeAddress)
		.vilMessageId(vilMessageId).status(status).capturedTime(currentTimeStamp).createdTime(currentTimeStamp)
		.createdUser(VilConstants.SOURCE_SYS_GVMSR).lastUpdatedUser(VilConstants.SOURCE_SYS_GVMSR)
		.lastUpdatedTime(currentTimeStamp).build();
	return messageNodeStatus;
    }

    public static VilMessageNodeIVSFError buildIVSFMessageNodeErrorEntity(String nodeAddress,
	    VilReceiverRequest request, String status, int ivsXmlVersion) {
	Timestamp currentTimeStamp = Timestamp.from(Instant.now());
	VilMessageNodeIVSFError messageNodeIVSFError = VilMessageNodeIVSFError.builder()
		.vilMessageId(request.getVilMessageRecordId()).vin(request.getVin())
		.vinHash(VilUtils.getVinHashKey(request.getVin()))
		.programCode(request.getIvsProgramId().getProgramCode())
		.salesModelYear(request.getIvsProgramId().getSalesModelYear()).retryCount(0)
		.processXmlVersion(ivsXmlVersion).nodeAddress(nodeAddress).status(status).capturedTime(currentTimeStamp)
		.createdTime(currentTimeStamp).createdUser(VilConstants.SOURCE_SYS_GVMSR)
		.lastUpdatedUser(VilConstants.SOURCE_SYS_GVMSR).lastUpdatedTime(currentTimeStamp).build();
	return messageNodeIVSFError;
    }

    public static FailedVILMessage buildFailedVILMessageEntity(String encodedPayload) {
	Timestamp currentTimeStamp = Timestamp.from(Instant.now());
	FailedVILMessage failedVILMessage = FailedVILMessage.builder().vilMessage(encodedPayload.getBytes())
		.createdUser(VilConstants.SOURCE_SYS_GVMSR).createdTime(currentTimeStamp).build();
	return failedVILMessage;
    }

}
