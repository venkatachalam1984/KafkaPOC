package com.ford.gvmsr.receiver.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.Did;
import com.ford.gvmsr.receiver.model.request.Node;
import com.ford.gvmsr.receiver.model.request.VIL;
import com.ford.gvmsr.receiver.util.ASCIIConverter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Set;

public class VilRuleValidator extends BaseValidator {

    private final Logger log = LoggerFactory.getLogger(VilRuleValidator.class);

    public Set<String> applicationDids = null;

    public VilRuleValidator(BaseValidator next) {
	super(next);
    }

    /**
     * Find the blank dids from the nodes and fill the did value, decodeResponse
     * from the rawResponse, in case of positive response else error will be set
     *
	 * @param nodes List of VIL Nodes
	 * @param request
	 *
     **/
	public void populateBlankNodesDid(List<Node> nodes, VilReceiverRequest request) {
		try {
			for (Node node : nodes) {
				if (!request.isRetryVilFlagEnabled() || request.getRetryAllowedNodesList().contains(node.getAddress())) {
					populateBlankNodeDid(node);
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		log.debug("After populate blank dids ==> " + nodes);
	}

    /**
     * Find the blank did from the given node and fill the did value, decoded
     * response if required, in case of positive response else error response
     *
     * @param node List of VIL nodes
     * @throws Exception
     */
    public void populateBlankNodeDid(Node node) {
	List<Did> didArray = node.getDid();
	populateBlankDids(didArray);
    }

    /**
     * Find and fill the blank dids, set did value and decode response based on
     * rawResponse, in case of positive response else error will be set
     *
     * @param didArray
     */
    public void populateBlankDids(List<Did> didArray) {
	try {
	    for (Did did : didArray) {
		// added changes for VIL application dids
		checkAndFormatApplicationDid(did);
		populateBlankDid(did);
	    }
	} catch (Exception exception) {
	    exception.printStackTrace();
	}
    }

    /**
     * Find and fill the blank did, set did value and decode response based on
     * rawResponse, in case of positive response else error will be set
     *
     * @param did
     */
    public void populateBlankDid(Did did) {
	try {
	    if (did != null) {

		// If didvalue, decodedresponse and rawresponse are blank
		if (isEmptyDid(did)) {
		    did.setError(VilConstants.DID_RESPONSE_PARSING_ERROR);
		    did.setIsValidationSuccessful("false");
		    did.setValidationFailReason("Empty Did Found");
		    return;
		}

		String didValue = did.getDidValue();
		String didDecodedResponse = did.getDecodedResponse();
		String didRawResponse = did.getRawResponse();

		// Case 1: The specific “DID” attribute is blank but positive response is
		// available
		if (StringUtils.isBlank(didValue)) {
		    String responseType = getResponseType(didRawResponse);
		    if (!isValidResponseType(responseType)) {
			did.setError(VilConstants.DID_RESPONSE_PARSING_ERROR);
			did.setIsValidationSuccessful("false");
			did.setValidationFailReason("Invalid Response Type!");
			return;
		    }

		    // Proceed with positive response type - 62 & 71
		    if (!responseType.equalsIgnoreCase(VilConstants.NEGATIVE_RESPONSE_7F)) {
			String didNumber = getDidValueFromRawResponse(responseType, didRawResponse);
			if (StringUtils.isNotBlank(didNumber)) {
			    did.setDidValue(didNumber);
			} else {
			    did.setError(VilConstants.DID_RESPONSE_PARSING_ERROR);
			    did.setIsValidationSuccessful("false");
			    did.setValidationFailReason("Did Value formation error!");
			}
		    }
		}

		// Case 2: The decoded response is blank but there is no error reported and
		// there is a positive response
		if (StringUtils.isBlank(didDecodedResponse)) {
		    String responseType = getResponseType(didRawResponse);
		    // Proceed with positive response type - 62 & 71
		    if (responseType != null && !responseType.equalsIgnoreCase(VilConstants.NEGATIVE_RESPONSE_7F)) {
			String decodedResponse = getDecodedResponseFromRawResponse(responseType, didRawResponse);
			if (StringUtils.isNotBlank(decodedResponse)) {
			    try {
				did.setDecodedResponse(ASCIIConverter.convertHexToString(decodedResponse));
				did.setIsValidationSuccessful("true");
				// added change for VIL
				checkAndFormatApplicationDid(did);
				if (StringUtils.isEmpty(did.getDecodedResponse())) {
				    did.setError(VilConstants.DID_RESPONSE_INVALID_CHAR_ERROR);
				    did.setIsValidationSuccessful("false");
				    did.setValidationFailReason("Decoded Response having Invalid characters");
				}
			    } catch (Exception exception) {
				exception.printStackTrace();
				did.setError(VilConstants.DID_RESPONSE_PARSING_ERROR);
				did.setIsValidationSuccessful("false");
				did.setValidationFailReason(exception.getMessage());
			    }
			} else {
			    did.setError(VilConstants.DID_RESPONSE_PARSING_ERROR);
			    did.setIsValidationSuccessful("false");
			    did.setValidationFailReason("Decoded Response formation error!");
			}

		    }
		}
	    }
	} catch (Exception ex) {
	    ex.printStackTrace();
	    did.setError(ex.getMessage());
	    did.setIsValidationSuccessful("false");
	}
    }

    /**
     * Find whether the given response type is valid or not
     *
     * @param responseType
     * @return
     */
    private Boolean isValidResponseType(String responseType) {
	boolean isValid = Boolean.TRUE;
	if (StringUtils.isBlank(responseType) || !(responseType.equalsIgnoreCase(VilConstants.POSITIVE_RESPONSE_62)
		|| responseType.equalsIgnoreCase(VilConstants.POSITIVE_RESPONSE_71)
		|| responseType.equalsIgnoreCase(VilConstants.NEGATIVE_RESPONSE_7F))) {
	    isValid = Boolean.FALSE;
	}
	return isValid;
    }

    /**
     * Gives the Response type from the given raw response
     *
     * @param rawResponse
     * @return
     */
    private String getResponseType(String rawResponse) {
	String response = null;
	if (rawResponse.length() > 2) {
	    response = rawResponse.substring(0, 2); // Response type 62-positive response
	}
	return response;
    }

    /**
     * Get Did Value from the given Raw Response
     *
     * @param responseType
     * @param rawResponse
     * @return
     */
    private String getDidValueFromRawResponse(String responseType, String rawResponse) {

	String didValue = null;

	if (responseType != null && rawResponse != null) {

	    if (responseType.equalsIgnoreCase(VilConstants.POSITIVE_RESPONSE_62)) {
		if (rawResponse.length() > 7) {
		    didValue = rawResponse.substring(2, 6); // Did Number
		}
	    } else if (responseType.equalsIgnoreCase(VilConstants.POSITIVE_RESPONSE_71)) {
		if (rawResponse.length() > 18) {
		    didValue = rawResponse.substring(14, 18); // Did Number
		}
	    }
	}

	return didValue;
    }

    /**
     * Get Decoded Response from the given Raw Response
     *
     * @param responseType
     * @param rawResponse
     * @return
     */
    private String getDecodedResponseFromRawResponse(String responseType, String rawResponse) {

	String decodedResponse = null;

	if (responseType != null && rawResponse != null) {

	    if (responseType.equalsIgnoreCase(VilConstants.POSITIVE_RESPONSE_62)) {
		if (rawResponse.length() > 7) {
		    decodedResponse = rawResponse.substring(6); // decodedResponse
		}
	    } else if (responseType.equalsIgnoreCase(VilConstants.POSITIVE_RESPONSE_71)) {
		if (rawResponse.length() > 18) {
		    decodedResponse = rawResponse.substring(18); // decodedResponse
		}
	    }
	}

	return decodedResponse;
    }

    /**
     * Find the given did is empty or not
     *
     * @param did
     * @return
     */
    public boolean isEmptyDid(Did did) {

	return did != null && (StringUtils.isBlank(did.getDidValue()) && StringUtils.isBlank(did.getDecodedResponse())
		&& StringUtils.isBlank(did.getRawResponse()));
    }

    // added changes for VIL application dids
    private void populateFixedLenghDidResponse(Did did) {
	String didResponse = did.getDecodedResponse();
	int noOfBytes = 24;
	int itrCount = 1;
	StringBuilder disResBuilder = new StringBuilder();

	String[] appDidRespArray = didResponse.split(",");
	for (String didResp : appDidRespArray) {
	    if (itrCount < appDidRespArray.length) {
		disResBuilder.append(padRightSpaces(didResp, noOfBytes));
	    } else {
		disResBuilder.append(didResp);
	    }
	    itrCount += 1;
	}
	did.setDecodedResponse(disResBuilder.toString());
    }

    private String padRightSpaces(String inputString, int noOfBytes) {
	if (inputString.length() >= noOfBytes) {
	    return inputString;
	}
	StringBuilder sb = new StringBuilder();
	while (sb.length() < noOfBytes - inputString.length()) {
	    sb.append(' ');
	}
	return inputString.concat(sb.toString());
    }

    private void checkAndFormatApplicationDid(Did did) {
	if (applicationDids.contains(did.getDidValue()) && StringUtils.isNotBlank(did.getDecodedResponse())) {
	    if (did.getDecodedResponse().contains(",")) {
		populateFixedLenghDidResponse(did);
	    }
	}
    }

    @Override
    public void handleRequest(VilValidationSourceEnum validationSource, VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	if (VilValidationSourceEnum.VIL_RULE_VALIDATOR == validationSource) {
	    validate(receiverRequest);
	} else {
	    super.handleRequest(validationSource, receiverRequest);
	}
    }

    public void validate(VilReceiverRequest request) throws VILValidationException {
	log.info("VilRuleValidator received req - VIN:" + request.getVin());
	this.applicationDids = request.getApplicationDIDs();
	if (applicationDids == null || applicationDids.isEmpty()) {
	    throw new VILValidationException("Application DID list is empty");
	}
	VIL vil = request.getVil();
	populateBlankNodesDid(vil.getNodes(), request);
	log.info(request.getVin() + ": validated by VilRuleValidator");
    }

}
