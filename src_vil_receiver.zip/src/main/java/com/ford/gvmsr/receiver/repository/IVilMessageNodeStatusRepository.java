package com.ford.gvmsr.receiver.repository;

import com.ford.gvmsr.receiver.entity.VilMessageNodeStatus;

import java.util.List;

public interface IVilMessageNodeStatusRepository {
    void saveAll(List<VilMessageNodeStatus> payloadNodeStatusList);
}
