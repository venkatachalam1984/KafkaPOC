package com.ford.gvmsr.receiver.model.vinreceiver;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class VinReceiverRequest {
    private String vin;
    private String traceId;
}
