package com.ford.gvmsr.receiver.builder;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ford.gvmsr.receiver.constant.VilConstants;

import java.sql.Timestamp;

@Component
public class DownStreamSyncUpBuilder {
    public static String build(String vin, String traceId, String vilPayloadJson, String vilTimeSTamp)
	    throws JsonProcessingException {
	ObjectMapper mapper = new ObjectMapper();
	ObjectNode rootNode = mapper.createObjectNode();
	rootNode.put(VilConstants.VIN_KEY, vin);
	rootNode.put(VilConstants.TRACE_ID_KEY, traceId);
	rootNode.put(VilConstants.RAW_VIL_KEY, vilPayloadJson);
	Timestamp vilTimestamp = new Timestamp(Long.parseLong(vilTimeSTamp) * 1000L);
	rootNode.put(VilConstants.TIMESTAMP_KEY, vilTimestamp.toString());
	String downStreamEventJson = mapper.writeValueAsString(rootNode);
	return downStreamEventJson;
    }
}
