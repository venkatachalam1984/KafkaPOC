package com.ford.gvmsr.receiver.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.domain.modulestate.metadata.redis.RedisKeyHelper;
import com.ford.gvmsr.domain.modulestate.metadata.redis.RedisSchema;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.util.BeanUtil;

public class VilHistoryValidator extends BaseValidator {

    private final Logger log = LoggerFactory.getLogger(VilHistoryValidator.class);
    RedisSchema redisSchema;
    RedisKeyHelper redisKeyHelper;
    PropertiesConfig properties;

    public VilHistoryValidator(BaseValidator next) {
	super(next);
    }

    public boolean checkIsLatestVIL(String vin, String timestamp) {
	if (properties.isCacheEnabled() && properties.isRedisCacheEnabledForVIL()) {
	    long currentVILTS = Long.parseLong(timestamp);
	    String key = redisKeyHelper.generateVILProcessedTSCacheKey(vin);
	    long vilTimeStampFromRedis = getVILProcessedTSFromRedis(key);
	    log.info("vin={}, vilTimeStampFromRedis={} ", vin, vilTimeStampFromRedis);
		return currentVILTS >= vilTimeStampFromRedis;
	}
	return true;
    }

    private long getVILProcessedTSFromRedis(String key) {
	String value = redisSchema.find(key);
	return value != null && !value.isEmpty() ? Long.parseLong(value) : 0L;
    }

    @Override
    public void validate(final VilReceiverRequest request)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	initializeBeansByApplicationContext();
	boolean isLatestVIL = checkIsLatestVIL(request.getVin(), request.getTimeStamp());
	log.info("Is VIL latest =" + isLatestVIL);
	if (!isLatestVIL)
	    throw new LateVILException("Received Late VIN -" + request.getVin());
    }

    @Override
    public void handleRequest(VilValidationSourceEnum validationSource, VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	if (VilValidationSourceEnum.VIL_HISTORY_VALIDATOR == validationSource) {
	    log.info("VilHistoryValidator Request received - " + receiverRequest.getVin());
	    validate(receiverRequest);
	    log.info(receiverRequest.getVin() + ": validated by VilHistoryValidator");
	} else {
	    super.handleRequest(validationSource, receiverRequest);
	}
    }

    void initializeBeansByApplicationContext() {
	redisSchema = BeanUtil.getBean(redisSchema, RedisSchema.class);
	redisKeyHelper = BeanUtil.getBean(redisKeyHelper, RedisKeyHelper.class);
	properties = BeanUtil.getBean(properties, PropertiesConfig.class);
    }
}
