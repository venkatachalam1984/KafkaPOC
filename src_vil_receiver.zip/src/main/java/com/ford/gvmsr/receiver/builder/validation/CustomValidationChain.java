package com.ford.gvmsr.receiver.builder.validation;

import org.springframework.stereotype.Component;

import com.ford.gvmsr.domain.modulestate.model.request.ModuleStateRequest;

@Component
public class CustomValidationChain {

    public Boolean validate(ModuleStateRequest moduleStateRequest) {
	return false;
    }

}
