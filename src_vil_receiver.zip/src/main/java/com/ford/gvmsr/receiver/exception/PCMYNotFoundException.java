package com.ford.gvmsr.receiver.exception;

public class PCMYNotFoundException extends Exception {

    public PCMYNotFoundException(String message) {
	super(message);
    }

}
