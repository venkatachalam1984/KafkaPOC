package com.ford.gvmsr.receiver.splunk;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.util.JsonUtils;
import com.ford.gvmsr.receiver.util.VilUtils;

@Component
public class SplunkEventSender {

    private final Logger logger = LoggerFactory.getLogger(SplunkEventSender.class);
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${splunk.hec.token}")
    private String hec_token;
    @Value("${splunk.hec.url}")
    private String hec_qa_url;

    public static String getHost() {
	try {
	    return InetAddress.getLocalHost().getHostName();
	} catch (UnknownHostException e) {
	    e.printStackTrace();
	}
	return null;
    }

    @Bean(name = "hecPostExecutor")
    public Executor hecPostExecutor() {
	ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	executor.setCorePoolSize(15);
	executor.setMaxPoolSize(25);
	executor.setQueueCapacity(1000);
	executor.afterPropertiesSet();
	executor.initialize();
	return executor;
    }

    @Async("hecPostExecutor")
    public void postToHEC(String appLogEvent, String source, String sourceType) throws JsonProcessingException {
	SplunkLogEvent splunkLogEvent = SplunkLogEvent.builder().host(getHost()).source(source).sourcetype(sourceType)
		.event(appLogEvent).time(String.valueOf(VilUtils.getCurrentTimeStamp())).build();
	String eventLogToPost = JsonUtils.getJsonString(splunkLogEvent);
	try {
	    HttpHeaders headers = new HttpHeaders();
	    headers.add("Authorization", "Splunk " + hec_token);
	    HttpEntity<String> entity = new HttpEntity<>(eventLogToPost, headers);
	    ResponseEntity<String> resp = restTemplate.postForEntity(hec_qa_url, entity, String.class);
	    JsonNode responseNode = objectMapper.readTree(resp.getBody());
	    String resMsg = responseNode.get("text").asText();
	    if (!resMsg.equalsIgnoreCase(VilConstants.VIL_TO_HEC_SPLUNK_SUCCESS)) {
		logger.info("Splunk HEC Response MSG : " + resMsg + " : " + eventLogToPost);
	    }
	} catch (Exception ex) {
	    logger.error("Exception while posting eventLogToPost to HEC Event Collector: " + "" + ex.getMessage()
		    + " : " + eventLogToPost);
	}
    }

}
