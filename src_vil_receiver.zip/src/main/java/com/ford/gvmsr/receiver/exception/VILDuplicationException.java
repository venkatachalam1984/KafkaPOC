package com.ford.gvmsr.receiver.exception;

public class VILDuplicationException extends Exception {

    public VILDuplicationException(String message) {
        super(message);
    }

}
