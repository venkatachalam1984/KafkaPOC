package com.ford.gvmsr.receiver.verticle;

import java.time.Duration;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.PCMYNotFoundException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.VilRequest;
import com.ford.gvmsr.receiver.repository.IVilMessageRepository;
import com.ford.gvmsr.receiver.repository.impl.VilMessageRepository;
import com.ford.gvmsr.receiver.util.BeanUtil;
import com.ford.gvmsr.receiver.util.JsonUtils;
import com.ford.gvmsr.receiver.util.SplunkUtils;
import com.ford.gvmsr.receiver.util.VilUtils;
import com.ford.gvmsr.receiver.validator.PCMYValidationHandler;
import com.ford.gvmsr.receiver.validator.VilValidationHandler;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.Message;

public class LogRequestValidationHandler extends AbstractVerticle {

    private final Integer verticleIndex;
    private final Logger log = LoggerFactory.getLogger(this.getClass());
	private IVilMessageRepository vilMessageRepository;
	private VilValidationHandler vilValidationHandler;
	private PCMYValidationHandler pcmyValidationHandler;
	private PropertiesConfig properties;
	private SplunkUtils splunkUtils;

    public LogRequestValidationHandler(Integer verticleIndex) {
	this.verticleIndex = verticleIndex;
    }

    @Override
    public void start() {
	log.debug("Deployed LogRequestHandler verticle with index = {} ", verticleIndex);
	vertx.eventBus().consumer(VilConstants.LOG_VALIDATOR_PREFIX + verticleIndex, this::vilValidationHandler);
	initializeDependentAutowiredBeans();
    }

    /**
     * Initialize dependent beans that uniquely matches the given object type, if
     * any.
     */
    private void initializeDependentAutowiredBeans() {
	this.vilMessageRepository = BeanUtil.getBean(vilMessageRepository, VilMessageRepository.class);
	this.vilValidationHandler = BeanUtil.getBean(vilValidationHandler, VilValidationHandler.class);
	this.splunkUtils = BeanUtil.getBean(splunkUtils, SplunkUtils.class);
	this.properties = BeanUtil.getBean(properties, PropertiesConfig.class);
	this.pcmyValidationHandler = BeanUtil.getBean(pcmyValidationHandler, PCMYValidationHandler.class);
    }

    /**
     * Received VIL request will be validated by list of base validators (i.e)
     * History Validator, Duplicate Validator, JSON Constraint Validator, PCMY
     * validator. If VIL passed all the validations then will sent Domain Validator
     * Verticle
     *
     * @param message Message represents data shared through Event-Bus.
     *
     */
    private void vilValidationHandler(Message<Object> message) {
	String vin = null;
	String traceId = null;
	Instant start = Instant.now();
	long vilMessageRecordId = Long.valueOf(message.headers().get(VilConstants.VIL_MESSAGE_RECORD_ID));
	try {
	    String vilMessage = JsonUtils.findValueByKey((String) message.body(), VilConstants.RAW_VIL_KEY);
	    vin = message.headers().get(VilConstants.PARTITION_KEY);
	    traceId = message.headers().get(VilConstants.TRACE_ID_KEY);
	    log.info("LogRequestHandler:received VIN={},traceId={},at index={}", vin, traceId, verticleIndex);
	    VilRequest vilRequest = VilUtils.generateVilRequest(vilMessage).setTraceId(traceId);
	    VilReceiverRequest receiverRequest = new VilReceiverRequest(vilRequest, properties.getApplicationDIDs());
	    pcmyValidationHandler.prepareIVSProgramId(receiverRequest);
		receiverRequest.setRetryVilFlagEnabled(Boolean.FALSE);
		receiverRequest.setVilMessageRecordId(vilMessageRecordId);
	    vilValidationHandler.applyVilValidations(receiverRequest);
		pushToDomainStateValidator(vin, receiverRequest);
	} catch (PCMYNotFoundException e) {
	    updateErrorStatus(vin, traceId, e, start, VilConstants.NO_PROGRAM_CODE, vilMessageRecordId);
	} catch (LateVILException e) {
	    updateErrorStatus(vin, traceId, e, start, VilConstants.LATE_VIL, vilMessageRecordId);
	} catch (VILDuplicationException e) {
	    updateErrorStatus(vin, traceId, e, start, VilConstants.DUPLICATE_VIL, vilMessageRecordId);
	} catch (VILValidationException e) {
	    updateErrorStatus(vin, traceId, e, start, VilConstants.VALIDATION_ERROR, vilMessageRecordId);
	} catch (Exception e) {
	    updateErrorStatus(vin, traceId, e, start, VilConstants.RUNTIME_FAILURE, vilMessageRecordId);
	}
    }

    /**
     * Send request to DOMAIN_STATE_VALIDATION_HANDLER through Vertx EventBus
     * @param vin             Vehicle Identification Number is primary identification field
     * @param receiverRequest unique UUID to trace specific VIL request
     */
	private void pushToDomainStateValidator(String vin, VilReceiverRequest receiverRequest) {
		String domainValidatorAddr = VilConstants.DOMAIN_STATE_VALIDATION_HANDLER + VilUtils.getVinModHash(vin);
		log.info("Verticle name={}, for VIN={}", domainValidatorAddr, vin);
		vertx.eventBus().send(domainValidatorAddr, receiverRequest);
	}

	/**
     * Updating a record with failed status in 02 table and exception details will
     * be sent to Splunk. Record will be identified by VIN & TraceID.
     *  @param vin       Vehicle Identification Number is primary identification
     *                  field
     * @param traceId   unique UUID to trace specific VIL request
	 * @param exception exception class to trace the failure reason
	 * @param start     Instant class which used to calculate method processed time
	 * @param status    Status to be updated in DB/Splunk for specific VIN
	 * @param vilMessageRecordId
	 */
    private void updateErrorStatus(String vin, String traceId, Exception exception, Instant start, String status, long vilMessageRecordId) {
	try {
	    log.error("LogRequestHandler:received exception=" + exception.getMessage() + " at=" + exception.getStackTrace()[0].getClassName());
	    vilMessageRepository.updateStatusById(status, vilMessageRecordId);
	} catch (Exception e) {
	    log.error("LogRequestHandler:received exception while updating VilMessage- " + e);
	}
	Instant end = Instant.now();
	splunkUtils.postErrorEvent(vin, traceId, status, exception.getMessage(), VilConstants.INDEXED_VIL_REQ_HANDLER,
		null, Duration.between(start, end).toMillis());
	splunkUtils.postInfoEvent(vin, traceId, VilConstants.RECV_END, VilConstants.INDEXED_VIL_REQ_HANDLER, null,
		Duration.between(start, end).toMillis());
    }
}
