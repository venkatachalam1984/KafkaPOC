package com.ford.gvmsr.receiver.builder.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.validator.*;

/**
 * OrcKing makes requests that are handled by the chain.
 */
public class VilValidationChainBuilder {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private BaseValidator chain;

    public VilValidationChainBuilder() {
	buildVilValidation();
    }

    private void buildVilValidation() {
	chain = new VilHistoryValidator(new VilDuplicationValidator(new VilConstraintValidator(
		new RawVilConstraintValidator(new VilRuleValidator(new VilRedundantNodeValidator(null))))));
    }

    public void applyValidation(VilValidationSourceEnum validationSource, VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	chain.handleRequest(validationSource, receiverRequest);
    }

}
