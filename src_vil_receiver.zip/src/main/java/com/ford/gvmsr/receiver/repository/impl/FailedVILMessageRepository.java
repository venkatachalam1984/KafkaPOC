package com.ford.gvmsr.receiver.repository.impl;

import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.ford.gvmsr.receiver.entity.FailedVILMessage;
import com.ford.gvmsr.receiver.repository.IFailedVILMessageRepository;

@Repository
public class FailedVILMessageRepository implements IFailedVILMessageRepository {

    private JdbcTemplate jdbcTemplate;

    public FailedVILMessageRepository(DataSource dataSource) {
	this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public long save(FailedVILMessage failedVILMessage) {
	final String insertIntoSql = "INSERT INTO PGVMR01_FAIL_VIL_MSG(GVMR01_VIL_MSG_L,GVMR01_CREATE_USER_C,GVMR01_CREATE_S) VALUES (?,?,?)";
	KeyHolder keyHolder = new GeneratedKeyHolder();
	jdbcTemplate.update(connection -> {
	    PreparedStatement ps = connection.prepareStatement(insertIntoSql, Statement.RETURN_GENERATED_KEYS);
	    ps.setBytes(1, failedVILMessage.getVilMessage());
	    ps.setString(2, failedVILMessage.getCreatedUser());
	    ps.setTimestamp(3, failedVILMessage.getCreatedTime());
	    return ps;
	}, keyHolder);
	return keyHolder.getKey().longValue();
    }
}
