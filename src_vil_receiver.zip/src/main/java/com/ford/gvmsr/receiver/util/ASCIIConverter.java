package com.ford.gvmsr.receiver.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ASCIIConverter {

    private static final Logger log = LoggerFactory.getLogger(ASCIIConverter.class);

    public static String convertHexToString(String hex) {
	StringBuilder value = new StringBuilder();
	StringBuilder decimalValue = new StringBuilder();
	boolean isValidChar = true;

	// 49204c6f7665204a617661 split into two characters 49, 20, 4c...
	for (int index = 0; index < hex.length(); index += 2) {

	    // grab the hex in pairs
	    String output = hex.substring(index, Math.min((index + 2), hex.length()));

	    // convert hex to decimal
	    int decimal = Integer.parseInt(output, 16);
	    isValidChar = isASCIIinValidRange(decimal);
	    if (!isValidChar) {
		log.debug("Invalid character found:" + decimal);
		break;
	    }
	    value.append((char) decimal);
	    decimalValue.append(decimal);
	}
	log.debug("Decimal : " + decimalValue.toString());
	return isValidChar ? value.toString().replaceAll("\\u0000", "") : StringUtils.EMPTY;
    }

    private static boolean isASCIIinValidRange(int decimal) {
	return (decimal == 45 || (decimal >= 48 && decimal <= 57) || (decimal >= 65 && decimal <= 90)
		|| (decimal == 0));

    }

}
