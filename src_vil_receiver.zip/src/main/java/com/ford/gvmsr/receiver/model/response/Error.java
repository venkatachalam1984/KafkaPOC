
package com.ford.gvmsr.receiver.model.response;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "node", "ruleNumber", "ruleShortDescription", "value" })
public class Error {

    @JsonProperty("node")
    private String node;
    @JsonProperty("ruleNumber")
    private String ruleNumber;
    @JsonProperty("ruleShortDescription")
    private String ruleShortDescription;
    @JsonProperty("value")
    private String value;
    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("node")
    public String getNode() {
	return node;
    }

    @JsonProperty("node")
    public void setNode(String node) {
	this.node = node;
    }

    @JsonProperty("ruleNumber")
    public String getRuleNumber() {
	return ruleNumber;
    }

    @JsonProperty("ruleNumber")
    public void setRuleNumber(String ruleNumber) {
	this.ruleNumber = ruleNumber;
    }

    @JsonProperty("ruleShortDescription")
    public String getRuleShortDescription() {
	return ruleShortDescription;
    }

    @JsonProperty("ruleShortDescription")
    public void setRuleShortDescription(String ruleShortDescription) {
	this.ruleShortDescription = ruleShortDescription;
    }

    @JsonProperty("value")
    public String getValue() {
	return value;
    }

    @JsonProperty("value")
    public void setValue(String value) {
	this.value = value;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
    }

    public String getExceptionCause() {
	Collection<Object> values = this.getAdditionalProperties().values();
	return values.stream().map(Object::toString).collect(Collectors.joining(","));
    }
}