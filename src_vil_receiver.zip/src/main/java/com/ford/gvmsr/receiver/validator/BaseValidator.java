package com.ford.gvmsr.receiver.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;

/**
 * RequestHandler.
 */
public abstract class BaseValidator {

    private final BaseValidator next;

    public BaseValidator(BaseValidator next) {
	this.next = next;
    }

    public abstract void validate(VilReceiverRequest request)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException;

    public void handleRequest(VilValidationSourceEnum validationSource, VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	if (next != null) {
	    next.handleRequest(validationSource, receiverRequest);
	}
    }
}
