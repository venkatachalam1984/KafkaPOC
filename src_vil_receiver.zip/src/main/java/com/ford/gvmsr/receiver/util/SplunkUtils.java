package com.ford.gvmsr.receiver.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.splunk.AppLogEvent;
import com.ford.gvmsr.receiver.splunk.KafkaLogEvent;
import com.ford.gvmsr.receiver.splunk.SplunkEventSender;

@Component
public class SplunkUtils {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private final SplunkEventSender splunkEventSender;
    @Value("${splunk.hec.call.flag}")
    private boolean splunkHecCallFlag;

    public SplunkUtils(SplunkEventSender splunkEventSender) {
	this.splunkEventSender = splunkEventSender;
    }

    private void pushSplunkLogEvent(AppLogEvent logEvent, String sourceType) {
	if (splunkHecCallFlag) {
	    try {
		String logEventJson = JsonUtils.getJsonString(logEvent);
		splunkEventSender.postToHEC(logEventJson, VilConstants.SPLUNK_SOURCE_VIL_RECEIVER, sourceType);
	    } catch (Exception ex) {
		log.error("Error while pushing Splunk log event : " + ex);
	    }
	} else {
	    log.info("Splunk log is disabled");
	}
    }

    public void pushSplunkLogEvent(KafkaLogEvent logEvent, String sourceType) {
	if (splunkHecCallFlag) {
	    try {
		String logEventJson = JsonUtils.getJsonString(logEvent);
		splunkEventSender.postToHEC(logEventJson, VilConstants.SPLUNK_SOURCE_VIL_RECEIVER, sourceType);
	    } catch (Exception ex) {
		log.error("Error while pushing Splunk log event : " + ex);
	    }
	} else {
	    log.info("Splunk log is disabled");
	}
    }

    public void postInfoEvent(String vin, String traceId, String status, String sourceType, String node,
	    Long duration) {
	AppLogEvent appLogEvent = AppLogEvent.builder().traceId(traceId).type(VilConstants.LOG_TYPE_INFO).status(status)
		.vin(vin).node(node).timeStamp(VilUtils.getCurrentTimeStamp()).duration(duration).build();
	pushSplunkLogEvent(appLogEvent, sourceType);
    }

    public void postErrorEvent(String vin, String traceId, String status, String errorDesc, String sourceType,
	    String node, long duration) {
	AppLogEvent appLogEvent = AppLogEvent.builder().traceId(traceId).type(VilConstants.LOG_TYPE_ERROR)
		.status(status).vin(vin).node(node).exception(errorDesc).timeStamp(VilUtils.getCurrentTimeStamp())
		.build();
	pushSplunkLogEvent(appLogEvent, sourceType);
    }

}
