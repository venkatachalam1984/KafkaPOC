
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "latitude", "longitude" })
public class LastGps {

    @NotNull(message = "VIL-latitude should not be null/empty")
    @JsonProperty("latitude")
    private String latitude;
    @NotNull(message = "VIL-longitude should not be null/empty")
    @JsonProperty("longitude")
    private String longitude;
    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("latitude")
    public String getLatitude() {
	return latitude;
    }

    @JsonProperty("latitude")
    public void setLatitude(String latitude) {
	this.latitude = latitude;
    }

    @JsonProperty("longitude")
    public String getLongitude() {
	return longitude;
    }

    @JsonProperty("longitude")
    public void setLongitude(String longitude) {
	this.longitude = longitude;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
    }

}
