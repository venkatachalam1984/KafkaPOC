package com.ford.gvmsr.receiver.builder;

import com.ford.gvmsr.domain.modulestate.ApplicationInitializer;
import com.ford.gvmsr.domain.modulestate.metadata.response.DIDCatalog;
import com.ford.gvmsr.domain.modulestate.model.request.*;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.constant.VilExceptionConstants;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.*;
import com.ford.gvmsr.receiver.util.SplunkUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;

@Component
public class ModuleStateRequestBuilder {

    final SplunkUtils splunkUtils;

    public ModuleStateRequestBuilder(SplunkUtils splunkUtils) {
	this.splunkUtils = splunkUtils;
    }

    public ModuleStateRequest build(final VilReceiverRequest request, String traceId) {
	ModuleStateRequest moduleStateRequest = new ModuleStateRequest();
	ModuleSnapshotType moduleSnapshotType = new ModuleSnapshotType();
	prepareModuleSnapshotType(request.getVil(), moduleSnapshotType);
	List<ModuleNodeType> validModuleNodeTypeList = moduleSnapshotType.getNode();
	Map<String, String> invalidModuleNodeTypeList = request.getInvalidModuleNodeTypeList();
	Map<String, DIDCatalog> didCatalogMap = ApplicationInitializer.didCatalogTypeMap;
	for (Node node : request.getVil().getNodes()) {
		if (!request.isRetryVilFlagEnabled() || request.getRetryAllowedNodesList().contains(node.getAddress())) {
			setNodeDidValues(node, validModuleNodeTypeList, didCatalogMap, moduleSnapshotType, traceId, invalidModuleNodeTypeList);
		}
	}
	moduleStateRequest.setModuleSnapshot(moduleSnapshotType);
	moduleStateRequest.setTraceID(traceId);
	return moduleStateRequest;
    }

    private void prepareModuleSnapshotType(final VIL vil, ModuleSnapshotType moduleSnapshotType) {
	moduleSnapshotType.setVIN(vil.getVin());
	moduleSnapshotType.setModuleName(ModuleNameENUMType.fromValue("ECU"));
	StateUpdateRoleType stateUpdateRoleType = new StateUpdateRoleType();
	RequestRole requestRole = vil.getRequestRole();
	if (requestRole != null) {
	    stateUpdateRoleType.setRole(RoleENUMType.CONSUMER);
	    stateUpdateRoleType.setRoleDesc(VilConstants.ROLE_DESC_FENIX);
	    stateUpdateRoleType.setRoleSource(RoleSourceENUMType.OTA);
	    stateUpdateRoleType.setRoleID(VilConstants.VIL_ROLE_ID);
	}
	moduleSnapshotType.setRequestRole(stateUpdateRoleType);
    }

    private void setNodeDidValues(Node node, List<ModuleNodeType> validModuleNodeTypeList,
	    Map<String, DIDCatalog> didCatalogMap, ModuleSnapshotType moduleSnapshotType, String traceId,
	    Map<String, String> invalidModuleNodeTypeList) {
	Instant start = Instant.now();
	ModuleNodeType moduleNodeType = new ModuleNodeType();
	moduleNodeType.setAddress(node.getAddress());
	moduleNodeType.setIsFlashed(Boolean.valueOf("false"));
	moduleNodeType.setSpecificationCategory(node.getSpecificationCategory());
	// ODL Network
	ModuleODLNetworkType moduleODLNetworkType = new ModuleODLNetworkType();
	OdlNetwork odlNetwork = node.getOdlNetwork();
	if (odlNetwork != null) {
	    moduleODLNetworkType.setNetworkDataRate(odlNetwork.getDataRate());
	    moduleODLNetworkType.setNetworkName(odlNetwork.getName());
	    moduleODLNetworkType.setNetworkProtocol(odlNetwork.getProtocol());
	}
	moduleNodeType.setODLNetwork(moduleODLNetworkType);

	// #2 ECUAcronymType details includes Dids
	List<ECUAcronymType> ecuAcronymTypes = moduleNodeType.getECUAcronym();
	ECUAcronymType ecuAcronymType = new ECUAcronymType();
	ecuAcronymType.setName(node.getEcuAcronym());
	ecuAcronymTypes.add(ecuAcronymType);

	List<HistoricType> historicTypes = ecuAcronymTypes.get(0).getState();
	HistoricType historicType = new HistoricType();
	historicTypes.add(historicType);

	List<GatewayType> gatewayTypes = historicTypes.get(0).getGateway();
	GatewayType gatewayType = new GatewayType();
	gatewayType.setGatewayType("NONE");
	gatewayTypes.add(gatewayType);

	List<DIDInfoType> didInfoTypes = gatewayTypes.get(0).getDID();
	boolean isMandatoryDidPresent = addDidInfoType(node, didCatalogMap, didInfoTypes);

	// #3 ESN Detail
	List<ESNMetadataType> esnMetadataTypes = moduleNodeType.getESNMetadata();
	ESNMetadataType esnMetadataType = new ESNMetadataType();
	esnMetadataType.setEsn(node.getEsn());
	esnMetadataTypes.add(esnMetadataType);
	if (didInfoTypes != null && didInfoTypes.size() > 0) {
	    if (isMandatoryDidPresent) {
		validModuleNodeTypeList.add(moduleNodeType);
	    } else {
		invalidModuleNodeTypeList.put(moduleNodeType.getAddress(), VilConstants.INVALID_NODE);
		Instant end = Instant.now();
		splunkUtils.postErrorEvent(moduleSnapshotType.getVIN(), traceId, VilConstants.INVALID_NODE,
			VilExceptionConstants.DID_NOT_PRESENT_F111_F113, VilConstants.MODULE_STATE_REQUEST_BUILDER,
			moduleNodeType.getAddress(), Duration.between(start, end).toMillis());
	    }
	} else {
	    invalidModuleNodeTypeList.put(moduleNodeType.getAddress(), VilConstants.INVALID_NODE);
	    Instant end = Instant.now();
	    splunkUtils.postErrorEvent(moduleSnapshotType.getVIN(), traceId, VilConstants.INVALID_NODE,
		    VilExceptionConstants.VALID_DID_NOT_PRESENT, VilConstants.MODULE_STATE_REQUEST_BUILDER,
		    moduleNodeType.getAddress(), Duration.between(start, end).toMillis());
	}
    }

    private boolean addDidInfoType(Node node, Map<String, DIDCatalog> didCatalogMap, List<DIDInfoType> didInfoTypes) {
	boolean isMandatoryDidPresent = false;
	for (Did did : node.getDid()) {
	    if (!isEmptyDidResponse(did) && !isDidResponseParseError(did)) {
		DIDInfoType didInfoType = new DIDInfoType();
		if (!isMandatoryDidPresent) {
		    isMandatoryDidPresent = (did.getDidValue().equalsIgnoreCase(VilConstants.F111_DID)
			    || did.getDidValue().equalsIgnoreCase(VilConstants.F113_DID));
		}
		didInfoType.setDidValue(did.getDidValue().toUpperCase());
		didInfoType.setResponse(did.getDecodedResponse().trim());
		didInfoType.setError(did.getError());
		didInfoType.setIsConfig(Boolean.FALSE); // Set false as default
		if (didCatalogMap != null) {
		    DIDCatalog didCatalog = didCatalogMap.get(did.getDidValue());
		    if (didCatalog != null) {
			if (StringUtils.isNotBlank(didCatalog.getIsConfig())) {
			    if (didCatalog.getIsConfig().equalsIgnoreCase("Y")) {
				didInfoType.setIsConfig(Boolean.TRUE);
			    } else {
				didInfoType.setIsConfig(Boolean.FALSE);
			    }
			}
		    }
		}
		didInfoTypes.add(didInfoType);
	    }
	}
	return isMandatoryDidPresent;
    }

    public boolean isEmptyDidResponse(Did did) {
	return did != null && (StringUtils.isBlank(did.getDecodedResponse()));
    }

    public boolean isDidResponseParseError(Did did) {
	return did != null && (did.getError().equalsIgnoreCase(VilConstants.DID_RESPONSE_PARSING_ERROR)
		|| did.getError().equalsIgnoreCase(VilConstants.DID_RESPONSE_INVALID_CHAR_ERROR));
    }
}
