package com.ford.gvmsr.receiver.splunk;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SplunkLogEvent {
    String host;
    String source;
    String sourcetype;
    String event;
    String time;

}
