package com.ford.gvmsr.receiver.util;

import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Base64;
import java.util.Objects;

import com.ford.gvmsr.receiver.constant.VilConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.exception.VILDecodeException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.request.VilRequest;

public class VilUtils {

	static PropertiesConfig config = null;
    private final static Logger log = LoggerFactory.getLogger(VilUtils.class);

    public static String decodeVIL(String base64_EncodedVIL) throws VILDecodeException {
	String base64_DecodedVIL;
	try {
	    byte[] vilDataInBytes = Base64.getDecoder().decode(base64_EncodedVIL.getBytes(StandardCharsets.UTF_8));
	    base64_DecodedVIL = new String(vilDataInBytes);
	} catch (Exception e) {
	    log.info("Exception while decoding VIL :: " + e);
	    throw new VILDecodeException(e.getMessage());
	}
	return base64_DecodedVIL;
    }

    public static Integer getVinHashKey(String vin) {
	return Integer.parseInt(vin.substring(vin.length() - 2));
    }

    public static Integer getVinModHash(String vin) {
	config = BeanUtil.getBean(config, PropertiesConfig.class);
	int vinHashLookUpKey = (Math.abs(vin.hashCode()) % config.getWorkerVerticleCount());
	return vinHashLookUpKey;
    }

    public static long getCurrentTimeStamp() {
	Instant instant = Instant.now();
	Timestamp timestamp = Timestamp.from(instant);
	return timestamp.getTime();
    }

    public static VilRequest generateVilRequest(final String vilString) throws VILValidationException {
	VilRequest vilRequest = null;
	try {
	    ObjectMapper objectMapper = new ObjectMapper();
	    JsonNode vilJsonNode = objectMapper.readTree(vilString);
	    if (null != vilJsonNode) {
		String vin = vilJsonNode.get("vin").asText();
		String timestamp = vilJsonNode.get("timeStamp").asText();
		JsonNode requestRoleNode = vilJsonNode.get("requestRole");
		String role = requestRoleNode.get("role").asText();
		Timestamp vilTimestamp = new Timestamp(Long.parseLong(timestamp) * 1000L);

		vilRequest = new VilRequest();
		vilRequest.setVin(vin);
		vilRequest.setRawVIL(vilString);
		vilRequest.setTimeStamp(vilTimestamp.toString());
		vilRequest.setRole(role);
		vilRequest.setSource(VilConstants.GVMSR_SOURCE_VIL);
		vilRequest.setReturn(VilConstants.RETURN_TYPE_VALIDATE_AND_PROCESS);
		vilRequest.setEPocheTimeStamp(timestamp);
	    }
	} catch (Exception ex) {
	    log.error("Exception in VilRequest generation >>>> " + ex);
	    throw new VILValidationException("VilRequest object preparation exception - " + ex.getMessage());
	}
	return vilRequest;
    }

    public static String millisecondsToSeconds(long milliseconds) {
	long seconds = (milliseconds / 1000);
	long milliSeconds = (milliseconds % 1000);
	String milliSecondsStr = Long.toString(milliSeconds);
	String milliSecs;
	if (milliSecondsStr.length() >= 2) {
	    milliSecs = milliSecondsStr.substring(0, 2);
	} else {
	    milliSecs = "0" + milliSecondsStr;
	}
	return seconds + "." + milliSecs;
    }
}
