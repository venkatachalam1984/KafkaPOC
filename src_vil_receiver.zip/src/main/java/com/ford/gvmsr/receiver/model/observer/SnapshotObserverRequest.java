package com.ford.gvmsr.receiver.model.observer;

import java.sql.Timestamp;
import java.util.Map;

import com.ford.gvmsr.domain.modulestate.model.request.ModuleStateRequest;
import lombok.Data;

@Data
public class SnapshotObserverRequest {

    private ModuleStateRequest moduleStateRequest;
    private Long infoKey;
    private long recordKey; // populated by snap observer by 2 table key
    private String partitionKey;
    private String requestType;
    private Timestamp vilProcessedTime;
    private Map<String, AdditionalProperties> additionalPropertiesMap;
    private Map<String, String> redisValue;
    private VilHeader vilHeader;

}
