package com.ford.gvmsr.receiver.validator;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.VilRequest;
import com.ford.gvmsr.receiver.model.response.Error;

public class VilConstraintValidator extends BaseValidator {

    private final Logger log = LoggerFactory.getLogger(VilConstraintValidator.class);

    public VilConstraintValidator(BaseValidator next) {
	super(next);
    }

    public void validate(VilReceiverRequest req) throws VILValidationException {
	VilRequest vilRequest = req.getVilRequest();
	List<Error> errorList = req.getErrorList();
	log.info("VilConstraintValidator Request received - " + req.getVin());
	if (vilRequest == null) {
	    throw new VILValidationException("VIL validation failed against Schema - JSON is null");
	}
	JsonConstraintValidator.validateJson(vilRequest, errorList);
	if (errorList.size() > 0) {
	    String errorCause = errorList.stream().map(Error::getExceptionCause).collect(Collectors.joining(","));
	    throw new VILValidationException("VIL validation failed against Schema - " + errorCause);
	}
	log.info(req.getVin() + ": validated by VilConstraintValidator");
    }

    @Override
    public void handleRequest(VilValidationSourceEnum validationSource, VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	if (VilValidationSourceEnum.VIL_CONSTRAINT_VALIDATOR == validationSource) {
	    validate(receiverRequest);
	} else {
	    super.handleRequest(validationSource, receiverRequest);
	}
    }

}
