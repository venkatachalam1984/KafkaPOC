package com.ford.gvmsr.receiver.exception;

public class LateVILException extends Exception {

    public LateVILException(String message) {
        super(message);
    }

}
