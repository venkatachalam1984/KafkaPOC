package com.ford.gvmsr.receiver.alarmevents;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by vm4 on 27/03/2017.
 */
public class ExceptionEventTO {

    private static final long serialVersionUID = -9087317979296277874L;
    private List<ExceptionEventHeaderTO> exceptionEventHeaderTOList=new ArrayList<>();

    public List<ExceptionEventHeaderTO> getExceptionEventHeaderTOList() {
        return exceptionEventHeaderTOList;
    }

    public void setExceptionEventHeaderTOList(List<ExceptionEventHeaderTO> exceptionEventHeaderTOList) {
        this.exceptionEventHeaderTOList = exceptionEventHeaderTOList;
    }

}
