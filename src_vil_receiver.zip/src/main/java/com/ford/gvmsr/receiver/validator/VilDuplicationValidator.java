package com.ford.gvmsr.receiver.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.checksum.builder.VILChecksumHandler;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.Node;
import com.ford.gvmsr.receiver.util.BeanUtil;
import com.ford.gvmsr.receiver.util.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import java.util.List;

public class VilDuplicationValidator extends BaseValidator {

    private final Logger log = LoggerFactory.getLogger(VilDuplicationValidator.class);
    VILChecksumHandler vilChecksumHandler = null;
    Environment environment = null;

    String vilDuplicationFlagKey = "receiver.vil.duplicate-validation.enabled";

    public VilDuplicationValidator(BaseValidator next) {
	super(next);
    }

    @Override
    public void validate(VilReceiverRequest request) throws JsonProcessingException, VILDuplicationException {
	String vin = request.getVin();
	List<Node> nodes = request.getVil().getNodes();
	boolean isDuplicateVil = vilChecksumHandler.isDuplicateVIL(vin, JsonUtils.getJsonString(nodes),request.isActiveRecordPresent());
	if (isDuplicateVil)
	    throw new VILDuplicationException("Duplicate:VIL-VIN-" + vin);
    }

    @Override
    public void handleRequest(VilValidationSourceEnum validationSource, VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	if (VilValidationSourceEnum.VIL_DUPLICATION_VALIDATOR == validationSource) {
	    log.info("VilDuplicationValidator received - " + receiverRequest.getVin());
	    initializeBeansByApplicationContext();
	    String duplicateCheckFlagEnabled = environment.getProperty(vilDuplicationFlagKey);
	    log.info("Duplicate VIL Validation flag - " + duplicateCheckFlagEnabled);
		if (Boolean.valueOf(duplicateCheckFlagEnabled) && !receiverRequest.isRetryVilFlagEnabled())
			validate(receiverRequest);
	    log.info(receiverRequest.getVin() + ": validated by VilDuplicationValidator");
	} else {
	    super.handleRequest(validationSource, receiverRequest);
	}
    }

    void initializeBeansByApplicationContext() {
	environment = BeanUtil.getBean(environment, Environment.class);
	vilChecksumHandler = BeanUtil.getBean(vilChecksumHandler, VILChecksumHandler.class);
    }
}
