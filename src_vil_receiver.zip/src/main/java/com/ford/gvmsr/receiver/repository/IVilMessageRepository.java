package com.ford.gvmsr.receiver.repository;

import java.sql.Timestamp;
import java.util.Optional;

import com.ford.gvmsr.receiver.entity.VilMessage;

public interface IVilMessageRepository {

    Optional<Timestamp> findProcessedTimeById(Long recordId);

    Optional<VilMessage> findById(Long recordId);

    int updatePartitionAndOffsetAndStatusById(String status, Integer kafkaPartition, Long kafkaOffset, String recordId);

    int updateStatusById(String status, long recordId);

    long save(VilMessage payloadVIL);
}
