package com.ford.gvmsr.receiver.controller;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;

import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.model.retry.VilRetryRequest;
import com.ford.gvmsr.receiver.model.retry.VilRetryResponse;
import com.ford.gvmsr.receiver.repository.impl.VilMessageRepository;
import com.ford.gvmsr.receiver.util.BeanUtil;
import com.ford.gvmsr.receiver.util.SplunkUtils;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.DeliveryOptions;
import io.vertx.core.json.Json;
import io.vertx.ext.healthchecks.HealthCheckHandler;
import io.vertx.ext.healthchecks.Status;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

public class VilReceiverController extends AbstractVerticle {
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private PropertiesConfig properties;
    private VilMessageRepository messageRepository;
    private SplunkUtils splunkUtils;

    @Override
    public void start() {
	Router router = Router.router(vertx);
	router.route().handler(BodyHandler.create());

	router.post("/api/v1/publish").handler(this::postNewVilRequest);
	router.post("/api/v1/retry-vil").handler(this::postRetryRequest);

	HealthCheckHandler healthCheckHandler1 = HealthCheckHandler.create(vertx);
	healthCheckHandler1.register("health", promise -> promise.complete(Status.OK()));
	router.get("/health").handler(healthCheckHandler1);

	vertx.createHttpServer().requestHandler(router).listen(8080);
	initializeDependentAutowiredBeans();
    }

    private void postNewVilRequest(RoutingContext routingContext) {
	log.info("Received vil request at-" + Instant.now().toString());
	String request = routingContext.getBody().toString();
	String encodedLine = Base64.getEncoder().encodeToString(request.getBytes(StandardCharsets.UTF_8));
	String traceId = UUID.randomUUID().toString();
	DeliveryOptions deliveryOptions = new DeliveryOptions().addHeader(VilConstants.TRACE_ID_KEY, traceId)
		.addHeader(VilConstants.PARTITION, String.valueOf(1)).addHeader(VilConstants.OFFSET, String.valueOf(1));
	vertx.eventBus().send(VilConstants.ENCODED_VIL_RECEIVER, encodedLine, deliveryOptions);
	routingContext.response().end("Success");
    }

    private void postRetryRequest(RoutingContext routingContext) {
	VilRetryRequest retryRequest = routingContext.getBodyAsJson().mapTo(VilRetryRequest.class);
	log.info("Received retry request-{}, at-{}", retryRequest, Instant.now().toString());
	DeliveryOptions deliveryOptions = new DeliveryOptions()
		.addHeader(VilConstants.TRACE_ID_KEY, retryRequest.getTraceId())
		.addHeader(VilConstants.KAFKA_TOPIC, properties.getLogConsumerTopic())
		.addHeader(VilConstants.PARTITION_KEY, retryRequest.getVin())
		.addHeader(VilConstants.REQUEST_TYPE, VilConstants.RETRY_VIL)
		.addHeader(VilConstants.VIL_MESSAGE_RECORD_ID, String.valueOf(retryRequest.getRecordId()));
	vertx.eventBus().request(VilConstants.KAFKA_REORDER_PRODUCER_VERTICLE, retryRequest.toString(), deliveryOptions,
		handler -> {
		    VilRetryResponse retryResponse = null;
		    if (handler.succeeded()) {
			String requestedNodes = !CollectionUtils.isEmpty(retryRequest.getNodeList())
				? String.join(", ", retryRequest.getNodeList())
				: null;
			splunkUtils.postInfoEvent(retryRequest.getVin(), retryRequest.getTraceId(),
				VilConstants.RETRY_REQ_START, VilConstants.VIL_RETRY_CTLR, requestedNodes, 0L);
			String errorDesc = (String) handler.result().body();
			retryResponse = buildVilRetryResponse(errorDesc);
		    } else {
			retryResponse = buildVilRetryResponse(handler.cause().toString());
			log.error("EventBus handler exception = ", handler.cause());
		    }
		    log.info("retryResponse ::" + retryResponse);
		    routingContext.response().putHeader("content-type", MediaType.APPLICATION_JSON_VALUE)
			    .end(Json.encodePrettily(retryResponse));
		});

    }

    private VilRetryResponse buildVilRetryResponse(String errorDesc) {
	int errorCode = errorDesc.equalsIgnoreCase("Success") ? 0 : 1;
	return VilRetryResponse.builder().errorCode(errorCode).errorDesc(errorDesc).build();
    }

    private void initializeDependentAutowiredBeans() {
	this.properties = BeanUtil.getBean(properties, PropertiesConfig.class);
	this.messageRepository = BeanUtil.getBean(messageRepository, VilMessageRepository.class);
	this.splunkUtils = BeanUtil.getBean(splunkUtils, SplunkUtils.class);
    }
}
