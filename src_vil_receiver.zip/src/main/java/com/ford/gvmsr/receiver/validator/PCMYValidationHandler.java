package com.ford.gvmsr.receiver.validator;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.domain.modulestate.metadata.request.IVSProgramId;
import com.ford.gvmsr.receiver.entity.Vehicle;
import com.ford.gvmsr.receiver.exception.PCMYNotFoundException;
import com.ford.gvmsr.receiver.external.VinReceiverServiceAdapter;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.vinreceiver.VinReceiverResponse;
import com.ford.gvmsr.receiver.repository.impl.VehicleRepository;
import com.ford.gvmsr.receiver.util.VilUtils;
import com.google.common.base.Strings;

@Component
public class PCMYValidationHandler {

    final VehicleRepository vehicleRepository;
    final VinReceiverServiceAdapter vinReceiverServiceAdapter;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public PCMYValidationHandler(VehicleRepository vehicleRepository,
	    VinReceiverServiceAdapter vinReceiverServiceAdapter) {
	this.vehicleRepository = vehicleRepository;
	this.vinReceiverServiceAdapter = vinReceiverServiceAdapter;
    }

    public void prepareIVSProgramId(VilReceiverRequest receiverRequest)
	    throws PCMYNotFoundException, JsonProcessingException {
	String vin = receiverRequest.getVin();
	String traceId = receiverRequest.getTraceId();
	IVSProgramId ivsProgramId = new IVSProgramId();
	Optional<Vehicle> vehicleOptional = vehicleRepository.findByVinAndVinHash(vin, VilUtils.getVinHashKey(vin));
	if (vehicleOptional.isPresent() && !Strings.isNullOrEmpty(vehicleOptional.get().getProgramCode())
		&& vehicleOptional.get().getSalesModelYear() > 0) {
	    Vehicle vehicle = vehicleOptional.get();
	    ivsProgramId.setSalesModelYear(vehicle.getSalesModelYear());
	    ivsProgramId.setProgramCode(vehicle.getProgramCode());
	} else {
	    VinReceiverResponse vinReceiverResponse = vinReceiverServiceAdapter.getPCMYFromVinReceiver(vin, traceId);
	    ivsProgramId.setSalesModelYear(vinReceiverResponse.getModelYear());
	    ivsProgramId.setProgramCode(vinReceiverResponse.getProgramCode());
	}
	log.debug("IvsProgramId - " + ivsProgramId);
	receiverRequest.setIvsProgramId(ivsProgramId);
    }
}
