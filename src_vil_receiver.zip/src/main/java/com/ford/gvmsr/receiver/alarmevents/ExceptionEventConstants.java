package com.ford.gvmsr.receiver.alarmevents;

/**
 * Created by vm4 on 27/03/2017.
 */

public class ExceptionEventConstants {

    public static final String ERROR = "ERROR";

    public static final String A011_EVENT_CODE = "A011"; // Node Missing in ODL
    public static final String A014_EVENT_CODE = "A014"; // Network Mismatch
    public static final String VL01_EVENT_CODE = "VL01"; // DA Failed

}
