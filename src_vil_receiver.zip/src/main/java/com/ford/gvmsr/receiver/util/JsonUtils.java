package com.ford.gvmsr.receiver.util;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import io.vertx.core.json.JsonObject;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.github.fge.jackson.JsonLoader;

public class JsonUtils {

    public static JsonNode getJsonNode(String jsonText) throws IOException {
	return JsonLoader.fromString(jsonText);
    }

    public static JsonNode getJsonNode(File jsonFile) throws IOException {
	return JsonLoader.fromFile(jsonFile);
    }

    public static JsonNode getJsonNode(URL url) throws IOException {
	return JsonLoader.fromURL(url);
    }

    public static JsonNode getJsonNodeFromResource(String resource) throws IOException {
	return JsonLoader.fromResource(resource);
    }

	public static String findValueByKey(String decodedVIL, String key) {
		String value = null;
		JsonObject jsonObject = new JsonObject(decodedVIL);
		if (jsonObject.containsKey(key)) {
			value = jsonObject.getString(key);
		}
		return value;
	}

    public static <T, R> R getChildObject(T source, Class<R> returnType, String fieldKey)
	    throws VILValidationException, IOException {
	R returnObj = null;
	JSONObject sourceObj = new JSONObject(source);
	JsonNode vilRequestJSONNode = JsonUtils.getJsonNode(sourceObj.toString());
	if (vilRequestJSONNode == null) {
	    throw new VILValidationException("Exception while parsing the VIL Json Object");
	}
	String decryptedVIL = vilRequestJSONNode.get(fieldKey).textValue();
	returnObj = new ObjectMapper().readValue(decryptedVIL, returnType);
	return returnObj;
    }
    
    public static String getJsonString(Object obj) throws JsonProcessingException {
	ObjectMapper objectMapper = new ObjectMapper();
	return objectMapper.writeValueAsString(obj);
    }

}
