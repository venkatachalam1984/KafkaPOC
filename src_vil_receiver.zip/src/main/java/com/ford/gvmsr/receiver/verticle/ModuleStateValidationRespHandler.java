package com.ford.gvmsr.receiver.verticle;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ford.gvmsr.domain.modulestate.metadata.request.IVSProgramId;
import com.ford.gvmsr.domain.modulestate.model.request.ModuleNodeType;
import com.ford.gvmsr.domain.modulestate.model.request.ModuleStateRequest;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStateResponse;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStatusTracker;
import com.ford.gvmsr.receiver.alarmevents.ExceptionEventGenerator;
import com.ford.gvmsr.receiver.builder.DBEntityBuilder;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.entity.VilMessageNodeIVSFError;
import com.ford.gvmsr.receiver.entity.VilMessageNodeStatus;
import com.ford.gvmsr.receiver.exception.DBTransactionException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.repository.IIVSFErrorMessageNodeRepository;
import com.ford.gvmsr.receiver.repository.IIVSXmlVersionRepository;
import com.ford.gvmsr.receiver.repository.IVilMessageNodeStatusRepository;
import com.ford.gvmsr.receiver.repository.IVilMessageRepository;
import com.ford.gvmsr.receiver.repository.impl.IVSFMessageNodeStatusRepository;
import com.ford.gvmsr.receiver.repository.impl.IVSXmlVersionRepository;
import com.ford.gvmsr.receiver.repository.impl.VilMessageNodeStatusRepository;
import com.ford.gvmsr.receiver.repository.impl.VilMessageRepository;
import com.ford.gvmsr.receiver.util.BeanUtil;
import com.ford.gvmsr.receiver.util.SplunkUtils;
import com.ford.gvmsr.receiver.util.VilUtils;
import com.google.common.base.Strings;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.DeliveryOptions;
import io.vertx.core.eventbus.Message;

public class ModuleStateValidationRespHandler extends AbstractVerticle {
    private final Integer index;
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private SplunkUtils splunkUtils;
    private IVilMessageNodeStatusRepository nodeStatusRepository;
    private IIVSFErrorMessageNodeRepository ivsfErrorMessageNodeRepository;
    private IVilMessageRepository vilMessageRepository;
    private ExceptionEventGenerator exceptionEventGenerator;
    private PropertiesConfig propertiesConfig;
    private IIVSXmlVersionRepository xmlVersionRepository;

    public ModuleStateValidationRespHandler(Integer index) {
	this.index = index;
    }

    /**
     * Initialize dependent beans that uniquely matches the given object type, if
     * any.
     */
    public void initializeDependentAutowiredBeans() {
	this.nodeStatusRepository = BeanUtil.getBean(nodeStatusRepository, VilMessageNodeStatusRepository.class);
	this.vilMessageRepository = BeanUtil.getBean(vilMessageRepository, VilMessageRepository.class);
	this.ivsfErrorMessageNodeRepository = BeanUtil.getBean(ivsfErrorMessageNodeRepository,
		IVSFMessageNodeStatusRepository.class);
	this.exceptionEventGenerator = BeanUtil.getBean(exceptionEventGenerator, ExceptionEventGenerator.class);
	this.splunkUtils = BeanUtil.getBean(splunkUtils, SplunkUtils.class);
	this.propertiesConfig = BeanUtil.getBean(propertiesConfig, PropertiesConfig.class);
	this.xmlVersionRepository = BeanUtil.getBean(xmlVersionRepository, IVSXmlVersionRepository.class);
    }

    /**
     * Start the verticle instance. Vert.x calls this method when deploying the
     * instance. You do not call it yourself.
     **/
    @Override
    public void start() {
	log.debug("Deployed ModuleStateValidationRespHandler verticle with index = {} ", index);
	vertx.eventBus().consumer(VilConstants.DOMAIN_VALIDATION_RESP_PROC + index,
		this::domainValidationResponseHandler);
	initializeDependentAutowiredBeans();
    }

    /**
     * Fetch ModuleNodeType records from Domain State Validator response and persist
     * into 03 table. Once records inserted vil request will be sent to Module
     * observer request builder verticle
     *
     * @param message Message represents data shared through Event-Bus.
     **/
    private <T> void domainValidationResponseHandler(Message<T> message) {
	VilReceiverRequest request = (VilReceiverRequest) message.body();
	try {
	    log.info("ModuleStateValidationRespHandler:received VIN = {} at index = {} ", request.getVin(), index);
	    Map<String, String> nodeStatusCodeMap = getNodeStatusCodeMap(request.getStateResponse().getDomainStatusTracker());
		Iterator<Map.Entry<String, String>> iterator = nodeStatusCodeMap.entrySet().iterator();
		while (iterator.hasNext()) {
		    Map.Entry<String, String> next = iterator.next();
		    if (next.getValue().equalsIgnoreCase(VilConstants.DUPLICATE_DID_FOUND_STATUS)) {
			request.getInvalidModuleNodeTypeList().put(next.getKey(), next.getValue());
			iterator.remove();
		    }
		}
	    if (!request.isRetryVilFlagEnabled()) {
		persistVilMessageNodeStatus(request.getInvalidModuleNodeTypeList(), request);
		persistIVSFModuleNodeTypeList(nodeStatusCodeMap, request.getTraceId(), request.getVin(), request);
	    }
	    if (!request.isRetryVilFlagEnabled() || VilConstants.TYPE_IVS_ERR.equalsIgnoreCase(request.getRetryRequestType())) {
		persistValidModuleNodeTypeList(nodeStatusCodeMap, request.getTraceId(), request.getVin(), request);
	    }
	    String observerRequestHandlerAddr = VilConstants.MODULE_STATE_OBSERVER_REQ_PROC + VilUtils.getVinModHash(request.getVin());
	    log.info("observerRequestHandlerAddr={} for VIN={} ", observerRequestHandlerAddr, request.getVin());
	    vertx.eventBus().send(observerRequestHandlerAddr, request, new DeliveryOptions()
		    .addHeader(VilConstants.RECORD_KEY, String.valueOf(request.getVilMessageRecordId())));
	} catch (Exception e) {
	    log.error("ModuleStateValidationRespHandler:received exception- " + e);
	}
    }

    private void persistIVSFModuleNodeTypeList(Map<String, String> nodeStatusCodeMap, String traceId, String vin,
	    VilReceiverRequest receiverRequest) {
	Instant start = Instant.now();
	nodeStatusCodeMap.forEach((key, value) -> log.debug("domainStatusTracker::Node-" + key + " status-" + value));
	Map<String, String> iVSFNodeList = nodeStatusCodeMap.entrySet().stream()
		.filter(entry -> !entry.getValue().equals(VilConstants.VALID_NODE_STATUS))
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
	receiverRequest.setIVSFNodesList(iVSFNodeList);
	int ivsXmlVersion = findIVSXmlVersionForPCMY(receiverRequest.getIvsProgramId());
	log.info("ivsXmlVersion for PC-{}, MY-{}", receiverRequest.getIvsProgramId().getProgramCode(),
		receiverRequest.getIvsProgramId().getSalesModelYear());
	persistIVSFMessageNodeStatus(iVSFNodeList, receiverRequest, ivsXmlVersion);
	pushToSplunk(vin, traceId, nodeStatusCodeMap, start);
    }

    private int findIVSXmlVersionForPCMY(IVSProgramId ivsProgramId) {
	return xmlVersionRepository.findXmlVersionByPCAndMY(ivsProgramId.getProgramCode(),
		ivsProgramId.getSalesModelYear());
    }

    private void persistIVSFMessageNodeStatus(Map<String, String> iVSFNodeList, VilReceiverRequest receiverRequest,
	    int ivsXmlVersion) {
	Instant start = Instant.now();
	try {
	    if (iVSFNodeList != null && !iVSFNodeList.isEmpty()) {
		List<VilMessageNodeIVSFError> payloadNodeStatusList = new ArrayList<>();
		iVSFNodeList.forEach((node, status) -> {
		    VilMessageNodeIVSFError messageNodeIVSFError = DBEntityBuilder.buildIVSFMessageNodeErrorEntity(node,
			    receiverRequest, status, ivsXmlVersion);
		    payloadNodeStatusList.add(messageNodeIVSFError);
		});
		payloadNodeStatusList.forEach(nodeStatus -> log.info(
			"Before persisting node - vin-{}, traceId-{}, address-{}, status-{}", receiverRequest.getVin(),
			receiverRequest.getTraceId(), nodeStatus.getNodeAddress(), nodeStatus.getStatus()));
		ivsfErrorMessageNodeRepository.saveAll(payloadNodeStatusList);
	    }
	} catch (Exception e) {
	    log.error("ModuleStateValidationRespHandler:received exception while persisting Node Status -" + e);
	    Instant end = Instant.now();
	    splunkUtils.postErrorEvent(receiverRequest.getVin(), receiverRequest.getTraceId(), "DB_ERR", e.getMessage(),
		    VilConstants.MODULE_INFO_NODE_PROCESSOR, null, Duration.between(start, end).toMillis());
	    vilMessageRepository.updateStatusById("DB_ERR", receiverRequest.getVilMessageRecordId());
	}
    }

    /**
     * prepares ModuleNodeType map after comparing Vil request with Domain state
     * validator response. Once records persisted, events will be pushed to Splunk
     * for tracking & monitoring purpose.
     *
     * @param nodeStatusCodeMap User-defined class to maintain Module state
     *                          validator response data
     * @param traceId           unique UUID to trace specific VIL request
     * @param vin               Vehicle Identification Number is primary
     *                          identification field
     * @param receiverRequest   02 table record, acts as foreign key for
     * @return
     */
    private void persistValidModuleNodeTypeList(Map<String, String> nodeStatusCodeMap, String traceId, String vin,
	    VilReceiverRequest receiverRequest) throws DBTransactionException {
	Instant start = Instant.now();
	nodeStatusCodeMap.forEach((key, value) -> log.debug("domainStatusTracker::Node-" + key + " status-" + value));
	Map<String, String> validNodeList = nodeStatusCodeMap.entrySet().stream()
		.filter(entry -> entry.getValue().equals(VilConstants.VALID_NODE_STATUS))
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
	persistVilMessageNodeStatus(validNodeList, receiverRequest);
	pushToSplunk(vin, traceId, nodeStatusCodeMap, start);
    }

    /**
     * Inserts ModuleNodeType records into 03 table and push node status to Splunk
     * for tracking & monitoring purpose.
     *
     * @param moduleNodeStatusMap Map of nodeAddress & status entries.
     * @param receiverRequest     02 table record, acts as foreign key for
     **/
    private void persistVilMessageNodeStatus(Map<String, String> moduleNodeStatusMap,
	    VilReceiverRequest receiverRequest) throws DBTransactionException {
	Instant start = Instant.now();
	try {
	    if (moduleNodeStatusMap != null && !moduleNodeStatusMap.isEmpty()) {
		List<VilMessageNodeStatus> payloadNodeStatusList = new ArrayList<>();
		moduleNodeStatusMap.forEach((node, status) -> {
		    VilMessageNodeStatus nodeStatus = DBEntityBuilder.buildPayloadNodeStatusEntity(node,
			    receiverRequest.getVilMessageRecordId(), status);
		    payloadNodeStatusList.add(nodeStatus);
		});
		payloadNodeStatusList.forEach(nodeStatus -> log.info(
			"Before persisting node - vin-{}, traceId-{}, address-{}, status-{}", receiverRequest.getVin(),
			receiverRequest.getTraceId(), nodeStatus.getNodeAddress(), nodeStatus.getStatus()));
		nodeStatusRepository.saveAll(payloadNodeStatusList);
	    }
	} catch (Exception e) {
	    log.error("ModuleStateValidationRespHandler:received exception while persisting Node Status -" + e);
	    Instant end = Instant.now();
	    splunkUtils.postErrorEvent(receiverRequest.getVin(), receiverRequest.getTraceId(), "DB_ERR", e.getMessage(),
		    VilConstants.MODULE_INFO_NODE_PROCESSOR, null, Duration.between(start, end).toMillis());
	    vilMessageRepository.updateStatusById("DB_ERR", receiverRequest.getVilMessageRecordId());
	    throw new DBTransactionException(e.getMessage());
	}
    }

    /**
     * Common method to publish Splunk events
     *
     * @param vin               Vehicle Identification Number is primary
     *                          identification field
     * @param traceId           unique UUID to trace specific VIL request
     * @param nodeStatusCodeMap Map of nodeAddress & status entries.
     * @param start             Instant class which used to calculate method
     *                          processed time
     **/
    private void pushToSplunk(String vin, String traceId, Map<String, String> nodeStatusCodeMap, Instant start) {
	Instant end = Instant.now();
	nodeStatusCodeMap.forEach((node, status) -> splunkUtils.postInfoEvent(vin, traceId, status,
		VilConstants.MODULE_INFO_NODE_PROCESSOR, node, Duration.between(start, end).toMillis()));
    }

    /**
     * Validates domainStatusTracker with user-defined logics to remove failed nodes
     * from snap request.
     *
     * @param domainStatusTracker object to build detail for matched network
     **/
    // Skipping NETWORK_MISMATCH for VIL
    private Map<String, String> getNodeStatusCodeMap(Map<String, DomainStatusTracker> domainStatusTracker) {
	Map<String, String> nodeStatusCodeMap = new HashMap<>();
	domainStatusTracker.forEach((key, statusTracker) -> {
	    String status;
	    if (!statusTracker.isNodePresentInODL()) {
		status = VilConstants.NODE_NOT_PRESENT_STATUS;
	    } else if (!statusTracker.isDAPassed()) {
		status = VilConstants.DA_PASSED_STATUS;
	    } else if (statusTracker.isDuplicateDIDFound()) {
		status = VilConstants.DUPLICATE_DID_FOUND_STATUS;
	    } else {
		status = VilConstants.VALID_NODE_STATUS;
	    }
	    nodeStatusCodeMap.put(key, status);
	    if (!statusTracker.getAssociatedNodes().isEmpty())
		statusTracker.getAssociatedNodes().forEach(node -> nodeStatusCodeMap.put(node, status));
	});
	return nodeStatusCodeMap;
    }

}
