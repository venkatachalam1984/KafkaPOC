package com.ford.gvmsr.receiver.constant;

public class VilExceptionConstants {

    public static final String KAFKA_HEADER_NOT_FOUND = " header not found in Kafka message";
    public static final String EMPTY_VALID_NODE_LIST = "No valid nodes are present for VIN - ";
    public static final String DID_NOT_PRESENT_F111_F113 = "Mandatory DIDs [F111 & F113] are not present";
    public static final String VALID_DID_NOT_PRESENT = "Valid DIDs are not present";
    public static final String EMPTY_VALID_NODES = "Valid node list is empty";
}
