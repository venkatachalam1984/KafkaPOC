package com.ford.gvmsr.receiver.serialize;

import java.io.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.buffer.Buffer;
import io.vertx.core.eventbus.MessageCodec;

public class GenericCodec<T> implements MessageCodec<T, T> {
    private final Class<T> cls;

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public GenericCodec(Class<T> cls) {
	super();
	this.cls = cls;
    }

    @Override
    public void encodeToWire(Buffer buffer, T s) {
	try (ByteArrayOutputStream bos = new ByteArrayOutputStream(); ObjectOutput out = new ObjectOutputStream(bos)) {
	    out.writeObject(s);
	    out.flush();
	    byte[] yourBytes = bos.toByteArray();
	    buffer.appendInt(yourBytes.length);
	    buffer.appendBytes(yourBytes);
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    @Override
    public T decodeFromWire(int pos, Buffer buffer) {
	int _pos = pos;
	int length = buffer.getInt(_pos);
	byte[] yourBytes = buffer.getBytes(_pos += 4, _pos += length);
	try (ByteArrayInputStream bis = new ByteArrayInputStream(yourBytes);
		ObjectInputStream ois = new ObjectInputStream(bis)) {
	    T msg = (T) ois.readObject();
	    return msg;
	} catch (IOException | ClassNotFoundException e) {
	    log.debug("Listen failed " + e.getMessage());
	}
	return null;
    }

    @Override
    public T transform(T customMessage) {
	return customMessage;
    }

    @Override
    public String name() {
	return cls.getSimpleName() + "Codec";
    }

    @Override
    public byte systemCodecID() {
	return -1;
    }
}
