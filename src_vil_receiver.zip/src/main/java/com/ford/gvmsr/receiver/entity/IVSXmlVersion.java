package com.ford.gvmsr.receiver.entity;

import java.sql.Timestamp;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class IVSXmlVersion {

    private String programCode;
    private float salesModelYear;
    private Timestamp xmlLastProcessedTime;
    private int xmlVersion;
    private String createdUser;
    private Timestamp createdTime;
    private String lastUpdatedUser;
    private Timestamp lastUpdatedTime;
}
