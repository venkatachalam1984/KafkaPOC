package com.ford.gvmsr.receiver.splunk;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AppLogEvent {

    private String vin;
    private String traceId;
    private String status;
    private String type;
    private long timeStamp;
    private long duration;
    private String node;
    private String exception;

}
