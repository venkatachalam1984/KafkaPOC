
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "key-1",
    "key-N"
})
public class Additionalprops {

    @JsonProperty("key-1")
    private String key1;
    @JsonProperty("key-N")
    private String keyN;
    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("key-1")
    public String getKey1() {
        return key1;
    }

    @JsonProperty("key-1")
    public void setKey1(String key1) {
        this.key1 = key1;
    }

    @JsonProperty("key-N")
    public String getKeyN() {
        return keyN;
    }

    @JsonProperty("key-N")
    public void setKeyN(String keyN) {
        this.keyN = keyN;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
