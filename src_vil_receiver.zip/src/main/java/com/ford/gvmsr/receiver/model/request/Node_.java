
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "address",
    "ecuAcronym",
    "esn",
    "specificationCategory",
    "odlNetwork",
    "did",
    "pecificationCategory"
})
public class Node_ {

    @JsonProperty("address")
    private String address;
    @JsonProperty("ecuAcronym")
    private String ecuAcronym;
    @JsonProperty("esn")
    private String esn;
    @JsonProperty("specificationCategory")
    private String specificationCategory;
    @JsonProperty("odlNetwork")
    private OdlNetwork_ odlNetwork;
    @JsonProperty("did")
    private List<Did_> did = null;
    @JsonProperty("pecificationCategory")
    private String pecificationCategory;
    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("address")
    public String getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(String address) {
        this.address = address;
    }

    @JsonProperty("ecuAcronym")
    public String getEcuAcronym() {
        return ecuAcronym;
    }

    @JsonProperty("ecuAcronym")
    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    @JsonProperty("esn")
    public String getEsn() {
        return esn;
    }

    @JsonProperty("esn")
    public void setEsn(String esn) {
        this.esn = esn;
    }

    @JsonProperty("specificationCategory")
    public String getSpecificationCategory() {
        return specificationCategory;
    }

    @JsonProperty("specificationCategory")
    public void setSpecificationCategory(String specificationCategory) {
        this.specificationCategory = specificationCategory;
    }

    @JsonProperty("odlNetwork")
    public OdlNetwork_ getOdlNetwork() {
        return odlNetwork;
    }

    @JsonProperty("odlNetwork")
    public void setOdlNetwork(OdlNetwork_ odlNetwork) {
        this.odlNetwork = odlNetwork;
    }

    @JsonProperty("did")
    public List<Did_> getDid() {
        return did;
    }

    @JsonProperty("did")
    public void setDid(List<Did_> did) {
        this.did = did;
    }

    @JsonProperty("pecificationCategory")
    public String getPecificationCategory() {
        return pecificationCategory;
    }

    @JsonProperty("pecificationCategory")
    public void setPecificationCategory(String pecificationCategory) {
        this.pecificationCategory = pecificationCategory;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
