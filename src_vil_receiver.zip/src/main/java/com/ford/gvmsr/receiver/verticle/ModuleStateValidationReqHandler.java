package com.ford.gvmsr.receiver.verticle;

import java.time.Duration;
import java.time.Instant;

import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.domain.modulestate.exception.ModuleStateValidationException;
import com.ford.gvmsr.domain.modulestate.metadata.request.IVSProgramId;
import com.ford.gvmsr.domain.modulestate.model.request.ModuleStateRequest;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStateResponse;
import com.ford.gvmsr.domain.modulestate.validator.Executor;
import com.ford.gvmsr.receiver.builder.ModuleStateRequestBuilder;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.constant.VilExceptionConstants;
import com.ford.gvmsr.receiver.exception.DomainValidationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.external.VinReceiverServiceAdapter;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.repository.IVilMessageRepository;
import com.ford.gvmsr.receiver.repository.impl.VehicleRepository;
import com.ford.gvmsr.receiver.repository.impl.VilMessageRepository;
import com.ford.gvmsr.receiver.util.BeanUtil;
import com.ford.gvmsr.receiver.util.JsonUtils;
import com.ford.gvmsr.receiver.util.SplunkUtils;
import com.ford.gvmsr.receiver.util.VilUtils;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.Message;

public class ModuleStateValidationReqHandler extends AbstractVerticle {

    private final Integer index;
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private VehicleRepository vehicleRepository;
    private SplunkUtils splunkUtils;
    private ModuleStateRequestBuilder moduleStateRequestBuilder;
    private Executor executor;
    private IVilMessageRepository vilMessageRepository;
    private VinReceiverServiceAdapter vinReceiverServiceAdapter;

    public ModuleStateValidationReqHandler(Integer index) {
	this.index = index;
    }

    /**
     * Initialize dependent beans that uniquely matches the given object type, if
     * any.
     */
    public void initializeDependentAutowiredBeans() {
	this.splunkUtils = BeanUtil.getBean(splunkUtils, SplunkUtils.class);
	this.moduleStateRequestBuilder = BeanUtil.getBean(moduleStateRequestBuilder, ModuleStateRequestBuilder.class);
	this.executor = BeanUtil.getBean(executor, Executor.class);
	this.vehicleRepository = BeanUtil.getBean(vehicleRepository, VehicleRepository.class);
	this.vilMessageRepository = BeanUtil.getBean(vilMessageRepository, VilMessageRepository.class);
	this.vinReceiverServiceAdapter = BeanUtil.getBean(vinReceiverServiceAdapter, VinReceiverServiceAdapter.class);
    }

    /**
     * Start the verticle instance. Vert.x calls this method when deploying the
     * instance. You do not call it yourself.
     **/
    @Override
    public void start() {
	log.debug("Deployed ModuleStateValidationReqHandler verticle with index = {} ", index);
	vertx.eventBus().consumer(VilConstants.DOMAIN_STATE_VALIDATION_HANDLER + index,
		this::moduleStateValidationHandler);
	initializeDependentAutowiredBeans();
    }

    /**
     * Performs Domain state validation and sends exception event JSON to GIVIS
     * topic for sync-up. If any validation exception thrown status will be updated
     * in 02 Table.
     * 
     * @param message Message represents data shared through Event-Bus.
     **/
    public void moduleStateValidationHandler(Message<Object> message) {
	Instant start = Instant.now();
	VilReceiverRequest request = (VilReceiverRequest) message.body();
	log.info("ModuleStateValidationReqHandler:received VIN = {} at index = {} ", request.getVin(), index);
	try {
	    Integer vinModHash = VilUtils.getVinModHash(request.getVin());
	    applyDomainStateValidations(request);
	    if (!request.isRetryVilFlagEnabled()) {
		vertx.eventBus().send(VilConstants.IVS_EXCEPTION_EVENT_PROC, request);
	    }
	    String domainValidatorRespAddr = VilConstants.DOMAIN_VALIDATION_RESP_PROC + vinModHash;
	    log.info("Verticle name={}, for VIN={}", domainValidatorRespAddr, request.getVin());
	    vertx.eventBus().send(domainValidatorRespAddr, request);
	} catch (DomainValidationException | ModuleStateValidationException e) {
	    log.error("ModuleStateValidationReqHandler:received ModuleStateValidation exception - " + e);
	    updateVilMessageFailedStatus(request, VilConstants.DOMAIN_VALIDATION_F, e, start);
	} catch (VILValidationException e) {
	    log.error("ModuleStateValidationReqHandler:received VILValidationException exception - " + e);
	    updateVilMessageFailedStatus(request, VilConstants.INVALID_VIL, e, start);
	} catch (Exception e) {
	    log.error("ModuleStateValidationReqHandler:received runtime exception - " + e);
	    updateVilMessageFailedStatus(request, VilConstants.RUNTIME_FAILURE, e, start);
	}
    }

    /**
     * Updating a Vil Message record with failed status in 02 table and exception
     * details will be sent to Splunk. Record will be identified by VIN & TraceID.
     *
     * @param request Custom POJO to maintain VIN level data
     * @param e       exception class to trace the failure reason
     * @param start   Instant class which used to calculate method processed time
     * @param status  Status to be updated in DB/Splunk for specific VIN
     */
    private void updateVilMessageFailedStatus(VilReceiverRequest request, String status, Exception e, Instant start) {
	vilMessageRepository.updateStatusById(status, request.getVilMessageRecordId());
	Instant end = Instant.now();
	splunkUtils.postErrorEvent(request.getVin(), request.getTraceId(), status, e.getMessage(),
		VilConstants.DOMAIN_VAL_REQ_HANDLER, null, Duration.between(start, end).toMillis());
    }

    /**
     * Prepares ModuleStateRequest from VilReceiverRequest and send it to Module
     * State Validator for Domain validation checks. If caught any runtime exception
     * Record will be updated as 'DVF'
     * 
     * @param request Custom POJO to maintain VIN level data
     * @throws ModuleStateValidationException
     * @throws DomainValidationException
     * @throws JsonProcessingException
     */
    public void applyDomainStateValidations(VilReceiverRequest request) throws DomainValidationException,
	    ModuleStateValidationException, JsonProcessingException, VILValidationException {
	Instant start = Instant.now();
	String vin = request.getVin();
	String traceId = request.getTraceId();
	ModuleStateRequest moduleStateRequest = moduleStateRequestBuilder.build(request, traceId);
	if (moduleStateRequest.getModuleSnapshot().getNode().isEmpty())
	    throw new VILValidationException(VilExceptionConstants.EMPTY_VALID_NODE_LIST + request.getVin());
	Instant end = Instant.now();
	splunkUtils.postInfoEvent(vin, traceId, VilConstants.IN_DOMAIN_VAL, VilConstants.DOMAIN_VAL_REQ_HANDLER, null,
		Duration.between(start, end).toMillis());
	DomainStateResponse response = executeModuleStateValidation(request, moduleStateRequest);
	request.setStateResponse(response);
    }

    /**
     * Method to push Module State validator to perform Domain-Validations.
     *
     * @param request            Custom POJO to maintain VIN level data
     * @param moduleStateRequest Object to hold VIL data for domain validations.
     * @return
     * @throws ModuleStateValidationException
     * @throws DomainValidationException
     * @throws JsonProcessingException
     */
    private DomainStateResponse executeModuleStateValidation(VilReceiverRequest request,
	    ModuleStateRequest moduleStateRequest)
	    throws ModuleStateValidationException, DomainValidationException, JsonProcessingException {
	Instant start = Instant.now();
	IVSProgramId ivsProgramId = request.getIvsProgramId();
	log.debug("Module State validator request JSON-" + JsonUtils.getJsonString(moduleStateRequest));
	DomainStateResponse domainStateResponse = executor.validate(moduleStateRequest, ivsProgramId, null);
	Instant end = Instant.now();
	log.info("Module State validator execution time={} ms, for VIN={}", Duration.between(start, end).toMillis(),
		request.getVin());
	if (ObjectUtils.anyNull(domainStateResponse, domainStateResponse.getModuleStateRequest(),
		domainStateResponse.getDomainStatusTracker()) || domainStateResponse.getDomainStatusTracker().isEmpty())
	    throw new DomainValidationException("Received Invalid/Null response from DomainStateValidator - "
		    + JsonUtils.getJsonString(domainStateResponse));
	log.debug("Module State validator response JSON-" + JsonUtils.getJsonString(domainStateResponse));
	return domainStateResponse;
    }

}
