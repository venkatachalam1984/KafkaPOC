package com.ford.gvmsr.receiver.repository;

import com.ford.gvmsr.receiver.entity.VilMessageNodeIVSFError;

import java.util.List;

public interface IIVSFErrorMessageNodeRepository {
    void saveAll(List<VilMessageNodeIVSFError> vilMessageNodeIVSFErrors);
}
