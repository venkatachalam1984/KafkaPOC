package com.ford.gvmsr.receiver.metrics;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.kafka.consumer.GVMSRVilConsumer;
import com.ford.gvmsr.receiver.kafka.consumer.ReOrderedVilConsumer;
import com.ford.gvmsr.receiver.model.metrics.KafkaPartitionTopicLag;
import com.ford.gvmsr.receiver.splunk.KafkaLogEvent;
import com.ford.gvmsr.receiver.util.SplunkUtils;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.kafka.admin.KafkaAdminClient;
import io.vertx.kafka.client.common.PartitionInfo;
import io.vertx.kafka.client.common.TopicPartition;
import io.vertx.kafka.client.consumer.KafkaConsumer;
import io.vertx.kafka.client.consumer.OffsetAndMetadata;

@Component
public class KafkaPartitionTopicLagMetricsHandler extends AbstractVerticle {

    final GVMSRVilConsumer gvmsrVilConsumer;
    final PropertiesConfig config;
    final ReOrderedVilConsumer reOrderedVilconsumer;
    final SplunkUtils splunkUtils;
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    KafkaAdminClient adminClient = null;

    public KafkaPartitionTopicLagMetricsHandler(PropertiesConfig config, ReOrderedVilConsumer consumer,
	    GVMSRVilConsumer gvmsrVilConsumer, SplunkUtils splunkUtils) {
	this.config = config;
	this.reOrderedVilconsumer = consumer;
	this.gvmsrVilConsumer = gvmsrVilConsumer;
	this.splunkUtils = splunkUtils;
    }

    @Override
    public void start() {
	registerKafkaAdmin();
	vertx.setPeriodic(config.getKafkaPartitionLagMetricsIntervalMs(), handler -> {
//	    loadConsumerTopicPartitionAndEndOffsetMap(gvmsrVilConsumer.getVilConsumer(), config.getVilConsumerTopic(), config.getVilConsumerGroup());
	    loadConsumerTopicPartitionAndEndOffsetMap(reOrderedVilconsumer.getLogConsumer(), config.getLogConsumerTopic(), config.getLogConsumerGroup());
	});
    }

    public void registerKafkaAdmin() {
	Properties config2 = new Properties();
	config2.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getVilKafkaBrokerEndpoints());
	config2.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_PLAINTEXT");
	adminClient = KafkaAdminClient.create(vertx, config2);
    }

    public void loadConsumerTopicPartitionAndEndOffsetMap(KafkaConsumer<String, String> consumer, String topic,
	    String group) {
	Map<TopicPartition, Long> topicPartitionInfoMap = new HashMap<>();
	consumer.partitionsFor(topic, handler -> {
	    if (handler.succeeded()) {
		List<PartitionInfo> partitionInfoList = handler.result();
		partitionInfoList.forEach(partitionInfo -> {
		    TopicPartition topicPartition = new TopicPartition(topic, partitionInfo.getPartition());
		    log.debug("PartitionInfo - " + partitionInfo.getPartition() + "-" + partitionInfo.getTopic());
		    Future<Long> endOffsetFuture = consumer.endOffsets(topicPartition);
		    endOffsetFuture.onComplete(eventHandler -> {
			if (eventHandler.succeeded()) {
			    log.debug("Topic-{}, Partition={}, EndOffset-{}", topic, partitionInfo.getPartition(), eventHandler.result());
			    topicPartitionInfoMap.put(topicPartition, endOffsetFuture.result());
			    if (topicPartitionInfoMap.size() == partitionInfoList.size())
				loadConsumerGroupTopicPartitionAndOffsetMeta(topicPartitionInfoMap, topic, group);
			} else {
			    log.error("Exception while fetching Partition endOffset for topic-{}, cause-", topic, eventHandler.cause());
			}
		    });
		});
	    } else {
		log.error("Exception while collecting endOffset metrics- " + handler.cause());
	    }
	});
    }

    public void loadConsumerGroupTopicPartitionAndOffsetMeta(Map<TopicPartition, Long> endOffsetForTopicPartitionMap,
	    String topic, String group) {
	if (endOffsetForTopicPartitionMap.isEmpty()) {
	    log.error("Partition info map is empty for topic -" + topic);
	} else {
	    adminClient.listConsumerGroupOffsets(group, handler -> {
		if (handler.succeeded()) {
		    Map<TopicPartition, OffsetAndMetadata> topicPartitionOffsetMetaMap = handler.result();
		    log.debug("topicPartitionOffsetMetaMap - " + topicPartitionOffsetMetaMap);
		    buildKafkaPartitionTopicLagMetrics(group, topicPartitionOffsetMetaMap,
			    endOffsetForTopicPartitionMap);
		} else {
		    log.error("Exception while collecting consumerGroupOffsets, cause-" + handler.cause());
		}
	    });
	}
    }

    private void buildKafkaPartitionTopicLagMetrics(String group,
	    Map<TopicPartition, OffsetAndMetadata> topicPartitionOffsetMetaMap,
	    Map<TopicPartition, Long> endOffsetForTopicPartitionMap) {
	topicPartitionOffsetMetaMap.entrySet().forEach(topicPartitionOffsetAndMetadataEntry -> {
	    TopicPartition topicPartition = topicPartitionOffsetAndMetadataEntry.getKey();
	    OffsetAndMetadata offsetMeta = topicPartitionOffsetAndMetadataEntry.getValue();
	    String key = topicPartition.getTopic() + "-" + group + "-" + topicPartition.getPartition();
	    int partition = topicPartition.getPartition();
	    long currentOffset = offsetMeta.getOffset();
	    Long endOffset = endOffsetForTopicPartitionMap.get(topicPartition);
	    log.debug("key-{} ,partition-{}, currentOffset-{}, endOffset-{}", key, partition, currentOffset, endOffset);
	    KafkaPartitionTopicLag kafkaPartitionTopicLag = KafkaPartitionTopicLag.builder()
		    .key(topicPartition.getTopic() + "-" + group + "-" + topicPartition.getPartition())
		    .topic(topicPartition.getTopic()).group(group).partition(topicPartition.getPartition())
		    .currentOffset(currentOffset).endOffset(endOffset).lastUpdatedTime(Instant.now().toString())
		    .build();
	    printKafkaPartitionTopicLagMetrics(kafkaPartitionTopicLag);
	});
    }

    private void printKafkaPartitionTopicLagMetrics(KafkaPartitionTopicLag kafkaPartitionTopicLag) {
	KafkaLogEvent kafkaLogEvent = KafkaLogEvent.builder().currentOffset(kafkaPartitionTopicLag.getCurrentOffset())
		.endOffset(kafkaPartitionTopicLag.getEndOffset()).partition(kafkaPartitionTopicLag.getPartition())
		.topic(kafkaPartitionTopicLag.getTopic()).build();
	splunkUtils.pushSplunkLogEvent(kafkaLogEvent, VilConstants.KAFKA_TOPIC_LAG);
	/*
	String kafkaPartitionTopicLagJson = JsonUtils.getJsonString(kafkaPartitionTopicLag);
	log.info("Kafka metrics JSON-" + kafkaPartitionTopicLagJson);
	*/
    }

}
