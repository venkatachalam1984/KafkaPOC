package com.ford.gvmsr.receiver.kafka.consumer;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.constant.VilExceptionConstants;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.repository.IVilMessageRepository;
import com.ford.gvmsr.receiver.repository.impl.VilMessageRepository;
import com.ford.gvmsr.receiver.splunk.KafkaLogEvent;
import com.ford.gvmsr.receiver.util.SplunkUtils;
import com.ford.gvmsr.receiver.util.VilUtils;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.DeliveryOptions;
import io.vertx.kafka.client.common.TopicPartition;
import io.vertx.kafka.client.consumer.KafkaConsumer;
import io.vertx.kafka.client.consumer.KafkaConsumerRecord;
import io.vertx.kafka.client.producer.KafkaHeader;

@Component
public class ReOrderedVilConsumer extends AbstractVerticle {

    final SplunkUtils splunkUtils;
    final PropertiesConfig config;
    final IVilMessageRepository vilMessageRepository;
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    KafkaConsumer<String, String> consumer;

    Map<TopicPartition, Long> topicPartitionInfoMap = new HashMap<>();

    public ReOrderedVilConsumer(PropertiesConfig config, VilMessageRepository vilMessageRepository,
	    SplunkUtils splunkUtils) {
	this.config = config;
	this.vilMessageRepository = vilMessageRepository;
	this.splunkUtils = splunkUtils;
    }

    /**
     * Start the verticle instance. Vert.x calls this method when deploying the
     * instance. You do not call it yourself.
     **/
    @Override
    public void start() {
	KafkaConsumer<String, String> consumer = registerReorderVilConsumer();
	subscribeToReorderVilTopic(consumer, config.getLogConsumerTopic());
    }

    /**
     * Create a new KafkaConsumer instance
     *
     * @return an instance of the KafkaConsumer
     */
    KafkaConsumer<String, String> registerReorderVilConsumer() {
	try {
	    Properties props = new Properties();
	    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getLogKafkaBrokerEndpoints());
	    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
	    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
	    props.put(ConsumerConfig.GROUP_ID_CONFIG, config.getLogConsumerGroup());
	    props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, config.getLogOffsetResetMode());
	    props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, config.getLogMaxPollRecords());
	    props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, config.isLogAutoCommitOffset());
	    props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, config.getLogProtocolConfig());
	    consumer = KafkaConsumer.create(vertx, props);
	} catch (Exception e) {
	    log.error("Exception while registering Log consumer -" + e);
	}
	return consumer;
    }

    /**
     * Subscribe to the given topic to get dynamically assigned partitions.
     *
     * @param topic    topic to subscribe to
     * @param consumer KafkaConsumer instance
     **/
    private void subscribeToReorderVilTopic(KafkaConsumer<String, String> consumer, String topic) {
	consumer.handler(this::reOrderedKafkaMessageHandler);
	consumer.subscribe(topic, handler -> {
	    if (handler.succeeded()) {
		log.info("Subscribed {} successfully", topic);
	    }
	});
    }

    /**
     * consume vil message inputs and updating current record's partition & offset
     * keys
     *
     * @param record Kafka consumer record
     */
    private void reOrderedKafkaMessageHandler(KafkaConsumerRecord<String, String> record) {
	Instant start = Instant.now();
	int partition = record.partition();
	Long offset = record.offset();
	String vin = record.key();
	String traceId = null;
	String vilMessageId = null;
	String requestType;
	try {
		postKafkaLogEvent(vin,record);
	    traceId = findHeaderValueForKey(record.headers(), VilConstants.TRACE_ID_KEY)
		    .orElseThrow(() -> new VILValidationException(
			    VilConstants.TRACE_ID_KEY + VilExceptionConstants.KAFKA_HEADER_NOT_FOUND));
	    vilMessageId = findHeaderValueForKey(record.headers(), VilConstants.VIL_MESSAGE_RECORD_ID)
		    .orElseThrow(() -> new VILValidationException(
			    VilConstants.VIL_MESSAGE_RECORD_ID + VilExceptionConstants.KAFKA_HEADER_NOT_FOUND));
		requestType = findHeaderValueForKey(record.headers(), VilConstants.REQUEST_TYPE)
		    .orElseThrow(() -> new VILValidationException(
			    VilConstants.REQUEST_TYPE + VilExceptionConstants.KAFKA_HEADER_NOT_FOUND));
	    if (requestType.equals(VilConstants.NEW_VIL)) {
		vilMessageRepository.updatePartitionAndOffsetAndStatusById(VilConstants.ORDERED_VIL, partition, offset, vilMessageId);
		pushToVILValidatorByVinHashLookUp(record.value(), vin, vilMessageId, traceId);
	    } else {
		DeliveryOptions options = new DeliveryOptions().addHeader(VilConstants.RECORD_KEY, vilMessageId)
			.addHeader(VilConstants.PARTITION_KEY, vin).addHeader(VilConstants.TRACE_ID_KEY, traceId);
		vertx.eventBus().send(VilConstants.RETRY_VIL_VALIDATOR_VERTICLE, record.value(), options);
	    }
	    consumer.commit(event -> {
		if (event.succeeded()) {
		    log.info("ReOrdered Consumer - Committed offset-{}, for vin={} ", record.offset(), vin);
		}
	    });
	    Instant end = Instant.now();
	    splunkUtils.postInfoEvent(vin, traceId, VilConstants.ORDERED_VIL, VilConstants.GVMSR_LOG_CONSUMER, null,
		    Duration.between(start, end).toMillis());
	} catch (Exception e) {
	    log.error("ReOrderedVIL:received exception at VilConsumer =" + e.getMessage());
	}
    }

    private void postKafkaLogEvent(String vin, KafkaConsumerRecord<String, String> record) {
	log.info("ReOrderedVIL:received VIN={}, Published TS={}, Consumed TS={}, Partition = {}", vin,
		Instant.ofEpochMilli(record.timestamp()).toString(), Instant.now().toString(), record.partition());
	KafkaLogEvent kafkaLogEvent = KafkaLogEvent.builder().vin(vin)
		.consumedTime(new Timestamp(System.currentTimeMillis()).getTime()).producedTime(record.timestamp())
		.topic(record.topic()).partition(record.partition()).build();
	splunkUtils.pushSplunkLogEvent(kafkaLogEvent, VilConstants.KAFKA_MESSAGE_QUEUE_DELAY);
    }

	private Optional<String> findHeaderValueForKey(List<KafkaHeader> headers, String key) {
	String value = null;
	for (KafkaHeader kafkaHeader : headers) {
	    if (kafkaHeader.key().equals(key)) {
		value = kafkaHeader.value().toString();
	    }
	}
	return Optional.ofNullable(value);
    }

    /**
     * Publish request across multiple snap validator worker verticles based on
     * vinHashLookUpKey
     *
     * @param message      Kafka Log request
     * @param vin          Vehicle Identification Number used as primary
     *                     identification
     * @param vilMessageId 02 table record id
     * @param traceId      unique UUID to trace specific VIL request
     */
    private void pushToVILValidatorByVinHashLookUp(String message, String vin, String vilMessageId, String traceId) {
	DeliveryOptions options = new DeliveryOptions().addHeader(VilConstants.TRACE_ID_KEY, traceId)
		.addHeader(VilConstants.PARTITION_KEY, vin).addHeader(VilConstants.VIL_MESSAGE_RECORD_ID, vilMessageId);
	String validatorName = VilConstants.LOG_VALIDATOR_PREFIX + VilUtils.getVinModHash(vin);
	log.info("Verticle name={}, for VIN={}", validatorName, vin);
	vertx.eventBus().send(validatorName, message, options);
    }

    public KafkaConsumer<String, String> getLogConsumer() {
	return this.consumer;
    }
}
