package com.ford.gvmsr.receiver.repository.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ford.gvmsr.receiver.entity.VilMessageNodeStatus;
import com.ford.gvmsr.receiver.repository.IVilMessageNodeStatusRepository;

@Repository
public class VilMessageNodeStatusRepository implements IVilMessageNodeStatusRepository {

    static String insertVilMessageNodeStatusQuery = "insert into PGVMR03_VIL_MSG_NODE_STS (GVMR02_VIL_MSG_K, GVMR03_NODE_ADRS_C,GVMR03_PRCS_STAT_C,GVMR03_PRCS_STAT_S,GVMR03_CREATE_USER_C,GVMR03_CREATE_S,GVMR03_LAST_UPDT_USER_C,GVMR03_LAST_UPDT_S) "
	    + "values(?,?,?,?,?,?,?,?)";
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private final JdbcTemplate jdbcTemplate;

    public VilMessageNodeStatusRepository(DataSource dataSource) {
	jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void saveAll(List<VilMessageNodeStatus> payloadNodeStatusList) {
	int[][] updatedCount = batchInsert(payloadNodeStatusList, payloadNodeStatusList.size());
	log.info("PayloadNodeStatus - list size-{}, updatedCount-{}", payloadNodeStatusList.size(), Arrays.deepToString(updatedCount));
    }

    public int[][] batchInsert(List<VilMessageNodeStatus> vilMessageNodeStatusList, int batchSize) {
	int[][] updateCounts = jdbcTemplate.batchUpdate(insertVilMessageNodeStatusQuery, vilMessageNodeStatusList,
		batchSize, (ps, nodeStatus) -> setPreparedStatement(ps, nodeStatus));
	return updateCounts;
    }

    private void setPreparedStatement(PreparedStatement ps, VilMessageNodeStatus nodeStatus) throws SQLException {
	ps.setLong(1, nodeStatus.getVilMessageId());
	ps.setString(2, nodeStatus.getNodeAddress());
	ps.setString(3, nodeStatus.getStatus());
	ps.setTimestamp(4, nodeStatus.getCapturedTime());
	ps.setString(5, nodeStatus.getCreatedUser());
	ps.setTimestamp(6, nodeStatus.getCreatedTime());
	ps.setString(7, nodeStatus.getLastUpdatedUser());
	ps.setTimestamp(8, nodeStatus.getLastUpdatedTime());
    }
}
