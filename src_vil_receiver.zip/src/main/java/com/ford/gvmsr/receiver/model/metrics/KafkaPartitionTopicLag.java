package com.ford.gvmsr.receiver.model.metrics;

import lombok.Builder;
import lombok.ToString;

@ToString
@Builder
public class KafkaPartitionTopicLag {
    private final String key;
    private final String topic;
    private final String group;
    private final int partition;
    private final long currentOffset;
    private final long endOffset;
    private final String lastUpdatedTime;

    public String getKey() {
	return key;
    }

    public String getTopic() {
	return topic;
    }

    public String getGroup() {
	return group;
    }

    public int getPartition() {
	return partition;
    }

    public long getCurrentOffset() {
	return currentOffset;
    }

    public long getEndOffset() {
	return endOffset;
    }

    public String getLastUpdatedTime() {
	return lastUpdatedTime;
    }
}
