package com.ford.gvmsr.receiver.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.Did;
import com.ford.gvmsr.receiver.model.request.Node;
import com.ford.gvmsr.receiver.model.request.VIL;

public class VilRedundantNodeValidator extends BaseValidator {

    private final Logger log = LoggerFactory.getLogger(VilRedundantNodeValidator.class);

    public VilRedundantNodeValidator(BaseValidator next) {
	super(next);
    }

    public static boolean isRedundantNodeFound(List<Node> nodes) {
	boolean isRedundantNodeFound = false;
	List<String> nodeAddressList = new ArrayList<>();
	for (Node node : nodes) {
	    String nodeAddress = node.getAddress();
	    if (nodeAddressList.contains(nodeAddress)) {
		isRedundantNodeFound = true;
		break;
	    } else {
		nodeAddressList.add(nodeAddress);
	    }
	}
	return isRedundantNodeFound;
    }

    public static List<Node> findAndRemoveRedundantNodes(List<Node> nodes) {
	HashMap<String, Node> redundantNodeMap = new HashMap<>();
	List<Node> nodeArrayList = new ArrayList<>();
	for (Node node : nodes) {
	    String nodeAddress = node.getAddress();
	    if (nodeAddress != null && !nodeAddress.isBlank()) {
		// Non redundant Node
		if (!redundantNodeMap.containsKey(nodeAddress)) {
		    redundantNodeMap.put(nodeAddress, node);
		} else {
		    // Redundant node - Process the available DID and place it
		    Node availableNode = redundantNodeMap.get(nodeAddress);
		    Node redundantNode = node;

		    // Make complete list
		    List<Did> completeDidList = new ArrayList<>();
		    completeDidList.addAll(availableNode.getDid());
		    completeDidList.addAll(redundantNode.getDid());

		    HashMap<String, Did> prepareDidMap = new HashMap<>();
		    for (Did did : completeDidList) {
			// Case 3: Instance 1 Did’s (Values are same as Instance1) + More Did’s
			// Case 4: Instance 1 Did’s (Values are different than Instance1) + More Did’s
			// Case 5: Instance 1 Did’s are missing + Other Did’s are reported
			if (!prepareDidMap.containsKey(did.getDidValue())) {
			    prepareDidMap.put(did.getDidValue(), did);
			} else {
			    Did availableDid = prepareDidMap.get(did.getDidValue());
			    Did redundantDid = did;

			    if (redundantDid.getDecodedResponse() != null
				    && !redundantDid.getDecodedResponse().isBlank()) {
				// Case 2: DIDs are the same but values are different
				if (!availableDid.getDecodedResponse().equals(redundantDid.getDecodedResponse())) {
				    prepareDidMap.put(redundantDid.getDidValue(), redundantDid);
				}
			    }
			}
		    }

		    // Update the modified Did
		    if (prepareDidMap.size() > 0) {
			List<Did> updatedDidList = new ArrayList(prepareDidMap.values());
			availableNode.setDid(updatedDidList);

			// Update the modified Node
			redundantNodeMap.put(nodeAddress, availableNode);
		    }
		}
	    }
	}

	if (redundantNodeMap.size() > 0) {
	    for (Map.Entry<String, Node> stringNodeEntry : redundantNodeMap.entrySet()) {
		Map.Entry mapElement = stringNodeEntry;
		nodeArrayList.add((Node) mapElement.getValue());
	    }
	}
	return nodeArrayList;
    }

    public void validate(VilReceiverRequest req) throws VILValidationException {
	VIL vil = req.getVil();
	try {
	    log.info("VilRedundantNodeValidator received req - VIN:" + req.getVin());
	    boolean isRedundantNodeFound = isRedundantNodeFound(vil.getNodes());
	    log.info("is redundant node found ==> " + isRedundantNodeFound);
	    if (isRedundantNodeFound) {
		// Find and Remove redundant nodes
		List<Node> updatedNodes = findAndRemoveRedundantNodes(vil.getNodes());
		log.debug("After Populate Redundant Nodes ===> " + updatedNodes);
		vil.setNodes(updatedNodes);
	    }
	} catch (Exception e) {
	    throw new VILValidationException(e.getMessage());
	}
	log.info(req.getVin() + ": validated by VilRedundantNodeValidator");
    }

    @Override
    public void handleRequest(VilValidationSourceEnum validationSource, VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	if (VilValidationSourceEnum.VIL_REDUNDANT_VALIDATOR == validationSource) {
	    validate(receiverRequest);
	} else {
	    super.handleRequest(validationSource, receiverRequest);
	}
    }

}
