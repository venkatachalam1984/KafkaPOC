package com.ford.gvmsr.receiver.entity;

import lombok.Builder;
import lombok.Data;

import java.sql.Timestamp;

@Data
@Builder
public class VilMessageNodeIVSFError {

    private Long id;
    private Long vilMessageId;
    private String vin;
    private int vinHash;
    private String programCode;
    private float salesModelYear;
    private int retryCount;
    private int processXmlVersion;
    private String nodeAddress;
    private String status;
    private Timestamp capturedTime;
    private String createdUser;
    private Timestamp createdTime;
    private String lastUpdatedUser;
    private Timestamp lastUpdatedTime;

}
