package com.ford.gvmsr.receiver.repository;

import com.ford.gvmsr.receiver.entity.FailedVILMessage;
import org.springframework.stereotype.Repository;

@Repository
public interface IFailedVILMessageRepository {

    long save(FailedVILMessage failedVILMessage);
}
