package com.ford.gvmsr.receiver.exception;

public class VILValidationException extends Exception {

    public VILValidationException(String message) {
        super(message);
    }

}
