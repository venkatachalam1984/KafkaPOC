package com.ford.gvmsr.receiver.verticle;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.builder.DBEntityBuilder;
import com.ford.gvmsr.receiver.builder.DownStreamSyncUpBuilder;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.entity.FailedVILMessage;
import com.ford.gvmsr.receiver.entity.VilMessage;
import com.ford.gvmsr.receiver.exception.DBTransactionException;
import com.ford.gvmsr.receiver.exception.VILDecodeException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.repository.IFailedVILMessageRepository;
import com.ford.gvmsr.receiver.repository.impl.FailedVILMessageRepository;
import com.ford.gvmsr.receiver.repository.impl.VilMessageRepository;
import com.ford.gvmsr.receiver.util.JsonUtils;
import com.ford.gvmsr.receiver.util.SplunkUtils;
import com.ford.gvmsr.receiver.util.VilUtils;
import com.google.common.base.Strings;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.DeliveryOptions;
import io.vertx.core.eventbus.Message;

@Service
public class EncodedVilProcessorVerticle extends AbstractVerticle {

    private final VilMessageRepository vilMessageRepository;
    private final IFailedVILMessageRepository failedVILMessageRepository;
    private final SplunkUtils splunkUtils;
    private final PropertiesConfig properties;

    private final Logger log = LoggerFactory.getLogger(EncodedVilProcessorVerticle.class);

    public EncodedVilProcessorVerticle(SplunkUtils splunkUtils, VilMessageRepository vilMessageRepository,
	    FailedVILMessageRepository failedVILMessageRepository, PropertiesConfig properties) {
	this.splunkUtils = splunkUtils;
	this.failedVILMessageRepository = failedVILMessageRepository;
	this.properties = properties;
	this.vilMessageRepository = vilMessageRepository;
    }

    /**
     * Start the verticle instance. Vert.x calls this method when deploying the
     * instance. You do not call it yourself.
     **/
    @Override
    public void start() {
	vertx.eventBus().consumer(VilConstants.ENCODED_VIL_RECEIVER, this::encodedVilHandler);
    }

    /**
     * Handler will persist VIL Message into 02 table and push message to
     * RE-ORDER_KAFKA_PRODUCER
     *
     * @param message Represents a message that is received from the event bus in a
     *                handler.
     **/
    private void encodedVilHandler(Message<Object> message) {
	String vin = null;
	String traceId = message.headers().get(VilConstants.TRACE_ID_KEY);
	String request = (String) message.body();
	Instant start = Instant.now();
	try {
	    String decodedVIL = VilUtils.decodeVIL(request);
	    vin = JsonUtils.findValueByKey(decodedVIL, VilConstants.VIN_KEY);
		String vilTimeStamp = JsonUtils.findValueByKey(decodedVIL, VilConstants.TIMESTAMP_KEY);
		Timestamp vilTimestamp = new Timestamp(Long.parseLong(vilTimeStamp) * 1000L);
	    log.info("EncodedVilProcessorVerticle:received VIN={},traceId={}", vin, traceId);
	    splunkUtils.postInfoEvent(vin, traceId, VilConstants.VIL_REQ_START, VilConstants.ENCODED_VIL_PROC, null, 0L);
	    long vilMessageRecordId = saveVilMessageIfValid(message, traceId, vin, decodedVIL, vilTimestamp);
	    pushToVilReorderKafkaProducer(vin, traceId, decodedVIL, vilMessageRecordId);
	    Instant end = Instant.now();
	    splunkUtils.postInfoEvent(vin, traceId, VilConstants.NEW_VIL, VilConstants.ENCODED_VIL_PROC, null,
		    Duration.between(start, end).toMillis());
	    message.reply(Boolean.TRUE);
	} catch (VILDecodeException e) {
	    log.error("EncodedVilProcessorVerticle:received VILDecodeException while decode EncodedVIL = " + e);
	    insertFailedEncodedVIL(message, vin, traceId, request, start, e, VilConstants.DECODE_EXCEPTION_VIL);
	} catch (Exception e) {
	    log.error("EncodedVilProcessorVerticle:received exception = " + e);
	    insertFailedEncodedVIL(message, vin, traceId, request, start, e, VilConstants.VALIDATION_ERROR);
	}
    }

    private void insertFailedEncodedVIL(Message<Object> message, String vin, String traceId, String request,
	    Instant start, Exception e, String status) {
	Instant end = Instant.now();
	long failedEncodedVILMessageId = persistFailedEncodedVIL(request);
	if (failedEncodedVILMessageId > 0)
	    message.reply(Boolean.TRUE);
	message.reply(Boolean.FALSE);
	splunkUtils.postErrorEvent(vin, traceId, status, e.getMessage(), VilConstants.ENCODED_VIL_PROC, null,
		Duration.between(start, end).toMillis());
    }

    /**
     * Perform VIL Message 02 table persist operation
     *
     * @param message Represents a message that is received from the event bus in a
     *                handler.
     * @param traceId unique UUID to trace specific VIL request
	 * @param vin     Vehicle Identification Number used as look-up key for Worker
	 * @param request Kafka VIL request
	 * @return
	 */
    private long saveVilMessageIfValid(Message<Object> message, String traceId, String vin, String request,
	    Timestamp vilTimestamp) throws DBTransactionException, VILValidationException {
	if (Strings.isNullOrEmpty(vin) || (vin.length() != 17))
	    throw new VILValidationException("Request is invalid - VIN length is invalid/empty");
	String kafkaPartition = message.headers().get(VilConstants.PARTITION);
	String kafkaOffset = message.headers().get(VilConstants.OFFSET);
	return saveVilMessage(request, vin, traceId, kafkaPartition, kafkaOffset, vilTimestamp);
    }

    /**
     * Store received Vil message into VIL_MSG_PRCS[02] Table. If returned ID is
     * equals 0 then DBTransaction will be thrown
     *
     * @param request Raw VIL request
     * @param vin     Vehicle Identification Number is primary identification field
     * @param traceId unique UUID to trace specific VIL request
     * @param offset  offset to seek inside the topic partition
     **/
    private long saveVilMessage(String request, String vin, String traceId, String partition, String offset,
	    							Timestamp vilTimestamp) throws DBTransactionException {
	long vilMessageId = 0;
	try {
	    VilMessage vilMessage = DBEntityBuilder.buildPayloadEntity(request, traceId, vin, partition, offset, vilTimestamp);
	    vilMessageId = vilMessageRepository.save(vilMessage);
	    if (vilMessageId == 0)
		throw new DBTransactionException("Could not persist VIL request in DB");
	    log.info("Persisted transaction id={} for VIN={}", vilMessageId, vin);
	} catch (Exception e) {
	    log.error("EncodedVilProcessorVerticle:received exception while persist Transaction = "
		    + e.fillInStackTrace());
	    throw new DBTransactionException(e.getMessage());
	}
	return vilMessageId;
    }

    /**
     * Send request to VIL_REORDER_KAFKA_PRODUCER through Vertx EventBus
     *
     * @param vin          Vehicle Identification Number is primary identification
     *                     field
     * @param traceId      unique UUID to trace specific VIL request
     * @param request      Kafka VIL request
     * @param vilMessageId 02 table record id
     */
    private void pushToVilReorderKafkaProducer(String vin, String traceId, String request, long vilMessageId)
	    throws JsonProcessingException {
	DeliveryOptions deliveryOptions = new DeliveryOptions().addHeader(VilConstants.PARTITION_KEY, vin)
		.addHeader(VilConstants.TRACE_ID_KEY, traceId)
		.addHeader(VilConstants.KAFKA_TOPIC, properties.getLogConsumerTopic())
		.addHeader(VilConstants.VIL_MESSAGE_RECORD_ID, String.valueOf(vilMessageId))
		.addHeader(VilConstants.REQUEST_TYPE, VilConstants.NEW_VIL);
	String vilTimeStamp = JsonUtils.findValueByKey(request, VilConstants.TIMESTAMP_KEY);
	String downStreamMessage = DownStreamSyncUpBuilder.build(vin, traceId, request, vilTimeStamp);
	vertx.eventBus().send(VilConstants.KAFKA_REORDER_PRODUCER_VERTICLE, downStreamMessage, deliveryOptions);
	log.debug("VIL pushed to " + VilConstants.KAFKA_REORDER_PRODUCER_VERTICLE);
    }

    /**
     * Persist Decode Failure VILs into FAIL_VIL_MESSAGE[01] table.
     *
     * @param request Kafka VIL request
     */
    private long persistFailedEncodedVIL(String request) {
	try {
	    FailedVILMessage failedVILMessage = DBEntityBuilder.buildFailedVILMessageEntity(request);
	    return failedVILMessageRepository.save(failedVILMessage);
	} catch (Exception e) {
	    log.error("EncodedVilProcessorVerticle:received exception while inserting message into 01 table -" + e);
	}
	return 0L;
    }

}
