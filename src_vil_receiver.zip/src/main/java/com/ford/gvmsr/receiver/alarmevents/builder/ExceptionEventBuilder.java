package com.ford.gvmsr.receiver.alarmevents.builder;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.ford.gvmsr.domain.modulestate.metadata.request.DIDInfo;
import com.ford.gvmsr.domain.modulestate.metadata.request.IVSProgramId;
import com.ford.gvmsr.receiver.alarmevents.ExceptionEventConstants;
import com.ford.gvmsr.receiver.alarmevents.ExceptionEventDetailTO;
import com.ford.gvmsr.receiver.alarmevents.ExceptionEventHeaderTO;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.google.common.base.Strings;

@Component
public class ExceptionEventBuilder {

    public ExceptionEventHeaderTO createExceptionEventHeaderToObject(VilReceiverRequest request, String address, String eventCode,
																	 String desc, List<DIDInfo> partNumberDidList) {
	List<ExceptionEventDetailTO> exceptionEventDetails = new ArrayList<>();
	if (eventCode.equalsIgnoreCase(ExceptionEventConstants.VL01_EVENT_CODE)) {
	    if (partNumberDidList != null) {
		partNumberDidList.forEach(didInfo -> {
		    ExceptionEventDetailTO exceptionEventDetailTO = new ExceptionEventDetailTO("N", address, didInfo.getDid(), didInfo.getDidResp());
		    exceptionEventDetails.add(exceptionEventDetailTO);
		});
	    }
	}
	ExceptionEventDetailTO exceptionEventDetailTO = new ExceptionEventDetailTO("N", address, null, desc);
	exceptionEventDetails.add(exceptionEventDetailTO);
	ExceptionEventHeaderTO exceptionEventHeaderTO = createExceptionEvent(request, "PTS", eventCode, request.getVin() + ";" + address,
		ExceptionEventConstants.ERROR, null, null, false, exceptionEventDetails);
	return exceptionEventHeaderTO;
    }

	public ExceptionEventHeaderTO createExceptionEvent(VilReceiverRequest request, String processingSourceCode,
													   String exceptionEventCode, String processKey, String subprocessKey, String esn, String commentDesc,
													   boolean clobRequired, List<ExceptionEventDetailTO> exceptionEventDetails) {
    IVSProgramId ivsProgramId = request.getIvsProgramId();
	ExceptionEventHeaderTO exceptionEventHeaderTO = new ExceptionEventHeaderTO();
	exceptionEventHeaderTO.setProcessingSourceCode(processingSourceCode);
	exceptionEventHeaderTO.setExceptionEventCode(exceptionEventCode);
	exceptionEventHeaderTO.setProcessKey(processKey);
	exceptionEventHeaderTO.setSubprocessKey(subprocessKey);
	exceptionEventHeaderTO.setVin(request.getVin());
	exceptionEventHeaderTO.setEsn(esn);
	exceptionEventHeaderTO.setSourceSystem(VilConstants.SOURCE_SYS_GVMS);
	exceptionEventHeaderTO.setCommentDescription(Strings.isNullOrEmpty(commentDesc) ? processKey : commentDesc);
	exceptionEventHeaderTO.setProgramCode(ivsProgramId.getProgramCode());
	exceptionEventHeaderTO.setModelYear(ivsProgramId.getSalesModelYear());
	exceptionEventHeaderTO.setClobRequired(clobRequired);
	exceptionEventHeaderTO.setExceptionEventDetailList(exceptionEventDetails);
	return exceptionEventHeaderTO;
    }
}
