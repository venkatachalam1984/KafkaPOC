package com.ford.gvmsr.receiver.validator;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.constant.VilValidationSourceEnum;
import com.ford.gvmsr.receiver.exception.LateVILException;
import com.ford.gvmsr.receiver.exception.VILDuplicationException;
import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.VIL;
import com.ford.gvmsr.receiver.model.response.Error;

public class RawVilConstraintValidator extends BaseValidator {

    private final Logger log = LoggerFactory.getLogger(RawVilConstraintValidator.class);

    public RawVilConstraintValidator(BaseValidator next) {
	super(next);
    }

    public void validate(final VilReceiverRequest req) throws VILValidationException {
	log.info("RawVilConstraintValidator received req - VIN:" + req.getVilRequest().getVin());
	VIL vil = req.getVil();
	List<Error> errorList = req.getErrorList();
	if (vil == null) {
	    throw new VILValidationException("VilRequest validation failed - JSON is null");
	}
	JsonConstraintValidator.validateJson(vil, errorList);
	if (!errorList.isEmpty()) {
	    String errorCause = errorList.stream().map(Error::getExceptionCause).collect(Collectors.joining(","));
	    throw new VILValidationException("VilRequest validation failed - " + errorCause);
	}
	log.info(req.getVilRequest().getVin() + ": validated by RawVilConstraintValidator");
    }

    @Override
    public void handleRequest(VilValidationSourceEnum validationSource, VilReceiverRequest receiverRequest)
	    throws VILValidationException, JsonProcessingException, VILDuplicationException, LateVILException {
	if (VilValidationSourceEnum.RAW_VIL_CONSTRAINT_VALIDATOR == validationSource) {
	    validate(receiverRequest);
	} else {
	    super.handleRequest(validationSource, receiverRequest);
	}
    }
}
