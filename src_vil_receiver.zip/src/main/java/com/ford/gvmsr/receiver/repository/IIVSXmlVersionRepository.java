package com.ford.gvmsr.receiver.repository;

public interface IIVSXmlVersionRepository {

    int findXmlVersionByPCAndMY(String programCode, Float modelYear);
}
