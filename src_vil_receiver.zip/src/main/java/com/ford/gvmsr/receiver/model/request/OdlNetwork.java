
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "dataRate", "name", "protocol" })
public class OdlNetwork {

    @NotNull(message = "OdlNetwork dataRate should not be null")
    @JsonProperty("dataRate")
    private String dataRate;

    @NotNull(message = "OdlNetwork name should not be null")
    @JsonProperty("name")
    private String name;

    @NotNull(message = "OdlNetwork protocol should not be null")
    @JsonProperty("protocol")
    private String protocol;

    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("dataRate")
    public String getDataRate() {
	return dataRate;
    }

    @JsonProperty("dataRate")
    public void setDataRate(String dataRate) {
	this.dataRate = dataRate;
    }

    @JsonProperty("name")
    public String getName() {
	return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
	this.name = name;
    }

    @JsonProperty("protocol")
    public String getProtocol() {
	return protocol;
    }

    @JsonProperty("protocol")
    public void setProtocol(String protocol) {
	this.protocol = protocol;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
    }

}
