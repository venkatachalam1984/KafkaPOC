package com.ford.gvmsr.receiver.repository.impl;

import com.ford.gvmsr.receiver.entity.VilMessageNodeIVSFError;
import com.ford.gvmsr.receiver.repository.IIVSFErrorMessageNodeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

@Repository
public class IVSFMessageNodeStatusRepository implements IIVSFErrorMessageNodeRepository {

    static String insertVilMessageNodeStatusQuery = "insert into PGVMR07_VIL_MSG_NODE_IVSF_ERR (GVMR02_VIL_MSG_K, GVMR07_VIN_R, GVMR07_VIN_HASH_R, GVMR07_PROGRAM_C,GVMR07_SALES_MODEL_YEAR_C,GVMR07_RETRY_T," +
            "GVMR07_PRCS_XML_VERSION_R,GVMR07_NODE_ADRS_C,GVMR07_PRCS_STAT_C,GVMR07_PRCS_STAT_S,GVMR07_CREATE_USER_C,GVMR07_CREATE_S,GVMR07_LAST_UPDT_USER_C,GVMR07_LAST_UPDT_S) "
            + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private final JdbcTemplate jdbcTemplate;

    public IVSFMessageNodeStatusRepository(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void saveAll(List<VilMessageNodeIVSFError> payloadNodeStatusList) {
        int[][] updatedCount = batchInsert(payloadNodeStatusList, payloadNodeStatusList.size());
        log.info("PayloadNodeStatus - list size-{}, updatedCount-{}", payloadNodeStatusList.size(), Arrays.deepToString(updatedCount));
    }

    public int[][] batchInsert(List<VilMessageNodeIVSFError> vilMessageNodeIVSFErrors, int batchSize) {
        int[][] updateCounts = jdbcTemplate.batchUpdate(insertVilMessageNodeStatusQuery, vilMessageNodeIVSFErrors,
                batchSize, (ps, nodeStatus) -> setPreparedStatement(ps, nodeStatus));
        return updateCounts;
    }

    private void setPreparedStatement(PreparedStatement ps, VilMessageNodeIVSFError nodeStatus) throws SQLException {
        ps.setLong(1, nodeStatus.getVilMessageId());
        ps.setString(2, nodeStatus.getVin());
        ps.setLong(3, nodeStatus.getVinHash());
        ps.setString(4, nodeStatus.getProgramCode());
        ps.setFloat(5, nodeStatus.getSalesModelYear());
        ps.setInt(6, nodeStatus.getRetryCount());
        ps.setInt(7, nodeStatus.getProcessXmlVersion());
        ps.setString(8, nodeStatus.getNodeAddress());
        ps.setString(9, nodeStatus.getStatus());
        ps.setTimestamp(10, nodeStatus.getCapturedTime());
        ps.setString(11, nodeStatus.getCreatedUser());
        ps.setTimestamp(12, nodeStatus.getCreatedTime());
        ps.setString(13, nodeStatus.getLastUpdatedUser());
        ps.setTimestamp(14, nodeStatus.getLastUpdatedTime());
    }
}
