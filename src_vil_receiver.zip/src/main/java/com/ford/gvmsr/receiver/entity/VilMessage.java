package com.ford.gvmsr.receiver.entity;

import lombok.Builder;
import lombok.Data;

import java.sql.Timestamp;

@Data
@Builder
public class VilMessage {
    private Long vilMessageId;
    private Integer partitionKeyRTSA;
    private Integer offsetKeyRTSA;
    private Integer partitionKeyGVMSR;
    private Integer offsetKeyGVMSR;
    private Timestamp messageCapturedTime;
    private String vin;
    private String vilPayloadMessage;
    private String status;
    private Timestamp processedTime;
    private String traceId;
    private String createdUser;
    private Timestamp createdTime;
    private String lastUpdatedUser;
    private Timestamp lastUpdatedTime;
}
