package com.ford.gvmsr.receiver.util;

import org.apache.kafka.common.header.Headers;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class RestTemplateUtil {

    public static String get(String url) {
	RestTemplate restTemplate = new RestTemplate();
	try {
	    String getResponse = restTemplate.getForObject(url, String.class);
	    return getResponse;
	} catch (RestClientException exception) {
	    throw exception;
	}
    }

    public static String post(String url, String body, Headers headers) {
	RestTemplate restTemplate = new RestTemplate();
	try {
	    String postResponse = restTemplate.postForObject(url, body, String.class, headers);
	    return postResponse;
	} catch (RestClientException exception) {
	    throw exception;
	}
    }
}
