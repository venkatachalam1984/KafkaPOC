package com.ford.gvmsr.receiver.repository;

import com.ford.gvmsr.receiver.entity.Vehicle;

import java.util.Optional;

public interface IVehicleRepository {
    Optional<Vehicle> findByVinAndVinHash(String vin, Integer vinHashKey);
}
