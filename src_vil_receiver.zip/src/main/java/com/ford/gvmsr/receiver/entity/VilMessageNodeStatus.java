package com.ford.gvmsr.receiver.entity;

import lombok.Builder;
import lombok.Data;

import java.sql.Timestamp;

@Data
@Builder
public class VilMessageNodeStatus {

    private Long vilMessageId;
    private String nodeAddress;
    private String status;
    private Timestamp capturedTime;
    private String createdUser;
    private Timestamp createdTime;
    private String lastUpdatedUser;
    private Timestamp lastUpdatedTime;

}
