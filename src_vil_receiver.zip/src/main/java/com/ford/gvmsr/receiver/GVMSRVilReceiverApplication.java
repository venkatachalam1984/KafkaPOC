package com.ford.gvmsr.receiver;

import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication
@ComponentScan(basePackages = { "com.ford.gvmsr" })
@EnableJpaRepositories
@EnableWebSecurity
public class GVMSRVilReceiverApplication {

    @Value("${kafka.server.env}")
    private String ENVIRONMENT;

    public static void main(String[] args) {
	SpringApplication application = new SpringApplication(GVMSRVilReceiverApplication.class);
	application.setWebApplicationType(WebApplicationType.NONE);
	SpringApplication.run(GVMSRVilReceiverApplication.class, args);
    }

    @PostConstruct
    public void deployKafka() {
	Properties sysprops = System.getProperties();
	if (ENVIRONMENT.equalsIgnoreCase("PROD")) {
	    sysprops.setProperty("java.security.auth.login.config",
		    "/home/vcap/app/BOOT-INF/classes/kafka_prod/jaas.conf");
	    sysprops.setProperty("java.security.krb5.conf", "/home/vcap/app/BOOT-INF/classes/kafka_prod/krb5.conf");
	} else if (StringUtils.equalsAny(ENVIRONMENT.trim(), "DEV", "QA", "STAGE")) {
	    /*sysprops.setProperty("java.security.auth.login.config",
		    "/home/vcap/app/BOOT-INF/classes/kafka_qa/jaas_qa.conf");
	    sysprops.setProperty("java.security.krb5.conf", "/home/vcap/app/BOOT-INF/classes/kafka_qa/krb5_qa.conf");
*/
		sysprops.setProperty("java.security.auth.login.config", "C:\\Users\\vmurug12\\gvmsr_kafka\\jaas_qa.conf");
		sysprops.setProperty("java.security.krb5.conf", "C:\\Users\\vmurug12\\gvmsr_kafka\\krb5_qa.conf");
	} else {
	    /*sysprops.setProperty("java.security.auth.login.config", "C:\\Security\\gvmsr-2\\jaas_qa.conf");
	    sysprops.setProperty("java.security.krb5.conf", "C:\\Security\\gvmsr-2\\krb5_qa.conf");*/
	}
    }
}
