package com.ford.gvmsr.receiver.kafka.producer;

import java.util.Properties;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.MultiMap;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.eventbus.Message;
import io.vertx.kafka.client.producer.KafkaHeader;
import io.vertx.kafka.client.producer.KafkaProducer;
import io.vertx.kafka.client.producer.KafkaProducerRecord;
import io.vertx.kafka.client.producer.RecordMetadata;

@Component
public class KafkaMessageProducer extends AbstractVerticle {

    final PropertiesConfig configuration;
    private final Logger log = LoggerFactory.getLogger(KafkaMessageProducer.class);
    KafkaProducer<String, String> gvmsrMessageProducer = null;

    public KafkaMessageProducer(PropertiesConfig configuration) {
	this.configuration = configuration;
    }

    /**
     * Start the verticle instance. Vert.x calls this method when deploying the
     * instance. You do not call it yourself.
     **/
    @Override
    public void start() {
	final EventBus eventBus = vertx.eventBus();
	registerDownstreamMessageProducer(vertx);
	eventBus.consumer(VilConstants.KAFKA_REORDER_PRODUCER_VERTICLE, this::publishKafkaRecord);
    }

    /**
     * Create a new KafkaProducer instance
     *
     * @param vertx Vert.x instance to use returns an instance of the KafkaProducer
     */
    public void registerDownstreamMessageProducer(Vertx vertx) {
	Properties config = new Properties();
	config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, configuration.getGvmsrProducerBrokerEndpoint());
	config.put(ProducerConfig.ACKS_CONFIG, configuration.getKafkaProducerAcksConfig());
	config.put(ProducerConfig.BATCH_SIZE_CONFIG, configuration.getProducerBatchSizeInBytes());
	config.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, configuration.getRequestTimeOutMs());
	config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, configuration.getKafkaProducerProtocolConfig());
	gvmsrMessageProducer = KafkaProducer.create(vertx, config, String.class, String.class);
    }

    /**
     * Method to Prepare Kafka Producer Record and push to send method
     *
     * @param message Message represents data shared through Event-Bus. It contains
     *                producing message properties (Topic, Partition_Key etc)
     */
    public void publishKafkaRecord(Message<Object> message) {
	KafkaProducerRecord<String, String> kafkaProducerRecord = prepareKafkaProducerRecord(message);
	publish(kafkaProducerRecord, message);
    }

    /**
     * Method to fetch Kafka message, partition_key & headers and prepare Kafka
     * Producer Record.
     *
     * @param message Message represents data shared through Event-Bus. It contains
     *                producing message properties (Topic, Partition_Key etc)
     */
    private KafkaProducerRecord<String, String> prepareKafkaProducerRecord(Message<Object> message) {
	String kafkaRequest = (String) message.body();
	MultiMap headers = message.headers();
	String topic = headers.get(VilConstants.KAFKA_TOPIC);
	headers.remove(VilConstants.KAFKA_TOPIC);
	String partitionKey = headers.get(VilConstants.PARTITION_KEY);
	KafkaProducerRecord<String, String> kafkaProducerRecord = KafkaProducerRecord.create(topic, partitionKey,
		kafkaRequest);
	headers.entries().forEach(entry -> kafkaProducerRecord.addHeader(entry.getKey(), entry.getValue()));
	return kafkaProducerRecord;
    }

    /**
     * Method will publish the message through Kafka producer based on the kafka
     * properties
     *
     * @param record  Vert.x Kafka producer record which holds topic, partitionKey
     *                and message details
     * @param message
     */
    private void publish(KafkaProducerRecord<String, String> record, Message<Object> message) {
	gvmsrMessageProducer.send(record, event -> {
	    if (event.succeeded()) {
		RecordMetadata result = event.result();
		log.info("Published to topic={}, partition={}", result.getTopic(), result.getPartition());
		for (KafkaHeader header : record.headers()) {
		    log.debug("Header key={}, value={}", header.key(), header.value().toString());
		}
		message.reply("Success");
	    } else {
		log.error("Error while publish log request = " + event.cause());
		message.reply(event.cause());
	    }
	});
    }

}
