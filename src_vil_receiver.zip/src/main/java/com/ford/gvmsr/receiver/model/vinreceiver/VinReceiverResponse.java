package com.ford.gvmsr.receiver.model.vinreceiver;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VinReceiverResponse {
    private String vin;
    private String programCode;
    private String traceId;
    private Float modelYear;
    private int errorCode;
    private String errorDesc;
}
