package com.ford.gvmsr.receiver.model.observer;

import java.util.List;

import com.ford.gvmsr.receiver.model.request.RequestRole;

public class VilHeader {

    protected RequestRole requestRole;
    private String swumVersion;
    private String campaignId;
    private String deploymentId;
    private String triggerType;
    private String vilReason;
    private String visVersion;
    private String policyTable;
    private String manifestSchema;
    private String timeStamp;
    private List<String> dtcList;

    public RequestRole getRequestRole() {
	return requestRole;
    }

    public void setRequestRole(RequestRole requestRole) {
	this.requestRole = requestRole;
    }

    public String getSwumVersion() {
	return swumVersion;
    }

    public void setSwumVersion(String swumVersion) {
	this.swumVersion = swumVersion;
    }

    public String getCampaignId() {
	return campaignId;
    }

    public void setCampaignId(String campaignId) {
	this.campaignId = campaignId;
    }

    public String getDeploymentId() {
	return deploymentId;
    }

    public void setDeploymentId(String deploymentId) {
	this.deploymentId = deploymentId;
    }

    public String getTriggerType() {
	return triggerType;
    }

    public void setTriggerType(String triggerType) {
	this.triggerType = triggerType;
    }

    public String getVilReason() {
	return vilReason;
    }

    public void setVilReason(String vilReason) {
	this.vilReason = vilReason;
    }

    public String getVisVersion() {
	return visVersion;
    }

    public void setVisVersion(String visVersion) {
	this.visVersion = visVersion;
    }

    public String getPolicyTable() {
	return policyTable;
    }

    public void setPolicyTable(String policyTable) {
	this.policyTable = policyTable;
    }

    public String getManifestSchema() {
	return manifestSchema;
    }

    public void setManifestSchema(String manifestSchema) {
	this.manifestSchema = manifestSchema;
    }

    public String getTimeStamp() {
	return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
	this.timeStamp = timeStamp;
    }

    public List<String> getDtcList() {
	return dtcList;
    }

    public void setDtcList(List<String> dtcList) {
	this.dtcList = dtcList;
    }
}
