package com.ford.gvmsr.receiver.verticle;

import java.net.URI;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.domain.modulestate.metadata.redis.RedisKeyHelper;
import com.ford.gvmsr.domain.modulestate.metadata.redis.RedisSchema;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStateResponse;
import com.ford.gvmsr.domain.modulestate.model.response.DomainStatusTracker;
import com.ford.gvmsr.receiver.builder.SnapObserverRequestBuilder;
import com.ford.gvmsr.receiver.checksum.builder.VILChecksumBuilder;
import com.ford.gvmsr.receiver.checksum.builder.VILChecksumHandler;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.constant.VilExceptionConstants;
import com.ford.gvmsr.receiver.kafka.producer.KafkaMessageProducer;
import com.ford.gvmsr.receiver.model.observer.SnapshotObserverRequest;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.repository.IVilMessageRepository;
import com.ford.gvmsr.receiver.repository.impl.VilMessageRepository;
import com.ford.gvmsr.receiver.util.BeanUtil;
import com.ford.gvmsr.receiver.util.JsonUtils;
import com.ford.gvmsr.receiver.util.SplunkUtils;
import com.google.common.base.Strings;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.DeliveryOptions;

public class ModuleStateObserverReqHandler extends AbstractVerticle {

    private final Integer index;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private PropertiesConfig propertiesConfig;
    private KafkaMessageProducer KafkaMessageProducer;
    private SplunkUtils splunkUtils;
    private IVilMessageRepository vilMessageRepository;
    private SnapObserverRequestBuilder snapObserverReqBuilder;
    private VILChecksumBuilder vilChecksumBuilder;
    private VILChecksumHandler vilChecksumHandler;
    private RedisSchema redisSchema;
    private RedisKeyHelper redisKeyHelper;

    public ModuleStateObserverReqHandler(Integer index) {
	this.index = index;
    }

    /**
     * Initialize dependent beans that uniquely matches the given object type, if
     * any.
     */
    public void initializeDependentAutowiredBeans() {
	this.vilMessageRepository = BeanUtil.getBean(vilMessageRepository, VilMessageRepository.class);
	this.snapObserverReqBuilder = BeanUtil.getBean(snapObserverReqBuilder, SnapObserverRequestBuilder.class);
	this.splunkUtils = BeanUtil.getBean(splunkUtils, SplunkUtils.class);
	this.KafkaMessageProducer = BeanUtil.getBean(KafkaMessageProducer, KafkaMessageProducer.class);
	this.propertiesConfig = BeanUtil.getBean(propertiesConfig, PropertiesConfig.class);
	this.vilChecksumBuilder = BeanUtil.getBean(vilChecksumBuilder, VILChecksumBuilder.class);
	this.vilChecksumHandler = BeanUtil.getBean(vilChecksumHandler, VILChecksumHandler.class);
	this.redisSchema = BeanUtil.getBean(redisSchema, RedisSchema.class);
	this.redisKeyHelper = BeanUtil.getBean(redisKeyHelper, RedisKeyHelper.class);
    }

    /**
     * Start the verticle instance. Vert.x calls this method when deploying the
     * instance. You do not call it yourself.
     **/
    @Override
    public void start() {
	log.debug("Deployed ModuleStateObserverReqHandler verticle with index = {} ", index);
	vertx.eventBus().consumer(VilConstants.MODULE_STATE_OBSERVER_REQ_PROC + index, event -> {
	    try {
		publishSnapObserverRequest((VilReceiverRequest) event.body(), event.headers().get(VilConstants.RECORD_KEY));
	    } catch (JsonProcessingException e) {
		log.error("ModuleStateObserverReqHandler::exception - " + e);
	    }
	});
	initializeDependentAutowiredBeans();
    }

    /**
     * Fetch nodes from Domain State Response and prepares Module State Observer
     * request with nodes which are all passes below conditions. If no valid nodes
     * are present then VIL will be considered as 'INVV'.
     *
     * Conditions :: 1. Node Present In ODL 2. DA Passed 3. Duplicate DID not found
     *
     * @param request      Custom POJO to maintain VIN level data
     * @param vilMessageId 02 table record id
     *
     **/
    private void publishSnapObserverRequest(VilReceiverRequest request, String vilMessageId)
	    throws JsonProcessingException {
	Instant start = Instant.now();
	String vin = request.getVin();
	String traceId = request.getTraceId();
	log.info("ModuleStateObserverReqHandler:received VIN = {} at index = {} ", vin, index);
	List<String> validNodeAddressList = getValidAddressNodeList(request.getStateResponse());
	if (validNodeAddressList.isEmpty() && !request.isRetryVilFlagEnabled()) {
	    String status = request.getIVSFNodesList().isEmpty() ? VilConstants.INVALID_VIL : VilConstants.PARTIALLY_CMPTD;
	    log.info("02 table status : before insert - " + status);
	    vilMessageRepository.updateStatusById(status, request.getVilMessageRecordId());
	    Instant end = Instant.now();
	    log.error(request.getVin() + "-" + VilExceptionConstants.EMPTY_VALID_NODES + "-" + status);
	    splunkUtils.postErrorEvent(vin, traceId, status, VilExceptionConstants.EMPTY_VALID_NODES,
		    VilConstants.OBSERVER_REQUEST_PROC, null, Duration.between(start, end).toMillis());
	} else if (!validNodeAddressList.isEmpty()) {
	    Optional<Timestamp> processedTimeByIdOptional = vilMessageRepository.findProcessedTimeById(request.getVilMessageRecordId());
	    log.debug("VILProcessedTimeById is present=" + processedTimeByIdOptional.isPresent());
	    if (processedTimeByIdOptional.isPresent()) {
		Timestamp timestamp = processedTimeByIdOptional.get();
		String observerRequest = buildModuleStateObserverRequest(request, Long.parseLong(vilMessageId),
			validNodeAddressList, timestamp);
		if (!Strings.isNullOrEmpty(observerRequest))
		    postModuleStateObserverRequest(vin, traceId, observerRequest, request);
	    }
	}
	Instant end = Instant.now();
	splunkUtils.postInfoEvent(vin, traceId, VilConstants.RECV_END, VilConstants.OBSERVER_REQUEST_PROC, null,
		Duration.between(start, end).toMillis());
    }

    /**
     * Publish request to Module State Observer topic.Once request publish status
     * will be updated into 02 table as 'TO_SNAP'.
     *
     * @param vin             Vehicle Identification Number used as look-up key for
     *                        Worker
     * @param traceId         unique UUID to trace specific VIL request
     * @param observerRequest Module state observer request
     * @param request
     *
     **/
    private void postModuleStateObserverRequest(String vin, String traceId, String observerRequest,
	    VilReceiverRequest request) throws JsonProcessingException {
	Instant start = Instant.now();
	if (propertiesConfig.isRestEnabled()) {
	    String observerResponse = postSnapObserverRequest(observerRequest);
	    log.debug("Module state observer response JSON-" + observerResponse);
	} else {
	    DeliveryOptions deliveryOptions = new DeliveryOptions().addHeader(VilConstants.KAFKA_TOPIC,
		    propertiesConfig.getModuleStateObserverTopic());
	    vertx.eventBus().send(VilConstants.KAFKA_REORDER_PRODUCER_VERTICLE, observerRequest, deliveryOptions);
	}
	if (!request.isRetryVilFlagEnabled() || VilConstants.TYPE_IVS_ERR.equalsIgnoreCase(request.getRetryRequestType()))
	    vilMessageRepository.updateStatusById(VilConstants.TO_SNAP_OBSERVER, request.getVilMessageRecordId());
	Instant end = Instant.now();
	splunkUtils.postInfoEvent(vin, traceId, VilConstants.TO_SNAP_OBSERVER, VilConstants.OBSERVER_REQUEST_PROC, null,
		Duration.between(start, end).toMillis());
	insertProcessedSnapHashToRedis(request);
	updateLatestTimeStampInRedis(request);
    }

    private void updateLatestTimeStampInRedis(VilReceiverRequest request) {
	String key = redisKeyHelper.generateVILProcessedTSCacheKey(request.getVin());
	redisSchema.insert(key, request.getTimeStamp());
    }

    private void insertProcessedSnapHashToRedis(VilReceiverRequest request) throws JsonProcessingException {
	long checksumTimestamp = System.currentTimeMillis();
	String vin = request.getVin();
	vilChecksumBuilder.setVIN(vin);
	vilChecksumBuilder.setVILBody(request.getRawVil());
	String generatedChecksum = vilChecksumBuilder.buildChecksum(VilConstants.CHECKSUM_CRC32);
	vilChecksumHandler.storeChecksumToCache(vin, generatedChecksum, checksumTimestamp);
    }

    /**
     * Prepares valid node address list to build Module State Observer request.
     *
     * @param domainStateResponse User-defined class to maintain Module state
     *                            validator response data
     **/
    private List<String> getValidAddressNodeList(DomainStateResponse domainStateResponse) {
	List<String> validNodeAddressList = new ArrayList<>();
	Map<String, DomainStatusTracker> domainStatusTrackerMap = domainStateResponse.getDomainStatusTracker();
	domainStatusTrackerMap.forEach((nodeAddr, statusTracker) -> {
	    if (isValidNode(statusTracker)) {
		if (!statusTracker.getAssociatedNodes().isEmpty()) {
		    validNodeAddressList.addAll(statusTracker.getAssociatedNodes());
		}
		validNodeAddressList.add(nodeAddr);
	    }
	});
	log.info("validNodeAddressList - " + validNodeAddressList);
	return validNodeAddressList;
    }

    /**
     * Prepares module state observer request with valid node list.
     * 
     * @param request              Custom POJO to maintain VIN level data
     * @param vilMessageId         02 table record id
     * @param validAddressNodeList valid node list to be processed
     * @param timestamp
     **/
    private String buildModuleStateObserverRequest(VilReceiverRequest request, Long vilMessageId,
	    List<String> validAddressNodeList, Timestamp timestamp) {
	String observerRequestJson = null;
	Instant start = Instant.now();
	try {
	    SnapshotObserverRequest snapshotObserverRequest = snapObserverReqBuilder.build(request, vilMessageId,
		    validAddressNodeList, timestamp);
	    observerRequestJson = JsonUtils.getJsonString(snapshotObserverRequest);
	    log.debug("Module state observer request JSON-" + observerRequestJson);
	} catch (JsonProcessingException e) {
	    vilMessageRepository.updateStatusById(VilConstants.SNAP_FAILURE, request.getVilMessageRecordId());
	    Instant end = Instant.now();
	    splunkUtils.postErrorEvent(request.getVin(), request.getTraceId(), VilConstants.SNAP_FAILURE,
		    e.getMessage(), VilConstants.OBSERVER_REQUEST_PROC, null, Duration.between(start, end).toMillis());
	}
	return observerRequestJson;
    }

    /**
     * Publish the request to module state observer's topic. Request will be sent by
     * PARTITION_KEY strategy to avoid parallel process.
     *
     * @param observerRequestJson Module state observer request JSON
     **/
    private String postSnapObserverRequest(String observerRequestJson) {
	RestTemplate restTemplate = new RestTemplate();
	HttpHeaders headers = new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	HttpEntity requestEntity = new HttpEntity(observerRequestJson, headers);
	URI uri = URI.create(propertiesConfig.getModuleStateObserverEndpoint());
	ResponseEntity<String> exchange = restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class);
	if (Objects.isNull(exchange))
	    throw new RuntimeException("Received null response from Module state validator service");
	return exchange.getBody();
    }

    /**
     * Set of conditions to decide whether node is valid or not
     *
     * @param domainStatusTracker object to build detail for matched network
     *
     **/
    public boolean isValidNode(DomainStatusTracker domainStatusTracker) {
	return domainStatusTracker.isNodePresentInODL() && domainStatusTracker.isDAPassed()
		&& !domainStatusTracker.isDuplicateDIDFound();
    }
}
