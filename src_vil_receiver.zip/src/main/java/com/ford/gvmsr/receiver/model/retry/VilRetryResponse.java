package com.ford.gvmsr.receiver.model.retry;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class VilRetryResponse {

    private int errorCode;
    private String errorDesc;

}
