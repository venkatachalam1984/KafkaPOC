
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "didValue", "decodedResponse", "rawResponse", "decodedresponse", "error", "rawresponse" })
public class Did {

    /*
     * @JsonProperty("rawresponse") private String rawresponse;
     */
    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();
    /*
     * @JsonProperty("didValue") private Integer didValue;
     */
    @NotNull(message = "DID - didValue should not be null")
    @JsonProperty("didValue")
    private String didValue;
    @NotNull(message = "DID - decodedResponse should not be null")
    @JsonProperty("decodedResponse")
    private String decodedResponse;
    @NotNull(message = "DID - rawResponse should not be null")
    @JsonProperty("rawResponse")
    private String rawResponse;
    @JsonProperty("decodedresponse")
    private String decodedresponse;
    @JsonProperty("error")
    private String error = "";
    private String IsValidationSuccessful;

    private String validationFailReason;

    /*
     * @JsonProperty("didValue") public Integer getDidValue() { return didValue; }
     * 
     * @JsonProperty("didValue") public void setDidValue(Integer didValue) {
     * this.didValue = didValue; }
     */

    @JsonProperty("didValue")
    public String getDidValue() {
	return didValue;
    }

    @JsonProperty("didValue")
    public void setDidValue(String didValue) {
	this.didValue = didValue;
    }

    @JsonProperty("decodedResponse")
    public String getDecodedResponse() {
	return decodedResponse;
    }

    @JsonProperty("decodedResponse")
    public void setDecodedResponse(String decodedResponse) {
	this.decodedResponse = decodedResponse;
    }

    @JsonProperty("rawResponse")
    public String getRawResponse() {
	return rawResponse;
    }

    @JsonProperty("rawResponse")
    public void setRawResponse(String rawResponse) {
	this.rawResponse = rawResponse;
    }

    @JsonProperty("decodedresponse")
    public String getDecodedresponse() {
	return decodedresponse;
    }

    @JsonProperty("decodedresponse")
    public void setDecodedresponse(String decodedresponse) {
	this.decodedresponse = decodedresponse;
    }

    @JsonProperty("error")
    public String getError() {
	return error;
    }

    @JsonProperty("error")
    public void setError(String error) {
	this.error = error;
    }

    /*
     * @JsonProperty("rawresponse") public String getRawresponse() { return
     * rawresponse; }
     * 
     * @JsonProperty("rawresponse") public void setRawresponse(String rawresponse) {
     * this.rawresponse = rawresponse; }
     */

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
    }

    public String getIsValidationSuccessful() {
	return IsValidationSuccessful;
    }

    public void setIsValidationSuccessful(String isValidationSuccessful) {
	IsValidationSuccessful = isValidationSuccessful;
    }

    public String getValidationFailReason() {
	return validationFailReason;
    }

    public void setValidationFailReason(String validationFailReason) {
	this.validationFailReason = validationFailReason;
    }
}
