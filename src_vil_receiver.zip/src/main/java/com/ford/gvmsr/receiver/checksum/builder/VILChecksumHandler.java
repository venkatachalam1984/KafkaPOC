package com.ford.gvmsr.receiver.checksum.builder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gvmsr.domain.modulestate.metadata.redis.RedisSchema;
import com.ford.gvmsr.receiver.constant.VilConstants;

@Component
public class VILChecksumHandler {

    private final Logger logger = LoggerFactory.getLogger(VILChecksumHandler.class);
    private final VILChecksumBuilder vilChecksumBuilder;
    private final RedisSchema redisSchema;

    @Value("${redis.cache.enabled}")
    private boolean isCacheEnabled;
    @Value("${redis.vil.cache.enabled}")
    private boolean isVILRedisCacheEnabled;

    public VILChecksumHandler(VILChecksumBuilder vilChecksumBuilder, RedisSchema redisSchema) {
	this.vilChecksumBuilder = vilChecksumBuilder;
	this.redisSchema = redisSchema;
    }

    private String getVILBodyChecksumFromRedis(String key) {
	return redisSchema.find(key);
    }

    private String retrieveChecksumFromRedis(String vin) {
	String vilBodyChecksumFromRedis, redisChecksum = null;
	if ((isCacheEnabled && isVILRedisCacheEnabled)) {
	    String key = generateVILBodyChecksumCacheKey(vin);
	    vilBodyChecksumFromRedis = getVILBodyChecksumFromRedis(key);
	    if (vilBodyChecksumFromRedis != null) {
		String[] redisCacheChecksum = vilBodyChecksumFromRedis.split(":");
		redisChecksum = redisCacheChecksum[1];
	    }
	}
	return redisChecksum;
    }

    public String generateVILBodyChecksumCacheKey(String vin) {
	String generatedKey = null;
	try {
	    generatedKey = "VIL:" + vin + ":DC";
	    logger.debug("Generated Key : " + generatedKey);
	} catch (Exception e) {
	    logger.error("error to generate VIL body checksum cache key :" + e.getMessage());
	}
	return generatedKey;
    }

    public boolean compareChecksum(String generatedChecksum, String redisChecksum) {
	boolean checksumEqual;
	checksumEqual = generatedChecksum.equals(redisChecksum);
	return checksumEqual;
    }

    public void storeChecksumToCache(String vin, String checksum, long timestamp) {
	if ((isCacheEnabled && isVILRedisCacheEnabled)) {
	    String key = generateVILBodyChecksumCacheKey(vin);
	    redisSchema.insert(key, timestamp + ":" + checksum);
	}
    }

    public boolean isDuplicateVIL(String vin, String nodeDetails, Boolean isActiveRecordPresent) {
	boolean duplicateVil = false;
	vilChecksumBuilder.setVIN(vin);
	vilChecksumBuilder.setVILBody(nodeDetails);
	long checksumTimestamp = System.currentTimeMillis();
	String generatedChecksum = vilChecksumBuilder.buildChecksum(VilConstants.CHECKSUM_CRC32);
	String redisChecksum = retrieveChecksumFromRedis(vin);
	logger.debug("VIN={} ,generatedChecksum={}, redisChecksum={}", vin, generatedChecksum, redisChecksum);
	boolean isChecksumEqual = compareChecksum(generatedChecksum, redisChecksum);
//	if (!isChecksumEqual || redisChecksum == null) {
//	    storeChecksumToCache(vin, generatedChecksum, checksumTimestamp);
//	} else
	if (isChecksumEqual) {
	    duplicateVil = true;
	}
	logger.debug("is VIL Duplicate={} for VIN={}", duplicateVil, vin);
	return duplicateVil;
    }
}
