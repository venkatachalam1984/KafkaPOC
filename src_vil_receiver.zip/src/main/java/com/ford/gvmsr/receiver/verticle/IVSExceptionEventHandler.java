package com.ford.gvmsr.receiver.verticle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ford.gvmsr.receiver.alarmevents.ExceptionEventGenerator;
import com.ford.gvmsr.receiver.alarmevents.ExceptionEventTO;
import com.ford.gvmsr.receiver.config.PropertiesConfig;
import com.ford.gvmsr.receiver.constant.VilConstants;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.util.JsonUtils;
import com.ford.gvmsr.receiver.util.SplunkUtils;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.DeliveryOptions;
import io.vertx.core.eventbus.Message;

@Component
public class IVSExceptionEventHandler extends AbstractVerticle {

	private final SplunkUtils splunkUtils;
	private final ExceptionEventGenerator exceptionEventGenerator;
	private final PropertiesConfig propertiesConfig;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public IVSExceptionEventHandler(ExceptionEventGenerator exceptionEventGenerator, SplunkUtils splunkUtils,
	    PropertiesConfig propertiesConfig) {
	this.exceptionEventGenerator = exceptionEventGenerator;
	this.splunkUtils = splunkUtils;
	this.propertiesConfig = propertiesConfig;
    }

    /**
     * Start the verticle instance. Vert.x calls this method when deploying the
     * instance. You do not call it yourself.
     **/
    @Override
    public void start() {
	vertx.eventBus().consumer(VilConstants.IVS_EXCEPTION_EVENT_PROC, this::domainStateResponseHandler);
    }

    /**
     * Prepare Exception event JSON and publish it to GIVIS
     * 
     * @param message Message represents data shared through Event-Bus.
     **/
    private <T> void domainStateResponseHandler(Message<T> message) {
	try {
	    VilReceiverRequest request = (VilReceiverRequest) message.body();
	    ExceptionEventTO exceptionEventTO = exceptionEventGenerator.prepareExceptionEvent(request);
	    if (!exceptionEventTO.getExceptionEventHeaderTOList().isEmpty()) {
		String exceptionEventJSON = JsonUtils.getJsonString(exceptionEventTO);
		log.info("IVSExceptionEventHandler:received alarm event list size - " + exceptionEventTO.getExceptionEventHeaderTOList().size());
		publishAlarmEventToGIVIS(request.getVin(), exceptionEventJSON);
	    }
	} catch (JsonProcessingException e) {
	    log.error("IVSExceptionEventHandler:received exception while preparing GivisExceptionEvent -" + e);
	}
    }

    /**
     * Publish exception event to GIVIS topic.
     *
     * @param vin                Vehicle Identification Number used as primary
     *                           identification
     * @param exceptionEventJSON Alarm event JSON to sync with GIVIS
     **/
    private void publishAlarmEventToGIVIS(String vin, String exceptionEventJSON) {
	log.debug("VIN={} Exception event JSON={}", vin, exceptionEventJSON);
	vertx.eventBus().send(VilConstants.DOWN_STREAM_PRODUCER_VERTICLE, exceptionEventJSON,
		new DeliveryOptions().addHeader(VilConstants.KAFKA_TOPIC, propertiesConfig.getExceptionEventTopic())
			.addHeader(VilConstants.PARTITION_KEY, vin));
	log.info("Sent Alarm Event to downStream message producer, for VIN = " + vin);
    }
}
