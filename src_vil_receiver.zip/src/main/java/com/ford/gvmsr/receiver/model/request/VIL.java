
package com.ford.gvmsr.receiver.model.request;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "vin", "swumVersion", "campaignId", "deploymentId", "triggerType", "vilReason", "visVersion",
	"policyTable", "manifestSchema", "timeStamp", "requestRole", "lastGps", "dtcList", "nodes" })
public class VIL {

    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    @NotEmpty(message = "VIL - VIN should not be empty")
    @Length(min = 17, max = 17, message = "Invalid VIN Length")
    @JsonProperty("vin")
    private String vin;

    @JsonProperty("swumVersion")
    private String swumVersion;

    @JsonProperty("campaignId")
    private String campaignId;

    @JsonProperty("deploymentId")
    private String deploymentId;

    @NotNull(message = "VIL - TriggerType should not be null")
    @NotEmpty(message = "VIL - TriggerType should not be empty")
    @JsonProperty("triggerType")
    private String triggerType;

    @NotNull(message = "VIL - VilReason should not be null")
    @JsonProperty("vilReason")
    private String vilReason;

    @JsonProperty("visVersion")
    private String visVersion;

    @JsonProperty("policyTable")
    private String policyTable;

    @JsonProperty("manifestSchema")
    private String manifestSchema;

    @NotNull(message = "VIL - TimeStamp should not be null")
    @JsonProperty("timeStamp")
    private String timeStamp;

    @NotNull(message = "VIL - RequestRole should not be null")
    @JsonProperty("requestRole")
    private @Valid RequestRole requestRole;

    @JsonProperty("lastGps")
    private @Valid LastGps lastGps;

    @JsonProperty("dtcList")
    private List<String> dtcList = null;

    @Size(min = 1, message = "VIL - Nodes element must not be empty")
    @JsonProperty("nodes")
    private @Valid List<Node> nodes = null;

    @JsonProperty("vin")
    public String getVin() {
	return vin;
    }

    @JsonProperty("vin")
    public void setVin(String vin) {
	this.vin = vin;
    }

    @JsonProperty("swumVersion")
    public String getSwumVersion() {
	return swumVersion;
    }

    @JsonProperty("swumVersion")
    public void setSwumVersion(String swumVersion) {
	this.swumVersion = swumVersion;
    }

    @JsonProperty("campaignId")
    public String getCampaignId() {
	return campaignId;
    }

    @JsonProperty("campaignId")
    public void setCampaignId(String campaignId) {
	this.campaignId = campaignId;
    }

    @JsonProperty("deploymentId")
    public String getDeploymentId() {
	return deploymentId;
    }

    @JsonProperty("deploymentId")
    public void setDeploymentId(String deploymentId) {
	this.deploymentId = deploymentId;
    }

    @JsonProperty("triggerType")
    public String getTriggerType() {
	return triggerType;
    }

    @JsonProperty("triggerType")
    public void setTriggerType(String triggerType) {
	this.triggerType = triggerType;
    }

    @JsonProperty("vilReason")
    public String getVilReason() {
	return vilReason;
    }

    @JsonProperty("vilReason")
    public void setVilReason(String vilReason) {
	this.vilReason = vilReason;
    }

    @JsonProperty("visVersion")
    public String getVisVersion() {
	return visVersion;
    }

    @JsonProperty("visVersion")
    public void setVisVersion(String visVersion) {
	this.visVersion = visVersion;
    }

    @JsonProperty("policyTable")
    public String getPolicyTable() {
	return policyTable;
    }

    @JsonProperty("policyTable")
    public void setPolicyTable(String policyTable) {
	this.policyTable = policyTable;
    }

    @JsonProperty("manifestSchema")
    public String getManifestSchema() {
	return manifestSchema;
    }

    @JsonProperty("manifestSchema")
    public void setManifestSchema(String manifestSchema) {
	this.manifestSchema = manifestSchema;
    }

    @JsonProperty("timeStamp")
    public String getTimeStamp() {
	return timeStamp;
    }

    @JsonProperty("timeStamp")
    public void setTimeStamp(String timeStamp) {
	this.timeStamp = timeStamp;
    }

    @JsonProperty("requestRole")
    public RequestRole getRequestRole() {
	return requestRole;
    }

    @JsonProperty("requestRole")
    public void setRequestRole(RequestRole requestRole) {
	this.requestRole = requestRole;
    }

    @JsonProperty("lastGps")
    public LastGps getLastGps() {
	return lastGps;
    }

    @JsonProperty("lastGps")
    public void setLastGps(LastGps lastGps) {
	if (null == lastGps) {
	    this.lastGps = new LastGps();
	} else {
	    this.lastGps = lastGps;
	}
    }

    @JsonProperty("dtcList")
    public List<String> getDtcList() {
	return dtcList;
    }

    @JsonProperty("dtcList")
    public void setDtcList(List<String> dtcList) {
	this.dtcList = dtcList;
    }

    @JsonProperty("nodes")
    public List<Node> getNodes() {
	return nodes;
    }

    @JsonProperty("nodes")
    public void setNodes(List<Node> nodes) {
	this.nodes = nodes;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
    }

}