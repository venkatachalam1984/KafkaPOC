package com.ford.gvmsr.receiver.validator;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;

import com.ford.gvmsr.receiver.model.response.Error;
import com.ford.gvmsr.receiver.constant.VilConstants;

public class JsonConstraintValidator {
    public static <T> void validateJson(T input, List<Error> errorList) {
	Set<ConstraintViolation<T>> violations = Validation.buildDefaultValidatorFactory().getValidator()
		.validate(input);
	if (violations.size() > 0) {
	    for (ConstraintViolation<T> violation : violations) {
		Error error = new Error();
		error.setAdditionalProperty(VilConstants.ERROR, violation.getMessage());
		errorList.add(error);
	    }
	}
    }
}
