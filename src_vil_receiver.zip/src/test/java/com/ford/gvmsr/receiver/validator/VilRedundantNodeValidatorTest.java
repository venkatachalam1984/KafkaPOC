package com.ford.gvmsr.receiver.validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.Node;
import com.ford.gvmsr.receiver.model.request.VilRequest;
import com.ford.gvmsr.receiver.util.VilUtils;

class VilRedundantNodeValidatorTest {

    VilReceiverRequest vilReceiverRequest;
    VilRedundantNodeValidator redundantNodeValidator = new VilRedundantNodeValidator(null);

    @BeforeEach
    public void setUp() throws IOException, VILValidationException {
	FileInputStream fisTargetFile = new FileInputStream(new File("src/test/VilRequest.txt"));
	String decodedVil = IOUtils.toString(fisTargetFile, StandardCharsets.UTF_8);
	VilRequest vilRequest = VilUtils.generateVilRequest(decodedVil);
	vilReceiverRequest = new VilReceiverRequest(vilRequest, null);
    }

    @Test
    void validateWithOutDuplicateNodes() throws VILValidationException {
	List<Node> nodes = vilReceiverRequest.getVil().getNodes();
	redundantNodeValidator.validate(vilReceiverRequest);
	Assert.assertEquals(vilReceiverRequest.getVil().getNodes().size(), nodes.size());
    }

    @Test
    void validateWithDuplicateNodes() throws VILValidationException {
	List<Node> nodes = vilReceiverRequest.getVil().getNodes();
	nodes.add(nodes.get(0));
	redundantNodeValidator.validate(vilReceiverRequest);
	Assert.assertEquals(vilReceiverRequest.getVil().getNodes().size(), nodes.size() - 1);
    }
}