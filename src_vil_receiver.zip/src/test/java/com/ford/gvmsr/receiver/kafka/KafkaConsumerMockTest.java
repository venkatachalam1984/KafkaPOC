package com.ford.gvmsr.receiver.kafka;

import com.ford.gvmsr.receiver.config.PropertiesConfig;
import io.vertx.core.Vertx;
import io.vertx.ext.unit.Async;
import io.vertx.ext.unit.TestContext;
import io.vertx.ext.unit.junit.VertxUnitRunner;
import io.vertx.kafka.client.consumer.KafkaReadStream;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.MockConsumer;
import org.apache.kafka.clients.consumer.OffsetResetStrategy;
import org.apache.kafka.common.TopicPartition;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;

import java.util.Collections;

@RunWith(VertxUnitRunner.class)
@ContextConfiguration(classes = PropertiesConfig.class)
public class KafkaConsumerMockTest {

    String logConsumerTopic = "gvmsr-test-topic";

    private Vertx vertx;

    @Before
    public void beforeTest() {
        vertx = Vertx.vertx();
    }

    @After
    public void afterTest(TestContext ctx) {
        vertx.close(ctx.asyncAssertSuccess());
    }

    @Test
    public void testVilConsumer(TestContext ctx) throws Exception {
        MockConsumer<String, String> mock = new MockConsumer<>(OffsetResetStrategy.EARLIEST);
        KafkaReadStream<String, String> consumer = createConsumer(vertx, mock);
        Async doneLatch = ctx.async();
        consumer.handler(record -> {
            ctx.assertEquals(logConsumerTopic, record.topic());
            ctx.assertEquals(0, record.partition());
            ctx.assertEquals("abc", record.key());
            ctx.assertEquals("def", record.value());
            consumer.close(v -> doneLatch.complete());
        });
        consumer.subscribe(Collections.singleton(logConsumerTopic), v -> {
            mock.schedulePollTask(() -> {
                mock.rebalance(Collections.singletonList(new TopicPartition(logConsumerTopic, 0)));
                mock.addRecord(new ConsumerRecord<>(logConsumerTopic, 0, 0L, "abc", "def"));
                mock.seek(new TopicPartition(logConsumerTopic, 0), 0L);
            });
        });
    }

    @Test
    public void testLogConsumer(TestContext ctx) throws Exception {
        MockConsumer<String, String> mock = new MockConsumer<>(OffsetResetStrategy.EARLIEST);
        KafkaReadStream<String, String> consumer = createConsumer(vertx, mock);
        Async doneLatch = ctx.async();
        consumer.handler(record -> {
            ctx.assertEquals(logConsumerTopic, record.topic());
            ctx.assertEquals(0, record.partition());
            ctx.assertEquals("xyz-k", record.key());
            ctx.assertEquals("xyz-v", record.value());
            consumer.close(v -> doneLatch.complete());
        });
        consumer.subscribe(Collections.singleton(logConsumerTopic), v -> {
            mock.schedulePollTask(() -> {
                mock.rebalance(Collections.singletonList(new TopicPartition(logConsumerTopic, 0)));
                mock.addRecord(new ConsumerRecord<>(logConsumerTopic, 0, 0L, "xyz-k", "xyz-v"));
                mock.seek(new TopicPartition(logConsumerTopic, 0), 0L);
            });
        });
    }

    <K, V> KafkaReadStream<K, V> createConsumer(Vertx vertx, Consumer<K, V> consumer) {
        return KafkaReadStream.create(vertx, consumer);
    }

}
