package com.ford.gvmsr.receiver;

import org.junit.Test;

//@RunWith(SpringRunner.class)
//@DataJpaTest
//@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class GVMSRVilReceiverApplicationTest {

    @Test
    public void main() {
    }

}