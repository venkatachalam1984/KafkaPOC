package com.ford.gvmsr.receiver.kafka;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ford.gvmsr.receiver.constant.VilConstants;

import io.vertx.core.Vertx;
import io.vertx.ext.unit.TestContext;
import io.vertx.ext.unit.TestSuite;
import io.vertx.ext.unit.junit.RunTestOnContext;
import io.vertx.ext.unit.junit.VertxUnitRunner;

@RunWith(VertxUnitRunner.class)
public class VertxModHashEventBusTest {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    @Rule
    public RunTestOnContext rule = new RunTestOnContext();
    Vertx vertx = rule.vertx();
    TestSuite suite = TestSuite.create("the_test_suite");

    @Test
    public void test_Consumer_VinHash(TestContext ctx) {
	String vin = "6FPPXXMJ2PJY51272";
	int vinHashLookUpKey = (Math.abs(vin.hashCode()) % 100);
	log.debug("vinHashLookUpKey " + vinHashLookUpKey);
	ctx.assertEquals(65, vinHashLookUpKey, "vin hash code matched");
    }

    @Test(timeout = 3000)
    public void test_EventBusProducer(TestContext ctx) {
	suite.test("producer - event bus ", result -> {
	    vertx.eventBus().sender(VilConstants.LOG_VALIDATOR_PREFIX + 0);
	    result.asyncAssertSuccess();
	});
    }

    @Test(timeout = 3000)
    public void test_EventBusConsumer(TestContext ctx) {
	suite.test("event bus - consumer ", result -> {
	    vertx.eventBus().consumer(VilConstants.LOG_VALIDATOR_PREFIX + 1, msg -> {
		result.asyncAssertSuccess();
	    });
	});
    }
}
