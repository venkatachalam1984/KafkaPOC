package com.ford.gvmsr.receiver.validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.jupiter.api.*;

import com.ford.gvmsr.receiver.exception.VILValidationException;
import com.ford.gvmsr.receiver.model.receiver.VilReceiverRequest;
import com.ford.gvmsr.receiver.model.request.VilRequest;
import com.ford.gvmsr.receiver.util.VilUtils;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RawVilConstraintValidatorTest {

    RawVilConstraintValidator rawVilConstraintValidator = new RawVilConstraintValidator(null);
    VilReceiverRequest vilReceiverRequest;

    @BeforeEach
    public void setUp() throws IOException, VILValidationException {
	FileInputStream fisTargetFile = new FileInputStream(new File("src/test/VilRequest.txt"));
	String decodedVil = IOUtils.toString(fisTargetFile, StandardCharsets.UTF_8);
	VilRequest vilRequest = VilUtils.generateVilRequest(decodedVil);
	vilReceiverRequest = new VilReceiverRequest(vilRequest, null);
    }

    @Test
    @Order(1)
    void validateVilRequestWithInvalidVIN() {
	vilReceiverRequest.getVil().setVin(null);
	Assert.assertThrows(VILValidationException.class, () -> {
	    rawVilConstraintValidator.validate(vilReceiverRequest);
	});
    }

    @Test
    @Order(2)
    void validateVilRequestWithValidVIN() throws VILValidationException {
	rawVilConstraintValidator.validate(vilReceiverRequest);
	Assert.assertEquals(vilReceiverRequest.getErrorList().size(), 0);
    }

}