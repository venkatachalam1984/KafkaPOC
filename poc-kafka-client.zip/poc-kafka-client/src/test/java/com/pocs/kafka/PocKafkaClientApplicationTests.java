package com.pocs.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocKafkaClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
