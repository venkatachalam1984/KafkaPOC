package com.pocs.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocKafkaClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocKafkaClientApplication.class, args);
	}

}
