package com.pocs.kafka.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class KafkaResetRequest {
	private boolean pauseComsumer;
	private boolean resumeConsumer;
	
	private boolean resetFromBegining;
	private boolean resetByOffset;
	private boolean resetByTime;
	
	private List<String> topics = new ArrayList<>();
	private Map<Integer, Long> partitionAndOffsetsMap;
	private List<PartitionAndOffset> partitionAndOffsets;
	private long timestamp;
}
