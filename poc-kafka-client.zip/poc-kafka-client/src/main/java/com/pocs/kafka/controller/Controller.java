package com.pocs.kafka.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pocs.kafka.model.KafkaMessageRequest;
import com.pocs.kafka.model.KafkaResetRequest;
import com.pocs.kafka.model.PartitionAndOffset;
import com.pocs.kafka.service.KafkaService;


@RestController
@RequestMapping("/pocs/kafka")
public class Controller {
	
	private final KafkaService kafkaService;

	@Autowired
	public Controller(KafkaService kafkaService) {
		this.kafkaService = kafkaService;
	}
	
	@GetMapping("/ping")
	public String ping() {
		return "Okay";
	}
	
	@PostMapping("/message")
	public String postKafkaMessage(@RequestBody KafkaMessageRequest kafkaMessageRequest) {
		return this.kafkaService.postKafkaMessage(kafkaMessageRequest);
	}
	
	@PostMapping("/reset")
	public String resetKafkaConsumer(@RequestBody KafkaResetRequest kafkaResetRequest) {
		List<PartitionAndOffset> partitionAndOffsets = kafkaResetRequest.getPartitionAndOffsets();
		long timestamp = kafkaResetRequest.getTimestamp();
		List<String> topics = kafkaResetRequest.getTopics();
		StringBuilder response = new StringBuilder();
		
		//** PAUSE
		if(kafkaResetRequest.isPauseComsumer()) return this.kafkaService.pauseKafkaMessageConsumption(topics);
		
		//** RESUME
		if(kafkaResetRequest.isResumeConsumer()) return this.kafkaService.resumeKafkaMessageConsumption(topics);
		
		//** RESET OFFSET FROM BEGINING
		if(kafkaResetRequest.isResetFromBegining()) return this.kafkaService.resetKafkaOffsetToBegining(topics);
		
		//** RESET OFFSET BY TIME
		if(kafkaResetRequest.isResetByTime()) return this.kafkaService.resetKafkaOffsetByTime(topics, timestamp);
				
		//** RESET OFFSET BY OFFSET
		if(kafkaResetRequest.isResetByOffset()) {
			topics.forEach(topic -> response.append("\n"+this.kafkaService.resetKafkaOffset(topic, partitionAndOffsets)));
			return response.toString();
		}
		
		
		return "Specify which one to reset..?!";
	}
	
}
