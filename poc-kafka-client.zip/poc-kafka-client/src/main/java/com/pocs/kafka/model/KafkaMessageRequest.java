package com.pocs.kafka.model;

import lombok.Data;

@Data
public class KafkaMessageRequest {
	private String topic;
	private String key;
	private String value;
	private Long timestamp;
	private Integer partition;
}
