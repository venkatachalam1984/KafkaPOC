package com.pocs.kafka.configs;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.vertx.core.Vertx;
import io.vertx.kafka.client.consumer.KafkaConsumer;

@Configuration
public class KafkaConsumerConfig  {
	
	Vertx vertx = Vertx.vertx();
	
	@Bean
	public KafkaConsumer<String, String> kafkaConsumer() {
		Map<String, String> config = new HashMap<>();
		config.put("bootstrap.servers", "localhost:9092");
		config.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		config.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		config.put("group.id", "my_group");
		config.put("auto.offset.reset", "earliest");
		config.put("enable.auto.commit", "false");

		// use consumer for interacting with Apache Kafka
		KafkaConsumer<String, String> consumer = KafkaConsumer.create(vertx, config);
		return consumer;
	}
	

}
