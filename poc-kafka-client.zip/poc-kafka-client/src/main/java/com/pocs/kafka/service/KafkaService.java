package com.pocs.kafka.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pocs.kafka.model.KafkaMessageRequest;
import com.pocs.kafka.model.PartitionAndOffset;

import io.vertx.kafka.client.common.TopicPartition;
import io.vertx.kafka.client.consumer.KafkaConsumer;
import io.vertx.kafka.client.consumer.KafkaConsumerRecord;
import io.vertx.kafka.client.consumer.OffsetAndTimestamp;
import io.vertx.kafka.client.producer.KafkaProducer;
import io.vertx.kafka.client.producer.KafkaProducerRecord;

@Service
public class KafkaService {

	private KafkaConsumer<String, String> kafkaConsumer;
	private KafkaProducer<String, String> kafkaProducer;
	private Logger log = LoggerFactory.getLogger(this.getClass());
	int counter1 = 0;
	int counter2 = 0;
	
	@Autowired
	public KafkaService(KafkaConsumer<String, String> kafkaConsumer, KafkaProducer<String, String> kafkaProducer) {
		this.kafkaConsumer = kafkaConsumer;
		this.kafkaProducer = kafkaProducer;
		this.setKafkaClients();
	}
	
	private void setKafkaClients() {
		Set<String> topics = new HashSet<>();
		topics.add("demo-events");
		topics.add("poc-events");
		this.kafkaConsumer.subscribe(topics);
		this.kafkaConsumer.handler(record -> this.kafkaMessageHandler((KafkaConsumerRecord<String, String>)record));
		
		Executor ex = CompletableFuture.delayedExecutor(2, TimeUnit.SECONDS, (_p)->{
			this.kafkaConsumer.listTopics().onSuccess((map)->{
				log.info("###################( TOPICS CONSUMED )##################");
				counter1 = 0;
				map.forEach((topic, partitionInfoes)->{
					
					counter2 = 0;
					log.info("###({}) <<<{}>>>", ++counter1, topic);
					partitionInfoes.forEach(info->{
						log.info("      *({}): {}", ++counter2, info);
					});
				});
				log.info("###################( ****** ******** )##################");
			});
		});
		
		ex.execute(()->{});
	}

	private void kafkaMessageHandler(KafkaConsumerRecord<String, String> record) {
		log.info("(partition: {}, offset: {}, topic: {})>>> Kafka record: {}", record.partition(), record.offset(), record.topic(), record);
		//log.info("Processing key=" + record.key() + ",value=" + record.value() + ",partition=" + record.partition() + ",offset=" + record.offset());
	}
	
	/**
	 * POST MESSAGE
	 * 
	 * @param kafkaMessageRequest
	 * @return
	 */
	public String postKafkaMessage(KafkaMessageRequest kafkaMessageRequest) {
		try {
			KafkaProducerRecord<String, String> record = KafkaProducerRecord.create(
					kafkaMessageRequest.getTopic(), kafkaMessageRequest.getKey(), kafkaMessageRequest.getValue(), 
					kafkaMessageRequest.getTimestamp(), kafkaMessageRequest.getPartition());
			this.kafkaProducer.write(record);
			return "Message posted successfully: "+kafkaMessageRequest.getValue();
		}catch (Exception e) {
			return "Error posting message: "+e.getMessage();
		}
		
	}
	
	/**
	 * (1) PAUSE CONSUMER <<DYNAMIC PARTITIONS FETCH>>
	 * 
	 * @return
	 */
	public String pauseKafkaMessageConsumption(List<String> topics) {
		try {
			
			//For each topic, get the associated partitions info dynamically and pause its consumption.
			topics.forEach(topic -> {
					this.kafkaConsumer.partitionsFor(topic, (partitionsInfo)->{
						Set<TopicPartition> topicPartitions = new HashSet<>();
						partitionsInfo.result().forEach(partitionInfo -> topicPartitions.add(new TopicPartition().setTopic(partitionInfo.getTopic()).setPartition(partitionInfo.getPartition())));
						this.kafkaConsumer.pause(topicPartitions);
					});
			});
			
			//this.kafkaConsumer.pause();
			return "Kafka consumer pause INITIATED successfully!";
		}catch (Exception e) {
			return "Kafka consumer couldn't be paused! Exception: "+e.getMessage();
		}
	}
	
	/**
	 * (2) RESUME CONSUMER <<DYNAMIC PARTITIONS FETCH>>
	 * 
	 * @return
	 */
	public String resumeKafkaMessageConsumption(List<String> topics) {
		try {
			//For each topic, get the associated partitions info dynamically and pause its consumption.
			topics.forEach(topic -> {
					this.kafkaConsumer.partitionsFor(topic, (partitionsInfo)->{
						Set<TopicPartition> topicPartitions = new HashSet<>();
						partitionsInfo.result().forEach(partitionInfo -> topicPartitions.add(new TopicPartition().setTopic(partitionInfo.getTopic()).setPartition(partitionInfo.getPartition())));
						this.kafkaConsumer.resume(topicPartitions);
					});
			});
			
			//this.kafkaConsumer.resume();
			return "Kafka consumer resume INITIATED successfully!";
		}catch (Exception e) {
			return "Kafka consumer couldn't be resumed! Exception: "+e.getMessage();
		}
	}
	
	
	/**
	 * (3) RESET CONSUMER OFFSET <<BY OFFSET>>
	 * 
	 * @param topic
	 * @param partitionAndOffsets
	 * @return
	 */
	public String resetKafkaOffset(String topic, List<PartitionAndOffset> partitionAndOffsets) {
		try {
			//For every set of partition & key sets, reset the offset position.
			for(PartitionAndOffset partitionAndOffset: partitionAndOffsets) {
				this.kafkaConsumer.seek(new TopicPartition().setTopic(topic).setPartition(partitionAndOffset.getPartition()), partitionAndOffset.getOffset());
			}
			
			return "Consumer offset reset INITIATED successfully!";
		}catch (Exception e) {
			return "Consumer offset reset failed! Exception: "+e.getMessage();
		}
	}
	
	
	/**
	 * (4) RESET CONSUMER OFFSET <<FROM BIGINING>> <<DYNAMIC PARTITIONS FETCH>>
	 * 
	 * @param topics
	 * @return
	 */
	public String resetKafkaOffsetToBegining(List<String> topics) {
		try {
			
			//For each topic, get the associated partitions info dynamically and reset the offset.
			topics.forEach(topic -> {
					this.kafkaConsumer.partitionsFor(topic, (partitionsInfo)->{
						Set<TopicPartition> topicPartitions = new HashSet<>();
						partitionsInfo.result().forEach(partitionInfo -> topicPartitions.add(new TopicPartition().setTopic(partitionInfo.getTopic()).setPartition(partitionInfo.getPartition())));
						this.kafkaConsumer.seekToBeginning(topicPartitions);
					});
			});
			
			return "Consumer offset reset INITIATED successfully!";
		}catch (Exception e) {
			return "Consumer offset reset failed! Exception: "+e.getMessage();
		}
	}
	
	
	/**
	 * (5) RESET CONSUMER OFFSET <<BY TIME>>  <<DYNAMIC PARTITIONS FETCH>>
	 * 
	 * @param topics
	 * @param timestamp
	 * @return
	 */
	public String resetKafkaOffsetByTime(List<String> topics, long timestamp) {
		try {
			
			//For each topic, get the associated partitions info dynamically. Then frame the topicPartitionTimestamp map and call the local method to reset by time 
			//(which inturn will get the eligible offset heads and will use that to call reset by offset method internally).
			topics.forEach(topic -> {
				this.kafkaConsumer.partitionsFor(topic, (partitionsInfo)->{
					Map<TopicPartition, Long> topicPartitionsAndTimeStamps = new HashMap<>();
					partitionsInfo.result().forEach(partitionInfo -> topicPartitionsAndTimeStamps.put(new TopicPartition().setTopic(partitionInfo.getTopic()).setPartition(partitionInfo.getPartition()), timestamp));
					this.resetKafkaOffsetByTime(topicPartitionsAndTimeStamps);
				});
				
			});
			
			return "Consumer time stamp reset INITIATED successfully!";
		}catch (Exception e) {
			return "Consumer time stamp reset failed! Exception: "+e.getMessage();
		}
	}


	private void resetKafkaOffsetByTime(Map<TopicPartition, Long> topicPartitionsAndTimeStamps) {
		
		//Get the eligible offset heads for each topicPartitionTimeStamp entry and use that to call the reset by offset method.
		this.kafkaConsumer.offsetsForTimes(topicPartitionsAndTimeStamps)
						  .onSuccess(partitionAndTimeStampDetails -> {
							  partitionAndTimeStampDetails
							  	.entrySet()
							  	.forEach(entry -> {
							  		TopicPartition topicPartition = entry.getKey();
							  		OffsetAndTimestamp offsetAndTimestamp = entry.getValue();
							  		
							  		List<PartitionAndOffset> partitionAndOffsets = new ArrayList<>();
							  		partitionAndOffsets.add(new PartitionAndOffset(topicPartition.getPartition(), offsetAndTimestamp.getOffset()));
							  		
							  		this.resetKafkaOffset(topicPartition.getTopic(), partitionAndOffsets);
							  	});
						  });
	}
	
}
