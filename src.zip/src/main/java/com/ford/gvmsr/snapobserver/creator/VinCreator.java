package com.ford.gvmsr.snapobserver.creator;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.enums.SnapSource;
import com.ford.gvmsr.snapobserver.exception.GVMSValidationException;
import com.ford.gvmsr.snapobserver.modulestate.request.RoleSourceENUMType;

import java.util.Optional;

public interface VinCreator {

    Vehicle createVin(String vin, RoleSourceENUMType roleSourceENUMType);
}
