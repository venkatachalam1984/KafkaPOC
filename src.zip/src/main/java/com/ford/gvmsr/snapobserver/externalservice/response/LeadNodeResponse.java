package com.ford.gvmsr.snapobserver.externalservice.response;

public class LeadNodeResponse {

    private String isMultiNode;

    private String leadNode;

    public String getIsMultiNode() {
        return isMultiNode;
    }

    public void setIsMultiNode(String isMultiNode) {
        this.isMultiNode = isMultiNode;
    }

    public String getLeadNode() {
        return leadNode;
    }

    public void setLeadNode(String leadNode) {
        this.leadNode = leadNode;
    }
}
