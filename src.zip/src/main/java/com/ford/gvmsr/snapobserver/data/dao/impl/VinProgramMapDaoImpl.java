package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VinProgramMapDao;
import com.ford.gvmsr.snapobserver.data.entity.VINProgramMap;
import com.ford.gvmsr.snapobserver.data.repository.VinProgramMapRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VinProgramMapDaoImpl implements VinProgramMapDao {


    @Autowired
    VinProgramMapRepository vinProgramMapRepository;

    @Override
    public List<VINProgramMap> getVinMapExpressionByVin(String vin) {


        return vinProgramMapRepository.getVINMapExpressionByVIN(vin);
    }
}
