package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by VYUVARA6 on 8/29/2017.
 */

/**
 * "Indicate the ROLE which can edit the VIN and Feauture association. Some of the values are
 SAVE ( Single Access to Vehicle Entry - I/O module accessing NAVIS, SOVID and GEVIS for vehicle com.ford.cloudnative.gvms.moduleinfo.com.ford.cloudnative.gvms.moduleupdate.data called by various FCSD systems)
 DEALER
 etc
 Data Source: GIVIS:NMGM165_VEH_FTR_UPD_ROLE_LIST"
 */

@Entity
@Table(name = "PGVMS18_VEH_FTR_UPD_ROLE_LIST")
public class VehFeatureUpdateSourceList extends BaseEntity {
    @Id
    @Column(name = "GVMS18_ROLE_K")
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "PGVMS18_ROLE_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS18_ROLE_K_SQ_GEN", sequenceName = "PGVMS18_ROLE_K_SQ", allocationSize = 1)
    private Long  roleSakey;

    @Column(name = "GVMS18_ROLE_D")
    private String roleId;

    @Column(name = "GVMS18_ROLE_N")
    private String roleName;

    @Column(name = "GVMS18_ROLE_SRC_C")
    private String roleSource;

    @Column(name = "GVMS18_PUT_IN_ON_XML_F")
    private String xmlFlag;

    @Column(name = "GVMS18_ROLE_X")
    private String roleDescription;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS18_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS18_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS18_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS18_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public Long  getRoleSakey() {
        return roleSakey;
    }

    public void setRoleSakey(Long  roleSakey) {
        this.roleSakey = roleSakey;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleSource() {
        return roleSource;
    }

    public void setRoleSource(String roleSource) {
        this.roleSource = roleSource;
    }

    public String getXmlFlag() {
        return xmlFlag;
    }

    public void setXmlFlag(String xmlFlag) {
        this.xmlFlag = xmlFlag;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }
}
