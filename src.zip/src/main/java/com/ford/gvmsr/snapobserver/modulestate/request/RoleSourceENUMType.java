
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RoleSourceENUMType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RoleSourceENUMType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="PTS"/&gt;
 *     &lt;enumeration value="IDS"/&gt;
 *     &lt;enumeration value="ETIS"/&gt;
 *     &lt;enumeration value="SMR"/&gt;
 *     &lt;enumeration value="CKS"/&gt;
 *     &lt;enumeration value="LCS"/&gt;
 *     &lt;enumeration value="ECATS"/&gt;
 *     &lt;enumeration value="EOL"/&gt;
 *     &lt;enumeration value="VHR"/&gt;
 *     &lt;enumeration value="FCS"/&gt;
 *     &lt;enumeration value="OTA"/&gt;
 *     &lt;enumeration value="FIMCO"/&gt;
 *     &lt;enumeration value="MODULE"/&gt;
 *     &lt;enumeration value="RVCM"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RoleSourceENUMType")
@XmlEnum
public enum RoleSourceENUMType {

    PTS,
    IDS,
    ETIS,
    SMR,
    CKS,
    LCS,
    ECATS,
    EOL,
    VHR,
    FCS,
    OTA,
    FIMCO,
    MODULE,
    RVCM;

    public String value() {
        return name();
    }

    public static RoleSourceENUMType fromValue(String v) {
        return valueOf(v);
    }

}
