package com.ford.gvmsr.snapobserver.data.entity;

import java.util.Map;


public class VILToALDetails {

    private String msgProcessingKey;
    private String vilContent;
    private Map<String , String> retrySnapNodeErrorMap;

    public String getMsgProcessingKey() {
        return msgProcessingKey;
    }

    public void setMsgProcessingKey(String msgProcessingKey) {
        this.msgProcessingKey = msgProcessingKey;
    }

    public String getVilContent() {
        return vilContent;
    }

    public void setVilContent(String vilContent) {
        this.vilContent = vilContent;
    }

    public Map<String, String> getRetrySnapNodeErrorMap() {
        return retrySnapNodeErrorMap;
    }

    public void setRetrySnapNodeErrorMap(Map<String, String> retrySnapNodeErrorMap) {
        this.retrySnapNodeErrorMap = retrySnapNodeErrorMap;
    }
}
