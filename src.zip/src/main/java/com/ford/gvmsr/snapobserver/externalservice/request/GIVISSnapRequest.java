package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.List;

/**
 * Created by KMANI4 on 29-08-2018.
 */
public class GIVISSnapRequest {

    private String vin;
    private List<String> nodeList;
    private boolean vinFlag;
    private boolean nodeFlag;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public List<String> getNodeList() {
        return nodeList;
    }

    public void setNodeList(List<String> nodeList) {
        this.nodeList = nodeList;
    }

    public boolean isVinFlag() {
        return vinFlag;
    }

    public void setVinFlag(boolean vinFlag) {
        this.vinFlag = vinFlag;
    }

    public boolean isNodeFlag() {
        return nodeFlag;
    }

    public void setNodeFlag(boolean nodeFlag) {
        this.nodeFlag = nodeFlag;
    }

    @Override
    public String toString() {
        return "GIVISSnapRequest{" +
                "vin='" + vin + '\'' +
                ", nodeList=" + nodeList +
                ", vinFlag=" + vinFlag +
                ", nodeFlag=" + nodeFlag +
                '}';
    }
}
