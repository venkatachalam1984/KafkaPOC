package com.ford.gvmsr.snapobserver.handler;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.constants.SnapConstants;
import com.ford.gvmsr.snapobserver.constants.VilConstants;
import com.ford.gvmsr.snapobserver.data.entity.ModuleNode;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.monitor.SnapshotChangeMonitor;
import com.ford.gvmsr.snapobserver.modulestate.monitor.SnapshotNodeMonitor;
import com.ford.gvmsr.snapobserver.modulestate.request.*;
import com.ford.gvmsr.snapobserver.helper.SnapCreationHelper;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.validator.*;
import com.ford.gvmsr.snapobserver.validator.request.NodeSkipValidatorRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@Component
public class CopyDidRuleHandler {

    private static final Logger logger = LoggerFactory.getLogger(CopyDidRuleHandler.class);

    @Autowired
    SnapCreationHelper snapCreationHelper;
    @Autowired
    ESNDidRule esnDidRule;
    @Autowired
    MacAddressDidRule macAddressDidRule;
    @Autowired
    ICCIDDidRule iccidDidRule;
    @Autowired
    ApplicationDidRule applicationDidRule;
    @Autowired
    DefaultConfigDidRule defaultConfigDidRule;
    @Autowired
    DefaultDidRule defaultDidRule;
    @Autowired
    EcuAcronymCheckRule ecuAcronymCheckRule;
    @Autowired
    NetworkNameCheckRule networkNameCheckRule;
    @Autowired
    ExceptionHandler exceptionHandler;

    @Value("#{'${esn.dids}'.split(',')}")
    private Set<String> ESN_DID_LIST;

    @Value("#{'${application.dids}'.split(',')}")
    private Set<String> APPLICATION_DID_LIST;

    @Value("#{'${mac.address.dids}'.split(',')}")
    private Set<String> MAC_ADDRESS_DID_LIST;

    @Value("#{'${iccid.dids}'.split(',')}")
    private Set<String> ICCID_DID_LIST;

    @Value("#{'${snap.skip.dids}'.split(',')}")
    private List<String> SNAP_SKIP_DID_LIST;

    @Value("#{'${snap.skip.esn.dids}'.split(',')}")
    private Set<String> SNAPSKIP_ESN_DID_LIST;

    @Value("#{'${snap.skip.mandatory.dids}'.split(',')}")
    private Set<String> SNAPSKIP_MANDATORY_DID_LIST;

    @Value("#{'${snap.strategy.dids}'.split(',')}")
    private Set<String> STRATEGY_DID_LIST;


    public NodeAndDIDResponseForNewSnap compareAndCopyDIDsFromPreviousSnap(ModuleSnapshotObserverRequest snapshotObserverRequest,
                                                                           ModuleNodeType node, PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode) throws Exception {
        logger.debug("CopyDidRuleHandler:Start compareAndCopyDIDsFromPreviousSnap for VIN : "+ snapshotObserverRequest.getVin());
        NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap = new NodeAndDIDResponseForNewSnap();

        try {
            Map<String, ModuleNode> moduleNodeMap = snapCreationHelper.populateModuleNodeType(snapshotObserverRequest.getVehicle());

            List<String> didList = new ArrayList<>();
            List<String> newApplicationList = new ArrayList<>();
            AtomicBoolean isF17Fdid = new AtomicBoolean(false);
            Map<String, List<String>> gwNodeIdMap = new HashMap<>();
            boolean isSnapSkipped = false;
            for (ECUAcronymType ecuAcronymType : node.getECUAcronym()) {
                for (HistoricType state : ecuAcronymType.getState()) {
                    for (GatewayType gateway : state.getGateway()) {
                        String gwNodeId = gateway.getGatewayedNodeId();

                        List<String> prevNonConfigDidTypeList =
                                previousSnapShotDetailsByNode.getPrevNonConfigDidResponseMap().values().stream().
                                        map(VehicleNodeDIDResponse::getDidCatalog).collect(Collectors.toList());

                        NodeSkipValidatorRequest nodeSkipValidatorRequest = NodeSkipValidatorRequest.builder().
                                snapshotObserverRequest(snapshotObserverRequest).node(node).gatewayType(gateway).
                                previousSnapShotDetailsByNode(previousSnapShotDetailsByNode).isF17FDid(isF17Fdid).
                                esnDidList(SNAPSKIP_ESN_DID_LIST).mandatoryDidList(SNAPSKIP_MANDATORY_DID_LIST).
                                strategyDidList(STRATEGY_DID_LIST).prevNonConfigDIDList(prevNonConfigDidTypeList).build();

                        SnapObserverValidationChainBuilder snapObserverValidationChainBuilder
                                = new SnapObserverValidationChainBuilder();

                        isSnapSkipped = snapObserverValidationChainBuilder.applyValidation(nodeSkipValidatorRequest);
                        if (!isSnapSkipped) {
                            for (DIDInfoType didInfoType : gateway.getDID()) {
                                if (didInfoType.isIsConfig()) {
                                    defaultConfigDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                                            nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);
                                } else {
                                    if (ESN_DID_LIST.contains(didInfoType.getDidValue())) {
                                        esnDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                                                nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);

                                    } else if (MAC_ADDRESS_DID_LIST.contains(didInfoType.getDidValue())) {
                                        macAddressDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                                                nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);

                                    } else if (APPLICATION_DID_LIST.contains(didInfoType.getDidValue())) {
                                        applicationDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                                                nodeAndDIDResponseForNewSnap,
                                                node, snapshotObserverRequest, newApplicationList);

                                    } else if (ICCID_DID_LIST.contains(didInfoType.getDidValue())) {
                                        iccidDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                                                nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);

                                    } else {
                                        defaultDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                                                nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);
                                    }
                                }
                                didList.add(didInfoType.getDidValue());

                            } //didInfoType loop end
                        }
                        if(isSnapSkipped) break;

                        //Application did check for VehicleProfile trigger and snap creation
                        snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.APPLICATION_DID,
                                applicationDidRule.isApplicationDidChanged(newApplicationList, previousSnapShotDetailsByNode.getPreviousAppList()));
                        snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.VEHICLE_PROF_TRIGGER,
                                applicationDidRule.isVehicleProfileTrigger(newApplicationList, previousSnapShotDetailsByNode.getPreviousAppList()));

                        //copy missing config dids to current snap to creation
                        defaultConfigDidRule.copyMissingConfigDIDsFromPreviousSnap(previousSnapShotDetailsByNode.getPrevConfigDidSixTableResponseMap(),
                                previousSnapShotDetailsByNode.getPrevConfigDidTwoTableResponseMap(), nodeAndDIDResponseForNewSnap);


                        //copy ICCID dids from previous snap if did is not present in current snap - START
                        SnapshotChangeMonitor snapshotChangeMonitor = snapshotObserverRequest.getSnapshotChangeMonitor();
                        SnapshotNodeMonitor snapshotNodeMonitor = snapshotChangeMonitor.getSnapshotNodeMonitor(node);
                        if (!snapshotNodeMonitor.getSnapshotChangeInfo().isIccidDidPresent() &&
                                node.getAddress().equalsIgnoreCase(GVMSModuleUpdateConstants.NODE_754)) {
                            iccidDidRule.copyICCIDDIDsFromPrevious(previousSnapShotDetailsByNode.getPrevNonConfigDidResponseMap(),
                                    nodeAndDIDResponseForNewSnap);
                        }

                        gwNodeIdMap.put(gwNodeId + "_" + gateway.getGatewayType(), didList);
                    } //gateway type loop end


                }//state loop end
                if(isSnapSkipped) break;
                //To set ModuleNode to VehicleNodeDIDResponse entity based on below map while snap creation
                Map<String, ModuleNode> moduleNodeIdSaKeyMap = snapCreationHelper.saveModuleNode(moduleNodeMap, gwNodeIdMap,
                        node.getAddress(), snapshotObserverRequest.getVehicle(),
                        snapshotObserverRequest.getRequestRole().getRoleSource().value());
                nodeAndDIDResponseForNewSnap.setModuleNodeIdSaKeyMap(moduleNodeIdSaKeyMap);
                //ECC Acronym check
                ecuAcronymCheckRule.validateECUAcronym(snapshotObserverRequest,
                        previousSnapShotDetailsByNode, node);

                // NetworkName check
                networkNameCheckRule.validateNetworkName(snapshotObserverRequest,
                        previousSnapShotDetailsByNode, node);
            } //EcuAcronym  loop end
        } catch (Exception ex) {
            logger.error("CopyDidRuleHandler:Exception in compareAndCopyDIDsFromPreviousSnap method : " + ex
                  +" >> VIN : "+ snapshotObserverRequest.getVin()  + " >> Node : " + node.getAddress());
            exceptionHandler.logException(ex, this.getClass().getSimpleName());
            throw ex;
        }
        logger.info("CopyDidRuleHandler:End compareAndCopyDIDsFromPreviousSnap for VIN : "+ snapshotObserverRequest.getVin());
        return nodeAndDIDResponseForNewSnap;
    }


    private void buildDidRule(ModuleSnapshotObserverRequest snapshotObserverRequest, ModuleNodeType node, PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode, NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap, List<String> newApplicationList, DIDInfoType didInfoType) {
        if (ESN_DID_LIST.contains(didInfoType.getDidValue())) {
            esnDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                    nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);
        } else if (MAC_ADDRESS_DID_LIST.contains(didInfoType.getDidValue())) {
            macAddressDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                    nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);

        } else if (APPLICATION_DID_LIST.contains(didInfoType.getDidValue())) {
            applicationDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType, nodeAndDIDResponseForNewSnap,
                    node, snapshotObserverRequest, newApplicationList);

        } else if (ICCID_DID_LIST.contains(didInfoType.getDidValue())) {
            iccidDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                    nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);

        } else {
            defaultDidRule.populateDidEntity(previousSnapShotDetailsByNode, didInfoType,
                    nodeAndDIDResponseForNewSnap, node, snapshotObserverRequest);
        }
    }


}
