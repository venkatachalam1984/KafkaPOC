package com.ford.gvmsr.snapobserver.handler;

import com.ford.gvmsr.snapobserver.data.dao.*;
import com.ford.gvmsr.snapobserver.data.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Component
public class SnapshotSaveHandler {

    @Autowired
    VehicleDao vehicleDao;

    @Autowired
    VehicleSnapshotDao vehicleSnapshotDao;

    @Autowired
    VehicleNodeDao vehicleNodeDao;

    @Autowired
    VehicleNodeSnapshotDao vehicleNodeSnapshotDao;

    @Autowired
    VehicleNodeDIDResponseDao vehicleNodeDIDResponseDao;

    @Autowired
    VehicleNodeConfigDao vehicleNodeConfigDao;

    @Autowired
    VehicleNodeDIDSoftwareDao vehicleNodeDIDSoftwareDao;

    @Autowired
    VehicleSnapshotVilDao vehicleSnapshotVilDao;

    public Optional<Vehicle> getByVinAndVinHash(String vin, int vinHash) {
        return vehicleDao.findOne(new VehicleId(vin, vinHash));
    }

    public Vehicle saveVehicle(Vehicle vehicle) {
        return vehicleDao.save(vehicle);
    }

    public VehicleSnapshot saveVehicleSnapshot(VehicleSnapshot vehicleSnapshot) {
        return vehicleSnapshotDao.save(vehicleSnapshot);
    }

    public VehicleNode saveVehicleNode(VehicleNode vehicleNode) {
        return vehicleNodeDao.save(vehicleNode);
    }

    public void deactivateAllExistingVehicleNodeSnapshots(Integer vinHash, String vin, String node) {
        vehicleNodeSnapshotDao.deactivateAllExistingVehicleNodeSnapshots(vinHash, vin, node);
    }

    public VehicleNodeSnapshot saveVehicleNodeSnapshot(VehicleNodeSnapshot vehicleNodeSnapshot) throws SQLException {
        return vehicleNodeSnapshotDao.save(vehicleNodeSnapshot);
    }

    public void updateVehicleNodeSnapshot(String flag, Long primaryKey, int vinHash) throws SQLException {
        vehicleNodeSnapshotDao.update(flag, primaryKey, vinHash);
    }

    public List<VehicleNodeDIDResponse> saveVehicleNodeDIDResponse(List<VehicleNodeDIDResponse> vehicleNodeDIDResponseList) throws SQLException {
        return vehicleNodeDIDResponseDao.save(vehicleNodeDIDResponseList);
    }

    public List<VehicleNodeConfig> saveVehicleNodeConfig(List<VehicleNodeConfig> vehicleNodeConfigList){
        return vehicleNodeConfigDao.save(vehicleNodeConfigList);
    }

    public VehicleNodeDIDSoftware saveVehicleNodeDIDSoftware(VehicleNodeDIDSoftware vehicleNodeDIDSoftware){
        return vehicleNodeDIDSoftwareDao.save(vehicleNodeDIDSoftware);
    }
    public List<VehicleNodeDIDSoftware> saveAllVehicleNodeDIDSoftware(List<VehicleNodeDIDSoftware> vehicleNodeDIDSoftwareList){
        return vehicleNodeDIDSoftwareDao.saveAll(vehicleNodeDIDSoftwareList);
    }

    public VehicleSnapshotVil saveVehicleSnapShotVil(VehicleSnapshotVil vehicleSnapshotVil) {
        return vehicleSnapshotVilDao.save(vehicleSnapshotVil);
    }

}
