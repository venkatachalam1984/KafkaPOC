package com.ford.gvmsr.snapobserver.modulestate.monitor;

import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NodeLevelChangeMonitor extends SnapshotNodeMonitor {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    public NodeLevelChangeMonitor(ModuleNodeType moduleNodeType) {
        super(moduleNodeType);
    }

    @Override
    public void update(TrackingLevel trackingLevel, TrackingType trackingType, boolean isChanged) {

        switch (trackingLevel) {
            case NODE:
                nodeLevelUpdate(trackingType, isChanged);
                break;
            case DID:
                didLevelUpdate(trackingType, isChanged);
                break;
            default:
                LOGGER.error("Unexpected value: " + trackingType);
        }
    }

    @Override
    public String getKey() {
        return getKey(moduleNodeType);
    }


    protected static String getKey(ModuleNodeType moduleNodeType) {
        return moduleNodeType.getAddress();
    }

    @Override
    public SnapshotChangeInfo getSnapshotChangeInfo() {
        return snapShotChangeInfo;
    }

    private void nodeLevelUpdate(TrackingType trackingType, boolean isChanged) {
        ModuleNodeType moduleNodeType = this.moduleNodeType;
        String nodeAddress = this.nodeAddress;
        switch (trackingType) {
            case ECU_ACRONYM:
                snapShotChangeInfo.setEcuAcronymChanged(isChanged);
                break;
            case NETWORK_NAME:
                snapShotChangeInfo.setNetworkNameChanged(isChanged);
                break;
            default:
                LOGGER.error("Unexpected value: " + trackingType);
        }
    }

    private void didLevelUpdate(TrackingType trackingType, boolean isChanged) {
        ModuleNodeType moduleNodeType = this.moduleNodeType;
        String nodeAddress = this.nodeAddress;

        switch (trackingType) {
            case CONFIG_DID:
                snapShotChangeInfo.setConfigDIDChanged(isChanged);
                break;
            case NON_CONFIG_DID:
                snapShotChangeInfo.setNonConfigDIDChanged(isChanged);
                break;
            case ESN_DID:
                snapShotChangeInfo.setEsnDIDChanged(isChanged);
                break;
            case MAC_ADDRESS_DID:
                snapShotChangeInfo.setMacAddressDIDChanged(isChanged);
                break;
            case APPLICATION_DID:
                snapShotChangeInfo.setAppDIDChanged(isChanged);
                break;
            case ICCID_DID_PRESENT:
                snapShotChangeInfo.setIccidDidPresent(isChanged);
                break;
            case ICCID_DID_CHANGED:
                snapShotChangeInfo.setIccidDidChanged(isChanged);
                break;
            case VEHICLE_PROF_TRIGGER:
                snapShotChangeInfo.setVehicleProfileTrigger(isChanged);
                break;
            case SNAP_SKIP_DID:
                snapShotChangeInfo.setSnapskipDidChanged(isChanged);
                break;


            default:
                LOGGER.error("Unexpected value: " + trackingType);
        }
    }

}
