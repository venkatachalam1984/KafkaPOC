package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.TransactionDetail;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;


public interface TransactionDetailRepository extends CrudRepository<TransactionDetail, Serializable> {

    @Query("SELECT td FROM TransactionDetail td where td.transactionId.transactionId = :id")
    public abstract List<TransactionDetail> findAllByTransactionId(@Param("id") int id);

    @Query("SELECT td FROM TransactionDetail td where td.transactionId.transactionId = :id and td.vin = :vin")
    public abstract TransactionDetail findTransactionDetailByTransactionIdAndVin(@Param("id") int id, @Param("vin") String vin);

    public TransactionDetail findTransactionDetailByTransactionDetailId(long id);

    public TransactionDetail findTransactionDetailByTransactionId_TransactionId(int id);

    public List<TransactionDetail> findAllByTransactionId_TransactionType_TransactionTypeIdAndTransactionStatus_TransctionStatusCode(String transactionType, String statusCode);

    @Query(value = "select dtl.* from PGVMT03_TXN_DTL dtl,PGVMT01_TXN txn where dtl.GVMT01_TXN_D=txn.GVMT01_TXN_D and txn.GVMT08_TXN_TYPE_C='RETRYSAVE' and (txn.GVMT02_TXN_STAT_C='NEW' OR txn.GVMT02_TXN_STAT_C='INPRG') ",nativeQuery = true)
    public List<TransactionDetail> findAllByTransactionIdTransactionIdIn();

    @Modifying
    @Query("update TransactionDetail set transactionStatus.transctionStatusCode = ?2,auditColumns.lastUpdatedTimestamp = ?3  where transactionDetailId= ?1")
    public int updateTransactionDetailStatus(long transactionId, String status, Timestamp timestamp);

    @Transactional
    @Modifying
    @Query("update TransactionDetail set transactionStatus.transctionStatusCode = ?2,auditColumns.lastUpdatedTimestamp = ?3, retryCount=?4  where transactionDetailId= ?1")
    public int updateTransactionDetailStatusRetry(long transactionDtlId, String status, Timestamp timestamp,int retryCount);

    @Query(value = "select dtl.GVMT03_EXTL_SYS_TXN_D from PGVMT03_TXN_DTL dtl,PGVMT01_TXN txn where dtl.GVMT01_TXN_D=txn.GVMT01_TXN_D and dtl.GVMT02_TXN_STAT_C in ('VHPRI','VHPRF') and dtl.GVMT03_VIN_HASH_R = ?2 and dtl.GVMT03_VIN_R = ?1 and txn.GVMT01_TXN_D = ?3",nativeQuery = true)
    public List<String> findSnaphshotKeyByViinAndTranctionId(String vin, int vinHash, long transactionId);
}
