
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OptimizedDIDType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OptimizedDIDType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DID" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDType"/&gt;
 *         &lt;element name="DIDDescription" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDDescriptionType"/&gt;
 *         &lt;element name="DIDFormat" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDFormatType" minOccurs="0"/&gt;
 *         &lt;element name="DIDResponseLength" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDResponseLengthType" minOccurs="0"/&gt;
 *         &lt;element name="VINSpecificDIDFlag" type="{urn:ford/Vehicle/Module/Information/v4.0}VINSpecificDIDFlagType"/&gt;
 *         &lt;element name="PrivateNetworkDIDFlag" type="{urn:ford/Vehicle/Module/Information/v4.0}PrivateNetworkDIDFlagType"/&gt;
 *         &lt;element name="DirectConfigurationDIDFlag" type="{urn:ford/Vehicle/Module/Information/v4.0}DirectConfigurationDIDFlagType"/&gt;
 *         &lt;element name="Compliance" type="{urn:ford/Vehicle/Module/Information/v4.0}ODLComplianceDetailType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OptimizedDIDType", propOrder = {
    "did",
    "didDescription",
    "didFormat",
    "didResponseLength",
    "vinSpecificDIDFlag",
    "privateNetworkDIDFlag",
    "directConfigurationDIDFlag",
    "compliance"
})
public class OptimizedDIDType {

    @XmlElement(name = "DID", required = true)
    protected String did;
    @XmlElement(name = "DIDDescription", required = true)
    protected String didDescription;
    @XmlElement(name = "DIDFormat")
    protected String didFormat;
    @XmlElement(name = "DIDResponseLength")
    protected String didResponseLength;
    @XmlElement(name = "VINSpecificDIDFlag", required = true)
    protected String vinSpecificDIDFlag;
    @XmlElement(name = "PrivateNetworkDIDFlag", required = true)
    protected String privateNetworkDIDFlag;
    @XmlElement(name = "DirectConfigurationDIDFlag", required = true)
    protected String directConfigurationDIDFlag;
    @XmlElement(name = "Compliance")
    protected ODLComplianceDetailType compliance;

    /**
     * Gets the value of the did property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDID() {
        return did;
    }

    /**
     * Sets the value of the did property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDID(String value) {
        this.did = value;
    }

    /**
     * Gets the value of the didDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDIDDescription() {
        return didDescription;
    }

    /**
     * Sets the value of the didDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDIDDescription(String value) {
        this.didDescription = value;
    }

    /**
     * Gets the value of the didFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDIDFormat() {
        return didFormat;
    }

    /**
     * Sets the value of the didFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDIDFormat(String value) {
        this.didFormat = value;
    }

    /**
     * Gets the value of the didResponseLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDIDResponseLength() {
        return didResponseLength;
    }

    /**
     * Sets the value of the didResponseLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDIDResponseLength(String value) {
        this.didResponseLength = value;
    }

    /**
     * Gets the value of the vinSpecificDIDFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVINSpecificDIDFlag() {
        return vinSpecificDIDFlag;
    }

    /**
     * Sets the value of the vinSpecificDIDFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVINSpecificDIDFlag(String value) {
        this.vinSpecificDIDFlag = value;
    }

    /**
     * Gets the value of the privateNetworkDIDFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrivateNetworkDIDFlag() {
        return privateNetworkDIDFlag;
    }

    /**
     * Sets the value of the privateNetworkDIDFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrivateNetworkDIDFlag(String value) {
        this.privateNetworkDIDFlag = value;
    }

    /**
     * Gets the value of the directConfigurationDIDFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDirectConfigurationDIDFlag() {
        return directConfigurationDIDFlag;
    }

    /**
     * Sets the value of the directConfigurationDIDFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDirectConfigurationDIDFlag(String value) {
        this.directConfigurationDIDFlag = value;
    }

    /**
     * Gets the value of the compliance property.
     * 
     * @return
     *     possible object is
     *     {@link ODLComplianceDetailType }
     *     
     */
    public ODLComplianceDetailType getCompliance() {
        return compliance;
    }

    /**
     * Sets the value of the compliance property.
     * 
     * @param value
     *     allowed object is
     *     {@link ODLComplianceDetailType }
     *     
     */
    public void setCompliance(ODLComplianceDetailType value) {
        this.compliance = value;
    }

}
