package com.ford.gvmsr.snapobserver.externalservice.response;

import java.io.Serializable;

public class EcuPartsId implements Serializable {

    private Long ecuModuleID;
    private int ecuModuleHashNumber;
    private String did;

    public Long getEcuModuleID() {
        return ecuModuleID;
    }

    public void setEcuModuleID(Long ecuModuleID) {
        this.ecuModuleID = ecuModuleID;
    }

    public int getEcuModuleHashNumber() {
        return ecuModuleHashNumber;
    }

    public void setEcuModuleHashNumber(int ecuModuleHashNumber) {
        this.ecuModuleHashNumber = ecuModuleHashNumber;
    }

    public String getDid() {return did; }

    public void setDid(String did) {this.did = did; }
}
