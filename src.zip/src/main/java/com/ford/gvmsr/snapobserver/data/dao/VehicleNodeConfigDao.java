package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeConfig;

import java.util.List;

public interface VehicleNodeConfigDao {

    List<VehicleNodeConfig> save(List<VehicleNodeConfig> vehicleNodeConfigList);
}
