package com.ford.gvmsr.snapobserver.data.entity.transaction;

import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by TANBUCHE on 11/20/2019.
 */
@Entity
@Table(name = "PGVMT13_EXCPTN_EVNT_HDR")
public class ExceptionEventHDR extends BaseEntity {


    @Id
    @Column(name="GVMT13_EXCPTN_EVNT_HDR_K", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMT13_EXCPTN_EVNT_HDR_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMT13_EXCPTN_EVNT_HDR_K_SQ_GEN", sequenceName = "PGVMT13_EXCPTN_EVNT_HDR_K_SQ", allocationSize = 1)
    private Long exceptionEventHdrId;


    @Column(name="GVMT13_PROCESS_KEY_D")
    private String processKey;

    @Column(name="GVMT13_PROCG_SRC_C")
    private String processingSourceCode;

    @Column(name="GVMT11_EXCPTN_EVNT_C")
    private String exceptionEventCode;

    @Column(name="GVMT13_PROCESS_SUB_KEY_D")
    private String subprocessKey;

    @Column(name="GVM002_PROC_STAT_C")
    private String ntfcnEvntProcStatusCode;

    @Column(name="GVMT13_PROC_STAT_S")
    private Timestamp ntfcnEvntProcStatusTime;

    @Column(name="GVMT13_LOGICAL_DELETE_F")
     private String logicalDeleteFlag;

    @Column(name="GVMT13_EXCPTN_EVNT_HDR_S")
    private Timestamp excptnEvntHdrTime;

    @Column(name="GVM008_PROGRAM_C")
    private String programCode;

    @Column(name="GVM008_SALES_MODEL_YEAR_C")
    private Float modelYear;

    @Column(name="GVMS10_VIN_R")
    private String vin;

    @Column(name="GVMT13_ESN_R")
    private String esn;

    @Column(name="GVMT13_COMMENT_X")
    private String commentDescription;

    @Column(name="GVMS11_PLANT_C")
    private String plantCode;

    @ManyToOne
    @JoinColumn(name="GVMT12_EXCPTN_EVNT_DATA_K", referencedColumnName="GVMT12_EXCPTN_EVNT_DATA_K",insertable = true,updatable = true)
    private ExceptionEventData exceptionEventData;

    @Column(name="GVM015_SRC_SYS_C")
    private String sourceSystem;


    @Column(name="GVMT13_SENT_TO_GIVIS_F")
    private String sentToGivis;

    @Column(name="GVMT13_SENT_TO_GIVIS_S")
    private Timestamp sentToGivisTime;


    public String getProcessKey() {
        return processKey;
    }

    public void setProcessKey(String processKey) {
        this.processKey = processKey;
    }

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT13_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT13_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT13_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT13_LAST_UPDT_S"))}
    )


    public Long getExceptionEventHdrId() {
        return exceptionEventHdrId;
    }

    public void setExceptionEventHdrId(Long exceptionEventHdrId) {
        this.exceptionEventHdrId = exceptionEventHdrId;
    }


    private AuditColumns auditColumns = new AuditColumns();

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }


}
