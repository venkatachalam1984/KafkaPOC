package com.ford.gvmsr.snapobserver.dto;


import com.ford.gvmsr.snapobserver.data.entity.VehicleId;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleSnapshotType;

import java.util.ArrayList;
import java.util.List;

public class DownStreamSyncUpRequest {

    private String vin;
    private long transactionId;
    private long transactionDetailId;
    private String traceId;
    private ModuleSnapshotType moduleSnapshotType;
    private List<String> snapSNodeList;
    private Boolean isVehicleProfileTrigger;
    private List<String> vehPrfModuleNodeStrList;
    private VehicleId vehicleId;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(long transactionId) {
        this.transactionId = transactionId;
    }

    public long getTransactionDetailId() {
        return transactionDetailId;
    }

    public void setTransactionDetailId(long transactionDetailId) {
        this.transactionDetailId = transactionDetailId;
    }

    public ModuleSnapshotType getModuleSnapshotType() {
        return moduleSnapshotType;
    }

    public void setModuleSnapshotType(ModuleSnapshotType moduleSnapshotType) {
        this.moduleSnapshotType = moduleSnapshotType;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public List<String> getSnapSNodeList() {
        return snapSNodeList;
    }

    public void setSnapSNodeList(List<String> snapSNodeList) {
        this.snapSNodeList = snapSNodeList;
    }

    public Boolean getVehicleProfileTrigger() {
        return isVehicleProfileTrigger;
    }

    public void setVehicleProfileTrigger(Boolean vehicleProfileTrigger) {
        isVehicleProfileTrigger = vehicleProfileTrigger;
    }

    public List<String> getVehPrfModuleNodeStrList() {
        return vehPrfModuleNodeStrList;
    }

    public void setVehPrfModuleNodeStrList(List<String> vehPrfModuleNodeStrList) {
        this.vehPrfModuleNodeStrList = vehPrfModuleNodeStrList;
    }

    public VehicleId getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(VehicleId vehicleId) {
        this.vehicleId = vehicleId;
    }

    @Override
    public String toString() {
        return "DownStreamSyncUpRequest{" +
                "vin='" + vin + '\'' +
                ", transactionId=" + transactionId +
                ", transactionDetailId=" + transactionDetailId +
                ", traceId='" + traceId + '\'' +
                ", moduleSnapshotType=" + moduleSnapshotType +
                ", snapSNodeList=" + snapSNodeList +
                ", isVehicleProfileTrigger=" + isVehicleProfileTrigger +
                ", vehPrfModuleNodeStrList=" + vehPrfModuleNodeStrList +
                ", vehicleId=" + vehicleId +
                '}';
    }
}
