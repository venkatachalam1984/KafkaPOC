package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/30/2017.
 */
@Entity
@Table(name = "PGVMS06_VEH_NODE_CFG")
public class VehicleNodeConfig extends BaseEntity {

   @EmbeddedId
    private VehicleNodeDIDResponseId vehicleNodeDIDResponseId;

    /* @Id
    @Column(name="GVMS02_VEH_NODE_DID_RSPNS_K")
    private Long vehicleNodeDidReponseKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;*/

    @Column(name = "GVMS06_CFG_DELINEATOR_C")
    private String configurationDelimeterId;

   /*@EmbeddedId
   private VehicleNodeConfigId vehicleNodeConfigId;*/

    @Column(name = "GVMS06_CFG_X")
    private String configurationData;

    @Column(name = "GVMS06_CFG_DATA_TYPE_C")
    private String configurationDataType;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS06_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS06_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS06_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS06_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

   /* public long getVehicleNodeDidReponseKey() {
        return vehicleNodeDidReponseKey;
    }

    public void setVehicleNodeDidReponseKey(long vehicleNodeDidReponseKey) {
        this.vehicleNodeDidReponseKey = vehicleNodeDidReponseKey;
    }

    public void setVehicleNodeDidReponseKey(Long vehicleNodeDidReponseKey) {
        this.vehicleNodeDidReponseKey = vehicleNodeDidReponseKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }*/

    public String getConfigurationDelimeterId() {
        return configurationDelimeterId;
    }

    public void setConfigurationDelimeterId(String configurationDelimeterId) {
        this.configurationDelimeterId = configurationDelimeterId;
    }

    public String getConfigurationData() {
        return configurationData;
    }

    public void setConfigurationData(String configurationData) {
        this.configurationData = configurationData;
    }

    public String getConfigurationDataType() {
        return configurationDataType;
    }

    public void setConfigurationDataType(String configurationDataType) {
        this.configurationDataType = configurationDataType;
    }

    public VehicleNodeDIDResponseId getVehicleNodeDIDResponseId() {
        return vehicleNodeDIDResponseId;
    }

    public void setVehicleNodeDIDResponseId(VehicleNodeDIDResponseId vehicleNodeDIDResponseId) {
        this.vehicleNodeDIDResponseId = vehicleNodeDIDResponseId;
    }

    /*public VehicleNodeConfigId getVehicleNodeConfigId() {
        return this.vehicleNodeConfigId;
    }

    public void setVehicleNodeConfigId(VehicleNodeConfigId vehicleNodeConfigId) {
        this.vehicleNodeConfigId = vehicleNodeConfigId;
    }*/

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }


}
