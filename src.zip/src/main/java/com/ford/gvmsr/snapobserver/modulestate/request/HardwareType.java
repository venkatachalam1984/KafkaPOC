
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for HardwareType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HardwareType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MappedFeatures" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="hardwarePartNumber" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="didValue" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HardwareType", propOrder = {
    "mappedFeatures"
})
public class HardwareType {

    @XmlElement(name = "MappedFeatures")
    protected String mappedFeatures;
    @XmlAttribute(name = "hardwarePartNumber")
    protected String hardwarePartNumber;
    @XmlAttribute(name = "didValue")
    protected String didValue;

    /**
     * Gets the value of the mappedFeatures property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMappedFeatures() {
        return mappedFeatures;
    }

    /**
     * Sets the value of the mappedFeatures property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMappedFeatures(String value) {
        this.mappedFeatures = value;
    }

    /**
     * Gets the value of the hardwarePartNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwarePartNumber() {
        return hardwarePartNumber;
    }

    /**
     * Sets the value of the hardwarePartNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwarePartNumber(String value) {
        this.hardwarePartNumber = value;
    }

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidValue(String value) {
        this.didValue = value;
    }

}
