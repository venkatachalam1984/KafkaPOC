package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.constants.VilConstants;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.exception.MandatoryDidValidationException;
import com.ford.gvmsr.snapobserver.exception.StrategyDidValidationException;
import com.ford.gvmsr.snapobserver.exception.alarmevents.ExceptionEventService;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.utils.BeanUtil;
import com.ford.gvmsr.snapobserver.validator.request.NodeSkipValidatorRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class StrategyDIDValidator extends NodeSkipValidator {

    private static final Logger logger = LoggerFactory.getLogger(MandatoryDIDValidator.class);

    private ExceptionEventService exceptionEventService;

    public StrategyDIDValidator(NodeSkipValidator next) {
        super(next);
    }
    public static <E> void addAllIfNotNull(List<E> list, Collection<? extends E> c) {
        if (c != null) {
            list.addAll(c);
        }
    }

    public boolean validate(NodeSkipValidatorRequest nodeSkipValidatorRequest) throws StrategyDidValidationException {

        boolean isStartegyDIDMissing = false;
        logger.info("Received Startegy DID validation");

        List<String> requestDIDTypeList = nodeSkipValidatorRequest.getGatewayType().getDID().stream()
                .map(DIDInfoType::getDidValue)
                .collect(Collectors.toList());

        if (requestDIDTypeList.contains(VilConstants.F188_DID)) {
            List<String> currentDIDStrategyFilteredList =
                    nodeSkipValidatorRequest.getGatewayType().getDID().stream()
                            .filter(e -> nodeSkipValidatorRequest.getStrategyDidList().contains(e.getDidValue())).map(DIDInfoType::getDidValue).
                            collect(Collectors.toList());

            List<String> prevConfigDidList =
                    nodeSkipValidatorRequest.getPreviousSnapShotDetailsByNode().getPrevConfigDidTwoTableResponseMap().values().stream().
                            map(VehicleNodeDIDResponse::getDidCatalog).collect(Collectors.toList());

            List<String> prevSnapConfigNonConfigDidList = new ArrayList<>();

            addAllIfNotNull(prevSnapConfigNonConfigDidList, prevConfigDidList);
            addAllIfNotNull(prevSnapConfigNonConfigDidList, nodeSkipValidatorRequest.getPrevNonConfigDIDList());

            List<String> prevSnapStrategyFilteredDIDList =
                    prevSnapConfigNonConfigDidList.stream()
                            .filter(e -> nodeSkipValidatorRequest.getStrategyDidList().contains(e)).collect(Collectors.toList());

            prevSnapStrategyFilteredDIDList.removeAll(currentDIDStrategyFilteredList);

            if (!CollectionUtils.isEmpty(prevSnapStrategyFilteredDIDList) && prevSnapStrategyFilteredDIDList.size() > 0) {
                nodeSkipValidatorRequest.getSnapshotObserverRequest().getSnapshotChangeMonitor().
                        update(nodeSkipValidatorRequest.getNode(), TrackingLevel.DID,
                                TrackingType.SNAP_SKIP_DID, true);
                exceptionEventService = BeanUtil.getBean(ExceptionEventService.class);
                exceptionEventService.createFailureAlarm(nodeSkipValidatorRequest.getSnapshotObserverRequest().getVin(),
                        nodeSkipValidatorRequest.getNode().getAddress(),null,null, "Strategy DID Validation Failed");
                isStartegyDIDMissing  = true;
                throw new StrategyDidValidationException("Startegy DIDs " + prevSnapStrategyFilteredDIDList + " are not present");
            }
        }
        return isStartegyDIDMissing;
    }

    @Override
    public boolean handleRequest(NodeSkipValidatorRequest nodeSkipValidatorRequest) throws Exception {
        logger.info("Received Mandatory DID validation");
        return validate(nodeSkipValidatorRequest);
    }

}
