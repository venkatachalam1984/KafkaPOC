package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by VYUVARA6 on 8/30/2017.
 */
@Entity
@Table(name = "PGVMS08_VEH_AUTH_SW_PART")
public class VehicleAuthorizedSoftwarePart extends BaseEntity {

    @EmbeddedId
    private VehicleAuthorizedSoftwarePartId vehicleAuthorizedSoftwarePartId;

    @Column(name = "GVM015_SRC_SYS_C")
    private String sourceSystem;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS08_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS08_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS08_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS08_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public VehicleAuthorizedSoftwarePartId getVehicleAuthorizedSoftwarePartId() {
        return vehicleAuthorizedSoftwarePartId;
    }

    public void setVehicleAuthorizedSoftwarePartId(VehicleAuthorizedSoftwarePartId vehicleAuthorizedSoftwarePartId) {
        this.vehicleAuthorizedSoftwarePartId = vehicleAuthorizedSoftwarePartId;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }
}
