package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by MJAFARUL on 11/20/2017.
 */
@Embeddable
public class VehicleNodeDIDSoftwareId implements Serializable {

/*    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;*/

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "GVMS02_VEH_NODE_DID_RSPNS_K", referencedColumnName = "GVMS02_VEH_NODE_DID_RSPNS_K",insertable = false,updatable = false),
            @JoinColumn(name = "GVMS10_VIN_HASH_R", referencedColumnName = "GVMS10_VIN_HASH_R",insertable = false,updatable = false)
    })
    private VehicleNodeDIDResponse vehicleNodeDID;

    @Column(name="GVMS07_SW_PART_SEQ_R")
    private int partSequenceNumber;

/*
    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }*/

    public VehicleNodeDIDResponse getVehicleNodeDID() {
        return vehicleNodeDID;
    }

    public void setVehicleNodeDID(VehicleNodeDIDResponse vehicleNodeDID) {
        this.vehicleNodeDID = vehicleNodeDID;
    }

    public int getPartSequenceNumber() {
        return partSequenceNumber;
    }

    public void setPartSequenceNumber(int partSequenceNumber) {
        this.partSequenceNumber = partSequenceNumber;
    }
}
