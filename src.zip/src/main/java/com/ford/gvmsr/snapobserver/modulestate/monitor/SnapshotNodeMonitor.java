package com.ford.gvmsr.snapobserver.modulestate.monitor;

import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;

public abstract class SnapshotNodeMonitor {

    protected ModuleNodeType moduleNodeType;
    protected String nodeAddress;
    protected SnapshotChangeInfo snapShotChangeInfo;

    public SnapshotNodeMonitor(ModuleNodeType moduleNodeType) {

        if (moduleNodeType == null) {
            throw new IllegalStateException("Node Cannot be null for SnapshotNodeMonitor");
        }
        this.moduleNodeType = moduleNodeType;
        this.nodeAddress = moduleNodeType.getAddress();
        snapShotChangeInfo = new SnapshotChangeInfo();
    }

    public abstract void update(TrackingLevel trackingLevel, TrackingType name, boolean isChanged);

    public abstract String getKey();

    public SnapshotChangeInfo getSnapshotChangeInfo() {
        return snapShotChangeInfo;
    }

    public ModuleNodeType getModuleNodeType() {
        return moduleNodeType;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public boolean isNodeChanged() {

        if(snapShotChangeInfo.isSnapskipDidChanged()) return false;

        return snapShotChangeInfo.isConfigDIDChanged() || snapShotChangeInfo.isNonConfigDIDChanged() ||
                snapShotChangeInfo.isEsnDIDChanged() || snapShotChangeInfo.isMacAddressDIDChanged() ||
                snapShotChangeInfo.isAppDIDChanged() || snapShotChangeInfo.isIccidDidChanged() ||
                snapShotChangeInfo.isEcuAcronymChanged() || snapShotChangeInfo.isNetworkNameChanged();
    }


    public boolean isVehicleProfileTrigger() {
        return snapShotChangeInfo.isNonConfigDIDChanged() || snapShotChangeInfo.isEsnDIDChanged() ||
                snapShotChangeInfo.isMacAddressDIDChanged() || snapShotChangeInfo.isAppDIDChanged() ||
                snapShotChangeInfo.isIccidDidChanged() || snapShotChangeInfo.isVehicleProfileTrigger();
    }



}
