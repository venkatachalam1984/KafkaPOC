package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.exception.MandatoryDidValidationException;
import com.ford.gvmsr.snapobserver.exception.alarmevents.ExceptionEventService;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.utils.BeanUtil;
import com.ford.gvmsr.snapobserver.validator.request.NodeSkipValidatorRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;


public class MandatoryDIDValidator extends NodeSkipValidator {

    private static final Logger logger = LoggerFactory.getLogger(MandatoryDIDValidator.class);

    private ExceptionEventService exceptionEventService;

    public MandatoryDIDValidator(NodeSkipValidator next) {
        super(next);
    }

    public boolean validate(NodeSkipValidatorRequest nodeSkipValidatorRequest) throws MandatoryDidValidationException {

        boolean isMandatoryDIDMissing = false;
        logger.info("Received Mandatory validation");

        List<String> currentMandatoryDIDList =
                nodeSkipValidatorRequest.getGatewayType().getDID().stream()
                        .filter(e -> nodeSkipValidatorRequest.getMandatoryDidList().contains(e.getDidValue())).map(DIDInfoType::getDidValue).
                        collect(Collectors.toList());

        List<String> prevSnapMandatoryDIDList =
                nodeSkipValidatorRequest.getPrevNonConfigDIDList().stream()
                        .filter(e -> nodeSkipValidatorRequest.getMandatoryDidList().contains(e)).collect(Collectors.toList());

        prevSnapMandatoryDIDList.removeAll(currentMandatoryDIDList);

        if(!CollectionUtils.isEmpty(prevSnapMandatoryDIDList) && prevSnapMandatoryDIDList.size()>0) {
            nodeSkipValidatorRequest.getSnapshotObserverRequest().getSnapshotChangeMonitor().
                    update(nodeSkipValidatorRequest.getNode(), TrackingLevel.DID,
                            TrackingType.SNAP_SKIP_DID, true);
            //Add Missing didlist splunk & alarm
            exceptionEventService = BeanUtil.getBean(ExceptionEventService.class);
            exceptionEventService.createFailureAlarm(nodeSkipValidatorRequest.getSnapshotObserverRequest().getVin(),
                    nodeSkipValidatorRequest.getNode().getAddress(),null,null, "Mandatory DID Validation Failed");
            isMandatoryDIDMissing = true;
            throw new MandatoryDidValidationException("Mandatory DIDs "+prevSnapMandatoryDIDList+" are not present or Blank");
        }
        return isMandatoryDIDMissing;

    }

    @Override
    public boolean handleRequest(NodeSkipValidatorRequest nodeSkipValidatorRequest) throws Exception {

        logger.info("Received ESN DID validation");
        validate(nodeSkipValidatorRequest);
        super.handleRequest(nodeSkipValidatorRequest);
        return false;
    }
}
