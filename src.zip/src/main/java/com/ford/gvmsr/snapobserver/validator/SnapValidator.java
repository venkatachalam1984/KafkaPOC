package com.ford.gvmsr.snapobserver.validator;

public interface SnapValidator {
     Boolean checkAnySnapIsInProgressForVin(String vin, String nodeAddress);
     Boolean deleteSnapInProgressKeyFromRedis(String vin , String nodeAddress);
}
