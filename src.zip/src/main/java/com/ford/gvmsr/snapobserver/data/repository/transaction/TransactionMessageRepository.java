package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.TransactionMessage;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;

public interface TransactionMessageRepository  extends CrudRepository<TransactionMessage, Serializable> {
}
