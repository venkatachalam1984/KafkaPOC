package com.ford.gvmsr.snapobserver.logevent.splunk;

public class SplunkLogEvent {

    String host;
    String source;
    String sourcetype;
    String event;
    String time;

    public String getHost() {
        return host;
    }
    public void setHost(String host) {
        this.host = host;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSourcetype() {
        return sourcetype;
    }

    public void setSourcetype(String sourcetype) {
        this.sourcetype = sourcetype;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getTime() {
        return String.valueOf(System.currentTimeMillis()/1000);
    }

    public void setTime(String time) {
        this.time = time;
    }
}
