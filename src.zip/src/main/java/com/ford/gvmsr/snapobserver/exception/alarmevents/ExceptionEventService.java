package com.ford.gvmsr.snapobserver.exception.alarmevents;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.snapobserver.config.VertxConfiguration;
import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.data.entity.IVSProgramId;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.kafka.producer.GVMSRExceptionEventProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component
@Scope("prototype")
public class ExceptionEventService {

    private IVSProgramId ivsProgramId;
    private String vin;

    private List<ExceptionEventHeaderTO> exceptionEventHeaderTOList = null;

    public IVSProgramId getIvsProgramId() {
        return ivsProgramId;
    }

    public void setIvsProgramId(IVSProgramId ivsProgramId) {
        this.ivsProgramId = ivsProgramId;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    List<String> exceptionEventsWithAutoClear = new ArrayList<>();

    @Autowired
    private ExceptionHandler exceptionHandler;

    @Autowired
    GVMSRExceptionEventProducer gvmsrExceptionEventProducer;
    @Autowired
    VertxConfiguration vertxConfiguration;

    public void createFailureAlarm(String vin, String nodeAddress, String esn, VehicleNodeDIDResponse didEntity, String alarmMessage) {
        try {
            exceptionEventHeaderTOList = new ArrayList<>();
            ExceptionEventDetailTO exceptionEventDetailTO = new ExceptionEventDetailTO(GVMSModuleUpdateConstants.NO, nodeAddress, didEntity.getDidCatalog(), "AnalyzeLogECU Unable to Update APIM Data - " + alarmMessage);
            List<ExceptionEventDetailTO> exceptionEventDetails = new ArrayList<>();
            exceptionEventDetails.add(exceptionEventDetailTO);
            ExceptionEventHeaderTO exceptionEventHeaderTO = createAlarmForFailure("PTS", ExceptionEventConstants.VL01_EVENT_CODE, vin + ";" + nodeAddress + ";" + GVMSModuleUpdateConstants.APPLICATION, ExceptionEventConstants.ERROR, esn, null, false, exceptionEventDetails);
            exceptionEventHeaderTOList.add(exceptionEventHeaderTO);
            sendAlarm(exceptionEventHeaderTOList);
        } catch (Exception e) {
            exceptionHandler.logException(e, this.getClass().getSimpleName());
        }
    }

    public ExceptionEventHeaderTO createAlarmForFailure(String processingSourceCode, String exceptionEventCode, String processKey, String subprocessKey, String esn, String commentDesc, boolean clobRequired, List<ExceptionEventDetailTO> exceptionEventDetails) {
        ExceptionEventHeaderTO exceptionEventHeaderTO = new ExceptionEventHeaderTO();
        exceptionEventHeaderTO.setProcessingSourceCode(processingSourceCode);
        exceptionEventHeaderTO.setExceptionEventCode(exceptionEventCode);
        exceptionEventHeaderTO.setProcessKey(processKey);
        exceptionEventHeaderTO.setSubprocessKey(subprocessKey);
        exceptionEventHeaderTO.setVin(vin);
        exceptionEventHeaderTO.setEsn(esn);
        exceptionEventHeaderTO.setSourceSystem("GVMS");
        if (commentDesc != null) {
            exceptionEventHeaderTO.setCommentDescription(commentDesc);
        } else {
            exceptionEventHeaderTO.setCommentDescription(processKey);
        }
        if (getIvsProgramId() != null) {
            exceptionEventHeaderTO.setProgramCode(getIvsProgramId().getProgramCode());
            exceptionEventHeaderTO.setModelYear(getIvsProgramId().getSalesModelYear());
        }
        exceptionEventHeaderTO.setClobRequired(clobRequired);
        exceptionEventHeaderTO.setExceptionEventDetailList(exceptionEventDetails);
        return exceptionEventHeaderTO;
    }

    private void sendAlarm(List<ExceptionEventHeaderTO> exceptionEventHeaderTOList){
        ExceptionEventTO exceptionEventTO =new ExceptionEventTO();
        exceptionEventTO.setExceptionEventHeaderTOList(exceptionEventHeaderTOList);
        ObjectMapper obj = new ObjectMapper();
        String exceptionEventStr;
        try {
            exceptionEventStr = obj.writeValueAsString(exceptionEventTO);
            gvmsrExceptionEventProducer.publishMessage(exceptionEventStr, vertxConfiguration.getExceptionEventProducerTopic());
        }catch (Exception e){
            exceptionHandler.logException(e,this.getClass().getSimpleName());
        }
    }

}
