package com.ford.gvmsr.snapobserver.data.entity.base;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.sql.Timestamp;

/**
 * Created by VYUVARA6 on 9/4/2017.
 */
@Embeddable
public class AuditColumns {

    @Column(name = "createdUser")
    private String createdUser;

    @Column(name = "createdTimestamp")
    private Timestamp createdTimestamp;

    @Column(name = "lastUpdatedUser")
    private String lastUpdatedUser;

    @Column(name = "lastUpdatedTimestamp")
    private Timestamp lastUpdatedTimestamp;


    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Timestamp getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(Timestamp createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    public Timestamp getLastUpdatedTimestamp() {
        return lastUpdatedTimestamp;
    }

    public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
        this.lastUpdatedTimestamp = lastUpdatedTimestamp;
    }
}
