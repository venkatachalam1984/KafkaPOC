package com.ford.gvmsr.snapobserver.data.entity.transaction;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

@Entity
@Table(name="PGVMT08_TXN_TYPE")
public class TransactionType extends BaseEntity {

    @Id
    @Column(name="GVMT08_TXN_TYPE_C")
    private String transactionTypeId;

    @Column(name="GVMT08_TXN_TYPE_N")
    private String transactioTypeName;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT08_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT08_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT08_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT08_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public String getTransactionTypeId() {
        return transactionTypeId;
    }

    public void setTransactionTypeId(String transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
    }

    public String getTransactioTypeName() {
        return transactioTypeName;
    }

    public void setTransactioTypeDesc(String transactioTypeName) {
        this.transactioTypeName = transactioTypeName;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }
}
