package com.ford.gvmsr.snapobserver.externalservice.response;



import com.ford.gvmsr.snapobserver.data.entity.FordPartNumberId;

/**
 * Created by MDEVARA3 on 1/3/2018.
 */
public class PartDIDComplianceDetailTO {


    private String complianceDid;

    private String complianceResponse;

    private String specComplianceDID;

    private String specDIDDescription;

    private String specResponse;

    public String getSpecComplianceDID() {
        return specComplianceDID;
    }

    public void setSpecComplianceDID(String specComplianceDID) {
        this.specComplianceDID = specComplianceDID;
    }

    public String getSpecDIDDescription() {
        return specDIDDescription;
    }

    public void setSpecDIDDescription(String specDIDDescription) {
        this.specDIDDescription = specDIDDescription;
    }

    public String getSpecResponse() {
        return specResponse;
    }

    public void setSpecResponse(String specResponse) {
        this.specResponse = specResponse;
    }


    private FordPartNumberId fordPartNumberId;

    public String getComplianceDid() {
        return complianceDid;
    }

    public void setComplianceDid(String complianceDid) {
        this.complianceDid = complianceDid;
    }

    public String getComplianceResponse() {
        return complianceResponse;
    }

    public void setComplianceResponse(String complianceResponse) {
        this.complianceResponse = complianceResponse;
    }


    public FordPartNumberId getFordPartNumberId() {
        return fordPartNumberId;
    }

    public void setFordPartNumberId(FordPartNumberId fordPartNumberId) {
        this.fordPartNumberId = fordPartNumberId;
    }

}
