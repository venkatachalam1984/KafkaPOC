package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDStatus;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDStatusID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.List;

@Repository
@Transactional
public interface VehicleNodeDIDStatusRepository extends JpaRepository<VehicleNodeDIDStatus, VehicleNodeDIDStatusID> {

    List<VehicleNodeDIDStatus> findAllByVehicleNodeDIDStatusID_VinHashNumberAndVinAndSoftwareStatus_SoftwareStatusCode(int vinHash, String vin, String swState);

    @Modifying
    @Query(value = "INSERT INTO PGVMS20_VEH_NODE_DID_ST(GVMS10_VIN_HASH_R,GVMS20_VEH_NODE_DID_ST_K,GVMS10_VIN_R,GVM023_NODE_ADRS_C,GVM011_DID_CATLG_D,GVMS20_RECORD_S,GVMS19_SW_ST_C," +
            "GVMS01_ROLE_N,GVM022_PART_PREFIX_R,GVM022_PART_BASE_R,GVM022_PART_SUFFIX_R,GVM019_ECU_ACRONYM_C,GVMS20_ROLE_SRC_C," +
            "GVMS20_ROLE_X,GVMS20_CREATE_USER_C,GVMS20_CREATE_S,GVMS20_LAST_UPDT_USER_C,GVMS20_LAST_UPDT_S) " +
            "VALUES (?1,PGVMS20_VEH_NODE_DID_ST_K_SQ.NEXTVAL,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17)", nativeQuery = true)
    public void insertVehicleState(@Param("vinHashNumber") int vinHashNumber, @Param("vin") String vin, @Param("nodeAddress") String nodeAddress, @Param("didCatalog") String didCatalog, @Param("recordedTime") Timestamp recordedTime, @Param("softwareStatusCode") String softwareStatusCode, @Param("roleName") String roleName, @Param("fordPartNumberPrefix") String fordPartNumberPrefix, @Param("fordPartNumberBase") String fordPartNumberBase, @Param("fordPartNumberSuffix") String fordPartNumberSuffix, @Param("ecuAcronym") String ecuAcronym, @Param("roleSource") String roleSource, @Param("roleDescription") String roleDescription, @Param("createdUser") String createdUser, @Param("createdTimestamp") Timestamp createdTimestamp, @Param("lastUpdatedUser") String lastUpdatedUser, @Param("lastUpdatedTimestamp") Timestamp lastUpdatedTimestamp);

    @Modifying
    @Query(value = "UPDATE PGVMS20_VEH_NODE_DID_ST SET GVMS19_SW_ST_C= ?1,GVMS20_RECORD_S=?11 WHERE GVMS10_VIN_HASH_R=?2 AND GVMS10_VIN_R=?3 AND GVM023_NODE_ADRS_C=?4" +
            " and GVM011_DID_CATLG_D=?5 AND GVM022_PART_PREFIX_R=?6 AND GVM022_PART_BASE_R =?7 AND GVM022_PART_SUFFIX_R=?8 " +
            "AND GVM019_ECU_ACRONYM_C=?9 AND GVMS20_VEH_NODE_DID_ST_K=?10", nativeQuery = true)
    public int updateVehicleState(String softwareStatusCode, int vinHashNumber, String vin, String nodeAddress, String didCatalog, String fordPartNumberPrefix, String fordPartNumberBase, String fordPartNumberSuffix, String ecuAcronym, long vehicleNodeDidStatusKey, Timestamp recordedTime);

}
