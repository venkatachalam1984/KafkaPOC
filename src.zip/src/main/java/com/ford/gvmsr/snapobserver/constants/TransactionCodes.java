package com.ford.gvmsr.snapobserver.constants;


public class TransactionCodes {

    /**
     * Transaction status codes
     **/
    public enum TransactionStatus {

        NEW("NEW"),SCHEDULED("SCHEDULED"),
        ALS("ALS"),ALF("ALF"),
        VLS("VLS"),VLF("VLF"),
        CCPUS("CCPUS"),CCPUT("CCPUT"),CCPUF("CCPUF"),
        ALCMS("ALCMS"),ALCMF("ALCMF"),
        RMQS("RMQS"),RMQF("RMQF"),
        FTRS("FTRS"),
        GCLHS("GCLHS"),GCLHF("GCLHF"),GCLWS("GCLWS"),GCLWF("GCLWF"),
        INPRG("INPRG"), SUCCESS("CMPLT"), IVSUN("IVSUN"),ERROR("ERROR"),
        RETRY("RETRY"),
        GVSKS("GVSKS"),
        GVSKF("GVSKF"),
        GVSHS("GVSHS"),
        GVSHF("GVSHF"),
        IGNORE("IGNRE"),
        VHPRI("VHPRI"),
        VHPRS("VHPRS"),
        VHPRF("VHPRF"),
        VPRTY("VPRTY"),
        CFGS("CFGS"),CFGF("CFGF"),
        GVSI("GVSI"),GVSS("GVSS"),GVSF("GVSF"),
        RTYHTTP("RTY-HTTP"),
        RTYKAFKA("RTY-KAFKA");

        private final String status;

        private TransactionStatus(String s) {
            this.status = s;
        }

        public String status() {
            return status;
        }
    }

    /**
     * Transaction status codes
     **/
    public enum TransactionType {
        RECVVIN("RECVVIN"),
        RECVECU("RECVECU"),
        RECVVINMAP("RECVVINMAP"),
        RECDIVSXML("RECDIVSXML"),
        RECVFTR("RECVFTR"),
        RECVVINBIN("RECVVINBIN"),
        RECVVINM2C("RECVVINM2C"),
        RETRYSAVE("RETRYSAVE"),
        ANALYZELOG("ANALYZELOG"),
        VILLOG("VILLOG"),
        ANALYZELOG_FTR("ALSNDFTR"),
        RECVVIL("RECVVIL"),
        CCPULOGGEN2("CCPULGGEN2"),
        CCPULOGGEN3("CCPULGGEN3"),
        SNDVEHPROF("SNDVEHPROF"),
		SENDGIVIS("SENDGIVIS"),
        CFGLOG("CFGLOG");

        private final String type;

        private TransactionType(String s) {
            this.type = s;
        }

        public String type() {
            return type;
        }
    }


    /**
     * Error and Success status codes
     **/
    public enum ErrorCodes {
        SUCCESS(0, "Success"),
        ERROR_EXCEPTION(10, "FAILURE. Error while processing Request");

        private final int code;
        private final String description;

        ErrorCodes(int aCode, String desc) {
            this.code = aCode;
            this.description = desc;
        }

        public int code() {
            return this.code;
        }

        public String description() {
            return this.description;
        }

        public String codeAndDescription() {
            return new StringBuffer(this.code).append(" - ").append(this.description).toString();
        }

        public static String description(int errorNum) {

            StringBuffer messageDesc = new StringBuffer();
            switch (errorNum) {
                case 0:
                    messageDesc.append(SUCCESS.description());
                    break;
                case 10:
                    messageDesc.append(ERROR_EXCEPTION.description());
                    break;
                default:
                    messageDesc.append("Unknown Error.");
                    break;
            }
            return messageDesc.toString();
        }
    }

}
