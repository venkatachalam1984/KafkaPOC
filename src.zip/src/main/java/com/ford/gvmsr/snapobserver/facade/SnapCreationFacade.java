package com.ford.gvmsr.snapobserver.facade;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.constants.SnapConstants;
import com.ford.gvmsr.snapobserver.constants.TransactionCodes;
import com.ford.gvmsr.snapobserver.creator.*;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.dto.NodeStatus;
import com.ford.gvmsr.snapobserver.dto.RequestRole;
import com.ford.gvmsr.snapobserver.dto.SnapshotResponse;
import com.ford.gvmsr.snapobserver.enums.SnapStatus;
import com.ford.gvmsr.snapobserver.externalservice.downstream.DownstreamSyncHandler;
import com.ford.gvmsr.snapobserver.handler.TransactionSaveHandler;
import com.ford.gvmsr.snapobserver.logevent.LogEventMonitor;
import com.ford.gvmsr.snapobserver.logevent.LogType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.SnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import com.ford.gvmsr.snapobserver.validator.SnapDuplicateValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;


@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SnapCreationFacade {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    LogEventMonitor logEventMonitor;

    @Autowired
    VinCreator vinCreator;

    @Autowired
    NodeCreator nodeCreator;

    @Autowired
    VehicleSnapshotCreator vehicleSnapshotCreator;

    @Autowired
    DidCreator didCreator;

    @Autowired
    ConfigDidCreator configDidCreator;

    @Autowired
    DownstreamSyncHandler downstreamSyncHandler;

    @Autowired
    SnapDuplicateValidator snapDuplicateValidator;

    @Autowired
    TransactionSaveHandler transactionSaveHandler;


    public SnapshotResponse createSnapshot(SnapshotObserverRequest snapshotObserverRequest) {
        LOGGER.info("SnapshotCreation:Entering createSnapshot");
        long start = System.currentTimeMillis();
        //New SnapshotObserverRequest
        ModuleSnapshotObserverRequest moduleSnapshotObserverRequest = new ModuleSnapshotObserverRequest(snapshotObserverRequest);

        SnapshotResponse snapshotResponse = new SnapshotResponse();
        snapshotResponse.setTraceId(moduleSnapshotObserverRequest.getTraceId());
        snapshotResponse.setVin(moduleSnapshotObserverRequest.getVin());
        snapshotResponse.setRecordKey(moduleSnapshotObserverRequest.getSnapshotObserverRequest().getRecordKey());
        RequestRole requestRole = new RequestRole();
        requestRole.setRole(moduleSnapshotObserverRequest.getRequestRole().getRole().value());
        requestRole.setRoleId(moduleSnapshotObserverRequest.getRequestRole().getRoleID());
        requestRole.setRoleDescription(moduleSnapshotObserverRequest.getRequestRole().getRoleDesc());
        requestRole.setRoleSource(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value());
        snapshotResponse.setRequestRole(requestRole);
        try {
            // ResponseObject -> Snapstatus , traceid, vin,
            LOGGER.debug("SnapshotCreation:MAIN FLOW:Create Vehicle VIN : " + moduleSnapshotObserverRequest.getVin());
            Vehicle vehicle = createVin(moduleSnapshotObserverRequest);
            moduleSnapshotObserverRequest.setVehicle(vehicle);
            Timestamp vinRecordedTimestamp = new Timestamp(new Date().getTime());
            LOGGER.debug("SnapshotCreation:before duplicate Validation:Create Vehicle Snapshot : " + moduleSnapshotObserverRequest.getVin());
            Map<String, NodeAndDIDResponseForNewSnap> nodeAndDIDResponseForNewSnapMap =
                    snapDuplicateValidator.validateDidResponseForNodes(moduleSnapshotObserverRequest, moduleSnapshotObserverRequest.getVehicle());
            moduleSnapshotObserverRequest.setNodeAndDIDResponseForNewSnapMap(nodeAndDIDResponseForNewSnapMap);
            moduleSnapshotObserverRequest.setVinRecordedTimestamp(vinRecordedTimestamp);

            LOGGER.debug("SnapshotCreation:after duplicate Validation:Create Vehicle Snapshot : " + moduleSnapshotObserverRequest.getVin());
            VehicleSnapshot vehicleSnapshot = createVehicleSnapshot(moduleSnapshotObserverRequest, vehicle);

            Map<String, NodeStatus> nodeStatusMap = nodeCreator.persistNode(vehicle, vehicleSnapshot, moduleSnapshotObserverRequest);
            snapshotResponse.setNodeStatusMap(nodeStatusMap);
            snapshotResponse.setSnapStatus(SnapConstants.SUCCESS);

            if(nodeStatusMap.entrySet().stream().anyMatch(nodeStatusEntry ->
                    nodeStatusEntry.getValue().getCode().equalsIgnoreCase(SnapStatus.SUCCESS.getCode()))) {
                //make entry in transaction and transaction details table after snap success
                long transactionId = transactionSaveHandler.saveTransaction(moduleSnapshotObserverRequest,
                        TransactionCodes.TransactionStatus.NEW.status(), GVMSModuleUpdateConstants.APP_CODE_GVMS);
                String status = ApplicationUtils.checkIsVil(moduleSnapshotObserverRequest) ?
                        TransactionCodes.TransactionStatus.VLS.status() : TransactionCodes.TransactionStatus.ALS.status();
                long transactionDetailId = transactionSaveHandler.saveTransactionDetail(moduleSnapshotObserverRequest, transactionId, status);
                //post request to module update service for sync up
                downstreamSyncHandler.sendToDownstreamSystems(moduleSnapshotObserverRequest, nodeStatusMap, transactionId,
                        transactionDetailId, vinRecordedTimestamp, vehicle.getVehicleId());
            }else{
                String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
                logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value(), moduleSnapshotObserverRequest.getVin(), null, moduleSnapshotObserverRequest.getTraceId(),
                        LogType.INFO, SnapStatus.DUPLICATE_SNAP.getCode(), duration, CommonUtils.getEventTimeStamp(),null);
            }

        } catch (Exception e) {
            snapshotResponse.setSnapStatus("Exception : "+ e.getMessage());
            long transactionId = transactionSaveHandler.saveTransaction(moduleSnapshotObserverRequest,
                    TransactionCodes.TransactionStatus.ERROR.status(), GVMSModuleUpdateConstants.APP_CODE_GVMS);
            String status = ApplicationUtils.checkIsVil(moduleSnapshotObserverRequest) ?
                    TransactionCodes.TransactionStatus.VLF.status(): TransactionCodes.TransactionStatus.ALF.status();
            transactionSaveHandler.saveTransactionDetail(moduleSnapshotObserverRequest, transactionId, status);

            String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
            logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value(), moduleSnapshotObserverRequest.getVin(), null, moduleSnapshotObserverRequest.getTraceId(),
                    LogType.FATAL, SnapStatus.FACADE_ERR.getCode(), duration, CommonUtils.getEventTimeStamp(), e.getMessage());
        }
        return snapshotResponse;
    }

    private Vehicle createVin(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest) {
        return vinCreator.createVin(moduleSnapshotObserverRequest.getVin(), moduleSnapshotObserverRequest.getRequestRole().getRoleSource());
    }

    private VehicleSnapshot createVehicleSnapshot(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, Vehicle vehicle) {
        return vehicleSnapshotCreator.createVehicleSnapshot(moduleSnapshotObserverRequest, vehicle);
    }
}
