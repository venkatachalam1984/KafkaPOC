package com.ford.gvmsr.snapobserver.modulestate.request;


import java.sql.Timestamp;
import java.util.Map;

public class SnapshotObserverRequest {

   private ModuleStateRequest moduleStateRequest;
   private Long infoKey;
   private long recordKey;
   private Map<String,String> redisValue;
   private String partitionKey;
   private Map<String,AdditionalProperties> additionalPropertiesMap;
   private VilHeader vilHeader;
   private String requestType;
   private Timestamp vilProcessedTime;

   public ModuleStateRequest getModuleStateRequest() {
      return moduleStateRequest;
   }

   public void setModuleStateRequest(ModuleStateRequest moduleStateRequest) {
      this.moduleStateRequest = moduleStateRequest;
   }

   public long getRecordKey() {
      return recordKey;
   }

   public void setRecordKey(long recordKey) {
      this.recordKey = recordKey;
   }

   public Map<String, AdditionalProperties> getAdditionalPropertiesMap() {
      return additionalPropertiesMap;
   }

   public void setAdditionalPropertiesMap(Map<String, AdditionalProperties> additionalPropertiesMap) {
      this.additionalPropertiesMap = additionalPropertiesMap;
   }

   public Long getInfoKey() {
      return infoKey;
   }

   public void setInfoKey(Long infoKey) {
      this.infoKey = infoKey;
   }

   public Map<String, String> getRedisValue() {
      return redisValue;
   }

   public void setRedisValue(Map<String, String> redisValue) {
      this.redisValue = redisValue;
   }

   public String getPartitionKey() {
      return partitionKey;
   }

   public void setPartitionKey(String partitionKey) {
      this.partitionKey = partitionKey;
   }

   public VilHeader getVilHeader() {
      return vilHeader;
   }

   public void setVilHeader(VilHeader vilHeader) {
      this.vilHeader = vilHeader;
   }

   public String getRequestType() {
      return requestType;
   }

   public void setRequestType(String requestType) {
      this.requestType = requestType;
   }

   public Timestamp getVilProcessedTime() {
      return vilProcessedTime;
   }

   public void setVilProcessedTime(Timestamp vilProcessedTime) {
      this.vilProcessedTime = vilProcessedTime;
   }
}
