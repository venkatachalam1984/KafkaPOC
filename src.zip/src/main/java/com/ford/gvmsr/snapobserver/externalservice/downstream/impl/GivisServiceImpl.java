package com.ford.gvmsr.snapobserver.externalservice.downstream.impl;

import com.ford.gvmsr.snapobserver.externalservice.downstream.GivisService;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleStateRequest;
import org.springframework.stereotype.Service;

@Service
public class GivisServiceImpl implements GivisService {

    @Override
    public void sendToGivis(ModuleStateRequest moduleStateRequest) {

    }
}
