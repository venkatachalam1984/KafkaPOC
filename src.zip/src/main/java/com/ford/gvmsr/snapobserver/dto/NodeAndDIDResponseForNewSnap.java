package com.ford.gvmsr.snapobserver.dto;

import com.ford.gvmsr.snapobserver.data.entity.ModuleNode;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeConfig;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NodeAndDIDResponseForNewSnap {

    private List<VehicleNodeDIDResponse> vehicleNodeDIDResponseList = new ArrayList<>();
    private Map<String, VehicleNodeConfig> vehicleNodeConfigMap = new HashMap<>();
    private Map<String, ModuleNode> moduleNodeIdSaKeyMap = new HashMap<>();
    private Map<String, String> paakProvisionMap = new HashMap<>();
    private List<VehicleNodeDIDStatus> previousVehicleNodeStatusList = new ArrayList<>();


    public List<VehicleNodeDIDResponse> getVehicleNodeDIDResponseList() {
        return vehicleNodeDIDResponseList;
    }

    public void setVehicleNodeDIDResponseList(List<VehicleNodeDIDResponse> vehicleNodeDIDResponseList) {
        this.vehicleNodeDIDResponseList = vehicleNodeDIDResponseList;
    }

    public Map<String, VehicleNodeConfig> getVehicleNodeConfigMap() {
        return vehicleNodeConfigMap;
    }

    public void setVehicleNodeConfigMap(Map<String, VehicleNodeConfig> vehicleNodeConfigMap) {
        this.vehicleNodeConfigMap = vehicleNodeConfigMap;
    }

    public Map<String, ModuleNode> getModuleNodeIdSaKeyMap() {
        return moduleNodeIdSaKeyMap;
    }

    public void setModuleNodeIdSaKeyMap(Map<String, ModuleNode> moduleNodeIdSaKeyMap) {
        this.moduleNodeIdSaKeyMap = moduleNodeIdSaKeyMap;
    }

    public Map<String, String> getPaakProvisionMap() {
        return paakProvisionMap;
    }

    public void setPaakProvisionMap(Map<String, String> paakProvisionMap) {
        this.paakProvisionMap = paakProvisionMap;
    }

    public List<VehicleNodeDIDStatus> getPreviousVehicleNodeStatusList() {
        return previousVehicleNodeStatusList;
    }

    public void setPreviousVehicleNodeStatusList(List<VehicleNodeDIDStatus> previousVehicleNodeStatusList) {
        this.previousVehicleNodeStatusList = previousVehicleNodeStatusList;
    }
}
