package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.*;
import com.ford.gvmsr.snapobserver.data.entity.*;
import com.ford.gvmsr.snapobserver.data.repository.VehicleNodeDIDResponseRepository;
import com.ford.gvmsr.snapobserver.data.repository.VehicleNodeSnapshotRepository;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@Component
public class PreviousVehicleSnapShotDaoImpl implements PreviousVehicleSnapShotDao {

    private static final String CLASS_NAME = "PreviousVehicleSnapShotDaoImpl";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    VehicleNodeSnapshotRepository vehicleNodeSnapshotRepository;

    @Autowired
    VehicleNodeDIDResponseRepository vehicleNodeDIDResponseRepository;

    @Autowired
    VehicleNodeDIDStatusDao vehicleNodeDIDStatusDao;

    @Autowired
    VehicleSnapshotDao vehicleSnapshotDao;

    @Autowired
    ModuleNodeDao moduleNodeDao;

    @Autowired
    VehicleNodeDao vehicleNodeDao;

    private DataSource dataSource;

    public PreviousVehicleSnapShotDaoImpl(@Qualifier("dataSource") DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public Set<VehicleNodeSnapshot> fetchPreviousActiveVehicleNodeSnapshotForAllNode(String vin, List<String> nodeListFromRequest) {
        Set<VehicleNodeSnapshot> prevVehicleNodeSnapshotList = null;
        try{
            prevVehicleNodeSnapshotList = vehicleNodeSnapshotRepository.getVehicleNodeSnapshotsByVehicleNodeSnapshotId_VinHashNumberAndVinAndNodeListAndActiveFlag(ApplicationUtils.getVinHash(vin), vin, nodeListFromRequest, "A");

        }catch(Exception ex){
            logger.error("Exception while fetchPreviousActiveVehicleNodeSnapshotForAllNode :" +ex.getMessage());
        }
        return prevVehicleNodeSnapshotList;
    }

    @Override
    public Map<String, List<VehicleNodeDIDResponse>> fetchPreviousActiveDidResponseForAllNode(String vin, List<Long> vehicleNodeSnapshotKeyList) {

        Map<String, List<VehicleNodeDIDResponse>> previousVehicleNodeDIDResponseMap = null;
        try {
            if (vehicleNodeSnapshotKeyList != null && !vehicleNodeSnapshotKeyList.isEmpty()) {
                List<VehicleNodeDIDResponse> oldVehicleNodeDIDResponseList = vehicleNodeDIDResponseRepository.fetchAllDidResponseByVehicleNodeSnapshotKey(ApplicationUtils.getVinHash(vin), vehicleNodeSnapshotKeyList);
                if (oldVehicleNodeDIDResponseList != null && !oldVehicleNodeDIDResponseList.isEmpty()) {
                    previousVehicleNodeDIDResponseMap = new HashMap<>();
                    for (VehicleNodeDIDResponse nodeDIDResponse : oldVehicleNodeDIDResponseList) {
                        if (previousVehicleNodeDIDResponseMap.containsKey(nodeDIDResponse.getModuleNode().getNodeAddress())) {
                            previousVehicleNodeDIDResponseMap.get(nodeDIDResponse.getModuleNode().getNodeAddress()).add(nodeDIDResponse);
                        } else {
                            List<VehicleNodeDIDResponse> nodeDIDResponsesList = new ArrayList<>();
                            nodeDIDResponsesList.add(nodeDIDResponse);
                            previousVehicleNodeDIDResponseMap.put(nodeDIDResponse.getModuleNode().getNodeAddress(), nodeDIDResponsesList);
                        }
                    }
                }
            }
        }catch (Exception ex){
            logger.error("Exception while fetchPreviousActiveDidResponseForAllNode :" +ex.getMessage());
        }
        return previousVehicleNodeDIDResponseMap;
    }

    @Override
    public Map<String, List<VehicleNodeConfig>> fetchPreviousActiveConfigDidResponseForAllNode(String vin, List<Long> vehicleNodeSnapshotKeyList) {
        long start = System.currentTimeMillis();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Map<String, List<VehicleNodeConfig>> previousVehicleNodeConfigMap = new HashMap<>();
        try {
            logger.debug("Connecting to database...");
            conn = dataSource.getConnection();
            String FETCH_VEH_NODE_CONFIG = "SELECT A.GVMS10_VIN_HASH_R,A.GVMS02_VEH_NODE_DID_RSPNS_K,A.GVMS06_CFG_DELINEATOR_C,A.GVMS06_CFG_X,A.GVMS06_CFG_DATA_TYPE_C," +
                    "C.GVM023_NODE_ADRS_C FROM PGVMS06_VEH_NODE_CFG A, PGVMS02_VEH_NODE_DID_RSPNS B, PGVMS04_VEH_NODE_SNPSHT C WHERE " +
                    "A.GVMS10_VIN_HASH_R=B.GVMS10_VIN_HASH_R AND A.GVMS02_VEH_NODE_DID_RSPNS_K=B.GVMS02_VEH_NODE_DID_RSPNS_K AND " +
                    "B.GVMS10_VIN_HASH_R=C.GVMS10_VIN_HASH_R AND B.GVMS04_VEH_NODE_SNPSHT_K=C.GVMS04_VEH_NODE_SNPSHT_K AND " +
                    "C.GVMS10_VIN_HASH_R=? and C.GVMS10_VIN_R=? AND C.GVMS04_ACTIVE_F='A' AND C.GVMS04_VEH_NODE_SNPSHT_K IN";
            StringBuilder stringBuilder = new StringBuilder();
            for (Long vehicleNodeSnapshotKey : vehicleNodeSnapshotKeyList) {
                stringBuilder.append("'").append(vehicleNodeSnapshotKey).append("'").append(",");
            }
            String nodeList = stringBuilder.toString().substring(0, stringBuilder.toString().length() - 1);
            FETCH_VEH_NODE_CONFIG = FETCH_VEH_NODE_CONFIG.concat("(" + nodeList + ")");
            //STEP 4: Execute a query
            logger.debug("Creating statement...");
            stmt = conn.prepareStatement(FETCH_VEH_NODE_CONFIG);
            stmt.setInt(1, ApplicationUtils.getVinHash(vin));
            stmt.setString(2, vin);
            // stmt.setString(3, nodeList);
            rs = stmt.executeQuery();
            while (rs.next()) {
                VehicleNodeConfig vehicleNodeConfig = new VehicleNodeConfig();
                VehicleNodeDIDResponseId vehicleNodeDIDResponseId = new VehicleNodeDIDResponseId();
                vehicleNodeDIDResponseId.setVinHashNumber(rs.getInt("GVMS10_VIN_HASH_R"));
                vehicleNodeDIDResponseId.setVehicleNodeDidReponseKey(rs.getLong("GVMS02_VEH_NODE_DID_RSPNS_K"));
                vehicleNodeConfig.setVehicleNodeDIDResponseId(vehicleNodeDIDResponseId);
                vehicleNodeConfig.setConfigurationDelimeterId(rs.getString("GVMS06_CFG_DELINEATOR_C"));
                vehicleNodeConfig.setConfigurationData(rs.getString("GVMS06_CFG_X"));
                vehicleNodeConfig.setConfigurationDataType(rs.getString("GVMS06_CFG_DATA_TYPE_C"));
                String nodeAddress = rs.getString("GVM023_NODE_ADRS_C");
                if (previousVehicleNodeConfigMap.get(nodeAddress) == null) {
                    List<VehicleNodeConfig> vehicleNodeConfigList = new ArrayList<>();
                    vehicleNodeConfigList.add(vehicleNodeConfig);
                    previousVehicleNodeConfigMap.put(nodeAddress, vehicleNodeConfigList);
                } else {
                    List<VehicleNodeConfig> vehicleNodeConfigList = previousVehicleNodeConfigMap.get(nodeAddress);
                    vehicleNodeConfigList.add(vehicleNodeConfig);
                }
            }
        } catch (Exception e) {
            logger.error("Error while fetching VehicleNodeConfig for all node :"+ e.getMessage());
        } finally {
            //finally block used to close resources
            try {
                if (rs != null)
                    rs.close();
            } catch (SQLException se3) {
                logger.error("Error while fetching VehicleNodeConfig for all node :"+ se3.getMessage());
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
                logger.error("Error while fetching VehicleNodeConfig for all node :"+ se2.getMessage());
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                logger.error("Error while fetching VehicleNodeConfig for all node :"+ se.getMessage());
            }//end finally try
        }
        long end = System.currentTimeMillis() - start;
        logger.debug("Time taken to getVehicleNodeConfigforAllNode:::" + end);
        return previousVehicleNodeConfigMap;
    }

    @Override
    public Map<String, List<VehicleNodeDIDStatus>> findAllVehicleNodeDIDStatusIDForAllNode(String vin, int vinHash, String sofwareState) {

        Map<String, List<VehicleNodeDIDStatus>> previousVehicleNodeDIDStatusMap = new HashMap<>();;
        try {
                List<VehicleNodeDIDStatus> previousVehicleNodeDIDStatusList = vehicleNodeDIDStatusDao.fetchAllCurrentlyInstalledSoftwares(ApplicationUtils.getVinHash(vin), vin, sofwareState);
                if (previousVehicleNodeDIDStatusList != null && !previousVehicleNodeDIDStatusList.isEmpty()) {
                    for (VehicleNodeDIDStatus vehicleNodeDIDStatus : previousVehicleNodeDIDStatusList) {
                        if (previousVehicleNodeDIDStatusMap.containsKey(vehicleNodeDIDStatus.getNodeAddress())) {
                            previousVehicleNodeDIDStatusMap.get(vehicleNodeDIDStatus.getNodeAddress()).add(vehicleNodeDIDStatus);
                        } else {
                            List<VehicleNodeDIDStatus> vehicleNodeDIDStatusList = new ArrayList<>();
                            vehicleNodeDIDStatusList.add(vehicleNodeDIDStatus);
                            previousVehicleNodeDIDStatusMap.put(vehicleNodeDIDStatus.getNodeAddress(), vehicleNodeDIDStatusList);
                        }
                    }
                }

        }catch (Exception ex){
            logger.error("Exception while findAllVehicleNodeDIDStatusIDForAllNode :" +ex.getMessage());
        }
        return previousVehicleNodeDIDStatusMap;
    }

    @Override
    public String getPreviousRole(long snapShotKey) {
        return vehicleSnapshotDao.getPreviousRole(snapShotKey);
    }

    @Override
    public Map<String, String> getProvisionFlagForAllNode(int vinHash, String vin, String PAAK_PROVISION_NODES) {
        return moduleNodeDao.getProvisionFlagForAllNode(vinHash, vin, PAAK_PROVISION_NODES);
    }

    @Override
    public Map<String, VehicleNodeId> populateVehicleNodeIdMap(String vin, int vinHash) {
        return vehicleNodeDao.populateVehicleNodeIdMap(vin, vinHash);
    }

}
