package com.ford.gvmsr.snapobserver.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.snapobserver.facade.SnapCreationFacade;
import com.ford.gvmsr.snapobserver.modulestate.request.SnapshotObserverRequest;
import io.vertx.core.AbstractVerticle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/")
@Validated
public class SnapObserverController extends AbstractVerticle {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    SnapCreationFacade snapCreationFacade;

    @PostMapping("snapshot")
    public String createSnapshot(@RequestBody SnapshotObserverRequest snapshotObserverRequest) {
        String snapResponse = null;
        ObjectMapper objectMapper = new ObjectMapper();
        logger.info("Entering createSnapshot for VIN=[{}] " + snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getVIN());
        try {
            snapResponse = objectMapper.writeValueAsString(snapCreationFacade.createSnapshot(snapshotObserverRequest));
            logger.info("snapResponse : " +snapResponse);
            return snapResponse;
        } catch (JsonProcessingException e) {
            snapResponse = e.getMessage();
        }
        return snapResponse;
    }
}
