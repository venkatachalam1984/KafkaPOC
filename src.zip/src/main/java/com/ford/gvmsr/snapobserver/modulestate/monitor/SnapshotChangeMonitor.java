package com.ford.gvmsr.snapobserver.modulestate.monitor;

import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import com.ford.gvmsr.snapobserver.modulestate.request.SnapshotObserverRequest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SnapshotChangeMonitor {

    private SnapshotObserverRequest snapshotObserverRequest;

    private Map<String, SnapshotNodeMonitor> snapshotNodeMonitorMap;

    public SnapshotChangeMonitor(SnapshotObserverRequest snapshotObserverRequest) {
        this.snapshotNodeMonitorMap = new HashMap<>();
        this.snapshotObserverRequest = snapshotObserverRequest;
        //attaching ModuleSnapObserver to ModuleSnapshot
    }

    public void attachSnapshotNodeMonitor(String key, SnapshotNodeMonitor snapshotNodeMonitor) {
        snapshotNodeMonitorMap.put(key, snapshotNodeMonitor);
    }

    public SnapshotNodeMonitor attachSnapshotNodeMonitor(ModuleNodeType moduleNodeType) {
        SnapshotNodeMonitor snapshotNodeMonitor = new NodeLevelChangeMonitor(moduleNodeType);
        snapshotNodeMonitorMap.put(snapshotNodeMonitor.getKey(), snapshotNodeMonitor);
        return snapshotNodeMonitor;
    }


    public void update(String key, TrackingLevel trackingLevel, TrackingType trackingType, boolean isChanged) {
        if (snapshotNodeMonitorMap.containsKey(key)) {
            SnapshotNodeMonitor snapshotNodeMonitor = snapshotNodeMonitorMap.get(key);
            snapshotNodeMonitor.update(trackingLevel, trackingType, isChanged);
        }
    }

    public void update(ModuleNodeType moduleNodeType, TrackingLevel trackingLevel, TrackingType trackingType, boolean isChanged) {
        String key = getNodeMonitorKey(moduleNodeType);
        if (snapshotNodeMonitorMap.containsKey(key)) {
            SnapshotNodeMonitor snapshotNodeMonitor = snapshotNodeMonitorMap.get(key);
            snapshotNodeMonitor.update(trackingLevel, trackingType, isChanged);
        } else {
            SnapshotNodeMonitor snapshotNodeMonitor = new NodeLevelChangeMonitor(moduleNodeType);
            snapshotNodeMonitor.update(trackingLevel, trackingType, isChanged);
            snapshotNodeMonitorMap.put(snapshotNodeMonitor.getKey(), snapshotNodeMonitor);
        }
    }

    public static String getNodeMonitorKey(ModuleNodeType moduleNodeType) {
        return NodeLevelChangeMonitor.getKey(moduleNodeType);
    }

    public SnapshotNodeMonitor getSnapshotNodeMonitor(String key) {
        SnapshotNodeMonitor snapshotNodeMonitor = null;
        if (snapshotNodeMonitorMap.containsKey(key)) {
            snapshotNodeMonitor = snapshotNodeMonitorMap.get(key);
        }
        return snapshotNodeMonitor;
    }

    public SnapshotChangeInfo getSnapshotChangeInfo(String key) {
        SnapshotChangeInfo snapshotChangeInfo = null;
        if (snapshotNodeMonitorMap.containsKey(key)) {
            snapshotChangeInfo = snapshotNodeMonitorMap.get(key).getSnapshotChangeInfo();
        }
        return snapshotChangeInfo;
    }

    public SnapshotNodeMonitor getSnapshotNodeMonitor(ModuleNodeType moduleNodeType) {
        SnapshotNodeMonitor snapshotNodeMonitor = snapshotNodeMonitorMap.get(getNodeMonitorKey(moduleNodeType));
        return (null != snapshotNodeMonitor? snapshotNodeMonitor : new NodeLevelChangeMonitor(moduleNodeType));
    }


    public List<SnapshotNodeMonitor> getAllSnapshotNodeMonitors() {
        return snapshotNodeMonitorMap.values().stream()
                .collect(Collectors.toList());
    }

}
