package com.ford.gvmsr.snapobserver.externalservice.response;

public class FASNodeDetailResponse {

    private String specCategory;

    private String ecuAcronym;

    private String node;

    private String network;

    private String protocol;

    private String isFasFlag;

    public String getIsFasFlag() {
        return isFasFlag;
    }

    public void setIsFasFlag(String isFasFlag) {
        this.isFasFlag = isFasFlag;
    }

    public String getSpecCategory() {
        return specCategory;
    }

    public void setSpecCategory(String specCategory) {
        this.specCategory = specCategory;
    }

    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getNetwork() {
        return network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }
}
