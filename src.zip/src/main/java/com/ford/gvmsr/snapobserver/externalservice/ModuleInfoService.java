package com.ford.gvmsr.snapobserver.externalservice;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;

import java.util.List;
import java.util.Optional;

public interface ModuleInfoService {

    Optional<Vehicle> getVin(String vin, List<String> nodeList);
}
