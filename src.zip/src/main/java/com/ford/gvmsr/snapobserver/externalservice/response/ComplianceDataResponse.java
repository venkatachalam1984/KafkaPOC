package com.ford.gvmsr.snapobserver.externalservice.response;


import java.util.List;

public class ComplianceDataResponse {

    private List<PartDIDComplianceDetailTO> partDIDComplianceDetails;

    public List<PartDIDComplianceDetailTO> getPartDIDComplianceDetails() {
        return partDIDComplianceDetails;
    }

    public void setPartDIDComplianceDetails(List<PartDIDComplianceDetailTO> partDIDComplianceDetails) {
        this.partDIDComplianceDetails = partDIDComplianceDetails;
    }
}
