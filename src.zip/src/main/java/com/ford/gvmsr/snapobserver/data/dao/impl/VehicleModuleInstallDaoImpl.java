package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.data.dao.VehicleModuleInstallDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleModuleInstall;
import com.ford.gvmsr.snapobserver.data.entity.VehicleModuleInstallID;
import com.ford.gvmsr.snapobserver.data.repository.VehicleModuleInstallRepository;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class VehicleModuleInstallDaoImpl implements VehicleModuleInstallDao {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    VehicleModuleInstallRepository vehicleModuleInstallRepository;

    @Autowired
    private ExceptionHandler exceptionHandler;

    @Override
    public Map<Boolean, String> saveVehicleModuleInstall(String vin, int vinHashNumber, String nodeAddress, String eSerialno, String ecuAcronym, Timestamp moduleInstallTimeStamp) {
        Map<Boolean, String> isDisassoaciation = null;
        try {
            List<VehicleModuleInstall> moduleInstallList = new ArrayList<>();
            VehicleModuleInstall vehicleModuleInstallExistEntity = null;
            isDisassoaciation = new HashMap<>();

            vehicleModuleInstallExistEntity = vehicleModuleInstallRepository.findByVinAndNode(vin, vinHashNumber, nodeAddress);

            if (vehicleModuleInstallExistEntity != null && eSerialno.equals(vehicleModuleInstallExistEntity.getVehicleModuleInstallID().getEserialno())) {
                isDisassoaciation.put(false, vehicleModuleInstallExistEntity.getVehicleModuleInstallID().getVin());
                return isDisassoaciation;
            } else if (vehicleModuleInstallExistEntity != null && !eSerialno.equals(vehicleModuleInstallExistEntity.getVehicleModuleInstallID().getEserialno())) {
                     vehicleModuleInstallExistEntity.setModuleUnInstallTimeStamp(new Timestamp(new Date().getTime()));

                moduleInstallList.add(vehicleModuleInstallExistEntity);
                isDisassoaciation.put(true, vehicleModuleInstallExistEntity.getVehicleModuleInstallID().getVin());
            }

            List<VehicleModuleInstall> alreadyMappedVINs = vehicleModuleInstallRepository.findAllByVehicleModuleInstallID_NodeAddressAndVehicleModuleInstallID_EserialnoAndModuleUnInstallTimeStampIsNull(nodeAddress,eSerialno);
            if (!alreadyMappedVINs.isEmpty()) {
                for (VehicleModuleInstall vehicleModuleInstall : alreadyMappedVINs) {
                    vehicleModuleInstall.setModuleUnInstallTimeStamp(new Timestamp(new Date().getTime()));
                    moduleInstallList.add(vehicleModuleInstall);
                    isDisassoaciation.put(true, vehicleModuleInstall.getVehicleModuleInstallID().getVin());
                }
            }

            vehicleModuleInstallExistEntity = populateVehicleModuleInstallEntity(vin, vinHashNumber, nodeAddress, eSerialno, ecuAcronym);
            if(moduleInstallTimeStamp!=null)
                vehicleModuleInstallExistEntity.getVehicleModuleInstallID().setModuleInstallTimeStamp(moduleInstallTimeStamp);
            moduleInstallList.add(vehicleModuleInstallExistEntity);
            vehicleModuleInstallRepository.saveAll(moduleInstallList);

        } catch (Exception ex) {
            logger.error("Exception while inserting ESN in #21 table : VIN:{},ESN:{}", vin, eSerialno);
        }
        return isDisassoaciation;
    }

    private VehicleModuleInstall populateVehicleModuleInstallEntity(String vin, int vinHash, String nodeAddress, String eSerialNo, String ecuAcronym) {

        VehicleModuleInstallID id = populateVehicleModuleInstallIDEntity(vin, vinHash, nodeAddress, eSerialNo);
        VehicleModuleInstall entity = new VehicleModuleInstall();
        entity.setVehicleModuleInstallID(id);
        entity.setEcuAcronymCode(ecuAcronym);
        return entity;
    }

    private VehicleModuleInstallID populateVehicleModuleInstallIDEntity(String vin, int vinHash, String nodeAddress, String eSerialNo) {
        VehicleModuleInstallID vehicleModuleInstallIDEntity = new VehicleModuleInstallID();
        vehicleModuleInstallIDEntity.setVin(vin);
        vehicleModuleInstallIDEntity.setVinHashNumber(vinHash);

        vehicleModuleInstallIDEntity.setNodeAddress(nodeAddress);
        vehicleModuleInstallIDEntity.setEserialno(eSerialNo);
        String effInTimeStamp = new SimpleDateFormat(GVMSModuleUpdateConstants.DATE_FORMAT).format(new Date());
        Timestamp effInTimeStampWithoutMilliSeconds = Timestamp.valueOf(effInTimeStamp);
        vehicleModuleInstallIDEntity.setModuleInstallTimeStamp(effInTimeStampWithoutMilliSeconds);
        return vehicleModuleInstallIDEntity;

    }
}
