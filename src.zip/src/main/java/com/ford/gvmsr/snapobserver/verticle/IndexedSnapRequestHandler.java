package com.ford.gvmsr.snapobserver.verticle;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.snapobserver.config.VertxConfiguration;
import com.ford.gvmsr.snapobserver.constants.VilConstants;
import com.ford.gvmsr.snapobserver.dto.SnapshotResponse;
import com.ford.gvmsr.snapobserver.facade.SnapCreationFacade;
import com.ford.gvmsr.snapobserver.kafka.producer.GVMSRSnapshotResponseProducer;
import com.ford.gvmsr.snapobserver.logevent.LogType;
import com.ford.gvmsr.snapobserver.logevent.splunk.Utils;
import com.ford.gvmsr.snapobserver.modulestate.request.SnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.utils.BeanUtil;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import io.vertx.core.AbstractVerticle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.Instant;


public class IndexedSnapRequestHandler extends AbstractVerticle {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private final Integer verticleIndex;

    private Utils splunkUtils ;

    private VertxConfiguration vertxConfiguration;

    private GVMSRSnapshotResponseProducer gvmsrSnapshotResponseProducer;

    private SnapConfirmerPropertyHandler snapConfirmerPropertyHandler;

    public IndexedSnapRequestHandler(Integer verticleIndex) {
        this.verticleIndex = verticleIndex;
    }


    @Override
    public void start() {

        logger.info("SnapReqHandler:Deployed instance with index = {} ", verticleIndex);
        vertx.eventBus().consumer(VilConstants.SNAP_REQUEST_HANDLER + verticleIndex, message -> {

            String vin = null;
            String traceId = null;
            splunkUtils = BeanUtil.getBean(Utils.class);
            SnapshotObserverRequest snapshotObserverRequest;
            String snapshotResponse;
            ObjectMapper objectMapper = new ObjectMapper();
            try {

                logger.debug("SnapReqHandler:Message body: " + message.body().toString());
                snapshotObserverRequest = objectMapper.readValue(message.body().toString(), SnapshotObserverRequest.class);
                vin = snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getVIN();
                traceId = snapshotObserverRequest.getModuleStateRequest().getTraceID();
                logger.debug("SnapReqHandler:VIN Received = {} & Index = {} & ThreadName = {} ", vin, verticleIndex, Thread.currentThread().getName());

                Instant start = Instant.now();
                SnapCreationFacade snapCreationFacade = BeanUtil.getBean(SnapCreationFacade.class);
                logger.debug("SnapReqHandler:Send to snapCreationFacade");
                SnapshotResponse snapCreationResponse = snapCreationFacade.createSnapshot(snapshotObserverRequest);
                snapshotResponse = objectMapper.writeValueAsString(snapCreationResponse);

                splunkUtils.prepareSnapObserverToConfirmerLogEvent(vin, traceId, LogType.INFO.getCode(),
                        VilConstants.SENT_TO_FACADE, null, null, VilConstants.FACADE_TRK_M,
                        CommonUtils.getEventTimeStamp(), null);

                if (snapshotResponse != null) {
                    logger.debug("SnapReqHandler:Sending snapshot response to Snap Confirmer" + snapshotResponse);
                    splunkUtils.prepareSnapObserverToConfirmerLogEvent(vin, traceId, LogType.INFO.getCode(),
                            VilConstants.RCVD_FRM_FACADE, null, null, VilConstants.FACADE_TRK_M,
                            CommonUtils.getEventTimeStamp(), null);
                    gvmsrSnapshotResponseProducer = BeanUtil.getBean(GVMSRSnapshotResponseProducer.class);
                    vertxConfiguration = BeanUtil.getBean(VertxConfiguration.class);
                    logger.debug("SnapReqHandler:snapshotResponse-before publish to:" + vertxConfiguration.getSnapshotProducerTopic());
                    gvmsrSnapshotResponseProducer.publishMessage(snapshotResponse, vertxConfiguration.getSnapshotProducerTopic());
                    logger.debug("SnapReqHandler:snapshotResponse-after published");
                    splunkUtils.prepareSnapObserverToConfirmerLogEvent(vin, traceId, LogType.INFO.getCode(),
                            VilConstants.SENT_TO_CNF, null, null,
                            VilConstants.PUSH_TO_OBS_PRODUCER, CommonUtils.getEventTimeStamp(), null);

                }
                Instant end = Instant.now();
                logger.info("SnapReqHandler:Time consuming to process Snapshot Response Duration = {} ", Duration.between(start, end).toMillis());

            } catch (JsonProcessingException ex) {
                logger.error("SnapReqHandler:JsonParse Exception while convert snapshotResponse to String");
                splunkUtils.prepareSnapObserverToConfirmerLogEvent(vin, traceId, LogType.ERROR.getCode(), VilConstants.VIL_JSON_PARSE_ERROR,
                        null, null, VilConstants.KAFKA_TRK_END, CommonUtils.getEventTimeStamp(), ex.getMessage());
            }catch (Exception ex) {
                logger.error("SnapReqHandler:Exception while getting snapshot response");
                splunkUtils.prepareSnapObserverToConfirmerLogEvent(vin, traceId, LogType.ERROR.getCode(), VilConstants.FACADE_ERROR,
                        null, null, VilConstants.KAFKA_TRK_END, CommonUtils.getEventTimeStamp(), ex.getMessage());
            }
            logger.info("SnapReqHandler:VIN Processed = {} & Index = {} & ThreadName = {} ", vin, verticleIndex, Thread.currentThread().getName());
        });

    }

}