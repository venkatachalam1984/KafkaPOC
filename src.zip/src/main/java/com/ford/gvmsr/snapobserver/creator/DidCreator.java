package com.ford.gvmsr.snapobserver.creator;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshot;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;

import java.sql.SQLException;

public interface DidCreator {

    void persistDid(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, VehicleNodeSnapshot vehicleNodeSnapshot) throws SQLException;
}
