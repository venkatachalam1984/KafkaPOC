package com.ford.gvmsr.snapobserver.exception;

public class MandatoryDidValidationException extends Exception {

    public MandatoryDidValidationException(String message) {
        super(message);
    }
}
