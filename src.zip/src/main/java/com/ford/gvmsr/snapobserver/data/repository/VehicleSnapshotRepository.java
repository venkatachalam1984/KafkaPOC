package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
@Transactional
public interface VehicleSnapshotRepository extends JpaRepository<VehicleSnapshot,Long> {

    @Query(value = "SELECT GVMS01_ROLE_N FROM PGVMS03_VEH_SNPSHT WHERE GVMS03_VEH_SNPSHT_K=:snapShotKey", nativeQuery = true)
    public String getPreviousRole(@Param("snapShotKey") long snapShotKey);
}
