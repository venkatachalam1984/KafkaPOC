package com.ford.gvmsr.snapobserver.creator.impl;

import com.ford.gvmsr.snapobserver.creator.ConfigDidCreator;
import org.springframework.stereotype.Service;

@Service
public class ConfigDidCreationHandler implements ConfigDidCreator {
}
