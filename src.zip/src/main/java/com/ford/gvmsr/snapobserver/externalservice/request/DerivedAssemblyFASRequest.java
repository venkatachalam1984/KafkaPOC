package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "VehicleNodeDidList", "ivsXmlInfoKey", "partitionKey"
})
public class DerivedAssemblyFASRequest {

    @JsonProperty("ivsXmlInfoKey")
    private Long ivsXmlInfoKey;

    @JsonProperty("partitionKey")
    private int partitionKey;

    @JsonProperty("programCode")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String programCode = "";

    @JsonProperty("salesModelYear")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private float salesModelYear;

    @JsonProperty("source")
    private String source;

    @JsonProperty("VehicleNode")
    private List<FASVehicleNode> vehicleNode = null;

    @JsonProperty("ivsXmlInfoKey")
    public Long getIvsXmlInfoKey() {
        return ivsXmlInfoKey;
    }

    @JsonProperty("ivsXmlInfoKey")
    public void setIvsXmlInfoKey(Long ivsXmlInfoKey) {
        this.ivsXmlInfoKey = ivsXmlInfoKey;
    }

    @JsonProperty("partitionKey")
    public int getPartitionKey() {
        return partitionKey;
    }

    @JsonProperty("partitionKey")
    public void setPartitionKey(int partitionKey) {
        this.partitionKey = partitionKey;
    }

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public List<FASVehicleNode> getVehicleNode() {
        return vehicleNode;
    }

    public void setVehicleNode(List<FASVehicleNode> vehicleNode) {
        this.vehicleNode = vehicleNode;
    }
}
