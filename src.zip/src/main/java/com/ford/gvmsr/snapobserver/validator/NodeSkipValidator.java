package com.ford.gvmsr.snapobserver.validator;


import com.ford.gvmsr.snapobserver.validator.request.NodeSkipValidatorRequest;

public abstract class NodeSkipValidator {

    private final NodeSkipValidator next;

    public NodeSkipValidator(NodeSkipValidator next) {
        this.next = next;
    }
    public abstract boolean validate(NodeSkipValidatorRequest request) throws Exception;

    public boolean handleRequest( NodeSkipValidatorRequest nodeSkipValidatorRequest) throws Exception {
        if (next != null) {
            return next.handleRequest(nodeSkipValidatorRequest);
        }
        return false;
    }
}
