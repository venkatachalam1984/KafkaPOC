package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeConfig;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponseId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleNodeConfigRepository extends JpaRepository<VehicleNodeConfig, VehicleNodeDIDResponseId> {
}
