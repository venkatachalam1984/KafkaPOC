package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.helper.SnapCreationHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Map;
import java.util.Set;

@Component
public class MacAddressDidRule {
    private static final Logger logger = LoggerFactory.getLogger(MacAddressDidRule.class);

    @Value("#{'${mac.address.did.roles}'.split(',')}")
    private Set<String> MAC_DID_EXCEPTION_ROLES;

    @Value("#{'${mac.address.did.rolesource}'.split(',')}")
    private Set<String> MAC_DID_EXCEPTION_ROLE_SOURCE;

    @Autowired
    SnapCreationHelper snapCreationHelper;

    public void populateDidEntity(PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode, DIDInfoType did,
                                  NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap, ModuleNodeType node, ModuleSnapshotObserverRequest snapshotObserverRequest) {
        VehicleNodeDIDResponse vehicleNodeDIDResponse = new VehicleNodeDIDResponse();

        //validate did response and compare Mac did response
        String didResponse = validateMacAddressRule(previousSnapShotDetailsByNode.getPrevNonConfigDidResponseMap(), node, did, snapshotObserverRequest);
        vehicleNodeDIDResponse.setDidResponse(didResponse);

        // populate the vehicleNodeDIDResponse for persistence
        snapCreationHelper.populateVehicleNodeDIDResponse(vehicleNodeDIDResponse, did, node, snapshotObserverRequest, previousSnapShotDetailsByNode);
        nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList().add(vehicleNodeDIDResponse);
    }


    private String validateMacAddressRule(Map<String, VehicleNodeDIDResponse> prevVehicleNodeDIDResponseMap, ModuleNodeType node, DIDInfoType did, ModuleSnapshotObserverRequest snapshotObserverRequest) {

        String didResponse = ApplicationUtils.toUpperCase(did.getResponse());
        String prevMacDidResponse = null;
        String role = snapshotObserverRequest.getRequestRole().getRole().value();
        String roleSource = snapshotObserverRequest.getRequestRole().getRoleSource().value();

        if (!CollectionUtils.isEmpty(prevVehicleNodeDIDResponseMap) && prevVehicleNodeDIDResponseMap.containsKey(did.getDidValue())) {
            prevMacDidResponse = prevVehicleNodeDIDResponseMap.get(did.getDidValue()).getDidResponse();
        }else{
            snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.MAC_ADDRESS_DID, true);
        }
        if (null != didResponse && !ApplicationUtils.isValidMacAddress(didResponse) &&
                MAC_DID_EXCEPTION_ROLES.contains(role)
                && MAC_DID_EXCEPTION_ROLE_SOURCE.contains(roleSource)) {
            didResponse = prevMacDidResponse;
        } else if (null != prevMacDidResponse && !didResponse.equalsIgnoreCase(prevMacDidResponse)) {
            snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.MAC_ADDRESS_DID, true);
        }
        return didResponse;
    }
}
