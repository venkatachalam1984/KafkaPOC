
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ECUSoftwareType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ECUSoftwareType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:ford/Vehicle/Module/Information/v4.0}SoftwareMetaDataType"&gt;
 *       &lt;attribute name="isCurrent" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="isAvailable" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="flashSequence" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="isVinSpecificDID" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="servicePackUpgradable" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="isDealerVisitRequired" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="isSellable" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="predecessorPartnumber" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="unlockerPartNumber" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ECUSoftwareType")
public class ECUSoftwareType
    extends SoftwareMetaDataType
{

    @XmlAttribute(name = "isCurrent")
    protected Boolean isCurrent;
    @XmlAttribute(name = "isAvailable")
    protected Boolean isAvailable;
    @XmlAttribute(name = "flashSequence")
    protected Integer flashSequence;
    @XmlAttribute(name = "isVinSpecificDID")
    protected Boolean isVinSpecificDID;
    @XmlAttribute(name = "servicePackUpgradable")
    protected Boolean servicePackUpgradable;
    @XmlAttribute(name = "isDealerVisitRequired")
    protected Boolean isDealerVisitRequired;
    @XmlAttribute(name = "isSellable")
    protected Boolean isSellable;
    @XmlAttribute(name = "predecessorPartnumber")
    protected String predecessorPartnumber;
    @XmlAttribute(name = "unlockerPartNumber")
    protected String unlockerPartNumber;

    /**
     * Gets the value of the isCurrent property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsCurrent() {
        return isCurrent;
    }

    /**
     * Sets the value of the isCurrent property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsCurrent(Boolean value) {
        this.isCurrent = value;
    }

    /**
     * Gets the value of the isAvailable property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsAvailable() {
        return isAvailable;
    }

    /**
     * Sets the value of the isAvailable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsAvailable(Boolean value) {
        this.isAvailable = value;
    }

    /**
     * Gets the value of the flashSequence property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFlashSequence() {
        return flashSequence;
    }

    /**
     * Sets the value of the flashSequence property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFlashSequence(Integer value) {
        this.flashSequence = value;
    }

    /**
     * Gets the value of the isVinSpecificDID property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsVinSpecificDID() {
        return isVinSpecificDID;
    }

    /**
     * Sets the value of the isVinSpecificDID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsVinSpecificDID(Boolean value) {
        this.isVinSpecificDID = value;
    }

    /**
     * Gets the value of the servicePackUpgradable property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isServicePackUpgradable() {
        return servicePackUpgradable;
    }

    /**
     * Sets the value of the servicePackUpgradable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setServicePackUpgradable(Boolean value) {
        this.servicePackUpgradable = value;
    }

    /**
     * Gets the value of the isDealerVisitRequired property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsDealerVisitRequired() {
        return isDealerVisitRequired;
    }

    /**
     * Sets the value of the isDealerVisitRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsDealerVisitRequired(Boolean value) {
        this.isDealerVisitRequired = value;
    }

    /**
     * Gets the value of the isSellable property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsSellable() {
        return isSellable;
    }

    /**
     * Sets the value of the isSellable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsSellable(Boolean value) {
        this.isSellable = value;
    }

    /**
     * Gets the value of the predecessorPartnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPredecessorPartnumber() {
        return predecessorPartnumber;
    }

    /**
     * Sets the value of the predecessorPartnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPredecessorPartnumber(String value) {
        this.predecessorPartnumber = value;
    }

    /**
     * Gets the value of the unlockerPartNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnlockerPartNumber() {
        return unlockerPartNumber;
    }

    /**
     * Sets the value of the unlockerPartNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnlockerPartNumber(String value) {
        this.unlockerPartNumber = value;
    }

}
