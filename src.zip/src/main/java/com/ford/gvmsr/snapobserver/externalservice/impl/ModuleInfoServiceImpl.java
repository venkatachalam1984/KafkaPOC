package com.ford.gvmsr.snapobserver.externalservice.impl;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.externalservice.ModuleInfoService;
import com.ford.gvmsr.snapobserver.externalservice.request.GIVISSnapRequest;
import com.ford.gvmsr.snapobserver.properties.ExternalServiceProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class ModuleInfoServiceImpl implements ModuleInfoService {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    ExternalServiceProperties externalServiceProperties;

    @Autowired
    @Qualifier("oauthServiceRegistryRestTemplate")
    RestTemplate oauthServiceRegistryRestTemplate;

    @Override
    public Optional<Vehicle> getVin(String vin, List<String> nodes) {
        Vehicle vehicle = null;
        GIVISSnapRequest givisSnapRequest = new GIVISSnapRequest();
        givisSnapRequest.setVin(vin);
        givisSnapRequest.setNodeList(nodes);
        givisSnapRequest.setVinFlag(true);

        try {
            LOGGER.trace("getVin VIN={}, with request GIVISSnapRequest ={}", vin, givisSnapRequest);
            ResponseEntity<Vehicle> vehicleResponseEntity = oauthServiceRegistryRestTemplate.postForEntity(externalServiceProperties.appUrlModuleInfo + externalServiceProperties.moduleInfoGetGivisSnap,
                    givisSnapRequest, Vehicle.class);
            vehicle = vehicleResponseEntity.getBody();
        } catch (Exception e) {
            LOGGER.error("getVin VIN =[{}] Error Msg:{}", vin, e.getMessage());
        }

        return Optional.ofNullable(vehicle);
    }
}
