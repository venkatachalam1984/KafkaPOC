package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.List;

public class FASRequest {

    private long infoKey;

    private int paritionKey;

    private List<String> nodeList;


    public long getInfoKey() {
        return infoKey;
    }

    public void setInfoKey(long infoKey) {
        this.infoKey = infoKey;
    }

    public int getParitionKey() {
        return paritionKey;
    }

    public void setParitionKey(int paritionKey) {
        this.paritionKey = paritionKey;
    }


    public List<String> getNodeList() {
        return nodeList;
    }

    public void setNodeList(List<String> nodeList) {
        this.nodeList = nodeList;
    }
}
