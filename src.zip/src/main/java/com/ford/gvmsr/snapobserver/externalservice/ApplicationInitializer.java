package com.ford.gvmsr.snapobserver.externalservice;

/**
 * Created by MDEVARA3 on 1/8/2018.
 */

import com.ford.gvmsr.snapobserver.data.entity.SoftwareStatus;
import com.ford.gvmsr.snapobserver.data.repository.SoftwareStatusRepository;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Component
public class ApplicationInitializer {


    @Autowired
    private ExceptionHandler exceptionHandler;

    @Autowired
    private SoftwareStatusRepository softwareStatusRepository;

    public static HashMap<String, SoftwareStatus> softwareStateMap = new HashMap<>();

    @EventListener({ContextRefreshedEvent.class, ApplicationReadyEvent.class})
    public void onApplicationEvent() {
        try {

            //Fetch all the software states and store in the static map and used in all the classes
            List<SoftwareStatus> softwareStatusList = (List<SoftwareStatus>) softwareStatusRepository.findAll();
            softwareStatusList.stream().forEach(softwareStatus -> {
                softwareStateMap.put(softwareStatus.getSoftwareStatusCode(), softwareStatus);
            });

        } catch (Exception ex) {
            // ex.printStackTrace();
            exceptionHandler.logException(ex,this.getClass().getSimpleName());
        }
    }

}