package com.ford.gvmsr.snapobserver.externalservice.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class FASDerivedAssemblyResponseForNode implements Serializable {

    @JsonProperty("lineageId")
    private long lineageId;

    @JsonProperty("partNumberForDA")
    private String partNumberForDA = "";

    @JsonProperty("ruleNo")
    private String ruleNo = "";

    @JsonProperty("warningText")
    private String warningText;

    @JsonProperty("fasFlag")
    private String fasFlag = "N";

    @JsonProperty("isDAPass")
    private Boolean isDAPass = false;

    @JsonProperty("fasWarningText")
    private String fasWarningText = "";

    @JsonProperty("ecuAcronym")
    private String ecuAcronym = "";

    public long getLineageId() {
        return lineageId;
    }

    public void setLineageId(long lineageId) {
        this.lineageId = lineageId;
    }

    public String getPartNumberForDA() {
        return partNumberForDA;
    }

    public void setPartNumberForDA(String partNumberForDA) {
        this.partNumberForDA = partNumberForDA;
    }

    public String getRuleNo() {
        return ruleNo;
    }

    public void setRuleNo(String ruleNo) {
        this.ruleNo = ruleNo;
    }

    public String getWarningText() {
        return warningText;
    }

    public void setWarningText(String warningText) {
        this.warningText = warningText;
    }

    public String getFasFlag() {
        return fasFlag;
    }

    public void setFasFlag(String fasFlag) {
        this.fasFlag = fasFlag;
    }

    public Boolean getDAPass() {
        return isDAPass;
    }

    public void setDAPass(Boolean DAPass) {
        isDAPass = DAPass;
    }

    public String getFasWarningText() {
        return fasWarningText;
    }

    public void setFasWarningText(String fasWarningText) {
        this.fasWarningText = fasWarningText;
    }

    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

}