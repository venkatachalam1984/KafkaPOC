package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeConfigDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeConfig;
import com.ford.gvmsr.snapobserver.data.repository.VehicleNodeConfigRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleNodeConfigDaoImpl implements VehicleNodeConfigDao {

    @Autowired
    VehicleNodeConfigRepository vehicleNodeConfigRepository;

    @Override
    public List<VehicleNodeConfig> save(List<VehicleNodeConfig> vehicleNodeConfigList) {
        return vehicleNodeConfigRepository.saveAll(vehicleNodeConfigList);
    }
}
