package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNode;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VehicleNodeRepository extends JpaRepository<VehicleNode, VehicleNodeId> {
    List<VehicleNode> findByVehicle_VehicleId_VinAndAndVehicle_VehicleId_VinHashNumber(String vin, int vinHashNumber);
}
