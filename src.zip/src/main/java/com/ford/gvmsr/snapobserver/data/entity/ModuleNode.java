package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/30/2017.
 *
 * Address to which messages are sent where the module at that node may then respond back.
 Data Source: GIVIS:NMGM060_MOD_NODE
 */

@Entity
@Table(name = "PGVMS14_MOD_NODE")
public class ModuleNode extends BaseEntity {

    @Id
    @Column(name = "GVMS14_MOD_NODE_K")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMS14_MOD_NODE_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS14_MOD_NODE_K_SQ_GEN", sequenceName = "PGVMS14_MOD_NODE_K_SQ", allocationSize = 1)
    private Long modNodeSaKey;

    @Embedded
    private IVSProgramId ivsProgramId;

    @Column(name = "GVM023_NODE_ADRS_C")
    private String nodeAddress;

    @Column(name = "GVMS14_GW_NODE_D")
    private String gwNodeId;

    @Column(name = "GVM015_SRC_SYS_C")
    private String sourceSystem;

    @Column(name = "GVM025_MOD_CPU_TYPE_C")
    private String moduleCpuType;

    @Column(name = "GVM026_GW_TYPE_C")
    private String gatewayType;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS14_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS14_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS14_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS14_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public Long getModNodeSaKey() {
        return modNodeSaKey;
    }

    public void setModNodeSaKey(Long modNodeSaKey) {
        this.modNodeSaKey = modNodeSaKey;
    }

    public IVSProgramId getIvsProgramId() {
        return ivsProgramId;
    }

    public void setIvsProgramId(IVSProgramId ivsProgramId) {
        this.ivsProgramId = ivsProgramId;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getGwNodeId() {
        return gwNodeId;
    }

    public void setGwNodeId(String gwNodeId) {
        this.gwNodeId = gwNodeId;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getModuleCpuType() {
        return moduleCpuType;
    }

    public void setModuleCpuType(String moduleCpuType) {
        this.moduleCpuType = moduleCpuType;
    }

    public String getGatewayType() {
        return gatewayType;
    }

    public void setGatewayType(String gatewayType) {
        this.gatewayType = gatewayType;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }
}
