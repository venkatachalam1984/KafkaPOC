package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class SnapNodeErrorStateId implements Serializable {

    @Column(name="GVMS35_VEH_MSG_PRCS_K")
    private String vehicleMessageProcessingKey;

    @Column(name = "GVM037_NODE_ADRS_C")
    private String nodeAddress;

    public String getVehicleMessageProcessingKey() {
        return vehicleMessageProcessingKey;
    }

    public void setVehicleMessageProcessingKey(String vehicleMessageProcessingKey) {
        this.vehicleMessageProcessingKey = vehicleMessageProcessingKey;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }
}
