package com.ford.gvmsr.snapobserver.externalservice.response;

import java.io.Serializable;

/**
 * Created by MDEVARA3 on 1/3/2018.
 */
public class OdlDiagSpecCategoryAndNetworkDetailsTO implements Serializable {

    private String diagSpecCategoryName;

    private String networkName;

    private String netwrokProtocolName;

    private String networkDataRate;

    public String getDiagSpecCategoryName() {
        return diagSpecCategoryName;
    }

    public void setDiagSpecCategoryName(String diagSpecCategoryName) {
        this.diagSpecCategoryName = diagSpecCategoryName;
    }

    public String getNetworkName() {
        return networkName;
    }

    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }

    public String getNetwrokProtocolName() {
        return netwrokProtocolName;
    }

    public void setNetwrokProtocolName(String netwrokProtocolName) {
        this.netwrokProtocolName = netwrokProtocolName;
    }

    public String getNetworkDataRate() {
        return networkDataRate;
    }

    public void setNetworkDataRate(String networkDataRate) {
        this.networkDataRate = networkDataRate;
    }
}
