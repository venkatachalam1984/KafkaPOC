package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.TransactionDetailDao;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.*;

@Component
public class TransactionDetailDaoImpl implements TransactionDetailDao {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    ExceptionHandler exceptionHandler;

    private DataSource dataSource;

    private static final String INSERT_TXN_DTL = "INSERT INTO PGVMT03_TXN_DTL (GVMT03_TXN_DTL_D,GVMT02_TXN_STAT_C,GVMT01_TXN_D,GVMT03_VIN_R,GVMT03_VIN_HASH_R,GVMT03_TXN_DTL_S,\n" +
            "GVMT03_SRC_SYS_C,GVMT03_RETRY_T,GVMT03_CREATE_USER_C,GVMT03_CREATE_S,GVMT03_LAST_UPDT_USER_C,GVMT03_LAST_UPDT_S)\n" +
            "values(PGVMT03_TXN_DTL_D_SQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?)";

    public TransactionDetailDaoImpl(@Qualifier("dataSource") DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public long save(String vin, String status, long txnId, String sourceSystem,
                     Timestamp currentTimestamp, int retryCount) {

        long start = System.currentTimeMillis();
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        long txnDtlId = 0;
        try {
            //STEP 1: Open a connection insert
            conn = dataSource.getConnection();
            //STEP 2: Execute a query
            preparedStatement = conn.prepareStatement(INSERT_TXN_DTL,new String[]{"GVMT03_TXN_DTL_D"});
            conn.setAutoCommit(false);

            preparedStatement.setString(1, status);
            preparedStatement.setLong(2, txnId);
            preparedStatement.setString(3, vin);
            preparedStatement.setInt(4, ApplicationUtils.getVinHash(vin));
            preparedStatement.setTimestamp(5, currentTimestamp);
            preparedStatement.setString(6, sourceSystem);
            preparedStatement.setInt(7, retryCount);
            preparedStatement.setString(8, sourceSystem);
            preparedStatement.setTimestamp(9, currentTimestamp);
            preparedStatement.setString(10, sourceSystem);
            preparedStatement.setTimestamp(11, currentTimestamp);
            int prepStmt = preparedStatement.executeUpdate();

            if(prepStmt > 0 )
            {
                ResultSet rs = preparedStatement.getGeneratedKeys();
                if(rs != null && rs.next()){
                    txnDtlId = rs.getLong(1);
                }
            }
            conn.commit();
            preparedStatement.close();
            conn.setAutoCommit(true);
            conn.close();
        } catch (Exception e) {
            //Handle errors for Class.forName
            exceptionHandler.logException(e, this.getClass().getSimpleName());
        } finally {
            //finally block used to close resources
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                exceptionHandler.logException(se, this.getClass().getSimpleName());
            }//end finally try
        }
        long end = System.currentTimeMillis() - start;
        LOGGER.debug("Time taken to save TxnDtl:::" + end);
        return txnDtlId;
    }
}
