package com.ford.gvmsr.snapobserver.exception;

/**
 * Created by tanbuche on 9/22/2017.
 */
public class GVMSValidationException extends GVMSSelfLoggingException {

    public GVMSValidationException(String customMsg) {

        super(customMsg);
    }

    public GVMSValidationException(String className, String methodName, String customMsg) {

        super(className, methodName, customMsg);
    }

    public GVMSValidationException(String className, String methodName, String customMsg, String expMsg) {

        super(className, methodName, customMsg, expMsg);
    }

    public GVMSValidationException(String className, String methodName, String customMsg, boolean isLogging) {
        super(className, methodName, customMsg, isLogging);
    }

    public GVMSValidationException(String className, String methodName, String customMsg, String expMsg, boolean isLogging) {

        super(className, methodName, customMsg, expMsg, isLogging);
    }

    public GVMSValidationException(String className, String methodName, String customMsg, Throwable throwable) {

        super(className, methodName, customMsg, throwable);
    }

    public GVMSValidationException(String className, String methodName, String customMsg, String expMsg, Throwable throwable) {

        super(className, methodName, customMsg, expMsg, throwable);
    }

    public GVMSValidationException(String className, String methodName, String customMsg, String expMsg, Throwable throwable, boolean isLogging) {

        super(className, methodName, customMsg, expMsg, throwable);
    }
}
