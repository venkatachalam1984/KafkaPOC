package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeDIDResponseDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.data.repository.VehicleNodeDIDResponseRepository;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Date;
import java.util.List;

@Service
public class VehicleNodeDIDResponseDaoImpl implements VehicleNodeDIDResponseDao {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    VehicleNodeDIDResponseRepository vehicleNodeDIDResponseRepository;

    @Autowired
    DataSource dataSource;

    @Autowired
    ExceptionHandler exceptionHandler;

    private static final String INSERT_VEH_NODE_DID_RESPONSE = "INSERT INTO PGVMS02_VEH_NODE_DID_RSPNS(\n" +
            "GVMS10_VIN_HASH_R,\n" +
            "GVMS02_VEH_NODE_DID_RSPNS_K,\n" +
            "GVMS04_VEH_NODE_SNPSHT_K,\n" +
            "GVMS14_MOD_NODE_K,\n" +
            "GVM011_DID_CATLG_D,\n" +
            "GVMS02_LAST_DID_RECORD_S,\n" +
            "GVMS02_IS_CONFIG_F,\n" +
            "GVMS02_IS_COMPLETE_F,\n" +
            "GVMS02_OPTIMIZED_DID_F,\n" +
            "GVM012_DID_TYPE_C,\n" +
            "GVM017_NW_NM_C,\n" +
            "GVM016_DID_SPEC_CATG_C,\n" +
            "GVMS02_VEH_MOD_DID_RSPNS_X,\n" +
            "GVMS02_MODIFIED_DID_RSPNS_X,\n" +
            "GVMS02_LAST_STATION_CELL_C,\n" +
            "GVMS02_LAST_FILE_N,\n" +
            "GVMS02_DID_CHILD_TABLE_R,\n" +
            "GVMS02_DEL_VEH_NODE_SNPSHT_K,\n" +
            "GVMS02_ACTIVE_F,\n" +
            "GVMS02_CREATE_USER_C,\n" +
            "GVMS02_CREATE_S,\n" +
            "GVMS02_LAST_UPDT_USER_C,\n" +
            "GVMS02_LAST_UPDT_S,\n" +
            "GVMS02_NTWK_PROTOCOL_N,\n" +
            "GVMS02_NTWK_DTA_RATE_R,\n" +
            "GVMS02_VIL_DID_RSPNS_ERR_X)\n" +
            "VALUES(?,PGVMS02_NODE_DID_RSPNS_K_SQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    @Override
    public List<VehicleNodeDIDResponse> save(List<VehicleNodeDIDResponse> vehicleNodeDIDResponseList) throws SQLException{

        long start = System.currentTimeMillis();
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        try {
            conn = dataSource.getConnection();
            preparedStatement = conn.prepareStatement(INSERT_VEH_NODE_DID_RESPONSE,  new String[]{"GVMS02_VEH_NODE_DID_RSPNS_K"});
            conn.setAutoCommit(false);

            for (VehicleNodeDIDResponse vehicleNodeDIDResponse : vehicleNodeDIDResponseList) {
                preparedStatement.setInt(1, vehicleNodeDIDResponse.getVehicleNodeDIDResponseId().getVinHashNumber());
                preparedStatement.setLong(2, vehicleNodeDIDResponse.getVehicleNodeSnapshot().getVehicleNodeSnapshotId().getVehicleNodeSnapshotKey());
                preparedStatement.setLong(3, vehicleNodeDIDResponse.getModuleNode().getModNodeSaKey());
                preparedStatement.setString(4, vehicleNodeDIDResponse.getDidCatalog());
                preparedStatement.setTimestamp(5, vehicleNodeDIDResponse.getLastDIDRecordDateTime());
                preparedStatement.setString(6, vehicleNodeDIDResponse.getIsConfig());
                preparedStatement.setString(7, vehicleNodeDIDResponse.getIsComplete());
                preparedStatement.setString(8, vehicleNodeDIDResponse.getIsOptimizedDID());
                preparedStatement.setString(9, vehicleNodeDIDResponse.getDidType());
                preparedStatement.setString(10, vehicleNodeDIDResponse.getNetworkName());
                preparedStatement.setString(11, vehicleNodeDIDResponse.getDidSpecificationCategory());
                preparedStatement.setString(12, vehicleNodeDIDResponse.getDidResponse());
                preparedStatement.setString(13, vehicleNodeDIDResponse.getModifiedDidResponse());
                preparedStatement.setString(14, vehicleNodeDIDResponse.getLastStationCellId());
                preparedStatement.setString(15, vehicleNodeDIDResponse.getLastFileName());
                preparedStatement.setString(16, vehicleNodeDIDResponse.getDidChildTableNbr());
                if (vehicleNodeDIDResponse.getDeletedVehicleNodeSnapshot() != null) {
                    preparedStatement.setLong(17, vehicleNodeDIDResponse.getDeletedVehicleNodeSnapshot());
                } else {
                    preparedStatement.setNull(17, Types.BIGINT);
                }
                preparedStatement.setString(18, vehicleNodeDIDResponse.getActiveFlag());
                preparedStatement.setString(19, GVMSModuleUpdateConstants.APP_CODE_GVMS);
                preparedStatement.setTimestamp(20, new Timestamp(new Date().getTime()));
                preparedStatement.setString(21, GVMSModuleUpdateConstants.APP_CODE_GVMS);
                preparedStatement.setTimestamp(22, new Timestamp(new Date().getTime()));
                preparedStatement.setString(23, vehicleNodeDIDResponse.getNetworkProtocol());
                preparedStatement.setString(24, vehicleNodeDIDResponse.getNetworkDataRate());
                preparedStatement.setString(25, vehicleNodeDIDResponse.getVilDIDError());
                int prepStmt =  preparedStatement.executeUpdate();

                if(prepStmt > 0 )
                {
                    ResultSet rs = preparedStatement.getGeneratedKeys();

                    if(rs != null && rs.next()){
                        vehicleNodeDIDResponse.getVehicleNodeDIDResponseId().setVehicleNodeDidReponseKey(rs.getLong(1));
                    }
                }
            }
            conn.commit();
            preparedStatement.close();
            conn.setAutoCommit(true);
            conn.close();
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
            exceptionHandler.logException(se, this.getClass().getSimpleName());
            throw se;
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
            exceptionHandler.logException(e, this.getClass().getSimpleName());
            throw e;
        } finally {
            //finally block used to close resources
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } catch (SQLException se2) {
            }// nothing we can do
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
                exceptionHandler.logException(se, this.getClass().getSimpleName());
            }//end finally try
        }
        String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
        logger.info("Time taken to save all the VehicleNodeDIDResponseList batch process:::" + duration);

        return vehicleNodeDIDResponseList;
    }
}
