package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.validator.request.NodeSkipValidatorRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SnapObserverValidationChainBuilder {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private NodeSkipValidator chain;

    public SnapObserverValidationChainBuilder() {
        buildSnapSkipValidation();
    }

    private void buildSnapSkipValidation() {
        chain = new ESNDIDValidator(new MandatoryDIDValidator(new StrategyDIDValidator(null)));
    }

    public boolean applyValidation(NodeSkipValidatorRequest receiverRequest) {
        try {
            return chain.handleRequest(receiverRequest);
        } catch (Exception e) {
            log.error("Exception Msg"+e.getMessage());
            return true;
        }
    }
}
