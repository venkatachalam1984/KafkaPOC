package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.List;


public class AnalyzelogFtrProperties {

    private String vin;

    private Integer vinHash;

    private List<String> featurecode = null;

    private String role;

    private String roleSource;

    private String roleDesc;

    private String roleID;

    private String gvmsTransId;

    private String gvmsTransDtlId;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public Integer getVinHash() {
        return vinHash;
    }

    public void setVinHash(Integer vinHash) {
        this.vinHash = vinHash;
    }

    public List<String> getFeaturecode() {
        return featurecode;
    }

    public void setFeaturecode(List<String> featurecode) {
        this.featurecode = featurecode;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getRoleSource() {
        return roleSource;
    }

    public void setRoleSource(String roleSource) {
        this.roleSource = roleSource;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public String getRoleID() {
        return roleID;
    }

    public void setRoleID(String roleID) {
        this.roleID = roleID;
    }

    public String getGvmsTransId() {
        return gvmsTransId;
    }

    public void setGvmsTransId(String gvmsTransId) {
        this.gvmsTransId = gvmsTransId;
    }

    public String getGvmsTransDtlId() {
        return gvmsTransDtlId;
    }

    public void setGvmsTransDtlId(String gvmsTransDtlId) {
        this.gvmsTransDtlId = gvmsTransDtlId;
    }
}
