package com.ford.gvmsr.snapobserver.kafka.producer;

import com.ford.gvmsr.snapobserver.config.VertxConfiguration;
import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.logevent.splunk.Utils;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import io.vertx.kafka.client.producer.KafkaProducer;
import io.vertx.kafka.client.producer.KafkaProducerRecord;
import io.vertx.kafka.client.producer.RecordMetadata;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class GVMSRExceptionEventProducer extends AbstractVerticle  {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    VertxConfiguration vertxConfiguration;

    @Autowired
    Utils splunkUtils ;

    KafkaProducer<String, String> exceptionEventProducer = null;

    @Override
    public void start() {
        registerKafkaSnapResponseProducer(vertx);
    }

    //New KafkaProducer instance
    public void registerKafkaSnapResponseProducer(Vertx vertx) {

        Properties properties = new Properties();
        if(vertxConfiguration.getSnapSyncupEnvironment().equalsIgnoreCase(GVMSModuleUpdateConstants.VERTX_KAFKA_SYNCUP_DEV)) {
            properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, vertxConfiguration.getExceptionEventProducerDevEndpoints());
        }else if(vertxConfiguration.getSnapSyncupEnvironment().equalsIgnoreCase(GVMSModuleUpdateConstants.VERTX_KAFKA_SYNCUP_QA)){
            properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, vertxConfiguration.getExceptionEventProducerQaEndpoints());
        }else if(vertxConfiguration.getSnapSyncupEnvironment().equalsIgnoreCase(GVMSModuleUpdateConstants.VERTX_KAFKA_SYNCUP_PROD)){
            properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, vertxConfiguration.getExceptionEventProducerProdEndpoints());
        }
        properties.put(ProducerConfig.ACKS_CONFIG, "1");
        properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, vertxConfiguration.getSnapshotProtocolConfig());
        exceptionEventProducer = KafkaProducer.create(vertx, properties, String.class, String.class);

    }

    public void publishMessage(String message, String topic) {

        logger.info("ExceptionEventProducer:Push snapshot response to topic = {} ", topic);
        KafkaProducerRecord<String, String> record = KafkaProducerRecord.create(topic, message);
        exceptionEventProducer.send(record, event -> {
            if (event.succeeded()) {
                RecordMetadata result = event.result();
                logger.info("ExceptionEventProducer:Published to topic={}, partition={}", result.getTopic(), result.getPartition());
                record.headers().forEach(
                        header -> logger.info("ExceptionEventProducer:Header key={}, value={} ", header.key(), header.value().toString()));
            } else {
                logger.error("ExceptionEventProducer:Error while publish message = " + event.cause());
            }
        });

    }


}