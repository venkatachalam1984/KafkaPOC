
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;


/**
 * 
 * 				Lists the VSCS Specifications that uses the Assembly.
 * 			
 * 
 * <p>Java class for UsedByVSCSSpecificationsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UsedByVSCSSpecificationsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SoftwareURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="VSCSID" type="{urn:ford/Vehicle/Module/Information/v4.0}VSCSIDType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UsedByVSCSSpecificationsType", propOrder = {
    "softwareURL"
})
public class UsedByVSCSSpecificationsType {

    @XmlElement(name = "SoftwareURL")
    protected String softwareURL;
    @XmlAttribute(name = "VSCSID")
    protected String vscsid;

    /**
     * Gets the value of the softwareURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareURL() {
        return softwareURL;
    }

    /**
     * Sets the value of the softwareURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareURL(String value) {
        this.softwareURL = value;
    }

    /**
     * Gets the value of the vscsid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVSCSID() {
        return vscsid;
    }

    /**
     * Sets the value of the vscsid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVSCSID(String value) {
        this.vscsid = value;
    }

}
