package com.ford.gvmsr.snapobserver;

import com.ford.gvmsr.snapobserver.facade.SnapCreationFacade;
import com.ford.gvmsr.snapobserver.modulestate.request.SnapshotObserverRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SnapRequestObserver {

    @Autowired
    SnapCreationFacade snapCreationFacade;

    public void createSnapShot(SnapshotObserverRequest snapshotObserverRequest){
        snapCreationFacade.createSnapshot(snapshotObserverRequest);
    }
}
