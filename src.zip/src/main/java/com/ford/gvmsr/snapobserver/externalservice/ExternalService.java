package com.ford.gvmsr.snapobserver.externalservice;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;

import java.util.List;
import java.util.Optional;

public interface ExternalService {

    Optional<Vehicle> getVinFromGivis(String vin);

    Optional<Vehicle> getVinFromGivis(String vin, List<String> nodeList);


}
