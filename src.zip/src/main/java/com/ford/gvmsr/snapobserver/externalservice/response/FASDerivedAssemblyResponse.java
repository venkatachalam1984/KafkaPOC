package com.ford.gvmsr.snapobserver.externalservice.response;

import java.util.Map;

public class FASDerivedAssemblyResponse {

    private Map<String, FASDerivedAssemblyResponseForNode> derivedAssemblyResponseForNodeMap;

    public Map<String, FASDerivedAssemblyResponseForNode> getDerivedAssemblyResponseForNodeMap() {
        return derivedAssemblyResponseForNodeMap;
    }

    public void setDerivedAssemblyResponseForNodeMap(Map<String, FASDerivedAssemblyResponseForNode> derivedAssemblyResponseForNodeMap) {
        this.derivedAssemblyResponseForNodeMap = derivedAssemblyResponseForNodeMap;
    }
}
