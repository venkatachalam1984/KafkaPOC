package com.ford.gvmsr.snapobserver.externalservice.response;

import java.util.List;


public class ODLComplianceResponse {

    private List<String> errorMessage;

    public List<String> getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(List<String> errorMessage) {
        this.errorMessage = errorMessage;
    }
}
