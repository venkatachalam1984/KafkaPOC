package com.ford.gvmsr.snapobserver.externalservice.response;

import java.util.List;


public class ECUModuleResponse {

    private boolean isESNExists;
    private EcuModule ecuModule;
    private boolean isPartNumberExists;
    private List<EcuParts> ecuParts;
    private String responseMessage;

    public boolean isESNExists() {
        return isESNExists;
    }

    public void setESNExists(boolean ESNExists) {
        isESNExists = ESNExists;
    }

    public EcuModule getEcuModule() {
        return ecuModule;
    }

    public void setEcuModule(EcuModule ecuModule) {
        this.ecuModule = ecuModule;
    }

    public List<EcuParts> getEcuParts() {
        return ecuParts;
    }

    public void setEcuParts(List<EcuParts> ecuParts) {
        this.ecuParts = ecuParts;
    }

    public boolean isPartNumberExists() {
        return isPartNumberExists;
    }

    public void setPartNumberExists(boolean partNumberExists) {
        isPartNumberExists = partNumberExists;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }
}
