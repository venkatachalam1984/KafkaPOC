package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.constants.VilConstants;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.exception.ESNDidValidationException;
import com.ford.gvmsr.snapobserver.exception.alarmevents.ExceptionEventService;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.utils.BeanUtil;
import com.ford.gvmsr.snapobserver.validator.request.NodeSkipValidatorRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

public class ESNDIDValidator extends NodeSkipValidator {

    private static final Logger logger = LoggerFactory.getLogger(ESNDIDValidator.class);

    private ExceptionEventService exceptionEventService;

    public ESNDIDValidator(NodeSkipValidator next) {
        super(next);
    }

    public boolean validate(NodeSkipValidatorRequest nodeSkipValidatorRequest) throws ESNDidValidationException {


        List<DIDInfoType> currentDIDESNFilteredList =
                nodeSkipValidatorRequest.getGatewayType().getDID().stream()
                        .filter(e -> nodeSkipValidatorRequest.getEsnDidList().contains(e.getDidValue())).
                        collect(Collectors.toList());

        Map<String,String> prevSnapNodeDidResponseMap =
                nodeSkipValidatorRequest.getPreviousSnapShotDetailsByNode().getPrevNonConfigDidResponseMap().values().stream().
                        filter(vehicleNodeDIDResponse -> nodeSkipValidatorRequest.getEsnDidList().
                                contains(vehicleNodeDIDResponse.getDidCatalog())).collect(Collectors.
                        toMap(VehicleNodeDIDResponse::getDidCatalog,VehicleNodeDIDResponse::getDidResponse));
        AtomicBoolean isF17FESNDId = new AtomicBoolean(false);
        boolean isESNChanged = false;

        if (!CollectionUtils.isEmpty(prevSnapNodeDidResponseMap) ) {
            for (DIDInfoType didInfoType : currentDIDESNFilteredList) {
                String prevEsnDidResponse = prevSnapNodeDidResponseMap.get(didInfoType.getDidValue());

                if (null != didInfoType.getResponse() && null != prevEsnDidResponse &&
                        ApplicationUtils.isValidDidResponse(didInfoType.getResponse())) {

                    if (didInfoType.equals(VilConstants.F17F_DID)) {
                        if (!didInfoType.getResponse().equalsIgnoreCase(prevEsnDidResponse)) {
                            nodeSkipValidatorRequest.getSnapshotObserverRequest().getSnapshotChangeMonitor().
                                    update(nodeSkipValidatorRequest.getNode(), TrackingLevel.DID,
                                    TrackingType.SNAP_SKIP_DID, true);
                            isESNChanged = true;

                        } else if (didInfoType.getResponse().equalsIgnoreCase(prevEsnDidResponse)) {
                            nodeSkipValidatorRequest.getSnapshotObserverRequest().getSnapshotChangeMonitor().update
                                    (nodeSkipValidatorRequest.getNode(), TrackingLevel.DID,
                                    TrackingType.SNAP_SKIP_DID, false);
                            isESNChanged = false;
                        }
                    } else if (isF17FESNDId.get() == false && !didInfoType.getResponse().equalsIgnoreCase(prevEsnDidResponse)) {
                        nodeSkipValidatorRequest.getSnapshotObserverRequest().getSnapshotChangeMonitor().
                                update(nodeSkipValidatorRequest.getNode(), TrackingLevel.DID,
                                TrackingType.SNAP_SKIP_DID, true);
                        isESNChanged = true;
                    }
                }
            }
        }
        if(isESNChanged) {
            exceptionEventService = BeanUtil.getBean(ExceptionEventService.class);
            exceptionEventService.createFailureAlarm(nodeSkipValidatorRequest.getSnapshotObserverRequest().getVin(),
                    nodeSkipValidatorRequest.getNode().getAddress(),null,null, "ESN DID Validation Failed");
            throw new ESNDidValidationException("ESN Validation is failing ");
        }
        return isESNChanged;
    }

    @Override
    public boolean handleRequest(NodeSkipValidatorRequest nodeSkipValidatorRequest) throws Exception {

        logger.info("Received ESN DID validation");
        validate(nodeSkipValidatorRequest);
        super.handleRequest(nodeSkipValidatorRequest);
        return false;
    }
}
