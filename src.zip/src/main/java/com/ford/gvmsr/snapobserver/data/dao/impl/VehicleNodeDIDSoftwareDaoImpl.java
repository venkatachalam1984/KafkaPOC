package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeDIDSoftwareDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDSoftware;
import com.ford.gvmsr.snapobserver.data.repository.VehicleNodeDIDSoftwareRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class VehicleNodeDIDSoftwareDaoImpl implements VehicleNodeDIDSoftwareDao {

    @Autowired
    VehicleNodeDIDSoftwareRepository vehicleNodeDIDSoftwareRepository;

    @Override
    public VehicleNodeDIDSoftware save(VehicleNodeDIDSoftware vehicleNodeDIDSoftware) {
        return vehicleNodeDIDSoftwareRepository.save(vehicleNodeDIDSoftware);
    }

    @Override
    public List<VehicleNodeDIDSoftware> saveAll(List<VehicleNodeDIDSoftware> vehicleNodeDIDSoftwareList) {
        return vehicleNodeDIDSoftwareRepository.saveAll(vehicleNodeDIDSoftwareList);
    }
}
