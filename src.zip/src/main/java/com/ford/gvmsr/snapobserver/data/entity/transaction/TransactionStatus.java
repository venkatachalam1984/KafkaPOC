package com.ford.gvmsr.snapobserver.data.entity.transaction;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

@Entity
@Table(name="PGVMT02_TXN_STAT")
public class TransactionStatus extends BaseEntity {

    @Id
    @Column (name="GVMT02_TXN_STAT_C")
    private String transctionStatusCode;

    @Column (name="GVMT02_TXN_STAT_X")
    private String transctionStatusDesc;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT02_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT02_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT02_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT02_LAST_UPDT_S"))}
    )


    private AuditColumns auditColumns = new AuditColumns();

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public String getTransctionStatusCode() {
        return transctionStatusCode;
    }

    public void setTransctionStatusCode(String transctionStatusCode) {
        this.transctionStatusCode = transctionStatusCode;
    }

    public String getTransctionStatusDesc() {
        return transctionStatusDesc;
    }

    public void setTransctionStatusDesc(String transctionStatusDesc) {
        this.transctionStatusDesc = transctionStatusDesc;
    }
}
