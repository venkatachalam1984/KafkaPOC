package com.ford.gvmsr.snapobserver.constants;

public class VilConstants {

    public static final String RETURN_TYPE_VIL = "VIL";

    public static final String RETURN_TYPE_VALIDATE = "VALIDATE";

    public static final String RETURN_TYPE_VALIDATE_AND_PROCESS = "PROCESS";

    public static final String RETURN_TYPE = "return";

    public static final String SOURCE = "source";

    public static final String SOURCE_VIL = "vil";

    public static final String SOURCE_EOL = "eol";

    public static final String SOURCE_AL = "al";

    public static final String RAW_VIL = "rawVIL";

    public static final String ENCRYPTED_VIL = "encryptedVIL";

    public static final String VALID_STATUS = "VALID";

    public static final String VALID_PROCESS_STATUS = "VALID & Proceed to Process";

    public static final String IN_VALID_STATUS = "INVALID";

    public static final String SCHEMA_VERSION = "v5";

    public static final String ERROR = "ERROR";

    public static final String ERROR_MESSAGE = "message";

    public static final String NODES = "nodes";

    public static final String DID = "did";

    public static final String DID_VALUE = "didValue";

    public static final String RAW_RESPONSE = "rawResponse";

    public static final String DECODED_RESPONSE = "decodedResponse";

    public static final String POSITIVE_RESPONSE_62 = "62";

    public static final String NEGATIVE_RESPONSE_7F = "7F";

    public static final String POSITIVE_RESPONSE_71 = "71";

    public static final String ADDRESS = "address";

    public static final String Message_TYPE_CODE = "VIL";

    public static final String Processing_State_Code = "NEW";

    public static final String COMPLETE = "CMPLT";

    public static final String VIL_DECODE_ERROR = "VIL_DECODE_ERROR";
    public static final String VIL_VALIDATION_ERROR = "VVERROR";
    public static final String VIL_JSON_PARSE_ERROR = "VJPERROR";
    public static final String VIL_KAFKA_FAILED = "KAFKA_FLR";
    public static final String DID_RESPONSE_PARSING_ERROR = "PARSING-ERROR";
    public static final String DID_RESPONSE_INVALID_CHAR_ERROR = "INVALID-CHAR-ERROR";
    public static final String LATE_VIL = "LATEVIL";
    public static final String VIL_REDIS_ERROR = "VIL_REDIS_E";

    public static final String VIL_REQ_GEN_ERROR ="VIL_REQ_GEN_E";

    public static final String VIL_SERVICE = "VIL_SERVICE";

    public static final String VIL_NEW_PROCESS = "NEW";
    public static final String VIL_RETRY_PROCESS = "RETRY";

    public static final String SEND_TO_AL = "SENDTOAL";
    public static final String PARTIAL_CMPLT = "PAR_CMPLT";
    public static final String VIL_SAVE_ERROR = "SAVE_ERROR";
    public static final String VIL_AL_ERR = "AL_ERR";

    public static final String VIL_TO_HEC_SPLUNK_SUCCESS ="Success";
    public static final String VIL_TRK_MSG ="VIL_TRK_M";
    public static final String SNP_TRKG_MSG ="SNP_TRK_M";
    public static final String SYNC_TRKG_MSG ="SYNC_TRK_M";
    public static final String VIL_CONSUMER ="VIL-CON";
    public static final String VIL_FACADE ="VIL-FAC";
    public static final String FAS_AL ="FAS-AL";

    public static final String log_info_type ="info";
    public static final String log_error_type ="error";
    public static final String log_fatal_type ="FATAL";

    public static final String VIL_RCVD="VIL_RECEIVED_S";
    public static final String VIL_VAL_FAILED="VALIDATION_F";
    public static final String VIL_DC_ERROR="DECODE_F";
    public static final String VIL_JSON_PARS_ERROR="PARSER_ERROR";
    public static final String VIL_SENT_TO_AL="TO_SNAP_S";
    public static final String VIL_SNP_SUCCESS="SNAP_S";
    public static final String VIL_SNP_ERROR="SNAP_F";
    public static final String VIL_VSS_SYNC_SUCCESS="VSS_SYNC_S";
    public static final String VIL_VSS_SYNC_FAIED="VSS_SYNC_F";
    public static final String VIL_GVS_SUCCESS="GIVIS_SYNC_S";
    public static final String VIL_GVS_FAILED="GIVIS_SYNC_F";
    public static final String VIL_NODE_DUP="DUP_NODE";
    public static final String VIL_SNP_DUP="DUP_SNAP";
    public static final String NODE_START="NODE_START";
    public static final String VIL_RECV_ERROR="VIL_RECEIVED_F";
    public static final String SNP_PROCESS_ERROR="SNAP_PROC_ERROR";
    public static final String VIN_CREATION_ERROR="VIN_ERROR";
    public static final String VIL_NO_VAL_DID="INVAL_NODE";
    public static final String VIL_NO_MAND_DID="NO_MAND_DID";


    public static final String VIL_START="VIL_START";
    public static final String VIL_END="VIL_END";

    public static final String F111_DID ="F111";
    public static final String F113_DID ="F113";

    public static final String F17F_DID ="F17F";

    public static final String F188_DID ="F188";

    //Snap Observer to Snap Confirmer constants
    public static final String SNAP_REQUEST_HANDLER = "GVMSRSnapRequestHandler-";

    public static final String SNAP_OBSERVER = "SNAP_OBSERVER";

    public static final String RCVD_FRM_VERTICLE = "RCVD_FRM_VERTICLE";

    public static final String RCVD_FRM_VIL_RECVR= "RCVD_FRM_VIL_RECVR";

    public static final String SENT_TO_FACADE = "SENT_TO_FACADE";

    public static final String FACADE_TRK_M = "FACADE_TRK_M";

    public static final String SENT_TO_VERTICLE = "SENT_TO_VERTICLE";

    public static final String RCVD_FRM_FACADE = "RCVD_FRM_FACADE";

    public static final String FACADE_ERROR = "FACADE_ERROR";

    public static final String VERTICLE_TRK_M = "VERTICLE_TRK_M";

    public static final String KAFKA_TRK_M = "KAFKA_TRK_M";

    public static final String SENT_TO_CNF = "SENT_TO_CNF";

    public static final String CNF_HANDLER_TRK_M = "CNF_HANDLER_TRK_M";

    public static final String SENT_TO_CNF_F = "SENT_TO_CNF_FAILED";

    public static final String KAFKA_TRK_END = "KAFKA_TRK_END";

    public static final String PUSH_TO_OBS_PRODUCER = "PUSH_TO_OBS_PRODUCER";

}
