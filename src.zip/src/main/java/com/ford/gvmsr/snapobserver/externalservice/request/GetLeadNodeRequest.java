package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.Map;

/**
 * Created by MDEVARA3 on 1/3/2018.
 */
public class GetLeadNodeRequest {

    private String programCode;
    private float salesModelYear;
    private Map<String,String> nodeAssyFPNMap;

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public Map<String, String> getNodeAssyFPNMap() {
        return nodeAssyFPNMap;
    }

    public void setNodeAssyFPNMap(Map<String, String> nodeAssyFPNMap) {
        this.nodeAssyFPNMap = nodeAssyFPNMap;
    }
}
