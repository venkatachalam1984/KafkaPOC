package com.ford.gvmsr.snapobserver.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ExternalServiceProperties {

    //App URL
    @Value("${app-url.moduleinfo}")
    public String appUrlModuleInfo;


    //Endpoints

    @Value("${moduleinfo.endpoint.get-givis-snap}")
    public String moduleInfoGetGivisSnap;


}
