package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by MDEVARA3 on 8/30/2017.
 *
 * Address to which messages are sent where the module at that node may then respond back.
 Data Source: GIVIS:NMGM060_MOD_NODE
 */

@Entity
@Table(name = "PGVMS02_VEH_NODE_DID_RSPNS")
public class VehicleNodeDIDResponse extends BaseEntity {

 /*   @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="GVMS02_VEH_NODE_DID_RSPNS_K")
    private long vehicleNodeDidReponseKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;*/

    @EmbeddedId
    private VehicleNodeDIDResponseId vehicleNodeDIDResponseId;


    /*@JoinColumnsOrFormulas({
            @JoinColumnOrFormula(column = @JoinColumn(name = "GVMS04_VEH_NODE_SNPSHT_K", referencedColumnName = "GVMS04_VEH_NODE_SNPSHT_K")),
            @JoinColumnOrFormula(formula = @JoinFormula(value = "GVMS10_VIN_HASH_R", referencedColumnName = "GVMS10_VIN_HASH_R"))

    })*/
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
            @JoinColumn(name = "GVMS04_VEH_NODE_SNPSHT_K", referencedColumnName = "GVMS04_VEH_NODE_SNPSHT_K",insertable = false,updatable = false),
            @JoinColumn(name = "GVMS10_VIN_HASH_R", referencedColumnName = "GVMS10_VIN_HASH_R",insertable = false,updatable = false)
    })
    private VehicleNodeSnapshot vehicleNodeSnapshot;

    @ManyToOne
    @JoinColumn(name = "GVMS14_MOD_NODE_K",referencedColumnName = "GVMS14_MOD_NODE_K")
    private ModuleNode moduleNode;

    @Column(name = "GVM011_DID_CATLG_D")
    private String didCatalog;

    @Column(name = "GVMS02_LAST_DID_RECORD_S")
    private Timestamp lastDIDRecordDateTime;

    @Column(name = "GVMS02_IS_CONFIG_F")
    private String isConfig;

    @Column(name = "GVMS02_IS_COMPLETE_F")
    private String isComplete;

    @Column(name = "GVMS02_OPTIMIZED_DID_F")
    private String isOptimizedDID;

    @Column(name = "GVM012_DID_TYPE_C")
    private String didType;

    @Column(name = "GVM017_NW_NM_C")
    private String networkName;

    @Column(name = "GVM016_DID_SPEC_CATG_C")
    private String didSpecificationCategory;

    @Column(name = "GVMS02_VEH_MOD_DID_RSPNS_X")
    private String didResponse;

    @Column(name = "GVMS02_MODIFIED_DID_RSPNS_X")
    private String modifiedDidResponse;

    @Column(name = "GVMS02_LAST_STATION_CELL_C")
    private String lastStationCellId;

    @Column(name = "GVMS02_LAST_FILE_N")
    private String lastFileName;

    @Transient
    private List<VehicleNodeDIDSoftware> vehicleNodeDIDSoftwares;

    @Column(name = "GVMS02_DID_CHILD_TABLE_R")
    private String didChildTableNbr;

    @Column(name = "GVMS02_DEL_VEH_NODE_SNPSHT_K")
    private Long deletedVehicleNodeSnapshot;

    @Column(name = "GVMS02_ACTIVE_F")
    private String activeFlag;

    @Column(name = "GVMS02_NTWK_PROTOCOL_N")
    private String networkProtocol;

    @Column(name = "GVMS02_NTWK_DTA_RATE_R")
    private String networkDataRate;

    @Column(name = "GVMS02_VIL_DID_RSPNS_ERR_X")
    private String vilDIDError;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS02_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS02_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS02_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS02_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public VehicleNodeDIDResponseId getVehicleNodeDIDResponseId() {
        return vehicleNodeDIDResponseId;
    }

    public void setVehicleNodeDIDResponseId(VehicleNodeDIDResponseId vehicleNodeDIDResponseId) {
        this.vehicleNodeDIDResponseId = vehicleNodeDIDResponseId;
    }

    /* public long getVehicleNodeDidReponseKey() {
        return vehicleNodeDidReponseKey;
    }

    public void setVehicleNodeDidReponseKey(long vehicleNodeDidReponseKey) {
        this.vehicleNodeDidReponseKey = vehicleNodeDidReponseKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }*/


    public VehicleNodeSnapshot getVehicleNodeSnapshot() {
        return vehicleNodeSnapshot;
    }

    public void setVehicleNodeSnapshot(VehicleNodeSnapshot vehicleNodeSnapshot) {
        this.vehicleNodeSnapshot = vehicleNodeSnapshot;
    }

    public ModuleNode getModuleNode() {
        return moduleNode;
    }

    public void setModuleNode(ModuleNode moduleNode) {
        this.moduleNode = moduleNode;
    }

    public String getDidCatalog() {
        return didCatalog;
    }

    public void setDidCatalog(String didCatalog) {
        this.didCatalog = didCatalog;
    }

    public Timestamp getLastDIDRecordDateTime() {
        return lastDIDRecordDateTime;
    }

    public void setLastDIDRecordDateTime(Timestamp lastDIDRecordDateTime) {
        this.lastDIDRecordDateTime = lastDIDRecordDateTime;
    }

    public String getIsConfig() {
        return isConfig;
    }

    public void setIsConfig(String isConfig) {
        this.isConfig = isConfig;
    }

    public String getIsComplete() {
        return isComplete;
    }

    public void setIsComplete(String isComplete) {
        this.isComplete = isComplete;
    }

    public String getIsOptimizedDID() {
        return isOptimizedDID;
    }

    public void setIsOptimizedDID(String isOptimizedDID) {
        this.isOptimizedDID = isOptimizedDID;
    }

    public String getDidType() {
        return didType;
    }

    public void setDidType(String didType) {
        this.didType = didType;
    }

    public String getNetworkName() {
        return networkName;
    }

    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }

    public String getDidSpecificationCategory() {
        return didSpecificationCategory;
    }

    public void setDidSpecificationCategory(String didSpecificationCategory) {
        this.didSpecificationCategory = didSpecificationCategory;
    }

    public String getDidResponse() {
        return didResponse;
    }

    public void setDidResponse(String didResponse) {
        this.didResponse = didResponse;
    }

    public String getModifiedDidResponse() {
        return modifiedDidResponse;
    }

    public void setModifiedDidResponse(String modifiedDidResponse) {
        this.modifiedDidResponse = modifiedDidResponse;
    }

    public String getLastStationCellId() {
        return lastStationCellId;
    }

    public void setLastStationCellId(String lastStationCellId) {
        this.lastStationCellId = lastStationCellId;
    }

    public String getLastFileName() {
        return lastFileName;
    }

    public void setLastFileName(String lastFileName) {
        this.lastFileName = lastFileName;
    }

    public String getDidChildTableNbr() {
        return didChildTableNbr;
    }

    public void setDidChildTableNbr(String didChildTableNbr) {
        this.didChildTableNbr = didChildTableNbr;
    }

    public Long getDeletedVehicleNodeSnapshot() {
        return deletedVehicleNodeSnapshot;
    }

    public void setDeletedVehicleNodeSnapshot(Long deletedVehicleNodeSnapshot) {
        this.deletedVehicleNodeSnapshot = deletedVehicleNodeSnapshot;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public List<VehicleNodeDIDSoftware> getVehicleNodeDIDSoftwares() {
        return vehicleNodeDIDSoftwares;
    }

    public void setVehicleNodeDIDSoftwares(List<VehicleNodeDIDSoftware> vehicleNodeDIDSoftwares) {
        this.vehicleNodeDIDSoftwares = vehicleNodeDIDSoftwares;
    }

    public String getNetworkProtocol() {
        return networkProtocol;
    }

    public void setNetworkProtocol(String networkProtocol) {
        this.networkProtocol = networkProtocol;
    }

    public String getNetworkDataRate() {
        return networkDataRate;
    }

    public void setNetworkDataRate(String networkDataRate) {
        this.networkDataRate = networkDataRate;
    }

    public String getVilDIDError() {
        return vilDIDError;
    }

    public void setVilDIDError(String vilDIDError) {
        this.vilDIDError = vilDIDError;
    }
}
