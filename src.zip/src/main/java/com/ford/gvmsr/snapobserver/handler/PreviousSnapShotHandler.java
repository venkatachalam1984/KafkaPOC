package com.ford.gvmsr.snapobserver.handler;

import com.ford.gvmsr.snapobserver.data.dao.*;
import com.ford.gvmsr.snapobserver.data.entity.*;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleStateRequest;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class PreviousSnapShotHandler {

    private static final Logger logger = LoggerFactory.getLogger(PreviousSnapShotHandler.class);

    @Autowired
    PreviousVehicleSnapShotDao previousVehicleSnapShotDao;

    @Value("${gvms.provision.nodes}")
    private String GVMS_PROVISION_NODES;

    @Value("#{'${application.dids}'.split(',')}")
    private Set<String> APPLICATION_DID_LIST;

    @Autowired
    ExceptionHandler exceptionHandler;

    public PreviousSnapShotDetails populatePreviousSnapDetails(ModuleStateRequest moduleStateRequest) {
        logger.debug("PreviousSnap:Start populatePreviousSnapDetails for VIN : "+moduleStateRequest.getModuleSnapshot().getVIN());
        long start = System.currentTimeMillis();
        String vin = moduleStateRequest.getModuleSnapshot().getVIN();
        List<String> nodeListFromRequest = new ArrayList<>();
        PreviousSnapShotDetails previousSnapShotDetails = new PreviousSnapShotDetails();
        moduleStateRequest.getModuleSnapshot().getNode().stream().forEach(nodeDetail -> {
            nodeListFromRequest.add(nodeDetail.getAddress());
        });
        Set<VehicleNodeSnapshot> prevVehicleNodeSnapshotList = previousVehicleSnapShotDao.fetchPreviousActiveVehicleNodeSnapshotForAllNode(vin, nodeListFromRequest);
        List<Long> vehicleNodeSnapshotKeyList = new ArrayList<>();
        Map<String, String> previousSnapRoleMap = new HashMap<>();
        Map<Long, String> previousSnapKeyRoleMap = new HashMap<>();
        Map<String, VehicleNodeSnapshot> previousVehicleNodeSnapshotMap = new HashMap<>();

        if (prevVehicleNodeSnapshotList != null && !prevVehicleNodeSnapshotList.isEmpty()) {
            for (VehicleNodeSnapshot vehicleNodeSnapshot : prevVehicleNodeSnapshotList) {
                vehicleNodeSnapshotKeyList.add(vehicleNodeSnapshot.getVehicleNodeSnapshotId().getVehicleNodeSnapshotKey());
                previousVehicleNodeSnapshotMap.put(vehicleNodeSnapshot.getNodeAddress(), vehicleNodeSnapshot);
                if (!previousSnapKeyRoleMap.containsKey(vehicleNodeSnapshot.getVehicleSnapshot().getVehicleSnapshotKey()))
                {
                    String previousSnapRole = previousVehicleSnapShotDao.getPreviousRole(
                            vehicleNodeSnapshot.getVehicleSnapshot().getVehicleSnapshotKey());
                    previousSnapKeyRoleMap.put(
                            vehicleNodeSnapshot.getVehicleSnapshot().getVehicleSnapshotKey(), previousSnapRole);
                    previousSnapRoleMap.put(vehicleNodeSnapshot.getNodeAddress(),previousSnapRole);
                } else {
                    previousSnapRoleMap.put(vehicleNodeSnapshot.getNodeAddress(),
                            previousSnapKeyRoleMap.get(vehicleNodeSnapshot.getVehicleSnapshot().getVehicleSnapshotKey()));
                }
            }
            previousSnapShotDetails.setPreviousSnapRoleMap(previousSnapRoleMap);
            previousSnapShotDetails.setPreviousVehicleNodeSnapshotMap(previousVehicleNodeSnapshotMap);
        }

        if (vehicleNodeSnapshotKeyList != null && !vehicleNodeSnapshotKeyList.isEmpty()) {

            Map<String, List<VehicleNodeDIDResponse>> previousActiveSnapshotMap = previousVehicleSnapShotDao.fetchPreviousActiveDidResponseForAllNode(vin, vehicleNodeSnapshotKeyList);
            previousSnapShotDetails.setPreviousActiveSnapshotMap(previousActiveSnapshotMap);

            Map<String, List<VehicleNodeConfig>> previousConfigDIDResponseMap = previousVehicleSnapShotDao.fetchPreviousActiveConfigDidResponseForAllNode(vin, vehicleNodeSnapshotKeyList);
            previousSnapShotDetails.setPreviousVehicleNodeConfigMap(previousConfigDIDResponseMap);
        }

        Map<String, String> paakProvisionMap = previousVehicleSnapShotDao.getProvisionFlagForAllNode(ApplicationUtils.getVinHash(vin),vin, GVMS_PROVISION_NODES);
        previousSnapShotDetails.setPaakProvisionMap(paakProvisionMap);

        Map<String, List<VehicleNodeDIDStatus>> preVehicleNodeDIDStatusIDForAllNodeMap = previousVehicleSnapShotDao.findAllVehicleNodeDIDStatusIDForAllNode(vin, ApplicationUtils.getVinHash(vin), "CI");
        previousSnapShotDetails.setPreVehicleNodeDIDStatusIDForAllNodeMap(preVehicleNodeDIDStatusIDForAllNodeMap);

        Map<String, VehicleNodeId> previousVehicleNodeIdMap = previousVehicleSnapShotDao.populateVehicleNodeIdMap(vin, ApplicationUtils.getVinHash(vin));
        previousSnapShotDetails.setPreviousVehicleNodeIdMap(previousVehicleNodeIdMap);

        String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
        logger.debug("PreviousSnap:Time taken - populatePreviousSnapDetails is::: {}", duration);
        return previousSnapShotDetails;
    }

    public PreviousSnapShotDetailsByNode getPreviousSnapShotDetailsForNode(String nodeAddress, PreviousSnapShotDetails previousSnapShotDetails){
        String prevNetworkName = null;
        String prevECUAcronym = null;
        PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode = new PreviousSnapShotDetailsByNode();
        Map<String, VehicleNodeDIDResponse> prevNonConfigDidResponseMap = new HashMap<>();
        Map<String, VehicleNodeDIDResponse> prevConfigDidTwoTabeResponseMap = new HashMap<>();
        Map<String, VehicleNodeConfig> prevConfigDidSixTabeResponseMap = new HashMap<>();
        List<String> previousAppList = new ArrayList<>();
        try {
            List<VehicleNodeDIDResponse> previousVehicleNodeDIDResponseList = previousSnapShotDetails.getPreviousActiveSnapshotMap().get(nodeAddress);
            VehicleNodeSnapshot preVehicleNodeSnapshot = previousSnapShotDetails.getPreviousVehicleNodeSnapshotMap().get(nodeAddress);
            List<VehicleNodeConfig> previousVehicleNodeConfigDidList = previousSnapShotDetails.getPreviousVehicleNodeConfigMap().get(nodeAddress);

            if (previousVehicleNodeDIDResponseList != null && !previousVehicleNodeDIDResponseList.isEmpty()) {
                for (VehicleNodeDIDResponse preVehicleNodeDIDResponse : previousVehicleNodeDIDResponseList) {
                    prevNetworkName = preVehicleNodeDIDResponse.getNetworkName();
                    prevECUAcronym = preVehicleNodeDIDResponse.getVehicleNodeSnapshot().getEcuAcronym();

                    if ("N".equalsIgnoreCase(preVehicleNodeDIDResponse.getIsConfig())) {
                        prevNonConfigDidResponseMap.put(preVehicleNodeDIDResponse.getDidCatalog(), preVehicleNodeDIDResponse);
                    }
                    if ("Y".equalsIgnoreCase(preVehicleNodeDIDResponse.getIsConfig())) {
                        prevConfigDidTwoTabeResponseMap.put(preVehicleNodeDIDResponse.getDidCatalog(), preVehicleNodeDIDResponse);
                    }
                    if(APPLICATION_DID_LIST.contains(preVehicleNodeDIDResponse.getDidCatalog())){
                        //Previous APP list
                        previousAppList.addAll(ApplicationUtils.getApplicationPartList(preVehicleNodeDIDResponse.getDidResponse()));
                    }
                }
            }
            if (previousVehicleNodeConfigDidList != null && !previousVehicleNodeDIDResponseList.isEmpty()) {
                for (VehicleNodeConfig vehicleNodeConfig : previousVehicleNodeConfigDidList) {
                    prevConfigDidSixTabeResponseMap.put(vehicleNodeConfig.getConfigurationDelimeterId(), vehicleNodeConfig);
                }
            }
            List<VehicleNodeDIDStatus> previousVehicleNodeStatusList = previousSnapShotDetails.getPreVehicleNodeDIDStatusIDForAllNodeMap().get(nodeAddress);

            previousSnapShotDetailsByNode.setPrevNonConfigDidResponseMap(prevNonConfigDidResponseMap);
            previousSnapShotDetailsByNode.setPrevConfigDidTwoTableResponseMap(prevConfigDidTwoTabeResponseMap);
            previousSnapShotDetailsByNode.setPrevConfigDidSixTableResponseMap(prevConfigDidSixTabeResponseMap);
            previousSnapShotDetailsByNode.setPrevVehicleNodeSnapshot(preVehicleNodeSnapshot);
            previousSnapShotDetailsByNode.setPreviousAppList(previousAppList);
            previousSnapShotDetailsByNode.setPrevEcuAcronym(prevECUAcronym);
            previousSnapShotDetailsByNode.setPrevNetworkName(prevNetworkName);
            String prevSnapRole = (previousSnapShotDetails.getPreviousSnapRoleMap() != null &&
                    previousSnapShotDetails.getPreviousSnapRoleMap().containsKey(nodeAddress)) ?
                    previousSnapShotDetails.getPreviousSnapRoleMap().get(nodeAddress): "";
            previousSnapShotDetailsByNode.setPreviousSnapRole(prevSnapRole);
            if(previousVehicleNodeStatusList != null)
                previousSnapShotDetailsByNode.setPreviousVehicleNodeStatusList(previousVehicleNodeStatusList);
        }catch (Exception ex){
            logger.error("Exception while setPreviousSnapShotDetailsForNode : "+ex.getMessage());
            exceptionHandler.logException(ex, this.getClass().getSimpleName());
            throw ex;
        }
        return previousSnapShotDetailsByNode;
    }
}
