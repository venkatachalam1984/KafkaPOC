package com.ford.gvmsr.snapobserver.data.entity.transaction;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table (name="PGVMT01_TXN")
public class Transaction extends BaseEntity {

    @Id
    @Column(name="GVMT01_TXN_D", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMT01_TXN_D_SQ_GEN")
    @SequenceGenerator(name = "PGVMT01_TXN_D_SQ_GEN", sequenceName = "PGVMT01_TXN_D_SQ", allocationSize = 1)
    private Long transactionId;

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    @ManyToOne
    @JoinColumn(name="GVMT02_TXN_STAT_C", referencedColumnName="GVMT02_TXN_STAT_C",insertable = true,updatable = true)
    private TransactionStatus transactionStatus;

    public String getMicroServiceName() {
        return microServiceName;
    }

    public void setMicroServiceName(String microServiceName) {
        this.microServiceName = microServiceName;
    }

    @ManyToOne
    @JoinColumn(name="GVMT08_TXN_TYPE_C", referencedColumnName="GVMT08_TXN_TYPE_C",insertable = true,updatable = true)
    private TransactionType transactionType;

    @Column(name="GVMT01_TXN_START_S")
    private Timestamp transactionStartTime;

    @Column(name="GVMT01_TXN_END_S")
    private Timestamp transactionEndTime;

    @Column(name="GVMT01_TRACE_D")
    private String traceId;

    @Column(name="GVMT01_TXN_DESC_X")
    private String transDesc;

    @Column(name="GVMT01_MIC_SVC_N")
    private String microServiceName;

    @Column(name = "GVMT01_RETRY_T")
    private int retryCount;

    @ManyToOne
    @JoinColumn (name="GVMT09_APPL_D", referencedColumnName="GVMT09_APPL_D",insertable = true,updatable = true )
    private Application applicationId;

    public TransactionStatus getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(TransactionStatus transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT01_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT01_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT01_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT01_LAST_UPDT_S"))}
    )


    private AuditColumns auditColumns = new AuditColumns();

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public Long getTransactionId() {
        return transactionId;
    }


    public Timestamp getTransactionStartTime() {
        return transactionStartTime;
    }

    public void setTransactionStartTime(Timestamp transactionStartTime) {
        this.transactionStartTime = transactionStartTime;
    }

    public Timestamp getTransactionEndTime() {
        return transactionEndTime;
    }

    public void setTransactionEndTime(Timestamp transactionEndTime) {
        this.transactionEndTime = transactionEndTime;
    }


    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getTransDesc() {
        return transDesc;
    }

    public void setTransDesc(String transDesc) {
        this.transDesc = transDesc;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public Application getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Application applicationId) {
        this.applicationId = applicationId;
    }
}
