package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VehicleSnapshotDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import com.ford.gvmsr.snapobserver.data.repository.VehicleSnapshotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehicleSnapshotDaoImpl implements VehicleSnapshotDao {

    @Autowired
    VehicleSnapshotRepository vehicleSnapshotRepository;

    @Override
    public VehicleSnapshot save(VehicleSnapshot vehicleSnapshot) {

        return vehicleSnapshotRepository.save(vehicleSnapshot);
    }

    @Override
    public String getPreviousRole(long snapShotKey) {
        return vehicleSnapshotRepository.getPreviousRole(snapShotKey);
    }
}
