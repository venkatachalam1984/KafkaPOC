
package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "node",
        "ecuAcronym",
        "DIDInfo"
})
public class VehicleNode {

    /**
     * The Node Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("node")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String node = "";
    /**
     * The Ecuacronym Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("ecuAcronym")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String ecuAcronym = "";

    @JsonProperty("specificationCategory")
    private String specificationCategory="";

    @JsonProperty("DIDInfo")
    private List<DIDInfo> dIDInfo = null;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * The Node Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("node")
    public String getNode() {
        return node;
    }

    /**
     * The Node Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("node")
    public void setNode(String node) {
        this.node = node;
    }

    /**
     * The Ecuacronym Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("ecuAcronym")
    public String getEcuAcronym() {
        return ecuAcronym;
    }

    /**
     * The Ecuacronym Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("ecuAcronym")
    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }


    @JsonProperty("DIDInfo")
    public List<DIDInfo> getDIDInfo() {
        return dIDInfo;
    }

    @JsonProperty("DIDInfo")
    public void setDIDInfo(List<DIDInfo> dIDInfo) {
        this.dIDInfo = dIDInfo;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String getSpecificationCategory() {
        return specificationCategory;
    }

    public void setSpecificationCategory(String specificationCategory) {
        this.specificationCategory = specificationCategory;
    }

}
