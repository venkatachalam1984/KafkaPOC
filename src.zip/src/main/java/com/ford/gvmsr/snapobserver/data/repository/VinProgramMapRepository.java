package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VINProgramMap;
import com.ford.gvmsr.snapobserver.data.entity.VINProgramMapId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VinProgramMapRepository extends JpaRepository<VINProgramMap, VINProgramMapId> {

    @Query(value = "SELECT * FROM PGVMS23_VIN_PROG_MAP WHERE REGEXP_LIKE(:vin, GVMS23_VIN_MAP_X)", nativeQuery = true)
    List<VINProgramMap> getVINMapExpressionByVIN(@Param("vin") String vin);
}
