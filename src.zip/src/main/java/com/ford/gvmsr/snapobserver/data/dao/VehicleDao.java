package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleId;

import java.util.Optional;

public interface VehicleDao {

    Optional<Vehicle> findOne(VehicleId vehicleId);

    Vehicle save(Vehicle vehicle);
}
