
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RoleENUMType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RoleENUMType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CONSUMER"/&gt;
 *     &lt;enumeration value="DEALER"/&gt;
 *     &lt;enumeration value="AFTERMARKET"/&gt;
 *     &lt;enumeration value="MODCENTER"/&gt;
 *     &lt;enumeration value="EOL"/&gt;
 *     &lt;enumeration value="ECATS"/&gt;
 *     &lt;enumeration value="VHR"/&gt;
 *     &lt;enumeration value="MFR"/&gt;
 *     &lt;enumeration value="ENGINEER"/&gt;
 *     &lt;enumeration value="PLANT TECHNICIAN"/&gt;
 *     &lt;enumeration value="TESTCONSUMER"/&gt;
 *     &lt;enumeration value="OTA"/&gt;
 *     &lt;enumeration value="TESTOTA"/&gt;
 *     &lt;enumeration value="ENGINEER TESTER"/&gt;
 *     &lt;enumeration value="SUPPLIER"/&gt;
 *     &lt;enumeration value="SUPPLIER TESTER"/&gt;
 *     &lt;enumeration value="FCS"/&gt;
 *     &lt;enumeration value="FDSP"/&gt;
 *     &lt;enumeration value="RVCM"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RoleENUMType")
@XmlEnum
public enum RoleENUMType {

    CONSUMER("CONSUMER"),
    DEALER("DEALER"),
    AFTERMARKET("AFTERMARKET"),
    MODCENTER("MODCENTER"),
    EOL("EOL"),
    ECATS("ECATS"),
    VHR("VHR"),
    MFR("MFR"),
    ENGINEER("ENGINEER"),
    @XmlEnumValue("PLANT TECHNICIAN")
    PLANT_TECHNICIAN("PLANT TECHNICIAN"),
    TESTCONSUMER("TESTCONSUMER"),
    OTA("OTA"),
    FORSE("FORSE"),
    TESTOTA("TESTOTA"),
    @XmlEnumValue("ENGINEER TESTER")
    ENGINEER_TESTER("ENGINEER TESTER"),
    SUPPLIER("SUPPLIER"),
    @XmlEnumValue("SUPPLIER TESTER")
    SUPPLIER_TESTER("SUPPLIER TESTER"),
    FCS("FCS"),
    FDSP("FDSP"),
    RVCM("RVCM");
    private final String value;

    RoleENUMType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RoleENUMType fromValue(String v) {
        for (RoleENUMType c: RoleENUMType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
