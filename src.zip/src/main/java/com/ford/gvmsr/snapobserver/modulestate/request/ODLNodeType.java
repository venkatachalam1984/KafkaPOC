
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * The Network Address (NodeID) of the Node
 * 
 * <p>Java class for ODLNodeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ODLNodeType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ECUAcronym" type="{urn:ford/Vehicle/Module/Information/v4.0}ODLECUType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Address" use="required" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeAddrType" /&gt;
 *       &lt;attribute ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkName"/&gt;
 *       &lt;attribute ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkProtocol"/&gt;
 *       &lt;attribute ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkDataRate"/&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ODLNodeType", propOrder = {
    "ecuAcronym"
})
public class ODLNodeType {

    @XmlElement(name = "ECUAcronym", required = true)
    protected List<ODLECUType> ecuAcronym;
    @XmlAttribute(name = "Address", required = true)
    protected String address;
    @XmlAttribute(name = "NetworkName", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
    protected String networkName;
    @XmlAttribute(name = "NetworkProtocol", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
    protected String networkProtocol;
    @XmlAttribute(name = "NetworkDataRate", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
    protected String networkDataRate;

    /**
     * Gets the value of the ecuAcronym property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ecuAcronym property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getECUAcronym().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ODLECUType }
     * 
     * 
     */
    public List<ODLECUType> getECUAcronym() {
        if (ecuAcronym == null) {
            ecuAcronym = new ArrayList<ODLECUType>();
        }
        return this.ecuAcronym;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Gets the value of the networkName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkName() {
        return networkName;
    }

    /**
     * Sets the value of the networkName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkName(String value) {
        this.networkName = value;
    }

    /**
     * Gets the value of the networkProtocol property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkProtocol() {
        return networkProtocol;
    }

    /**
     * Sets the value of the networkProtocol property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkProtocol(String value) {
        this.networkProtocol = value;
    }

    /**
     * Gets the value of the networkDataRate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkDataRate() {
        return networkDataRate;
    }

    /**
     * Sets the value of the networkDataRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkDataRate(String value) {
        this.networkDataRate = value;
    }

}
