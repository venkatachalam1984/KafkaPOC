package com.ford.gvmsr.snapobserver.redis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;


@Component
public class CacheKeyHelper {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    RedisRepository redisRepository;

    //Generate cache key for Snap inProgress vin and node
    public String generateSnapInProgressCacheKey(String vin, String nodeAddress){
        String generatedKey = null;
        try{
            generatedKey = String.format("SNAP:%s:%s", vin, nodeAddress);

            logger.debug("Generated Key :{}" +generatedKey);
        }
        catch (Exception e){
            logger.error("error generateSnapInProgressCacheKey in Redis :" +e.getMessage());
        }
        return generatedKey;
    }

    public void setSnapInProgressFlagInRedis(String cacheLookUpKey, String snapInProgressFlag){
        try {
            redisRepository.opsForString().setKey(cacheLookUpKey, snapInProgressFlag);
        }
        catch (Exception e){
            logger.error("error setting snapInProgressFlag in Redis :" +e.getMessage());
        }
    }

    public String getSnapInProgressFlagFromRedis(String cacheLookUpKey){
        String snapInProgressFlag =  null;
        try {
            if (!StringUtils.isEmpty(cacheLookUpKey)) {
                String redisVal = redisRepository.opsForString().getKey(cacheLookUpKey);
                snapInProgressFlag = StringUtils.isEmpty(redisVal) ? null : redisVal;
            }
        } catch (Exception ex) {
            logger.error("error to get snapInProgressFlag from Redis :" +ex.getMessage());
        }
        return  snapInProgressFlag;
    }

    /**
     * Method to save value in GVMS Redis
     *
     * @param key   - redis key
     * @param value - redis value
     * @return - true/false based on redis commit
     */
    public boolean insert(String key, String value) {
            return redisRepository.opsForString().setKey(key, value);
    }

    /**
     * Method to delete value in GVMS Redis
     *
     * @param key   - redis key
     * @return - true/false based on redis commit
     */

    public boolean delete(String key) {
        return redisRepository.opsForString().delKey(key);
    }

}
