package com.ford.gvmsr.snapobserver;

import com.ford.cloudnative.annotations.EnableFordSecurityTools;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import javax.annotation.PostConstruct;
import java.util.Properties;

@SpringBootApplication
@EnableFordSecurityTools
public class SnapObserverApplication {

	@Value("${kafka.server.env}")
	private String ENVIRONMENT ;

	public static void main(String[] args) {
		SpringApplication.run(SnapObserverApplication.class, args);
	}

	@PostConstruct
	public void deployKafka() {
		Properties sysprops = System.getProperties();
		if (ENVIRONMENT.equalsIgnoreCase("PROD")) {
			sysprops.setProperty("java.security.auth.login.config",
					"/home/vcap/app/BOOT-INF/classes/kafka_prod/jaas.conf");
			sysprops.setProperty("java.security.krb5.conf", "/home/vcap/app/BOOT-INF/classes/kafka_prod/krb5.conf");
		} else {
			/*sysprops.setProperty("java.security.auth.login.config", "/home/vcap/app/BOOT-INF/classes/kafka_qa/jaas_qa.conf");
			sysprops.setProperty("java.security.krb5.conf", "/home/vcap/app/BOOT-INF/classes/kafka_qa/krb5_qa.conf");
*/
			sysprops.setProperty("java.security.auth.login.config", "C:\\Users\\vmurug12\\gvmsr_kafka\\jaas_qa.conf");
			sysprops.setProperty("java.security.krb5.conf", "C:\\Users\\vmurug12\\gvmsr_kafka\\krb5_qa.conf");
		}
	}
}
