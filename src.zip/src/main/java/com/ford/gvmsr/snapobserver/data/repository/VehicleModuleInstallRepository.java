package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleModuleInstall;
import com.ford.gvmsr.snapobserver.data.entity.VehicleModuleInstallID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface VehicleModuleInstallRepository extends JpaRepository<VehicleModuleInstall, VehicleModuleInstallID> {

    @Query("SELECT vmi FROM VehicleModuleInstall vmi where vmi.vehicleModuleInstallID.vin = :vin and vmi.vehicleModuleInstallID.vinHashNumber = :vinHashNumber and vmi.vehicleModuleInstallID.nodeAddress = :node and vmi.moduleUnInstallTimeStamp is null")
    public abstract VehicleModuleInstall findByVinAndNode(@Param("vin") String vin, @Param("vinHashNumber") int vinHashNumber, @Param("node") String node);

    public List<VehicleModuleInstall> findAllByVehicleModuleInstallID_NodeAddressAndVehicleModuleInstallID_EserialnoAndModuleUnInstallTimeStampIsNull(String node, String esn);

}

