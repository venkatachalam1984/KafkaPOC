package com.ford.gvmsr.snapobserver.creator.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.constants.SnapConstants;
import com.ford.gvmsr.snapobserver.creator.DidCreator;
import com.ford.gvmsr.snapobserver.creator.NodeCreator;
import com.ford.gvmsr.snapobserver.data.entity.*;
import com.ford.gvmsr.snapobserver.dto.NodeStatus;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.enums.SnapStatus;
import com.ford.gvmsr.snapobserver.handler.SnapshotSaveHandler;
import com.ford.gvmsr.snapobserver.logevent.LogEventMonitor;
import com.ford.gvmsr.snapobserver.logevent.LogType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.monitor.SnapshotChangeInfo;
import com.ford.gvmsr.snapobserver.modulestate.monitor.SnapshotNodeMonitor;
import com.ford.gvmsr.snapobserver.modulestate.request.*;
import com.ford.gvmsr.snapobserver.redis.CacheKeyHelper;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import com.ford.gvmsr.snapobserver.validator.SnapValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Service
public class NodeCreationHandler implements NodeCreator {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    SnapshotSaveHandler snapshotSaveHandler;

    @Autowired
    LogEventMonitor logEventMonitor;

    @Autowired
    DidCreator didCreator;

    @Autowired
    SnapValidator snapValidator;

    @Autowired
    CacheKeyHelper redisCache;

    @Value("${vil.retry.flag}")
    private boolean vilRetryFlag;

    @Override
    public Map<String, NodeStatus> persistNode(Vehicle vehicle, VehicleSnapshot vehicleSnapshot, ModuleSnapshotObserverRequest moduleSnapshotObserverRequest) {
        LOGGER.info("NodeCreation:Start persistNode : " + moduleSnapshotObserverRequest.getVin());
        long start = System.currentTimeMillis();
        ModuleSnapshotType moduleSnapshotType = moduleSnapshotObserverRequest.getModuleSnapshotType();
        Map<String, NodeStatus> nodeStatusMap = new HashMap<>();
        try {
            for (ModuleNodeType moduleNodeType : moduleSnapshotType.getNode()) {
                //check snap is in progress for the VIN - Node
                boolean isSnapInProgress = snapValidator.checkAnySnapIsInProgressForVin(moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress());
                if (!isSnapInProgress) {
                    SnapshotNodeMonitor snapshotNodeMonitor = moduleSnapshotObserverRequest.getSnapshotChangeMonitor().getSnapshotNodeMonitor(moduleNodeType);
                    if (snapshotNodeMonitor.isNodeChanged()) {
                        if (vilRetryFlag && null != moduleSnapshotObserverRequest.
                                getSnapshotObserverRequest().getRequestType() && moduleSnapshotObserverRequest.
                                getSnapshotObserverRequest().getRequestType().equalsIgnoreCase(SnapConstants.REQ_TYPE_RETRY)) {
                            boolean isRetryNodeLatest = validateRetryNodeTimeStamp(moduleSnapshotObserverRequest, moduleNodeType);
                            if (isRetryNodeLatest) {
                                LOGGER.info("NodeCreation:Persisting Node =[{}] for VIN =[{}]", moduleNodeType.getAddress(), moduleSnapshotType.getVIN());
                                NodeStatus persistNodeStatus = persistNode(vehicle, vehicleSnapshot, moduleNodeType, moduleSnapshotObserverRequest);
                                nodeStatusMap.put(moduleNodeType.getAddress(), persistNodeStatus);
                            } else {
                                LOGGER.debug(moduleNodeType.getAddress() + " : Retry SNAP is OLD for this Node ");
                                NodeStatus nodeStatus = updateNodeStatus(moduleSnapshotObserverRequest,
                                        moduleNodeType, SnapStatus.SNAP_OLD.getCode(), start);
                                nodeStatusMap.put(moduleNodeType.getAddress(), nodeStatus);
                            }
                        } else {
                            LOGGER.info("NodeCreation:Persisting Node =[{}] for VIN =[{}]", moduleNodeType.getAddress(), moduleSnapshotType.getVIN());
                            NodeStatus persistNodeStatus = persistNode(vehicle, vehicleSnapshot, moduleNodeType, moduleSnapshotObserverRequest);
                            nodeStatusMap.put(moduleNodeType.getAddress(), persistNodeStatus);
                        }
                    } else {
                        LOGGER.debug(moduleNodeType.getAddress() + " : Node is Duplicate or Invalid ");

                        String statusCode = getStatusCoode(snapshotNodeMonitor.getSnapshotChangeInfo());
                        NodeStatus nodeStatus = updateNodeStatus(moduleSnapshotObserverRequest,
                                moduleNodeType, statusCode, start);
                        nodeStatusMap.put(moduleNodeType.getAddress(), nodeStatus);
                    }
                } else {
                    LOGGER.debug(moduleNodeType.getAddress() + " : Node is InProgress for Previous VIN");
                    NodeStatus nodeStatus = updateNodeStatus(moduleSnapshotObserverRequest,
                            moduleNodeType, SnapStatus.SNAP_INPROG.getCode(), start);
                    nodeStatusMap.put(moduleNodeType.getAddress(), nodeStatus);
                }
            }
            if (nodeStatusMap.entrySet().stream().anyMatch(nodeStatusEntry ->
                    nodeStatusEntry.getValue().getCode().equalsIgnoreCase(SnapStatus.SUCCESS.getCode()))) {
                //34 table has to persist for VIL request after snap success
                VehicleSnapshotVil vehicleSnapshotVil =
                        populateVehicleSnapShotVil(moduleSnapshotObserverRequest, vehicleSnapshot);
                if (vehicleSnapshotVil != null) {
                    snapshotSaveHandler.saveVehicleSnapShotVil(vehicleSnapshotVil);
                }
                //storing vil receiver redis value into GVMS redis after snap success
                insertRedisValueInGVMS(moduleSnapshotObserverRequest);
            }
        } catch (Exception ex) {
            LOGGER.error("NodeCreation:Exception in persistNode :" + ex.getMessage());
            String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
            logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value(), moduleSnapshotObserverRequest.getVin(), null, moduleSnapshotObserverRequest.getTraceId(),
                    LogType.FATAL, SnapStatus.SNAP_PROC_ERR.getCode(), duration, CommonUtils.getEventTimeStamp(), ex.getMessage());
        }
        LOGGER.info("NodeCreation:End persistNode : " + moduleSnapshotObserverRequest.getVin());
        return nodeStatusMap;
    }

    private String getStatusCoode(SnapshotChangeInfo snapshotChangeInfo) {
        if(snapshotChangeInfo.isSnapskipDidChanged()) {
            return SnapStatus.SNAP_I.getCode();
        } else {
            return SnapStatus.DUPLICATE.getCode();
        }
    }

    private NodeStatus persistNode(Vehicle vehicle, VehicleSnapshot vehicleSnapshot, ModuleNodeType moduleNodeType, ModuleSnapshotObserverRequest moduleSnapshotObserverRequest) {
        LOGGER.info("NodeCreation:Entering persistNode for VIN=[{}], Node=[{}]", moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress());
        long start = System.currentTimeMillis();
        NodeStatus nodeStatus = new NodeStatus();
        try {
            Map<String, VehicleNodeId> previousVehicleNodeIdMap = moduleSnapshotObserverRequest.getPreviousSnapShotDetails().getPreviousVehicleNodeIdMap();
            //15 Table entry
            if (CollectionUtils.isEmpty(previousVehicleNodeIdMap) || !previousVehicleNodeIdMap.containsKey(moduleNodeType.getAddress())) {
                VehicleNode vehicleNode = populateVehicleNode(vehicle, moduleNodeType, moduleSnapshotObserverRequest.getRoleSource());
                snapshotSaveHandler.saveVehicleNode(vehicleNode);
                LOGGER.info("NodeCreation:VehicleNode for VIN =[{}] Node=[{}] Saved Successfully ", vehicle.getVehicleId().getVin(), moduleNodeType.getAddress());
            }
            // 04 Table entry
            nodeStatus = persistNodeDetails(vehicle, vehicleSnapshot, moduleNodeType, moduleSnapshotObserverRequest, start);
        } catch (Exception e) {
            LOGGER.error("NodeCreation:Exception while persisting node e={}", e);
            String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
            logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value(), moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress(), moduleSnapshotObserverRequest.getTraceId(),
                    LogType.FATAL, SnapStatus.FAILURE.getCode(), duration, CommonUtils.getEventTimeStamp(), e.getMessage());
            nodeStatus.setCode(SnapStatus.FAILURE.getCode());
            nodeStatus.setMessage(e.getMessage());
        }
        LOGGER.info("NodeCreation:Leaving persistNode for VIN=[{}], Node=[{}]", moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress());
        return nodeStatus;
    }

    private NodeStatus persistNodeDetails(Vehicle vehicle, VehicleSnapshot vehicleSnapshot, ModuleNodeType moduleNodeType, ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, long start) throws SQLException {
        NodeStatus nodeStatus = new NodeStatus();
        VehicleNodeSnapshot vehicleNodeSnapshot = null;
        VehicleNodeSnapshot preVehicleNodeSnapshot = null;
        try {
            //deactivate all existing vehicle node snapshot
            snapshotSaveHandler.deactivateAllExistingVehicleNodeSnapshots(vehicle.getVehicleId().getVinHashNumber(), vehicle.getVehicleId().getVin(), moduleNodeType.getAddress());
            LOGGER.info("NodeCreation:Deactivated All Existing Vehicle Node Snapshots for VIN =[{}] Node=[{}] Saved Successfully ", vehicle.getVehicleId().getVin(), moduleNodeType.getAddress());

            //will get previousVehicleNodeSnapshot for to activate if any exception in current snap creation.
            PreviousSnapShotDetails previousSnapShotDetails = moduleSnapshotObserverRequest.getPreviousSnapShotDetails();
            if (null != previousSnapShotDetails && previousSnapShotDetails.getPreviousVehicleNodeSnapshotMap() != null) {
                preVehicleNodeSnapshot = previousSnapShotDetails.getPreviousVehicleNodeSnapshotMap().get(moduleNodeType.getAddress());
            }

            vehicleNodeSnapshot = populateVehicleNodeSnapshot(moduleNodeType, vehicleSnapshot, vehicle, moduleSnapshotObserverRequest);
            vehicleNodeSnapshot = snapshotSaveHandler.saveVehicleNodeSnapshot(vehicleNodeSnapshot);
            LOGGER.info("NodeCreation:VehicleNodeSnapshot for VIN=[{}] Node =[{}] Saved  Successfully", moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress());

            didCreator.persistDid(moduleSnapshotObserverRequest, vehicleNodeSnapshot);

            nodeStatus.setCode(SnapStatus.SUCCESS.getCode());

            //deleting the isSnapInProgress key from Redis after snap success
            snapValidator.deleteSnapInProgressKeyFromRedis(moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress());

            String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
            logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRoleSourceString(), moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress(), moduleSnapshotObserverRequest.getTraceId(),
                    LogType.INFO, SnapStatus.SUCCESS.getCode(), duration, CommonUtils.getEventTimeStamp(), null);

        } catch (Exception e) {
            LOGGER.error("NodeCreation:Exception while persisting node e={}", e);

            //update current active node to de-activate
            if(vehicleNodeSnapshot != null && vehicleNodeSnapshot.getVehicleNodeSnapshotId() != null &&
                    vehicleNodeSnapshot.getVehicleNodeSnapshotId().getVehicleNodeSnapshotKey() != null) {
                snapshotSaveHandler.updateVehicleNodeSnapshot(GVMSModuleUpdateConstants.STATUS_DELETED,
                        vehicleNodeSnapshot.getVehicleNodeSnapshotId().getVehicleNodeSnapshotKey(),
                        vehicleNodeSnapshot.getVehicleNodeSnapshotId().getVinHashNumber());
            }
            //update previous de-active node to activate again
            if(preVehicleNodeSnapshot != null) {
                snapshotSaveHandler.updateVehicleNodeSnapshot(GVMSModuleUpdateConstants.STATUS_ACTIVE,
                        preVehicleNodeSnapshot.getVehicleNodeSnapshotId().getVehicleNodeSnapshotKey(),
                        preVehicleNodeSnapshot.getVehicleNodeSnapshotId().getVinHashNumber());
            }

            String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
            logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRoleSourceString(), moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress(), moduleSnapshotObserverRequest.getTraceId(),
                    LogType.FATAL, SnapStatus.FAILURE.getCode(), duration, CommonUtils.getEventTimeStamp(), e.getMessage());
            nodeStatus.setCode(SnapStatus.FAILURE.getCode());
            nodeStatus.setMessage(e.getMessage());
        }
        return nodeStatus;
    }


    private VehicleNode populateVehicleNode(Vehicle vehicle, ModuleNodeType moduleNodeType, RoleSourceENUMType roleSourceENUMType) {
        LOGGER.info("NodeCreation:Entering  saveVehicleId VehicleNode for VIN =[{}] Node=[{}] Saved Successfully ", vehicle.getVehicleId().getVin(), moduleNodeType.getAddress());
        VehicleNodeId vehicleNodeKey = new VehicleNodeId();
        VehicleId vehicleId = new VehicleId(vehicle.getVehicleId().getVin(), vehicle.getVehicleId().getVinHashNumber());
        vehicleNodeKey.setVehicleId(vehicleId);
        vehicleNodeKey.setNodeAddress(moduleNodeType.getAddress());
        VehicleNode vehicleNode = new VehicleNode();
        vehicleNode.setVehicleNodeId(vehicleNodeKey);
        vehicleNode.setVehicle(vehicle);
        vehicleNode.setSourceSystem(roleSourceENUMType.value());
        return vehicleNode;
    }

    private VehicleNodeSnapshot populateVehicleNodeSnapshot(ModuleNodeType moduleNodeType, VehicleSnapshot vehicleSnapshot, Vehicle vehicle,
                                                            ModuleSnapshotObserverRequest moduleSnapshotObserverRequest)  {
        LOGGER.info("NodeCreation:Entering saveVehicleNodeSnapshot for VIN=[{}] Node =[{}]", moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress());
        AdditionalProperties additionalProperties = moduleSnapshotObserverRequest.getAdditionalProperties(moduleNodeType.getAddress());
        VehicleNodeSnapshot vehicleNodeSnapshot = new VehicleNodeSnapshot();

        VehicleNodeSnapshotId vehicleNodeSnapshotId = new VehicleNodeSnapshotId();
        vehicleNodeSnapshotId.setVinHashNumber(vehicle.getVehicleId().getVinHashNumber());
        vehicleNodeSnapshotId.setVehicleNodeSnapshotKey(vehicleSnapshot.getVehicleSnapshotKey());
        vehicleNodeSnapshot.setVehicleNodeSnapshotId(vehicleNodeSnapshotId);
        vehicleNodeSnapshot.setNodeAddress(moduleNodeType.getAddress());
        vehicleNodeSnapshot.setVin(vehicle.getVehicleId().getVin());
        vehicleNodeSnapshot.setRoleEventCode(moduleSnapshotObserverRequest.getRequestRole().getRoleEvent());
        vehicleNodeSnapshot.setVscsVersionDesc(additionalProperties.getVscsVersionDesc());
        vehicleNodeSnapshot.setVscsVersionDate(additionalProperties.getVscsVersionDate());
        vehicleNodeSnapshot.setActiveFlag("A");
        vehicleNodeSnapshot.setNodeTimeStamp(moduleSnapshotObserverRequest.getVinRecordedTimestamp());

        if (additionalProperties != null && !StringUtils.isEmpty(additionalProperties.getOdlNetworkDetailsForNode().getEcuAcronym())) {
            vehicleNodeSnapshot.setEcuAcronym(additionalProperties.getOdlNetworkDetailsForNode().getEcuAcronym());
        }else{
            vehicleNodeSnapshot.setEcuAcronym(moduleNodeType.getECUAcronym().get(0).getName());
        }
        NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap = moduleSnapshotObserverRequest.getNodeAndDIDResponseForNewSnapMap().
                get(moduleNodeType.getAddress());

        if (nodeAndDIDResponseForNewSnap != null && nodeAndDIDResponseForNewSnap.getPaakProvisionMap().containsKey(moduleNodeType.getAddress())) {
            vehicleNodeSnapshot.setIsProvisionedFlag(nodeAndDIDResponseForNewSnap.getPaakProvisionMap().get(moduleNodeType.getAddress()));
        }else{
            vehicleNodeSnapshot.setIsProvisionedFlag("N");
        }
        if (additionalProperties.getDerivedAssemblyResponseForNode() != null && !StringUtils.isEmpty(additionalProperties.getDerivedAssemblyResponseForNode().getPartNumberForDA())) {
            vehicleNodeSnapshot.setFordPartNumber(CommonUtils.getFordPartNumberId(additionalProperties.getDerivedAssemblyResponseForNode().getPartNumberForDA()));
        }
        vehicleNodeSnapshot.setVehicleSnapshot(vehicleSnapshot);
        return vehicleNodeSnapshot;
    }

    private void insertRedisValueInGVMS(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest){
        Map<String, String> redisValueMap = moduleSnapshotObserverRequest.getSnapshotObserverRequest().getRedisValue();
        if(redisValueMap != null) {
            redisValueMap.entrySet().stream().forEach(redisValue -> {
                redisCache.insert(redisValue.getKey(), redisValue.getValue());
            });
        }
    }

    private VehicleSnapshotVil populateVehicleSnapShotVil(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest,
                                                          VehicleSnapshot vehicleSnapshot){
        if(ApplicationUtils.checkIsVil(moduleSnapshotObserverRequest)) {
            String vilContent = null;
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                vilContent = objectMapper.writeValueAsString(moduleSnapshotObserverRequest.getSnapshotObserverRequest().getVilHeader());
            } catch (JsonProcessingException e) {
                LOGGER.error("NodeCreation:Json Exception while processing VilHeader into json : " + e.getMessage());
            }
            VehicleSnapshotVil vehicleSnapshotVil = new VehicleSnapshotVil();
            VehicleSnapshotId vehicleSnapshotId = new VehicleSnapshotId();
            vehicleSnapshotId.setVinHashNumber(ApplicationUtils.getVinHash(moduleSnapshotObserverRequest.getVin()));
            vehicleSnapshotId.setVehicleSnapshotKey(vehicleSnapshot.getVehicleSnapshotKey());
            vehicleSnapshotVil.setVehicleSnapshotId(vehicleSnapshotId);
            vehicleSnapshotVil.setVilContent(vilContent);
            return vehicleSnapshotVil;
        }
        return null;
    }

    private boolean validateRetryNodeTimeStamp(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, ModuleNodeType moduleNodeType){
        VehicleNodeSnapshot preVehicleNodeSnapshot = moduleSnapshotObserverRequest.
                getPreviousSnapShotDetails().getPreviousVehicleNodeSnapshotMap().get(moduleNodeType.getAddress());
        SnapshotObserverRequest snapshotObserverRequest = moduleSnapshotObserverRequest.getSnapshotObserverRequest();
        if (null != preVehicleNodeSnapshot && snapshotObserverRequest.getVilProcessedTime() != null) {
            long prevSnapTime = preVehicleNodeSnapshot.getNodeTimeStamp().getTime();
            long vilProcessTimeFromRequest = snapshotObserverRequest.getVilProcessedTime().getTime();
            LOGGER.debug("NodeCreation:validateRetryNodeTimeStamp : prevSnapTime = {}, vilProcessTimeFromRequest = {}",
                    prevSnapTime, vilProcessTimeFromRequest);
            if(prevSnapTime > vilProcessTimeFromRequest)
                return false;
        }
        return true;
    }

    private NodeStatus updateNodeStatus(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest,
                                        ModuleNodeType moduleNodeType, String nodeStatusCode, long startTime){
        NodeStatus nodeStatus = new NodeStatus();
        nodeStatus.setCode(nodeStatusCode);
        String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - startTime);
        logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value(), moduleSnapshotObserverRequest.getVin(), moduleNodeType.getAddress(), moduleSnapshotObserverRequest.getTraceId(),
                LogType.INFO, nodeStatusCode, duration, CommonUtils.getEventTimeStamp(), null);
        return nodeStatus;
    }

}
