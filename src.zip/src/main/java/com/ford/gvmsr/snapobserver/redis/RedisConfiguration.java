package com.ford.gvmsr.snapobserver.redis;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.common.RedisServiceInfo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;


@Configuration
public class RedisConfiguration {

    /*@Value("${redis.instance.name}")
    private String INSTANCE_NAME;

    @Bean
    public RedisConnectionFactory redisConnectionFactory() {
        CloudFactory cloudFactory = new CloudFactory();
        Cloud cloud = cloudFactory.getCloud();
        RedisServiceInfo serviceInfo = (RedisServiceInfo) cloud.getServiceInfo(INSTANCE_NAME);
        String serviceId = serviceInfo.getId();
        return cloud.getServiceConnector(serviceId, RedisConnectionFactory.class, null);
    }

    @Bean(name = "strRedisTemplate")
    RedisTemplate<String, String> strRedisTemplate() {
        RedisTemplate<String, String> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory());
        redisTemplate.setDefaultSerializer(new StringRedisSerializer());
        return redisTemplate;
    }*/

    @Value("${redis.cache.host}")
    public String HOST;

    @Value("${redis.cache.password}")
    public String PASSWORD;

    @Value("${redis.cache.port}")
    private int PORT;

    @Primary
    @Bean
    JedisConnectionFactory jedisConnectionFactory() {
        JedisConnectionFactory redis = new JedisConnectionFactory();
        redis.setHostName(HOST);
        redis.setPassword(PASSWORD);
        redis.setPort(PORT);
        redis.setTimeout(500);
        //redis.setUsePool(true);
        return redis;
    }

    @Bean(name = "strRedisTemplate")
    RedisTemplate<String, String> strRedisTemplate() {
        RedisTemplate<String, String> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(jedisConnectionFactory());
        redisTemplate.setDefaultSerializer(new StringRedisSerializer());
        return redisTemplate;
    }
}

