package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by MDEVARA3 on 8/29/2017.
 */
@Embeddable
public class IVSProgramId implements Serializable{

    @Column(name = "GVM008_PROGRAM_C")
    private String programCode;

    @Column(name = "GVM008_SALES_MODEL_YEAR_C")
    private Float salesModelYear;

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public Float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(Float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }
}
