package com.ford.gvmsr.snapobserver.constants;

public class SnapConstants {

    public static final String INVALID_INPUT = "INVALID INPUT :";
    public static final String SNP_TRKG_MSG ="SNP_TRK_M";
    public static final String SNP_VIN_TRKG_MSG ="SNP_VIN_TRKG_M";
    public static final String SYNC_TRKG_MSG ="SYNC_TRK_M";
    public static final String CONSUMER_TRKG_MSG ="consumer";

    public static final String OTA = "OTA";
    public static final String CONSUMER = "CONSUMER";
    public static final String VIL_SOURCE_DES = "FENIX";
    public static final String SUCCESS = "SUCCESS";
    public static final String SNAP_OBSERVER = "SNAP_OBSERVER";

    public static final String REQ_TYPE_NEW = "NEW";
    public static final String REQ_TYPE_RETRY = "RETRY";

}
