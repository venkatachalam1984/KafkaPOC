package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.sql.Timestamp;

@Entity
@Table(name = "PGVMS28_GA_GL_VEH_INFO_CACHE")
public class GAGLVehicleInfoCache {

    @EmbeddedId
    private GAGLVehicleInfoCacheId gaglVehicleInfoCacheId;

    @Column(name = "GVMS10_VIN_R")
    private String vin;

    @Column(name = "GVM023_NODE_ADRS_C")
    private String nodeAddress;

    @Column(name = "GVMS28_INFO_TYPE_C")
    private String infoType;

    @Column(name = "GVMS28_CACHE_KEY_X")
    private String cacheKey;

    @Column(name = "GVMS28_INFO_BLOB_L")
    private byte[] infoBlob;

    @Column(name = "GVMS28_ACTIVE_F")
    private String createdUser;

    @Column(name = "GVMS28_CREATE_USER_C")
    private Timestamp createdTimestamp;

    @Column(name = "GVMS28_CREATE_S")
    private String isActive;

    @Column(name = "GVM010_IVS_XML_INFO_K")
    private long ivsXmlInfoKey;

    public GAGLVehicleInfoCacheId getGaglVehicleInfoCacheId() {
        return gaglVehicleInfoCacheId;
    }

    public void setGaglVehicleInfoCacheId(GAGLVehicleInfoCacheId gaglVehicleInfoCacheId) {
        this.gaglVehicleInfoCacheId = gaglVehicleInfoCacheId;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getInfoType() {
        return infoType;
    }

    public void setInfoType(String infoType) {
        this.infoType = infoType;
    }

    public String getCacheKey() {
        return cacheKey;
    }

    public void setCacheKey(String cacheKey) {
        this.cacheKey = cacheKey;
    }

    public byte[] getInfoBlob() {
        return infoBlob;
    }

    public void setInfoBlob(byte[] infoBlob) {
        this.infoBlob = infoBlob;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Timestamp getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(Timestamp createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public long getIvsXmlInfoKey() {
        return ivsXmlInfoKey;
    }

    public void setIvsXmlInfoKey(long ivsXmlInfoKey) {
        this.ivsXmlInfoKey = ivsXmlInfoKey;
    }
}
