package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDSoftware;

import java.util.List;

public interface VehicleNodeDIDSoftwareDao {
    VehicleNodeDIDSoftware save(VehicleNodeDIDSoftware vehicleNodeDIDSoftware);
    List<VehicleNodeDIDSoftware> saveAll(List<VehicleNodeDIDSoftware> vehicleNodeDIDSoftwareList);
}
