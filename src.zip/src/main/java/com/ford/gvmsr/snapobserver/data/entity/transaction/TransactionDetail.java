package com.ford.gvmsr.snapobserver.data.entity.transaction;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table (name="PGVMT03_TXN_DTL")
public class TransactionDetail extends BaseEntity {

    @Id
    @Column (name="GVMT03_TXN_DTL_D")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMT03_TXN_DTL_D_SQ_GEN")
    @SequenceGenerator(name="PGVMT03_TXN_DTL_D_SQ_GEN", sequenceName = "PGVMT03_TXN_DTL_D_SQ", allocationSize = 1)
    private Long  transactionDetailId;

    @ManyToOne
    @JoinColumn (name="GVMT02_TXN_STAT_C", referencedColumnName="GVMT02_TXN_STAT_C",insertable = true,updatable = true )
    private TransactionStatus transactionStatus;

    @ManyToOne
    @JoinColumn (name="GVMT01_TXN_D", referencedColumnName="GVMT01_TXN_D",insertable = true,updatable = false )
    private Transaction transactionId;


    @Column (name="GVMT03_VIN_R")
    private String vin;

    @Column(name="GVMT03_VIN_HASH_R")
    private Integer vinHash;

/*
    @ManyToOne
    @JoinColumn (name="GVMT09_APPL_D", referencedColumnName="GVMT09_APPL_D",insertable = true,updatable = true )
    private Application applicationId;
*/


    @Column(name="GVMT03_TXN_DTL_S")
    private Timestamp transactionTime;

    @Column(name="GVMT03_EXTL_SYS_TXN_D")
    private String externalTransactionId;

    @Column(name="GVMT03_ESN_R")
    private String esn;

    @Column(name="GVMT03_NODE_ADRS_C")
    private String nodeAddress;

    @Column(name="GVMT03_ECU_ACRONYM_C")
    private String ecuAcronym;

    @Column (name="GVMT03_SRC_SYS_C")
    private String sourceSystem;

    @Column(name = "GVM008_PROGRAM_C")
    private String programCode;

    @Column(name = "GVM008_SALES_MODEL_YEAR_C")
    private Float salesModelYear;

    @Column(name = "GVMT03_TXN_DTL_DESC_X")
    private String transactoindetaildescription;

    @Column(name = "GVMT03_RETRY_T")
    private int retryCount;

  /*  public Application getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Application applicationId) {
        this.applicationId = applicationId;
    }*/

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT03_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT03_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT03_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT03_LAST_UPDT_S"))}
    )


    private AuditColumns auditColumns = new AuditColumns();


    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public Long  getTransactionDetailId() {
        return transactionDetailId;
    }

    public void setTransactionDetailId(Long  transactionDetailId) {
        this.transactionDetailId = transactionDetailId;
    }


    public TransactionStatus getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(TransactionStatus transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public Transaction getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Transaction transactionId) {
        this.transactionId = transactionId;
    }

    public Timestamp getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(Timestamp transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getExternalTransactionId() {
        return externalTransactionId;
    }

    public void setExternalTransactionId(String externalTransactionId) { this.externalTransactionId = externalTransactionId;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public Float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(Float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public String getTransactoindetaildescription() {
        return transactoindetaildescription;
    }

    public void setTransactoindetaildescription(String transactoindetaildescription) {
        this.transactoindetaildescription = transactoindetaildescription;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public Integer getVinHash() {
        return vinHash;
    }

    public void setVinHash(Integer vinHash) {
        this.vinHash = vinHash;
    }
}
