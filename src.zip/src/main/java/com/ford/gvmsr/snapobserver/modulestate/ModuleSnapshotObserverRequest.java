package com.ford.gvmsr.snapobserver.modulestate;

import com.ford.gvmsr.snapobserver.modulestate.request.*;

import java.util.List;

public class ModuleSnapshotObserverRequest extends ModuleSnapshotObserverAdditionalInfo {

    private SnapshotObserverRequest snapshotObserverRequest;

    public ModuleSnapshotObserverRequest(SnapshotObserverRequest snapshotObserverRequest) {
        super(snapshotObserverRequest);
        this.snapshotObserverRequest = snapshotObserverRequest;
    }

    public SnapshotObserverRequest getSnapshotObserverRequest() {
        return snapshotObserverRequest;
    }

    public void setSnapshotObserverRequest(SnapshotObserverRequest snapshotObserverRequest) {
        this.snapshotObserverRequest = snapshotObserverRequest;
    }

    public ModuleSnapshotType getModuleSnapshotType() {

        return snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot();
    }

    public ModuleStateRequest getModuleStateRequest() {

        return snapshotObserverRequest.getModuleStateRequest();
    }

    public String getVin() {

        return snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getVIN();
    }

    public String getTraceId() {

        return snapshotObserverRequest.getModuleStateRequest().getTraceID();
    }

    public StateUpdateRoleType getRequestRole() {

        return snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getRequestRole();
    }

    public List<ModuleNodeType> getModuleNodeTypes() {

        return snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getNode();
    }

    public AdditionalProperties getAdditionalProperties(String nodeAddress) {
        AdditionalProperties additionalProperties = null;
        if (snapshotObserverRequest.getAdditionalPropertiesMap().containsKey(nodeAddress)) {
            additionalProperties = snapshotObserverRequest.getAdditionalPropertiesMap().get(nodeAddress);
        }
        return additionalProperties;
    }

    public String getRoleSourceString() {
        return this.snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getRequestRole().getRoleSource().value();
    }

    public RoleSourceENUMType getRoleSource() {
        return this.snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getRequestRole().getRoleSource();
    }


}
