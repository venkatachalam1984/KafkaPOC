package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import java.io.Serializable;

/**
 * Created by MDEVARA3 on 8/30/2017.
 */

public class FordPartNumberId implements Serializable {

    @Column(name = "GVM022_PART_PREFIX_R")
    private String fordPartNumberPrefix;
    @Column(name = "GVM022_PART_BASE_R")
    private String fordPartNumberBase;
    @Column(name = "GVM022_PART_SUFFIX_R")
    private String fordPartNumberSuffix;

    public String getFordPartNumberPrefix() {
        return fordPartNumberPrefix;
    }

    public void setFordPartNumberPrefix(String fordPartNumberPrefix) {
        this.fordPartNumberPrefix = fordPartNumberPrefix;
    }

    public String getFordPartNumberBase() {
        return fordPartNumberBase;
    }

    public void setFordPartNumberBase(String fordPartNumberBase) {
        this.fordPartNumberBase = fordPartNumberBase;
    }

    public String getFordPartNumberSuffix() {
        return fordPartNumberSuffix;
    }

    public void setFordPartNumberSuffix(String fordPartNumberSuffix) {
        this.fordPartNumberSuffix = fordPartNumberSuffix;
    }

    @Override
    public String toString() {
        return fordPartNumberPrefix + "-" + fordPartNumberBase + "-" + fordPartNumberSuffix;
    }
}
