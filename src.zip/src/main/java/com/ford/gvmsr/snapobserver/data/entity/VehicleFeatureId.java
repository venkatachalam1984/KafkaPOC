package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by MDEVARA3 on 8/31/2017.
 */
@Embeddable
public class VehicleFeatureId  implements Serializable {

    private VehicleId vehicleId;

    @Column(name = "GVMS16_EFF_IN_S")
    private Timestamp effInTimestamp;

    @ManyToOne
    @JoinColumn(name = "GVMS17_FTR_FAM_K",referencedColumnName = "GVMS17_FTR_FAM_K")
    private WersFeature wersFeature;


    public VehicleId getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(VehicleId vehicleId) {
        this.vehicleId = vehicleId;
    }

    public Timestamp getEffInTimestamp() {
        return effInTimestamp;
    }

    public void setEffInTimestamp(Timestamp effInTimestamp) {
        this.effInTimestamp = effInTimestamp;
    }

    public WersFeature getWersFeature() {
        return wersFeature;
    }

    public void setWersFeature(WersFeature wersFeature) {
        this.wersFeature = wersFeature;
    }
}
