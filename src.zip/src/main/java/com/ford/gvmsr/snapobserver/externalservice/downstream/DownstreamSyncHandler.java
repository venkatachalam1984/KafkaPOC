package com.ford.gvmsr.snapobserver.externalservice.downstream;


import com.ford.gvmsr.snapobserver.data.entity.VehicleId;
import com.ford.gvmsr.snapobserver.dto.NodeStatus;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;

import java.sql.Timestamp;
import java.util.Map;

public interface DownstreamSyncHandler {
    void sendToDownstreamSystems(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, Map<String, NodeStatus> nodeStatusMap, long transactionId, long transactionDetailId, Timestamp vinRecordedTimestamp, VehicleId vehicleId);
}
