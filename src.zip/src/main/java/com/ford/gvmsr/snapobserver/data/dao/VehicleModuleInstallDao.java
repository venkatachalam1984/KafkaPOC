package com.ford.gvmsr.snapobserver.data.dao;

import java.sql.Timestamp;
import java.util.Map;

public interface VehicleModuleInstallDao {
    Map<Boolean, String> saveVehicleModuleInstall(String vin, int vinHashNumber, String nodeAddress, String eSerialno, String ecuAcronym, Timestamp moduleInstallTimeStamp);
}
