package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="PGVMS35_VEH_MSG_PRCS_TEMP")
public class VehicleVilData extends BaseEntity {

    @Id
    @Column(name="GVMS35_VEH_MSG_PRCS_K", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMS35_VEH_MSG_PRCS_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS35_VEH_MSG_PRCS_K_SQ_GEN", sequenceName = "PGVMS35_VEH_MSG_PRCS_K_SQ", allocationSize = 1)
    private Long vehicleMessageProcessingKey;

    public Long getVehicleMessageProcessingKey() {
        return vehicleMessageProcessingKey;
    }

    public void setVehicleMessageProcessingKey(Long vehicleMessageProcessingKey) {
        this.vehicleMessageProcessingKey = vehicleMessageProcessingKey;
    }

    @Column(name = "GVMS36_PAYLOAD_MSG_K")
    private String payLoadMessageProcessingKey;

    public String getPayLoadMessageProcessingKey() {
        return payLoadMessageProcessingKey;
    }

    public void setPayLoadMessageProcessingKey(String payLoadMessageProcessingKey) {
        this.payLoadMessageProcessingKey = payLoadMessageProcessingKey;
    }

    @Column(name = "GVMS35_MSG_TYPE_C")
    private String messageTypeCode;

    public String getMessageTypeCode() {
        return messageTypeCode;
    }

    public void setMessageTypeCode(String messageTypeCode) {
        this.messageTypeCode = messageTypeCode;
    }

    @Column(name = "GVMS35_MSG_CAPTURE_S")
    private Timestamp messageCaptureTimeStamp ;

    public Timestamp getMessageCaptureTimeStamp() {
        return messageCaptureTimeStamp;
    }

    public void setMessageCaptureTimeStamp(Timestamp messageCaptureTimeStamp) {
        this.messageCaptureTimeStamp = messageCaptureTimeStamp;
    }

    @Column(name = "GVMS35_ESN_R")
    private String esn;

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    @Column(name = "GVMS35_VIN_R")
    private String vin;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    @Lob
    @Column(name = "GVMS35_MSG_L")
    private String messageLog;
    public String getMessageLog() {
        return messageLog;
    }

    public void setMessageLog(String messageLog) {
        this.messageLog = messageLog;
    }

    @Column(name = "GVMS35_PRCS_STAT_C")
    private  String processingStateCode;

    public String getProcessingStateCode() {
        return processingStateCode;
    }

    public void setProcessingStateCode(String processingStateCode) {
        this.processingStateCode = processingStateCode;
    }

    @Column(name = "GVMS35_PRCS_STAT_S")
    private Timestamp processingStatusTimeStamp ;

    public Timestamp getProcessingStatusTimeStamp() {
        return processingStatusTimeStamp;
    }

    public void setProcessingStatusTimeStamp(Timestamp processingStatusTimeStamp) {
        this.processingStatusTimeStamp = processingStatusTimeStamp;
    }

    @Column(name = "GVMS35_TRACE_D")
    private String traceId;

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }


    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS35_CREATE_USER_C", updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS35_CREATE_S", updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS35_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS35_LAST_UPDT_S")),
    }
    )
    private AuditColumns auditColumns = new AuditColumns();

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }

}