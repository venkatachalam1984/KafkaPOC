package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.List;


public class FPNRequest {

    private List<String> fpnList;

    public List<String> getFpnList() {
        return fpnList;
    }

    public void setFpnList(List<String> fpnList) {
        this.fpnList = fpnList;
    }
}
