package com.ford.gvmsr.snapobserver.externalservice.request;

/**
 * Created by MDEVARA3 on 8/30/2017.
 *
 * A catalog of DID as provided by IVS. It is a unique address assigned to all modules for reporting a specific value programed within module.
 Data Source: GIVIS:NMGM056_DID_CATLG
 */

public class DIDCatalog {

    private String didId;

    private String sourceSystem;

    private int responseLength;

    private String didType;

    private String didFormat;

    private String isConfig;

    private String isVehicleSpecificFlag;

    private String isPrivateNetworkFlag;

    public String getDidId() {
        return didId;
    }

    public void setDidId(String didId) {
        this.didId = didId;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public int getResponseLength() {
        return responseLength;
    }

    public void setResponseLength(int responseLength) {
        this.responseLength = responseLength;
    }

    public String getDidType() {
        return didType;
    }

    public void setDidType(String didType) {
        this.didType = didType;
    }

    public String getDidFormat() {
        return didFormat;
    }

    public void setDidFormat(String didFormat) {
        this.didFormat = didFormat;
    }

    public String getIsConfig() {
        return isConfig;
    }

    public void setIsConfig(String isConfig) {
        this.isConfig = isConfig;
    }

    public String getIsVehicleSpecificFlag() {
        return isVehicleSpecificFlag;
    }

    public void setIsVehicleSpecificFlag(String isVehicleSpecificFlag) {
        this.isVehicleSpecificFlag = isVehicleSpecificFlag;
    }

    public String getIsPrivateNetworkFlag() {
        return isPrivateNetworkFlag;
    }

    public void setIsPrivateNetworkFlag(String isPrivateNetworkFlag) {
        this.isPrivateNetworkFlag = isPrivateNetworkFlag;
    }
}
