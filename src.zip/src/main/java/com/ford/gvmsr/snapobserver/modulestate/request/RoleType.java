
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RoleType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RoleType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CONSUMER"/&gt;
 *     &lt;enumeration value="DEALER"/&gt;
 *     &lt;enumeration value="AFTERMARKET"/&gt;
 *     &lt;enumeration value="MODCENTER"/&gt;
 *     &lt;enumeration value="ENGINEER"/&gt;
 *     &lt;enumeration value="TESTCONSUMER"/&gt;
 *     &lt;enumeration value="OTA"/&gt;
 *     &lt;enumeration value="TESTOTA"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RoleType", namespace = "urn:ford/productdesign/vis/common/v1.0")
@XmlEnum
public enum RoleType {

    CONSUMER,
    DEALER,
    AFTERMARKET,
    MODCENTER,
    ENGINEER,
    TESTCONSUMER,
    OTA,
    TESTOTA;

    public String value() {
        return name();
    }

    public static RoleType fromValue(String v) {
        return valueOf(v);
    }

}
