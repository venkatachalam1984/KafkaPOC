package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by MDEVARA3 on 8/29/2017.
 */
@Embeddable
public class VINProgramMapId implements Serializable{

    private IVSProgramId ivsProgramId;

    @Column(name = "GVMS23_PROG_MAP_CNTR_T")
    private int programMapCounter;

    public IVSProgramId getIvsProgramId() {
        return ivsProgramId;
    }

    public void setIvsProgramId(IVSProgramId ivsProgramId) {
        this.ivsProgramId = ivsProgramId;
    }

    public int getProgramMapCounter() {
        return programMapCounter;
    }

    public void setProgramMapCounter(int programMapCounter) {
        this.programMapCounter = programMapCounter;
    }
}
