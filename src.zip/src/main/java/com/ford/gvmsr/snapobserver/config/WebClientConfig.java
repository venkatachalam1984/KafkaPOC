package com.ford.gvmsr.snapobserver.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class WebClientConfig {

    //For accessing endpoints using oauth
    @Bean(name = "oauthRestTemplate")
    RestTemplate oauthRestTemplate() {
        return new RestTemplate();
    }

    //For accessing endpoints via service registry using oauth
    @Bean(name = "oauthServiceRegistryRestTemplate")
    @LoadBalanced
    RestTemplate oauthServiceRegistryRestTemplate() {
        return new RestTemplate();
    }
}
