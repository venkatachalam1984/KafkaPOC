package com.ford.gvmsr.snapobserver.dto;

import com.ford.gvmsr.snapobserver.data.entity.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PreviousSnapShotDetails {

    private IVSProgramId ivsProgramId;
    private String ivsXmlInfoKey;
    private Integer partitionKey;
    private String didSpecificationCategory;
    private Map<String, String> previousSnapRoleMap;
    private List<VehicleNodeDIDResponse> prevVehicleNodeDIDResponseList = new ArrayList<>();
    private Map<String, List<VehicleNodeConfig>> previousVehicleNodeConfigMap = new HashMap<>();
    private Timestamp vinRecordedTimestamp;
    private Map<String, List<VehicleNodeDIDResponse>> previousActiveSnapshotMap = new HashMap<>();
    private Map<String, VehicleNodeSnapshot> previousVehicleNodeSnapshotMap = new HashMap<>();
    private Map<String, String> paakProvisionMap = new HashMap<>();
    private Map<String, List<VehicleNodeDIDStatus>> preVehicleNodeDIDStatusIDForAllNodeMap = new HashMap<>();
    private Map<String, VehicleNodeId> previousVehicleNodeIdMap = new HashMap<>();

    public IVSProgramId getIvsProgramId() {
        return ivsProgramId;
    }

    public void setIvsProgramId(IVSProgramId ivsProgramId) {
        this.ivsProgramId = ivsProgramId;
    }

    public String getIvsXmlInfoKey() {
        return ivsXmlInfoKey;
    }

    public void setIvsXmlInfoKey(String ivsXmlInfoKey) {
        this.ivsXmlInfoKey = ivsXmlInfoKey;
    }

    public Integer getPartitionKey() {
        return partitionKey;
    }

    public void setPartitionKey(Integer partitionKey) {
        this.partitionKey = partitionKey;
    }

    public String getDidSpecificationCategory() {
        return didSpecificationCategory;
    }

    public void setDidSpecificationCategory(String didSpecificationCategory) {
        this.didSpecificationCategory = didSpecificationCategory;
    }

    public List<VehicleNodeDIDResponse> getPrevVehicleNodeDIDResponseList() {
        return prevVehicleNodeDIDResponseList;
    }

    public void setPrevVehicleNodeDIDResponseList(List<VehicleNodeDIDResponse> prevVehicleNodeDIDResponseList) {
        this.prevVehicleNodeDIDResponseList = prevVehicleNodeDIDResponseList;
    }

    public Map<String, List<VehicleNodeConfig>> getPreviousVehicleNodeConfigMap() {
        return previousVehicleNodeConfigMap;
    }

    public void setPreviousVehicleNodeConfigMap(Map<String, List<VehicleNodeConfig>> previousVehicleNodeConfigMap) {
        this.previousVehicleNodeConfigMap = previousVehicleNodeConfigMap;
    }

    public Timestamp getVinRecordedTimestamp() {
        return vinRecordedTimestamp;
    }

    public void setVinRecordedTimestamp(Timestamp vinRecordedTimestamp) {
        this.vinRecordedTimestamp = vinRecordedTimestamp;
    }

    public Map<String, List<VehicleNodeDIDResponse>> getPreviousActiveSnapshotMap() {
        return previousActiveSnapshotMap;
    }

    public void setPreviousActiveSnapshotMap(Map<String, List<VehicleNodeDIDResponse>> previousActiveSnapshotMap) {
        this.previousActiveSnapshotMap = previousActiveSnapshotMap;
    }

    public Map<String, VehicleNodeSnapshot> getPreviousVehicleNodeSnapshotMap() {
        return previousVehicleNodeSnapshotMap;
    }

    public void setPreviousVehicleNodeSnapshotMap(Map<String, VehicleNodeSnapshot> previousVehicleNodeSnapshotMap) {
        this.previousVehicleNodeSnapshotMap = previousVehicleNodeSnapshotMap;
    }

    public Map<String, String> getPreviousSnapRoleMap() {
        return previousSnapRoleMap;
    }

    public void setPreviousSnapRoleMap(Map<String, String> previousSnapRoleMap) {
        this.previousSnapRoleMap = previousSnapRoleMap;
    }

    public Map<String, String> getPaakProvisionMap() {
        return paakProvisionMap;
    }

    public void setPaakProvisionMap(Map<String, String> paakProvisionMap) {
        this.paakProvisionMap = paakProvisionMap;
    }

    public Map<String, List<VehicleNodeDIDStatus>> getPreVehicleNodeDIDStatusIDForAllNodeMap() {
        return preVehicleNodeDIDStatusIDForAllNodeMap;
    }

    public void setPreVehicleNodeDIDStatusIDForAllNodeMap(Map<String, List<VehicleNodeDIDStatus>> preVehicleNodeDIDStatusIDForAllNodeMap) {
        this.preVehicleNodeDIDStatusIDForAllNodeMap = preVehicleNodeDIDStatusIDForAllNodeMap;
    }

    public Map<String, VehicleNodeId> getPreviousVehicleNodeIdMap() {
        return previousVehicleNodeIdMap;
    }

    public void setPreviousVehicleNodeIdMap(Map<String, VehicleNodeId> previousVehicleNodeIdMap) {
        this.previousVehicleNodeIdMap = previousVehicleNodeIdMap;
    }
}
