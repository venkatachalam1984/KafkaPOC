package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class VehicleNodeConfigId implements Serializable{

    /*@EmbeddedId
    private VehicleNodeDIDResponseId vehicleNodeDIDResponseId;*/

    @Column(name="GVMS02_VEH_NODE_DID_RSPNS_K")
    private Long vehicleNodeDidReponseKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    @Column(name = "GVMS06_CFG_DELINEATOR_C")
    private String configurationDelimeterId;

    /*public VehicleNodeConfigId(VehicleNodeDIDResponseId vehicleNodeDIDResponseId, String configurationDelimeterId){

        this.vehicleNodeDIDResponseId = vehicleNodeDIDResponseId;
        this.configurationDelimeterId = configurationDelimeterId;
    }*/

    public VehicleNodeConfigId(){}

   /* public VehicleNodeDIDResponseId getVehicleNodeDIDResponseId() {
        return this.vehicleNodeDIDResponseId;
    }

    public void setVehicleNodeDIDResponseId(VehicleNodeDIDResponseId vehicleNodeDIDResponseId) {
        this.vehicleNodeDIDResponseId = vehicleNodeDIDResponseId;
    }*/

    public String getConfigurationDelimeterId() {
        return this.configurationDelimeterId;
    }

    public void setConfigurationDelimeterId(String configurationDelimeterId) {
        this.configurationDelimeterId = configurationDelimeterId;
    }

    public Long getVehicleNodeDidReponseKey() {
        return this.vehicleNodeDidReponseKey;
    }

    public void setVehicleNodeDidReponseKey(Long vehicleNodeDidReponseKey) {
        this.vehicleNodeDidReponseKey = vehicleNodeDidReponseKey;
    }

    public int getVinHashNumber() {
        return this.vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }
}
