package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.AdditionalProperties;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class EcuAcronymCheckRule {

    private static final Logger logger = LoggerFactory.getLogger(EcuAcronymCheckRule.class);

    public void validateECUAcronym(ModuleSnapshotObserverRequest snapshotObserverRequest,
                                   PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode,
                                   ModuleNodeType node) {
        logger.debug("Inside validateECUAcronym for Request ECUAcronym = {}", node.getECUAcronym().get(0).getName());
        String prevEcuAcronym = previousSnapShotDetailsByNode.getPrevEcuAcronym();
        String newEcuACronym = null;
        if (ApplicationUtils.checkIsVil(snapshotObserverRequest)) {
            AdditionalProperties additionalProperties = snapshotObserverRequest.getAdditionalProperties(node.getAddress());
            if (additionalProperties != null && !StringUtils.isEmpty(additionalProperties.getOdlNetworkDetailsForNode().getEcuAcronym())) {
                newEcuACronym = additionalProperties.getOdlNetworkDetailsForNode().getEcuAcronym();
            }
        } else {
            newEcuACronym = node.getECUAcronym().get(0).getName();
        }
        if (prevEcuAcronym == null && (newEcuACronym != null && !newEcuACronym.isBlank())) {
            snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.NODE, TrackingType.ECU_ACRONYM, true);
        } else if ((newEcuACronym != null && !newEcuACronym.isBlank()) && !prevEcuAcronym.equalsIgnoreCase(newEcuACronym)) {
            snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.NODE, TrackingType.ECU_ACRONYM, true);
        }

    }

}
