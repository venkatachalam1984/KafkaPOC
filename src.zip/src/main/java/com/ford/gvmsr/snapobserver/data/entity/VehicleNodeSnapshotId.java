package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by MDEVARA3 on 8/31/2017.
 */
@Embeddable
public class VehicleNodeSnapshotId implements Serializable{


    @Column(name = "GVMS04_VEH_NODE_SNPSHT_K")
    /*@SequenceGenerator(name = "PGVMS04_VEH_NODE_SNPSHT_K_SQ_GEN", sequenceName = "PGVMS04_VEH_NODE_SNPSHT_K_SQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMS04_VEH_NODE_SNPSHT_K_SQ_GEN")*/
    private Long vehicleNodeSnapshotKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    public Long getVehicleNodeSnapshotKey() {
        return vehicleNodeSnapshotKey;
    }

    public void setVehicleNodeSnapshotKey(Long vehicleNodeSnapshotKey) {
        this.vehicleNodeSnapshotKey = vehicleNodeSnapshotKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }
}
