package com.ford.gvmsr.snapobserver.constants;

public interface ConfigDidConstants {

    String FORCE = "FORCE";
    String Role_Id = "CFG-GPH001";
    String RELOAD_DIDCATALOGMAP = "RELOAD_DIDCATALOGMAP" ;
    String CONFIGUPDATEREQUEST_SERVICE = "CFG_SERVICE";
    String PREFNV2_CONFIGUPD_SERVICE = "CFGR_SERVICE";
    String CONFIGUPDATEREQUEST_TO_AL = "CFG_TO_AL";
    String CFG_PROCESS_STARTED = "PROCESS STARTED";
    String CFG_PROCESS_V_FOUND = "VEHICLE_PGM_FOUND";
    String CFG_PROCESS_V_NOT_FOUND = "VEHICLE_PGM_NOT_FOUND";
    String CFG_PROCESS_PRV_SNAP_FOUND = "PRV_SNAP_FOUND";
    String CFG_PROCESS_ODL_NW_FOUND = "ODL_SPEC_NW_FOUND";
    String CFG_PROCESS_ODL_NW_NOT_FOUND = "ODL_SPEC_NW_NOT_FOUND";
    String NODE_ODL_SPEC_NW_NOT_FOUND = "NODE_ODL_SPEC_NW_NOT_FOUND";
    String NODE_ODL_SPEC_NW_FOUND = "NODE_ODL_SPEC_NW_FOUND";
    String CFG_PROCESS_PRV_SNAP_NOT_FOUND = "PRV_SNAP_NOT_FOUND";
    String CONFIG_DID = "CFG";
    String CMPLT = "CMPLT";
    String ERROR = "ERROR";
    String NO_SNAP = "NO_SNAP";
    String RECEIVED = "RECEIVED";
    String PRV_SNAP_FOUND = "PRV_SNAP_FOUND";
    String PRV_SNAP_NOT_FOUND = "PRV_SNAP_NOT_FOUND";
    String PRV_SNAP_NO_CFG_DID_FOUND = "PRV_SNAP_NO_CFG_DID_FOUND";
    String CF_TO_AL_REQ_PREPARED = "CF_TO_AL_REQ_PREPARED";
    String REQ_CFG_U_DID_RSP_EMPTY = "REQ_CFG_U_DID_RSP_EMPTY";
    String REQ_CFG_N_DID_RSP_EMPTY = "REQ_CFG_N_DID_RSP_EMPTY";
    String CFG_TRACE_ID_TAG = "traceId";
    String CFG_CALLBACK_TAG = "callback";
    String CFG_INDEX_TAG = "index";
    String REQ_CFG_U_DID_RSP_DUPLICATE = "REQ_CFG_U_DID_RSP_DUPLICATE";

    //HEC Splunk changes
    //Source
    String CFG_TRKG_M = "CFG_TRKG_M";
    String CFG_SNAP_TRKG_M = "CFG_SNAP_TRKG_M";
    String CFG_SYNC_TRKG_M = "CFG_SYNC_TRKG_M";

    //Event status level
    String CFG_RECEIVED_S = "CFG_RECEIVED_S";
    String CFG_RECEIVED_F = "CFG_RECEIVED_F";
    String CFG_TO_AL_S = "CFG_TO_AL_S";
    String CFG_TO_AL_F = "CFG_TO_AL_F";
    String CFG_NO_ODL_NW ="CFG_NO_ODL_NW";
    String CFG_NO_PRV_SNP ="CFG_NO_PRV_SNP";
    String CFG_NO_VEH_PGM ="CFG_NO_VEH_PGM";
    String CFG_DUP_SNP ="CFG_DUP_SNP";
    String CFG_VIN_CREATION_ERROR="CFG_VIN_ERROR";

    String CFG_A011 = "CFG_A011";
    String CFG_SNAP_S = "CFG_SNAP_S";
    String CFG_SNAP_F = "CFG_SNAP_F";
    String CFG_VSS_SYNC_S = "CFG_VSS_SYNC_S";
    String CFG_VSS_SYNC_F = "CFG_VSS_SYNC_F";
    String CFG_GVS_SUCCESS="CFG_GIVIS_SYNC_S";
    String CFG_GVS_FAILED="CFG_GIVIS_SYNC_F";
    String CFG_NODE_DUP="CFG_DUP_NODE";
    String CFG_SNP_DUP="CFG_DUP_SNAP";
    String CFG_NODE_START="CFG_NODE_START";
    String CFG_NO_PRV_NC_DID ="CFG_NO_PRV_NC_DID";

    String CFG_RUNTIME_ERROR="CFG_RUNTIME_ERR";

    String CFG_START="CFG_START";
    String CFG_END="CFG_END";

    //sourceType
    String CFG_CONTROLLER = "CFG_CONT";
    String CFG_FACADE = "CFG_FAC";
    String CFG_SYNC_PROC = "CFG_PROC";
    String CFG_SNAP_PROC = "CFG_SNAP_PROC";
    String CFG_TO_AL_REQ = "CFG_TO_AL_REQ";
    String CFG_SNAP_PROC_ERROR ="CFG_SNAP_PROC_ERROR";

    String CFG_ALERT_SYNC_CB = "cfgUpdateSync";

}
