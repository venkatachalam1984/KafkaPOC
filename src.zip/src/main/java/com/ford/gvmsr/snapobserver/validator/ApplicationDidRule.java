package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.helper.SnapCreationHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ApplicationDidRule {
    private static final Logger logger = LoggerFactory.getLogger(ICCIDDidRule.class);

    @Autowired
    SnapCreationHelper snapCreationHelper;

    public void populateDidEntity(PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode, DIDInfoType did,
                                  NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap, ModuleNodeType node, ModuleSnapshotObserverRequest snapshotObserverRequest, List<String> newApplicationList) {
        VehicleNodeDIDResponse vehicleNodeDIDResponse = new VehicleNodeDIDResponse();

        //validate did response and compare prevAppln did response
        String didResponse = validateApplnDidRule(did, newApplicationList);
        vehicleNodeDIDResponse.setDidResponse(didResponse);

        // populate the vehicleNodeDIDResponse for persistence
        snapCreationHelper.populateVehicleNodeDIDResponse(vehicleNodeDIDResponse, did, node, snapshotObserverRequest, previousSnapShotDetailsByNode);
        nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList().add(vehicleNodeDIDResponse);
    }

    private String validateApplnDidRule(DIDInfoType did,
                                        List<String> newApplicationList) {
        String didResponse = ApplicationUtils.toUpperCase(did.getResponse());
        newApplicationList.addAll(ApplicationUtils.getApplicationPartList(didResponse));
        return didResponse;
    }

    public boolean isApplicationDidChanged(List<String> newApplicationList, List<String> prevApplicationList){
        boolean isApplicationDidChanged = false;
        if (!newApplicationList.isEmpty() && !prevApplicationList.isEmpty()) {
            if ((newApplicationList.size() == prevApplicationList.size()) && newApplicationList.containsAll(prevApplicationList)) {
                isApplicationDidChanged = false;
            }else{
                isApplicationDidChanged = true;
            }
        }else if(!newApplicationList.isEmpty() && prevApplicationList.isEmpty()){
            isApplicationDidChanged = true;
        }
        return isApplicationDidChanged;
    }

    public boolean isVehicleProfileTrigger(List<String> newApplicationList, List<String> prevApplicationList){
        return (!prevApplicationList.isEmpty() && newApplicationList.isEmpty());
    }
}
