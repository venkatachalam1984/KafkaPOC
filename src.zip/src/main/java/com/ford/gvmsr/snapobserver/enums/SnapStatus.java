package com.ford.gvmsr.snapobserver.enums;

public enum SnapStatus {

    SUCCESS("SNAP_S"),
    FAILURE("SNAP_F"),
    DUPLICATE("SNAP_D"),
    CREATE_SNAP("SNAP_CREATE"),
    SNAP_INPROG("SNAP_INPROG"),
    SYNC_SENT_S("SYNC_SENT_S"),
    SYNC_SENT_F("SYNC_SENT_F"),
    FACADE_ERR("FACADE_E"),
    SNAP_PROC_ERR("SNAP_PROC_E"),
    DUPLICATE_SNAP("DUP_SNAP"),
    SNAP_I("SNAP_I"),
    SNAP_OLD("SNAP_O");
    private String code;

    SnapStatus(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }

    @Override
    public String toString() {
        return "SnapStatus{" +
                "code='" + code + '\'' +
                '}';
    }
}
