package com.ford.gvmsr.snapobserver.externalservice.response;

import java.util.List;

public class FASNodeDetailResponseList {

    private List<FASNodeDetailResponse> fasNodeDetailResponseList;

    public List<FASNodeDetailResponse> getFasNodeDetailResponseList() {
        return fasNodeDetailResponseList;
    }

    public void setFasNodeDetailResponseList(List<FASNodeDetailResponse> fasNodeDetailResponseList) {
        this.fasNodeDetailResponseList = fasNodeDetailResponseList;
    }
}
