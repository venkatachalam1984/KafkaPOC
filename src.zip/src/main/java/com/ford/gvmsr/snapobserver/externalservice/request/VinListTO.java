
package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "vinList"
})
public class VinListTO{

    @JsonProperty("vinList")
    private VinPropertiesListTO vinList = null;

    @JsonProperty("messageProperties")
    private MessageProperties messageProperties = null;

    @JsonProperty("vinList")
    public VinPropertiesListTO getvinList() {
        return vinList;
    }

    @JsonProperty("vinList")
    public void setvinList(VinPropertiesListTO vinList) {
        this.vinList = vinList;
    }

    @JsonProperty("messageProperties")
    public MessageProperties getMessageProperties() {
        return messageProperties;
    }

    @JsonProperty("messageProperties")
    public void setMessageProperties(MessageProperties messageProperties) {
        this.messageProperties = messageProperties;
    }

  }
