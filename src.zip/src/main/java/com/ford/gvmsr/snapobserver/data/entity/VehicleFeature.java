package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by VYUVARA6 on 8/30/2017.
 */

@Entity
@Table(name = "PGVMS16_VEH_FTR")
public class VehicleFeature extends BaseEntity {

    @EmbeddedId
    private VehicleFeatureId vehicleFeatureId;

    @ManyToOne
    @JoinColumn(name = "GVMS17_FTR_FAM_K",referencedColumnName = "GVMS17_FTR_FAM_K", insertable = false, updatable = false)
    private WersFeature wersFeature;

    @ManyToOne
    @JoinColumn(name = "GVMS18_ROLE_K",referencedColumnName = "GVMS18_ROLE_K")
    private VehFeatureUpdateSourceList vehFeatureUpdateSourceList;

    @Column(name = "GVMS16_EFF_OUT_S")
    private Timestamp effOutTimestamp;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS16_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS16_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS16_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS16_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();


    public VehicleFeatureId getVehicleFeatureId() {
        return vehicleFeatureId;
    }

    public void setVehicleFeatureId(VehicleFeatureId vehicleFeatureId) {
        this.vehicleFeatureId = vehicleFeatureId;
    }

    public VehFeatureUpdateSourceList getVehFeatureUpdateSourceList() {
        return vehFeatureUpdateSourceList;
    }

    public void setVehFeatureUpdateSourceList(VehFeatureUpdateSourceList vehFeatureUpdateSourceList) {
        this.vehFeatureUpdateSourceList = vehFeatureUpdateSourceList;
    }

    public Timestamp getEffOutTimestamp() {
        return effOutTimestamp;
    }

    public void setEffOutTimestamp(Timestamp effOutTimestamp) {
        this.effOutTimestamp = effOutTimestamp;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public WersFeature getWersFeature() {
        return wersFeature;
    }

    public void setWersFeature(WersFeature wersFeature) {
        this.wersFeature = wersFeature;
    }
}
