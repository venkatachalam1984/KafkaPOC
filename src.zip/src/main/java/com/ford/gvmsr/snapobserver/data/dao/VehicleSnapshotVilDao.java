package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshotVil;

public interface VehicleSnapshotVilDao {
    VehicleSnapshotVil save(VehicleSnapshotVil vehicleSnapshotVil);
}
