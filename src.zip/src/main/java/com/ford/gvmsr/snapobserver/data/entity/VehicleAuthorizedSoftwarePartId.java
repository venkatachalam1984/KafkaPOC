package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by VYUVARA6 on 8/30/2017.
 */
@Embeddable
public class VehicleAuthorizedSoftwarePartId implements Serializable{

    private VehicleId vehicleId;

    @Column(name = "GVM022_PART_PREFIX_R")
    private String  partPrefix;

    @Column(name = "GVM022_PART_BASE_R")
    private String  partBase;

    @Column(name = "GVM022_PART_SUFFIX_R")
    private String  partSuffix;

    public String getPartPrefix() {
        return partPrefix;
    }

    public void setPartPrefix(String partPrefix) {
        this.partPrefix = partPrefix;
    }

    public String getPartBase() {
        return partBase;
    }

    public void setPartBase(String partBase) {
        this.partBase = partBase;
    }

    public String getPartSuffix() {
        return partSuffix;
    }

    public void setPartSuffix(String partSuffix) {
        this.partSuffix = partSuffix;
    }

    public VehicleId getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(VehicleId vehicleId) {
        this.vehicleId = vehicleId;
    }
}
