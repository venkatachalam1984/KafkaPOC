package com.ford.gvmsr.snapobserver.data.entity;

import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MJAFARUL on 11/13/2017.
 */
@Entity
@Table(name = "PGVMS22_VEH_NODE_DID_CMPLNC")
public class VehicleNodeDIDCompliance extends BaseEntity {

    @EmbeddedId
    private VehicleNodeDIDComplianceId complianceId;

    @Column(name = "GVMS22_CMPLNC_RSPNS_N")
    private String complicanceResponse;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS22_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS22_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS22_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS22_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();


    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public VehicleNodeDIDComplianceId getComplianceId() {
        return complianceId;
    }

    public void setComplianceId(VehicleNodeDIDComplianceId complianceId) {
        this.complianceId = complianceId;
    }

    public String getComplicanceResponse() {
        return complicanceResponse;
    }

    public void setComplicanceResponse(String complicanceResponse) {
        this.complicanceResponse = complicanceResponse;
    }
}
