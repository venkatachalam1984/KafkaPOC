package com.ford.gvmsr.snapobserver.data.entity;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/29/2017.
 *
 * A reference table used to store plant information to support selection list - Data Source: GIVIS:NMGM068_PLANT
 */
@Entity
@Table(name = "PGVMS11_PLANT")
public class Plant extends BaseEntity {

    @Id
    @Column(name = "GVMS11_PLANT_C")
    private String plantCode;

    @Column(name = "GVMS11_PLANT_N")
    private String plantName;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS11_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS11_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS11_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS11_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

}
