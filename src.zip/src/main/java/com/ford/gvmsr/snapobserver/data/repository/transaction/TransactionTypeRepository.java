package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.TransactionType;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;

public interface TransactionTypeRepository extends CrudRepository<TransactionType, Serializable> {
}
