package com.ford.gvmsr.snapobserver.validator.impl;

import com.ford.gvmsr.snapobserver.redis.CacheKeyHelper;
import com.ford.gvmsr.snapobserver.validator.SnapValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SnapValidatorImpl implements SnapValidator {

    private static final Logger logger = LoggerFactory.getLogger(SnapValidatorImpl.class);

    @Autowired
    private CacheKeyHelper redisCache;

    @Value("${redis.cache.enabled}")
    private boolean isCacheEnabled;

    @Override
    public Boolean checkAnySnapIsInProgressForVin(String vin, String nodeAddress) {
        long start = System.currentTimeMillis();
        boolean isSnapProgress = false;
        try {
            if (isCacheEnabled && nodeAddress != null) {

                    String key = redisCache.generateSnapInProgressCacheKey(vin, nodeAddress);
                    String snapInProgressFlagFromRedis = redisCache.getSnapInProgressFlagFromRedis(key);
                    if (snapInProgressFlagFromRedis != null && snapInProgressFlagFromRedis.equalsIgnoreCase("ON")) {
                        isSnapProgress = true;
                    } else if (null != key) {
                        redisCache.setSnapInProgressFlagInRedis(key, "ON");
                    }
            }
        }catch(Exception ex){
            long duration = (System.currentTimeMillis() - start);
            logger.error("Exception in checkAnySnapIsInProgressForVin : {} {}", ex.getMessage(), duration);
        }
        long duration = (System.currentTimeMillis() - start);
        logger.debug("Time taken method - checkAnySnapIsInProgressForVin is::: {}", duration);
        return isSnapProgress;
    }

    @Override
    public Boolean deleteSnapInProgressKeyFromRedis(String vin, String nodeAddress){
        try {
            if (vin != null && nodeAddress != null) {
                String key = redisCache.generateSnapInProgressCacheKey(vin, nodeAddress);
                return redisCache.delete(key);
            }
        }catch(Exception ex){
            logger.error("Exception in deleteSnapInProgressKeyFromRedis : {} ", ex.getMessage());
        }
        return false;
    }

}
