package com.ford.gvmsr.snapobserver.enums;

public enum SnapSource {

    VIL("VIL"),
    AL("AL"),
    CFG("CFG");

    private String source;

    SnapSource(String source) {
        this.source = source;
    }

    public String getSource() {
        return this.source;
    }

    public static SnapSource getBySource(String source) {
        for (SnapSource snapSource : SnapSource.values()) {
            if (snapSource.getSource().equals(source)) {
                return snapSource;
            }
        }
        throw new IllegalArgumentException();
    }
}
