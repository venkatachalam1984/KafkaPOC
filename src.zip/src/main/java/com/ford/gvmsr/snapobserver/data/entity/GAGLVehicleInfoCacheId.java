package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.io.Serializable;

@Embeddable
public class GAGLVehicleInfoCacheId implements Serializable {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "GVMS28_VEH_INFO_CACHE_K", insertable = false, updatable = false, nullable = false)
    private int gaglVehicleInfoCacheKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    public int getGaglVehicleInfoCacheKey() {
        return gaglVehicleInfoCacheKey;
    }

    public void setGaglVehicleInfoCacheKey(int gaglVehicleInfoCacheKey) {
        this.gaglVehicleInfoCacheKey = gaglVehicleInfoCacheKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }
}

