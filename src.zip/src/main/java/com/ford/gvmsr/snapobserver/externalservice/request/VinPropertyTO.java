
package com.ford.gvmsr.snapobserver.externalservice.request;


import com.fasterxml.jackson.annotation.JsonProperty;


public class VinPropertyTO {

    @JsonProperty("vin")
    private String vin;

    @JsonProperty("featureList")
    private FeatureListTO featureList;

    @JsonProperty("pgmCode")
    private String pgmCode;

    @JsonProperty("savemodelyear")
    private String savemodelyear;

    @JsonProperty("manufacturingModelYear")
    private String manufacturingModelYear;

    @JsonProperty("srcTransID")
    private Long srcTransID;

    @JsonProperty("srcTransDtlID")
    private Long srcTransDtlID;

    @JsonProperty("extTransID")
    private Long extTransID;

    @JsonProperty("extTransDtlID")
    private Long extTransDtlID;

    @JsonProperty("traceId")
    private String traceId;

    @JsonProperty("transactionType")
    private String transactionType;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getSavemodelyear() {
        return savemodelyear;
    }

    public void setSavemodelyear(String savemodelyear) {
        this.savemodelyear = savemodelyear;
    }

    public String getManufacturingModelYear() {
        return manufacturingModelYear;
    }

    public void setManufacturingModelYear(String manufacturingModelYear) {
        this.manufacturingModelYear = manufacturingModelYear;
    }

    public String getPgmCode() {
        return pgmCode;
    }

    public void setPgmCode(String pgmCode) {
        this.pgmCode = pgmCode;
    }

    public FeatureListTO getFeatureList() {
        return featureList;
    }

    public void setFeatureList(FeatureListTO featureList) {
        this.featureList = featureList;
    }

    public Long getSrcTransID() {
        return srcTransID;
    }

    public void setSrcTransID(Long srcTransID) {
        this.srcTransID = srcTransID;
    }

    public Long getSrcTransDtlID() {
        return srcTransDtlID;
    }

    public void setSrcTransDtlID(Long srcTransDtlID) {
        this.srcTransDtlID = srcTransDtlID;
    }

    public Long getExtTransID() {
        return extTransID;
    }

    public void setExtTransID(Long extTransID) {
        this.extTransID = extTransID;
    }

    public Long getExtTransDtlID() {
        return extTransDtlID;
    }

    public void setExtTransDtlID(Long extTransDtlID) {
        this.extTransDtlID = extTransDtlID;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }
}
