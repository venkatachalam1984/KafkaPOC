package com.ford.gvmsr.snapobserver.externalservice.response;

import com.ford.gvmsr.snapobserver.externalservice.request.FPNDIDInfoType;

import java.util.List;

/**
 * Created by vm4 on 12/05/2018.
 */
public class PersistNodeAndDidAndFPNResponse {
    private String responseMessage;
    private String nodeAddressStatus;
    private String didCatalogStatus;
    private String fpnStatus;
    private Integer requestFPNCount;
    private Integer availableFPNCount;
    private Integer missingFPNCount;
    private List<FPNDIDInfoType> missingFPNs;
    private List<String> availableFPNs;

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public String getNodeAddressStatus() {
        return nodeAddressStatus;
    }

    public void setNodeAddressStatus(String nodeAddressStatus) {
        this.nodeAddressStatus = nodeAddressStatus;
    }

    public String getDidCatalogStatus() {
        return didCatalogStatus;
    }

    public void setDidCatalogStatus(String didCatalogStatus) {
        this.didCatalogStatus = didCatalogStatus;
    }

    public String getFpnStatus() {
        return fpnStatus;
    }

    public void setFpnStatus(String fpnStatus) {
        this.fpnStatus = fpnStatus;
    }

    public Integer getRequestFPNCount() {
        return requestFPNCount;
    }

    public void setRequestFPNCount(Integer requestFPNCount) {
        this.requestFPNCount = requestFPNCount;
    }

    public Integer getAvailableFPNCount() {
        return availableFPNCount;
    }

    public void setAvailableFPNCount(Integer availableFPNCount) {
        this.availableFPNCount = availableFPNCount;
    }

    public Integer getMissingFPNCount() {
        return missingFPNCount;
    }

    public void setMissingFPNCount(Integer missingFPNCount) {
        this.missingFPNCount = missingFPNCount;
    }

    public List<String> getAvailableFPNs() {
        return availableFPNs;
    }

    public void setAvailableFPNs(List<String> availableFPNs) {
        this.availableFPNs = availableFPNs;
    }

    public List<FPNDIDInfoType> getMissingFPNs() {
        return missingFPNs;
    }

    public void setMissingFPNs(List<FPNDIDInfoType> missingFPNs) {
        this.missingFPNs = missingFPNs;
    }
}
