package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by vm4 on 09/11/2018.
 */

@Embeddable
public class VehicleInfoCacheId implements Serializable {

    @Column(name = "GVMS25_VEH_INFO_CACHE_K",insertable = false,updatable = false, nullable = false)
    /*@GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "PGVMS25_VEH_INFO_CACHE_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS25_VEH_INFO_CACHE_K_SQ_GEN", sequenceName = "PGVMS25_VEH_INFO_CACHE_K_SQ", allocationSize = 1)*/
    private int vehicleInfoCacheKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    public int getVehicleInfoCacheKey() {
        return vehicleInfoCacheKey;
    }

    public void setVehicleInfoCacheKey(int vehicleInfoCacheKey) {
        this.vehicleInfoCacheKey = vehicleInfoCacheKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }
}
