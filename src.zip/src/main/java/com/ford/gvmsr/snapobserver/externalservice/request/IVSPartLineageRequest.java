package com.ford.gvmsr.snapobserver.externalservice.request;

/**
 * Created by MDEVARA3 on 1/3/2018.
 */
//@JsonTypeInfo(include= JsonTypeInfo.As.WRAPPER_OBJECT, use= JsonTypeInfo.Id.NAME)
public class IVSPartLineageRequest {

    private String programCode;
    private float salesModelYear;
    private String assemblyPartNumber;
    private String nodeAddress;

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public String getAssemblyPartNumber() {
        return assemblyPartNumber;
    }

    public void setAssemblyPartNumber(String assemblyPartNumber) {
        this.assemblyPartNumber = assemblyPartNumber;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }
}
