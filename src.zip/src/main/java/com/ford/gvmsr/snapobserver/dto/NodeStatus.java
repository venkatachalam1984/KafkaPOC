package com.ford.gvmsr.snapobserver.dto;

import com.ford.gvmsr.snapobserver.enums.SnapStatus;

public class NodeStatus {

    private String code;

    private String message;

    public NodeStatus() {
    }

    public NodeStatus(String code) {
        this.code = code;
    }

    public NodeStatus(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "NodeStatus{" +
                "code=" + code +
                ", message='" + message + '\'' +
                '}';
    }

}
