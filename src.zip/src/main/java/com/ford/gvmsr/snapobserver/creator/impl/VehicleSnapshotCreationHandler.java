package com.ford.gvmsr.snapobserver.creator.impl;

import com.ford.gvmsr.snapobserver.handler.SnapshotSaveHandler;
import com.ford.gvmsr.snapobserver.creator.VehicleSnapshotCreator;
import com.ford.gvmsr.snapobserver.data.entity.RequestorRole;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.exception.ServiceFault;
import com.ford.gvmsr.snapobserver.exception.ServiceFaultException;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Date;

import static com.ford.gvmsr.snapobserver.constants.SnapConstants.INVALID_INPUT;

@Service
public class VehicleSnapshotCreationHandler implements VehicleSnapshotCreator {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    ExceptionHandler exceptionHandler;

    @Autowired
    SnapshotSaveHandler snapshotSaveHandler;

    @Override
    public VehicleSnapshot createVehicleSnapshot(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, Vehicle vehicle) {
        VehicleSnapshot vehicleSnapshot = null;
        try {
                vehicleSnapshot = new VehicleSnapshot();
                vehicleSnapshot.setVehicle(vehicle);
                vehicleSnapshot = populateRoleInfo(moduleSnapshotObserverRequest, vehicleSnapshot);
                vehicleSnapshot.setRecordDateTime(new Timestamp(new Date().getTime()));
                vehicleSnapshot.setIvsXmlInfo(moduleSnapshotObserverRequest.getSnapshotObserverRequest().getInfoKey());
                vehicleSnapshot = snapshotSaveHandler.saveVehicleSnapshot(vehicleSnapshot);
        } catch (Exception e) {
            LOGGER.error("Exception @ createVehicleSnapshot : ", e);
            String validationErrorMessage ="Exception while creating Vehicle Snapshot";
            exceptionHandler.logException(e, this.getClass().getSimpleName());
            throw new ServiceFaultException(validationErrorMessage, new ServiceFault(
                    INVALID_INPUT, validationErrorMessage));
        }
        return vehicleSnapshot;
    }

    private VehicleSnapshot populateRoleInfo(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, VehicleSnapshot vehicleSnapshot) {

        RequestorRole requestorRole = new RequestorRole();
        if (isRoleExist(moduleSnapshotObserverRequest)) {

            requestorRole.setRoleName(moduleSnapshotObserverRequest.getRequestRole().getRole().value());
            vehicleSnapshot.setRequestorRole(requestorRole);
            vehicleSnapshot.setRoleDescription(moduleSnapshotObserverRequest.getRequestRole().getRoleDesc());
            vehicleSnapshot.setRoleId(moduleSnapshotObserverRequest.getRequestRole().getRoleID());
            vehicleSnapshot.setRoleSource(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value());
        }
        return vehicleSnapshot;
    }

    private boolean isRoleExist(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest) {
        return moduleSnapshotObserverRequest != null && moduleSnapshotObserverRequest.getRequestRole() != null && moduleSnapshotObserverRequest.getRequestRole().getRole()!=null;
    }
}
