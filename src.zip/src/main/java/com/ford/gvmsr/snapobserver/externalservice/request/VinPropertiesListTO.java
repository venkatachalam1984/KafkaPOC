
package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonPropertyOrder({
        "vinProperties"
})
public class VinPropertiesListTO {

    @JsonProperty("vinProperties")
    private List<VinPropertyTO> vinProperties = null;


    @JsonProperty("vinProperties")
    public List<VinPropertyTO> getvinProperties() {
        return vinProperties;
    }

    @JsonProperty("vinProperties")
    public void setvinProperties(List<VinPropertyTO> vinProperties) {
        this.vinProperties = vinProperties;
    }


}
