package com.ford.gvmsr.snapobserver.data.entity;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/29/2017.
 */
@Entity
@Table(name = "PGVMS23_VIN_PROG_MAP")
public class VINProgramMap extends BaseEntity {

    @EmbeddedId
    private VINProgramMapId vinProgramMapId;

    @Column(name = "GVMS23_VIN_MAP_X",unique = true)
    private String vinMapExpression;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS23_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS23_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS23_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS23_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();


    public VINProgramMapId getVinProgramMapId() {
        return vinProgramMapId;
    }

    public void setVinProgramMapId(VINProgramMapId vinProgramMapId) {
        this.vinProgramMapId = vinProgramMapId;
    }

    public String getVinMapExpression() {
        return vinMapExpression;
    }

    public void setVinMapExpression(String vinMapExpression) {
        this.vinMapExpression = vinMapExpression;
    }

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

}

