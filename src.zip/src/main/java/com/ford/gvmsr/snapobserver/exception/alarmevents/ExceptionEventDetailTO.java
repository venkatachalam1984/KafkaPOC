package com.ford.gvmsr.snapobserver.exception.alarmevents;

public class ExceptionEventDetailTO {

    private Long exceptionEventHeaderId;
    private Integer exceptionEventDtlNumber;
    private String isPartNumber;
    private String nodeAdrs;
    private String didCatlgId;
    private String dataDescription;
    //private String traceId;

    public ExceptionEventDetailTO() {
    }

    public ExceptionEventDetailTO(String isPartNumber, String nodeAdrs, String didCatlgId, String dataDescription) {

        this.isPartNumber = isPartNumber;
        this.nodeAdrs = nodeAdrs;
        this.didCatlgId = didCatlgId;
        this.dataDescription = dataDescription;
    }

    public Long getExceptionEventHeaderId() {
        return exceptionEventHeaderId;
    }

    public void setExceptionEventHeaderId(Long exceptionEventHeaderId) {
        this.exceptionEventHeaderId = exceptionEventHeaderId;
    }

    public Integer getExceptionEventDtlNumber() {
        return exceptionEventDtlNumber;
    }

    public void setExceptionEventDtlNumber(Integer exceptionEventDtlNumber) {
        this.exceptionEventDtlNumber = exceptionEventDtlNumber;
    }

    public String getIsPartNumber() {
        return isPartNumber;
    }

    public void setIsPartNumber(String isPartNumber) {
        this.isPartNumber = isPartNumber;
    }

    public String getNodeAdrs() {
        return nodeAdrs;
    }

    public void setNodeAdrs(String nodeAdrs) {
        this.nodeAdrs = nodeAdrs;
    }

    public String getDidCatlgId() {
        return didCatlgId;
    }

    public void setDidCatlgId(String didCatlgId) {
        this.didCatlgId = didCatlgId;
    }

    public String getDataDescription() {
        return dataDescription;
    }

    public void setDataDescription(String dataDescription) {
        this.dataDescription = dataDescription;
    }

}
