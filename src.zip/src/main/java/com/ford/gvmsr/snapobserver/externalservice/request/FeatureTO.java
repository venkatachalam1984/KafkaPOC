
package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
	"description",
    "featureCode",
    "roleID",
    "roleName",
    "roleSource",
    "putInOnXmlFile",
    "roleDesc",
    "effInTimestamp",
    "effOutTimestamp"
})
public class FeatureTO{

    @JsonProperty("description")
    private String description;
    @JsonProperty("featureCode")
    private String featureCode;
   	@JsonProperty("roleID")
    private String roleID;
    @JsonProperty("roleName")
    private String roleName;
    @JsonProperty("roleSource")
    private String roleSource;
    @JsonProperty("putInOnXmlFile")
    private String putInOnXmlFile;
    @JsonProperty("roleDesc")
    private String roleDesc;
    @JsonProperty("effInTimestamp")
    private String effInTimestamp;
    @JsonProperty("effOutTimestamp")
    private String effOutTimestamp;
    @JsonProperty("effOutTimestamp")
    public String getEffOutTimestamp() {
		return effOutTimestamp;
	}@JsonProperty("effOutTimestamp")
	public void setEffOutTimestamp(String effOutTimestamp) {
		this.effOutTimestamp = effOutTimestamp;
	}
	@JsonProperty("effInTimestamp")
    public String getEffInTimestamp() {
		return effInTimestamp;
	}
    @JsonProperty("effInTimestamp")
	public void setEffInTimestamp(String effInTimestamp) {
		this.effInTimestamp = effInTimestamp;
	}

	@JsonProperty("description")
    public String getdescription() {
        return description;
    }

    @JsonProperty("description")
    public void setdescription(String description) {
        this.description = description;
    }

    @JsonProperty("featureCode")
    public String getfeatureCode() {
        return featureCode;
    }

    @JsonProperty("featureCode")
    public void setfeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }
    @JsonProperty("roleID")
    public String getroleID() {
		return roleID;
	}
    @JsonProperty("roleID")
	public void setroleID(String roleID) {
		this.roleID = roleID;
	}
	@JsonProperty("roleName")
	public String getroleName() {
		return roleName;
	}
	@JsonProperty("roleName")
	public void setroleName(String roleName) {
		this.roleName = roleName;
	}
	@JsonProperty("roleSource")
	public String getroleSource() {
		return roleSource;
	}
	@JsonProperty("roleSource")
	public void setroleSource(String roleSource) {
		this.roleSource = roleSource;
	}
	 @JsonProperty("putInOnXmlFile")
	public String getputInOnXmlFile() {
		return putInOnXmlFile;
	}
	 @JsonProperty("putInOnXmlFile")
	public void setputInOnXmlFile(String putInOnXmlFile) {
		this.putInOnXmlFile = putInOnXmlFile;
	}
	  @JsonProperty("roleDesc")
	public String getroleDesc() {
		return roleDesc;
	}
	  @JsonProperty("roleDesc")
	public void setroleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}



}
