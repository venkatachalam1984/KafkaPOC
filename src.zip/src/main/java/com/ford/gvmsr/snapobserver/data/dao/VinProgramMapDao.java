package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.VINProgramMap;

import java.util.List;

public interface VinProgramMapDao {

    List<VINProgramMap> getVinMapExpressionByVin(String vin);

}
