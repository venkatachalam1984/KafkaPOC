package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;

import java.util.Map;

public interface SnapDuplicateValidator {
    public Map<String, NodeAndDIDResponseForNewSnap> validateDidResponseForNodes(ModuleSnapshotObserverRequest snapshotObserverRequest, Vehicle vehicle);
}
