package com.ford.gvmsr.snapobserver.data.entity;

import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by MJAFARUL on 11/21/2017.
 */
@Entity
@Table(name = "PGVMS20_VEH_NODE_DID_ST")
public class VehicleNodeDIDStatus extends BaseEntity {
    /*
        @Id
        @Column(name="GVMS20_VEH_NODE_DID_ST_K")
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int vehicleNodeDidStatusKey;

        @Column(name = "GVMS10_VIN_HASH_R")
        private int vinHashNumber;*/
    @EmbeddedId
    private VehicleNodeDIDStatusID vehicleNodeDIDStatusID;

    @Column(name = "GVMS10_VIN_R")
    private String vin;

    @Column(name = "GVM023_NODE_ADRS_C")
    private String nodeAddress;

    @Column(name = "GVM011_DID_CATLG_D")
    private String didCatalog;

    @Column(name = "GVM019_ECU_ACRONYM_C")
    private String ecuAcronym;

    @Column(name = "GVMS20_RECORD_S")
    private Timestamp recordedTime;

    @ManyToOne
    @JoinColumn(name = "GVMS19_SW_ST_C", referencedColumnName = "GVMS19_SW_ST_C")
    private SoftwareStatus softwareStatus;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "GVMS01_ROLE_N", referencedColumnName = "GVMS01_ROLE_N")
    private RequestorRole roleName;

    @Embedded
    private FordPartNumberId partNumber;

    @Column(name = "GVMS20_ROLE_SRC_C")
    private String roleSource;

    @Column(name = "GVMS20_ROLE_X")
    private String roleDescription;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS20_CREATE_USER_C", updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS20_CREATE_S", updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS20_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS20_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

 /*   public int getVehicleNodeDidStatusKey() {
        return vehicleNodeDidStatusKey;
    }

    public void setVehicleNodeDidStatusKey(int vehicleNodeDidStatusKey) {
        this.vehicleNodeDidStatusKey = vehicleNodeDidStatusKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }*/

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getDidCatalog() {
        return didCatalog;
    }

    public void setDidCatalog(String didCatalog) {
        this.didCatalog = didCatalog;
    }

    public Timestamp getRecordedTime() {
        return recordedTime;
    }

    public void setRecordedTime(Timestamp recordedTime) {
        this.recordedTime = recordedTime;
    }

    public SoftwareStatus getSoftwareStatus() {
        return softwareStatus;
    }

    public void setSoftwareStatus(SoftwareStatus softwareStatus) {
        this.softwareStatus = softwareStatus;
    }

    public RequestorRole getRoleName() {
        return roleName;
    }

    public void setRoleName(RequestorRole roleName) {
        this.roleName = roleName;
    }

    public FordPartNumberId getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(FordPartNumberId partNumber) {
        this.partNumber = partNumber;
    }

    public String getRoleSource() {
        return roleSource;
    }

    public void setRoleSource(String roleSource) {
        this.roleSource = roleSource;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }

    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    public VehicleNodeDIDStatusID getVehicleNodeDIDStatusID() {
        return vehicleNodeDIDStatusID;
    }

    public void setVehicleNodeDIDStatusID(VehicleNodeDIDStatusID vehicleNodeDIDStatusID) {
        this.vehicleNodeDIDStatusID = vehicleNodeDIDStatusID;
    }
}
