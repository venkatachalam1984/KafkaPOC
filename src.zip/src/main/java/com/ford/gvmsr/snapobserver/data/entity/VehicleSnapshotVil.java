package com.ford.gvmsr.snapobserver.data.entity;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/30/2017.
 * <p>
 * A record at a point in time of the information from the vehicle's module(s).
 * Data Source: GIVIS:NMGM072_VEH_NODE_SNPSHT
 */

@Entity
@Table(name = "PGVMS34_VEH_SNPSHT_VIL")
public class VehicleSnapshotVil extends BaseEntity {

    @EmbeddedId
    private VehicleSnapshotId vehicleSnapshotId;

    @Lob
    @Column(name = "GVMS34_VIL_L")
    private String vilContent;

    public VehicleSnapshotId getVehicleSnapshotId() {
        return vehicleSnapshotId;
    }

    public void setVehicleSnapshotId(VehicleSnapshotId vehicleSnapshotId) {
        this.vehicleSnapshotId = vehicleSnapshotId;
    }

    public String getVilContent() {
        return vilContent;
    }

    public void setVilContent(String vilContent) {
        this.vilContent = vilContent;
    }

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS34_CREATE_USER_C", updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS34_CREATE_S", updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS34_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS34_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }

}
