package com.ford.gvmsr.snapobserver.data.entity;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MJAFARUL on 11/21/2017.
 */
@Entity
@Table(name = "PGVMS19_SW_ST")
public class SoftwareStatus extends BaseEntity {

    @Id
    @Column (name = "GVMS19_SW_ST_C")
    private String softwareStatusCode;

    @Column(name = "GVMS19_SW_ST_X")
    private String softwareStatusDesc;

    @Column(name = "GVMS19_ST_TYPE_C")
    private String statusTypeCode;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS19_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS19_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS19_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS19_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public String getSoftwareStatusCode() {
        return softwareStatusCode;
    }

    public void setSoftwareStatusCode(String softwareStatusCode) {
        this.softwareStatusCode = softwareStatusCode;
    }

    public String getSoftwareStatusDesc() {
        return softwareStatusDesc;
    }

    public void setSoftwareStatusDesc(String softwareStatusDesc) {
        this.softwareStatusDesc = softwareStatusDesc;
    }

    public String getStatusTypeCode() {
        return statusTypeCode;
    }

    public void setStatusTypeCode(String statusTypeCode) {
        this.statusTypeCode = statusTypeCode;
    }
}
