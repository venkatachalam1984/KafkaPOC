package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VehicleSnapshotVilDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshotVil;
import com.ford.gvmsr.snapobserver.data.repository.VehicleSnapshotVilRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class VehicleSnapshotVilDaoImpl implements VehicleSnapshotVilDao {

    @Autowired
    VehicleSnapshotVilRepository vehicleSnapshotVilRepository;

    @Override
    public VehicleSnapshotVil save(VehicleSnapshotVil vehicleSnapshotVil) {
        return vehicleSnapshotVilRepository.save(vehicleSnapshotVil);
    }
}
