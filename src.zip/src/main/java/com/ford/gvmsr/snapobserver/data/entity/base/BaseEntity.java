package com.ford.gvmsr.snapobserver.data.entity.base;

import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import java.sql.Timestamp;

/**
 * Created by VYUVARA6 on 9/4/2017.
 */
@EntityListeners(BaseEntityEventListener.class)
@MappedSuperclass
public abstract class BaseEntity {

    public abstract AuditColumns getAuditColumns();

    public void setCreatedTimestamp(Timestamp date){
        getAuditColumns().setCreatedTimestamp(date);
    }

    public void setCreatedUser(String user){
        getAuditColumns().setCreatedUser(user);
    }

    public void setLastUpdatedTimestamp(Timestamp date){
        getAuditColumns().setLastUpdatedTimestamp(date);
    }

    public void setLastUpdatedUser(String user){
        getAuditColumns().setLastUpdatedUser(user);
    }
}
