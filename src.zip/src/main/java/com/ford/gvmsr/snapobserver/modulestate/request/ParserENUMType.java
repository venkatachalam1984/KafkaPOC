
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ParserENUMType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ParserENUMType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="PMI"/&gt;
 *     &lt;enumeration value="MR"/&gt;
 *     &lt;enumeration value="HIST"/&gt;
 *     &lt;enumeration value="ALL"/&gt;
 *     &lt;enumeration value="TSB"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ParserENUMType")
@XmlEnum
public enum ParserENUMType {

    PMI,
    MR,
    HIST,
    ALL,
    TSB;

    public String value() {
        return name();
    }

    public static ParserENUMType fromValue(String v) {
        return valueOf(v);
    }

}
