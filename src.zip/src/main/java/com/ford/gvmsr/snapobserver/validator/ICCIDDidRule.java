package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.monitor.SnapshotChangeMonitor;
import com.ford.gvmsr.snapobserver.modulestate.monitor.SnapshotNodeMonitor;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.helper.SnapCreationHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Map;
import java.util.Set;

@Component
public class ICCIDDidRule {
    private static final Logger logger = LoggerFactory.getLogger(ICCIDDidRule.class);

    @Autowired
    SnapCreationHelper snapCreationHelper;

    @Value("#{'${iccid.dids}'.split(',')}")
    private Set<String> ICCID_DID_LIST;

    public void populateDidEntity(PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode, DIDInfoType did,
                                  NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap, ModuleNodeType node, ModuleSnapshotObserverRequest snapshotObserverRequest) {
        VehicleNodeDIDResponse vehicleNodeDIDResponse = new VehicleNodeDIDResponse();

        //validate did response and compare prevICCID did response
        String didResponse = validateICCIDRule(previousSnapShotDetailsByNode.getPrevNonConfigDidResponseMap(), node, did, snapshotObserverRequest);
        vehicleNodeDIDResponse.setDidResponse(didResponse);

        // populate the vehicleNodeDIDResponse for persistence
        snapCreationHelper.populateVehicleNodeDIDResponse(vehicleNodeDIDResponse, did, node, snapshotObserverRequest, previousSnapShotDetailsByNode);
        nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList().add(vehicleNodeDIDResponse);
    }

    private String validateICCIDRule(Map<String, VehicleNodeDIDResponse> prevVehicleNodeDIDResponseMap, ModuleNodeType node, DIDInfoType did, ModuleSnapshotObserverRequest snapshotObserverRequest) {

        String didResponse = ApplicationUtils.toUpperCase(did.getResponse());

        if (!CollectionUtils.isEmpty(prevVehicleNodeDIDResponseMap) && prevVehicleNodeDIDResponseMap.containsKey(did.getDidValue())) {
            String prevICCIDDidResponse = prevVehicleNodeDIDResponseMap.get(did.getDidValue()).getDidResponse();
            if (null != didResponse) {
                if (null != didResponse && node.getAddress().equalsIgnoreCase(GVMSModuleUpdateConstants.NODE_754)) {
                    snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.ICCID_DID_PRESENT, true);
                    if (null != prevICCIDDidResponse && !didResponse.equalsIgnoreCase(prevICCIDDidResponse)) {
                        snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.ICCID_DID_CHANGED, true);
                    }
                }
            }
        }else{
            snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.ICCID_DID_CHANGED, true);
        }

        return didResponse;
    }

    public void copyICCIDDIDsFromPrevious(Map<String, VehicleNodeDIDResponse> prevVehicleNodeDIDResponseMap,
                                          NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap) {
            for (Map.Entry<String, VehicleNodeDIDResponse> vehicleNodeDIDResponseEntry : prevVehicleNodeDIDResponseMap.entrySet()) {
                if (ICCID_DID_LIST.contains(vehicleNodeDIDResponseEntry.getValue().getDidCatalog())) {
                    nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList().add(vehicleNodeDIDResponseEntry.getValue());
                    break;
                }
            }
    }
}
