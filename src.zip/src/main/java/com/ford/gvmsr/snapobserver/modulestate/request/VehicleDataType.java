
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for VehicleDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VehicleDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CurrentDIDList" type="{urn:ford/Vehicle/Module/Information/v4.0}CurrentDIDListType" minOccurs="0"/&gt;
 *         &lt;element name="FeatureList" type="{urn:ford/Vehicle/Module/Information/v4.0}FeatureCodeInfoType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VehicleDataType", propOrder = {
    "currentDIDList",
    "featureList"
})
public class VehicleDataType {

    @XmlElement(name = "CurrentDIDList")
    protected CurrentDIDListType currentDIDList;
    @XmlElement(name = "FeatureList")
    protected List<FeatureCodeInfoType> featureList;

    /**
     * Gets the value of the currentDIDList property.
     * 
     * @return
     *     possible object is
     *     {@link CurrentDIDListType }
     *     
     */
    public CurrentDIDListType getCurrentDIDList() {
        return currentDIDList;
    }

    /**
     * Sets the value of the currentDIDList property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrentDIDListType }
     *     
     */
    public void setCurrentDIDList(CurrentDIDListType value) {
        this.currentDIDList = value;
    }

    /**
     * Gets the value of the featureList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the featureList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFeatureList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeatureCodeInfoType }
     * 
     * 
     */
    public List<FeatureCodeInfoType> getFeatureList() {
        if (featureList == null) {
            featureList = new ArrayList<FeatureCodeInfoType>();
        }
        return this.featureList;
    }

}
