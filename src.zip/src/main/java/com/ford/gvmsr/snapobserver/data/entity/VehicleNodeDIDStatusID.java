package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by KMANI4 on 12-09-2018.
 */
@Embeddable
public class VehicleNodeDIDStatusID implements Serializable {

    @Column(name = "GVMS20_VEH_NODE_DID_ST_K")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMS20_VEH_NODE_DID_ST_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS20_VEH_NODE_DID_ST_K_SQ_GEN", sequenceName = "PGVMS20_VEH_NODE_DID_ST_K_SQ", allocationSize = 1)
    private Long vehicleNodeDidStatusKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    public Long  getVehicleNodeDidStatusKey() {
        return vehicleNodeDidStatusKey;
    }

    public void setVehicleNodeDidStatusKey(Long  vehicleNodeDidStatusKey) {
        this.vehicleNodeDidStatusKey = vehicleNodeDidStatusKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }
}
