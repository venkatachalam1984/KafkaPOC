package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.TransactionStatus;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;

public interface TransactionStatusRepository extends CrudRepository<TransactionStatus, Serializable> {
}
