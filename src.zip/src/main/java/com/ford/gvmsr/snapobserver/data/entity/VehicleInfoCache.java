package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by vm4 on 06/30/2018.
 */

@Entity
@Table(name = "PGVMS25_GC_VEH_INFO_CACHE")
public class VehicleInfoCache implements Serializable{


    /*@Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "GVMS25_VEH_INFO_CACHE_K")
    private int vehicleInfoCacheKey;*/

    @EmbeddedId
    private VehicleInfoCacheId vehicleInfoCacheId;

    @Column(name = "GVMS10_VIN_R")
    private String vin;

    @Column(name = "GVM023_NODE_ADRS_C")
    private String nodeAddress;

    @Column(name = "GVMS25_INFO_TYPE_C")
    private String infoType;

    @Column(name = "GVMS25_CACHE_KEY_X")
    private String cacheKey;

    @Column(name = "GVMS25_INFO_BLOB_L")
    private byte[] infoBlob;

    @Column(name = "GVMS25_CREATE_USER_C")
    private String createdUser;

    @Column(name = "GVMS25_CREATE_S")
    private Timestamp createdTimestamp;


    @Column(name = "GVMS25_ACTIVE_F")
    private String isActive;


   /* public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }

    public int getVehicleInfoCacheKey() {
        return vehicleInfoCacheKey;
    }

    public void setVehicleInfoCacheKey(int vehicleInfoCacheKey) {
        this.vehicleInfoCacheKey = vehicleInfoCacheKey;
    }*/

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getInfoType() {
        return infoType;
    }

    public void setInfoType(String infoType) {
        this.infoType = infoType;
    }

    public String getCacheKey() {
        return cacheKey;
    }

    public void setCacheKey(String cacheKey) {
        this.cacheKey = cacheKey;
    }

    public byte[] getInfoBlob() {
        return infoBlob;
    }

    public void setInfoBlob(byte[] infoBlob) {
        this.infoBlob = infoBlob;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Timestamp getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(Timestamp createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public VehicleInfoCacheId getVehicleInfoCacheId() {
        return vehicleInfoCacheId;
    }

    public void setVehicleInfoCacheId(VehicleInfoCacheId vehicleInfoCacheId) {
        this.vehicleInfoCacheId = vehicleInfoCacheId;
    }
}
