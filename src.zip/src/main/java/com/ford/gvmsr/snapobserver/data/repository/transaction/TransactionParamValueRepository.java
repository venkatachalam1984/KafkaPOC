package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.TransactionParamValue;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Repository
@Transactional
public interface TransactionParamValueRepository  extends CrudRepository<TransactionParamValue,Serializable>{

    public List<TransactionParamValue> findAllByTransactionId(long id);

    @Modifying
    @Query("update TransactionParamValue p set p.paramValue=?2, p.auditColumns.lastUpdatedTimestamp = ?3 where p.transactionId =?1")
    public void updateParamValueForTransactionId(long id, String paramValue, Timestamp timestamp);
}
