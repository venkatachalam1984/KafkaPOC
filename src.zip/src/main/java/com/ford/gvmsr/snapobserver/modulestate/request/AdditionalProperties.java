package com.ford.gvmsr.snapobserver.modulestate.request;


import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public class AdditionalProperties {

    private DerivedAssemblyResponseForNode derivedAssemblyResponseForNode;
    private ODLNetworkDetails odlNetworkDetailsForNode;
    private String vscsVersionDesc;
    private Timestamp vscsVersionDate;

    public DerivedAssemblyResponseForNode getDerivedAssemblyResponseForNode() {
        return derivedAssemblyResponseForNode;
    }

    public void setDerivedAssemblyResponseForNode(DerivedAssemblyResponseForNode derivedAssemblyResponseForNode) {
        this.derivedAssemblyResponseForNode = derivedAssemblyResponseForNode;
    }

    public ODLNetworkDetails getOdlNetworkDetailsForNode() {
        return odlNetworkDetailsForNode;
    }

    public void setOdlNetworkDetailsForNode(ODLNetworkDetails odlNetworkDetailsForNode) {
        this.odlNetworkDetailsForNode = odlNetworkDetailsForNode;
    }

    public String getVscsVersionDesc() {
        return vscsVersionDesc;
    }

    public void setVscsVersionDesc(String vscsVersionDesc) {
        this.vscsVersionDesc = vscsVersionDesc;
    }

    public Timestamp getVscsVersionDate() {
        return vscsVersionDate;
    }

    public void setVscsVersionDate(Timestamp vscsVersionDate) {
        this.vscsVersionDate = vscsVersionDate;
    }

}
