package com.ford.gvmsr.snapobserver.exception;

public class StrategyDidValidationException extends Exception{

    public StrategyDidValidationException(String message) {
        super(message);
    }


}
