package com.ford.gvmsr.snapobserver.creator;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDStatus;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshot;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public interface AppDidCreator {
    void persistApplicationDid(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, VehicleNodeDIDResponse vehicleNodeDIDResponse);
    void persistSoftwareDidState(List<VehicleNodeDIDStatus> vehicleNodeDIDStatusList, Timestamp vinRecordedTimestamp);
    Map<Boolean, String> performModuleSwapForSyncAndTCU(ModuleSnapshotObserverRequest snapshotObserverRequest, VehicleNodeSnapshot vehicleNodeSnapshot, Map<String, String> swapMap, Boolean ccpuFlag);
}
