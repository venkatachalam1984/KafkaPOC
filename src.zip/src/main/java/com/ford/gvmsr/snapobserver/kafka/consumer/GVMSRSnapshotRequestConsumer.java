package com.ford.gvmsr.snapobserver.kafka.consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.snapobserver.config.VertxConfiguration;
import com.ford.gvmsr.snapobserver.constants.VilConstants;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.logevent.LogType;
import com.ford.gvmsr.snapobserver.logevent.splunk.Utils;
import com.ford.gvmsr.snapobserver.modulestate.request.SnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import io.vertx.core.AbstractVerticle;
import io.vertx.kafka.client.common.TopicPartition;
import io.vertx.kafka.client.consumer.KafkaConsumer;
import io.vertx.kafka.client.consumer.KafkaConsumerRecord;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Properties;

@Component
public class GVMSRSnapshotRequestConsumer extends AbstractVerticle {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    VertxConfiguration vertxConfiguration;

    @Autowired
    Utils splunkUtils ;

    @Autowired
    ExceptionHandler exceptionHandler;

    @Override
    public void start() {

        KafkaConsumer<String, String> consumer = registerKafkaSnapshotRequestConsumer();
        subscribeToGVMSRSnapshotTopic(consumer, vertxConfiguration.getSnapshotConsumerTopic());

    }

    private KafkaConsumer<String, String> registerKafkaSnapshotRequestConsumer() {

        Properties properties = new Properties();
        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, vertxConfiguration.getSnapshotKafkaBrokerEndpoints());
        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        properties.put(ConsumerConfig.GROUP_ID_CONFIG, vertxConfiguration.getSnapshotConsumerGroup());
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, vertxConfiguration.getAutoOffsetReset());
        properties.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, vertxConfiguration.getMaxPollRecordsLimit());
        properties.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, vertxConfiguration.getMaxPollRecordsInterval());
        properties.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, vertxConfiguration.getAutoCommitInterval());
        properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, vertxConfiguration.isSnapshotAutoCommitOffset());
        properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, vertxConfiguration.getSnapshotProtocolConfig());
        return KafkaConsumer.create(vertx, properties);

    }

    private void subscribeToGVMSRSnapshotTopic(KafkaConsumer<String, String> consumer, String kafkaTopic) {

        consumer.handler(record -> handleSnapshotRequest(consumer, record));
        consumer.subscribe(kafkaTopic, handler -> {
            if(handler.succeeded())
                logger.info("Subscribed {} successfully", kafkaTopic);
        });
    }

    private void handleSnapshotRequest(KafkaConsumer<String, String> consumer, KafkaConsumerRecord<String, String> record) {

        Instant start = Instant.now();
        logger.info("SnapshotRequest:Received");
        SnapshotObserverRequest snapshotObserverRequest;
        String vin = null;
        String traceId;
        try {
            snapshotObserverRequest = new ObjectMapper().readValue(record.value(), SnapshotObserverRequest.class);
            vin = snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getVIN();
            traceId = snapshotObserverRequest.getModuleStateRequest().getTraceID();
            //added kafka log event
            splunkUtils.postKafkaLogEvent(vin, record);
            splunkUtils.prepareSnapObserverToConfirmerLogEvent(vin, traceId, LogType.INFO.getCode(), VilConstants.RCVD_FRM_VIL_RECVR,
                    null, null, VilConstants.KAFKA_TRK_M, CommonUtils.getEventTimeStamp(), null);

            pushToSnapObserverByHashLookUp(record, vin, traceId, consumer);

            consumer.commit(event -> {
                if (event.succeeded()) {
                    logger.info("SnapshotRequest:Committed offset-{}, for vin={} ", record.offset(),
                            snapshotObserverRequest.getModuleStateRequest().getModuleSnapshot().getVIN());
                }
            });

        } catch (Exception ex) {
            logger.error("SnapshotRequest:Exception while handling VIN = {}", vin);
            exceptionHandler.logException(ex, this.getClass().getSimpleName());
        }
        Instant end = Instant.now();
        logger.info("SnapshotRequest:Processing time for VIN = {} Duration = {} ", vin, Duration.between(start,end).toMillis());

    }

    private void pushToSnapObserverByHashLookUp(KafkaConsumerRecord<String, String> record, String vin, String traceId, KafkaConsumer<String, String> consumer) {

        int vinHashLookUpKey = (Math.abs(vin.hashCode()) %
                vertxConfiguration.getWorkerVerticleCount());

        logger.info("vinHashLookUpKey = {} for VIN = {} ", vinHashLookUpKey, vin);
        String snapRequestHandler = VilConstants.SNAP_REQUEST_HANDLER + vinHashLookUpKey;
        vertx.eventBus().send(snapRequestHandler, record.value());
        splunkUtils.prepareSnapObserverToConfirmerLogEvent(vin, traceId, LogType.INFO.getCode(), VilConstants.SENT_TO_VERTICLE,
                null, null, VilConstants.VERTICLE_TRK_M, CommonUtils.getEventTimeStamp(), null);
        /*vertx.eventBus().request(snapRequestHandler, record.value(),  promise -> {  //send
            logger.info("Response - " +promise);
            *//*if(promise.succeeded()) {
                Boolean isRequestProcessed = (Boolean) promise.result().body();
                if(isRequestProcessed)
                    consumer.commit();
            } else {
                logger.error("EventBus promise exception = ", promise.cause());
                //resetToLastCommittedPosition(consumer, record);
            }*//*
            consumer.commit();
            //auto.commit = 1000 ms
            //enable auto commit = true
            logger.info("Committed " + " offset=" + record.offset() + " Partition=" + record.partition());
        });*/

    }

    //kafka retry for failed messages
    private void resetToLastCommittedPosition(KafkaConsumer<String, String> consumer,
                                              KafkaConsumerRecord<String, String> record) {
        logger.info("Calling Kafka retry for hash = {}, consumer = {} ", record.value().hashCode(), consumer.toString());
        int consumerRetry = Integer.parseInt(MDC.get(consumer.toString()));
        if (consumerRetry < vertxConfiguration.getSnapshotKakfaRetryCount()) {
            seekConsumerOffset(consumer, record.topic(), record.partition(), record.offset());
            MDC.put(consumer.toString(), String.valueOf(consumerRetry + 1));
        } else {
            logger.info("Seek consumer is done!!");
            consumer.commit();
            MDC.put(consumer.toString(), String.valueOf(0));
        }

    }

    private void seekConsumerOffset(KafkaConsumer<String, String> consumer, String topic, int partition, Long offset) {

        consumer.seek(new TopicPartition(topic, partition), offset, event ->
                logger.info("Seek consumer to read=" + topic + " Partition=" + partition + " offset=" + offset));

    }


}