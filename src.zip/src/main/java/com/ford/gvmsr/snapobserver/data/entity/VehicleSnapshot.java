package com.ford.gvmsr.snapobserver.data.entity;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by MDEVARA3 on 8/30/2017.
 * <p>
 * A record at a point in time of the information from the vehicle's module(s).
 * Data Source: GIVIS:NMGM072_VEH_NODE_SNPSHT
 */

@Entity
@Table(name = "PGVMS03_VEH_SNPSHT")
public class VehicleSnapshot extends BaseEntity {

    @Id
    @Column(name = "GVMS03_VEH_SNPSHT_K")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="PGVMS03_VEH_SNPSHT_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS03_VEH_SNPSHT_K_SQ_GEN", sequenceName = "PGVMS03_VEH_SNPSHT_K_SQ", allocationSize = 1)
    private Long  vehicleSnapshotKey;

    public Long getVehicleSnapshotKey() {
        return vehicleSnapshotKey;
    }

    public void setVehicleSnapshotKey(Long vehicleSnapshotKey) {
        this.vehicleSnapshotKey = vehicleSnapshotKey;
    }

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumns({
            @JoinColumn(name = "GVMS10_VIN_R", referencedColumnName = "GVMS10_VIN_R"),
            @JoinColumn(name = "GVMS10_VIN_HASH_R", referencedColumnName = "GVMS10_VIN_HASH_R")
    })
    private Vehicle vehicle;

    @Column(name = "GVMS03_RECORD_S")
    private Timestamp recordDateTime;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "GVMS01_ROLE_N", referencedColumnName = "GVMS01_ROLE_N")
    private RequestorRole requestorRole;

    @Column(name = "GVMS03_ROLE_D")
    private String roleId;

    @Column(name = "GVMS03_ROLE_SRC_C")
    private String roleSource;

    @Column(name = "GVMS03_ROLE_X")
    private String roleDescription;

    @Column(name = "GVM010_IVS_XML_INFO_K")
    private Long ivsXmlInfo;

 /*   @OneToMany(mappedBy = "vehicleSnapshot",cascade = CascadeType.ALL)
    private List<VehicleNodeSnapshot> vehicleNodeSnapshotList;*/

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS03_CREATE_USER_C", updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS03_CREATE_S", updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS03_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS03_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Timestamp getRecordDateTime() {
        return recordDateTime;
    }

    public void setRecordDateTime(Timestamp recordDateTime) {
        this.recordDateTime = recordDateTime;
    }

    public RequestorRole getRequestorRole() {
        return requestorRole;
    }

    public void setRequestorRole(RequestorRole requestorRole) {
        this.requestorRole = requestorRole;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleSource() {
        return roleSource;
    }

    public void setRoleSource(String roleSource) {
        this.roleSource = roleSource;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public Long getIvsXmlInfo() {
        return ivsXmlInfo;
    }

    public void setIvsXmlInfo(Long ivsXmlInfo) {
        this.ivsXmlInfo = ivsXmlInfo;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }


  /*  public List<VehicleNodeSnapshot> getVehicleNodeSnapshotList() {
        return vehicleNodeSnapshotList;
    }

    public void setVehicleNodeSnapshotList(List<VehicleNodeSnapshot> vehicleNodeSnapshotList) {
        this.vehicleNodeSnapshotList = vehicleNodeSnapshotList;
    }*/
}
