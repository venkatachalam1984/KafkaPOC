package com.ford.gvmsr.snapobserver.data.entity.transaction;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="PGVMT06_TXN_ERR")
public class TransactionError extends BaseEntity {

    @Id
    @Column (name="GVMT06_TXN_ERROR_D")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMT06_TXN_ERROR_D_SQ_GEN")
    @SequenceGenerator(name = "PGVMT06_TXN_ERROR_D_SQ_GEN", sequenceName = "PGVMT06_TXN_ERROR_D_SQ", allocationSize = 1)
    private Long transactionErrorId;

    @ManyToOne
    @JoinColumn (name="GVMT01_TXN_D", referencedColumnName = "GVMT01_TXN_D", insertable = true, updatable = false)
    private Transaction transactionId;

    @ManyToOne
    @JoinColumn (name="GVMT03_TXN_DTL_D", referencedColumnName = "GVMT03_TXN_DTL_D", insertable = true, updatable = false)
    private TransactionDetail transactionDetailId;

    @Column(name="GVMT06_ERR_S")
    private Timestamp transactioErrorTime;

    @Column(name="GVMT06_ERR_C")
    private String transactionErrorCode;

    @Column(name="GVMT06_ERR_STRING_X")
    private String transactionErrorDesc;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT06_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT06_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT06_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT06_LAST_UPDT_S"))}
    )


    private AuditColumns auditColumns = new AuditColumns();

    public Long  getTransactionErrorId() {
        return transactionErrorId;
    }

    public void setTransactionErrorId(Long transactionErrorId) {
        this.transactionErrorId = transactionErrorId;
    }

    public Transaction getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Transaction transactionId) {
        this.transactionId = transactionId;
    }

    public TransactionDetail getTransactionDetailId() {
        return transactionDetailId;
    }

    public void setTransactionDetailId(TransactionDetail transactionDetailId) {
        this.transactionDetailId = transactionDetailId;
    }

    public Timestamp getTransactioErrorTime() {
        return transactioErrorTime;
    }

    public void setTransactioErrorTime(Timestamp transactioErrorTime) {
        this.transactioErrorTime = transactioErrorTime;
    }

    public String getTransactionErrorCode() {
        return transactionErrorCode;
    }

    public void setTransactionErrorCode(String transactionErrorCode) {
        this.transactionErrorCode = transactionErrorCode;
    }

    public String getTransactionErrorDesc() {
        return transactionErrorDesc;
    }

    public void setTransactionErrorDesc(String transactionErrorDesc) {
        this.transactionErrorDesc = transactionErrorDesc;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }
}
