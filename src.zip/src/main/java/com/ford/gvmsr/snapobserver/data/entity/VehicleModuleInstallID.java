package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NPOSANI on 11/7/2017.
 */
@Embeddable
public class VehicleModuleInstallID implements Serializable {

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    @Column(name = "GVMS10_VIN_R")
    private String vin;

    /*@EmbeddedId
    private VehicleId vehicleId;*/

    @Column(name = "GVM023_NODE_ADRS_C")
    private String nodeAddress;

    @Column(name = "GVMS21_ESN_R")
    private String eserialno;


    @Column(name = "GVMS21_MOD_INSTALL_S")
    private Timestamp moduleInstallTimeStamp;


    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    /*public VehicleId getVehicleId() {
        return this.vehicleId;
    }

    public void setVehicleId(VehicleId vehicleId) {
        this.vehicleId = vehicleId;
    }*/

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getEserialno() {
        return eserialno;
    }

    public void setEserialno(String eserialno) {
        this.eserialno = eserialno;
    }

    public Timestamp getModuleInstallTimeStamp() {
        return moduleInstallTimeStamp;
    }

    public void setModuleInstallTimeStamp(Timestamp moduleInstallTimeStamp) {
        this.moduleInstallTimeStamp = moduleInstallTimeStamp;
    }
}
/*
    create table DBO.PGVMS21_VEH_MOD_INSTALL (
    GVMS10_VIN_HASH_R    numeric(2)           not null,
    GVMS10_VIN_R         varchar(17)          not null,
    GVM023_NODE_ADRS_C   varchar(4)           not null,
    GVMS21_ESN_R         varchar(8)           not null,
    GVMS21_MOD_INSTALL_S datetime             not null,
    GVM019_ECU_ACRONYM_C varchar(20)          not null,
    GVMS21_MOD_UNINSTALL_S datetime             null,
    GVMS21_CREATE_USER_C varchar(8)           not null,
    GVMS21_CREATE_S      datetime             not null default getdate(),
    GVMS21_LAST_UPDT_USER_C varchar(8)           not null,
    GVMS21_LAST_UPDT_S   datetime             not null default getdate()
)*/