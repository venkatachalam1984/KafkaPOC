package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by MJAFARUL on 11/13/2017.
 */
@Embeddable
public class VehicleNodeDIDComplianceId implements Serializable {

/*    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;*/

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "GVMS02_VEH_NODE_DID_RSPNS_K", referencedColumnName = "GVMS02_VEH_NODE_DID_RSPNS_K"),
            @JoinColumn(name = "GVMS10_VIN_HASH_R", referencedColumnName = "GVMS10_VIN_HASH_R")
    })
    private VehicleNodeDIDResponse vehicleNodeDIDResponse;

    @Column(name = "GVM011_DID_CATLG_D")
    private String didCatalog;

   /* public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }*/

    public VehicleNodeDIDResponse getVehicleNodeDIDResponse() {
        return vehicleNodeDIDResponse;
    }

    public void setVehicleNodeDIDResponse(VehicleNodeDIDResponse vehicleNodeDIDResponse) {
        this.vehicleNodeDIDResponse = vehicleNodeDIDResponse;
    }

    public String getDidCatalog() {
        return didCatalog;
    }

    public void setDidCatalog(String didCatalog) {
        this.didCatalog = didCatalog;
    }
}
