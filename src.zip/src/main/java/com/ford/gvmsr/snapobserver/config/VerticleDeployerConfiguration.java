package com.ford.gvmsr.snapobserver.config;

import com.ford.gvmsr.snapobserver.kafka.consumer.GVMSRSnapshotRequestConsumer;
import com.ford.gvmsr.snapobserver.kafka.producer.GVMSRExceptionEventProducer;
import com.ford.gvmsr.snapobserver.kafka.producer.GVMSRSnapshotResponseProducer;
import com.ford.gvmsr.snapobserver.kafka.producer.GVMSRSnapshotSyncupProducer;
import com.ford.gvmsr.snapobserver.verticle.IndexedSnapRequestHandler;
import io.vertx.core.DeploymentOptions;
import io.vertx.core.Verticle;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class VerticleDeployerConfiguration {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    Vertx vertx = null;

    @Autowired
    GVMSRSnapshotRequestConsumer gvmsrSnapshotRequestConsumer;

    @Autowired
    GVMSRSnapshotResponseProducer gvmsrSnapshotResponseProducer;

    @Autowired
    GVMSRSnapshotSyncupProducer gvmsrSnapshotSyncupProducer;

    @Autowired
    GVMSRExceptionEventProducer gvmsrExceptionEventProducer;

    @Autowired
    VertxConfiguration vertxConfiguration;

    @EventListener({ ApplicationReadyEvent.class })
    public void deployVerticles() {
        vertx = Vertx.vertx(getVertxOptions());
        deploySnapObserverKafkaVerticles();
        deployIndexedSnapRequestVerticles();
    }

    public VertxOptions getVertxOptions() {

        VertxOptions options = new VertxOptions();
        options.setMaxEventLoopExecuteTime(vertxConfiguration.getVertxEventLoopExecutionTimeInSecs());
        options.setMaxEventLoopExecuteTimeUnit(TimeUnit.SECONDS);
        options.setMaxWorkerExecuteTime(vertxConfiguration.getVertxWorkerExecutionTimeInSecs());
        options.setMaxWorkerExecuteTimeUnit(TimeUnit.SECONDS);
        options.setBlockedThreadCheckInterval(vertxConfiguration.getThreadBlockedCheckInterval());
        options.setBlockedThreadCheckIntervalUnit(TimeUnit.SECONDS);
        options.setWarningExceptionTime(vertxConfiguration.getVertxThreadExecutionLimit());
        options.setWarningExceptionTimeUnit(TimeUnit.SECONDS);
        return options;

    }

    public void deploySnapObserverKafkaVerticles() {
        //standard loop verticle
        deployVerticle(gvmsrSnapshotRequestConsumer);
        deployVerticle(gvmsrSnapshotResponseProducer);
        deployVerticle(gvmsrSnapshotSyncupProducer);
        deployVerticle(gvmsrExceptionEventProducer);
    }

    private void deployVerticle(Verticle verticle) {
        String className = verticle.getClass().getCanonicalName();
        vertx.deployVerticle(verticle, result -> {
            if (result.failed()) {
                logger.error("Failed to deploy verticle = {}, Cause = {}", className, result.cause());
            } else {
                logger.debug("Deployed verticle = " + className);
            }
        });

    }

    private void deployIndexedSnapRequestVerticles() {
        //Thread pool verticle
        DeploymentOptions options = new DeploymentOptions();
        options.setWorkerPoolSize(1);
        options.setWorker(Boolean.TRUE);
        for (int i = 0; i < vertxConfiguration.getWorkerVerticleCount(); i++) {
            options.setWorkerPoolName("observer-" +i);
            deployWorkerVerticle(new IndexedSnapRequestHandler(i), options,
                    IndexedSnapRequestHandler.class.getCanonicalName());
        }

    }

    private void deployWorkerVerticle(Verticle verticle, DeploymentOptions options, String name) {

        vertx.deployVerticle(verticle, options, result -> {
            if (result.failed()) {
                logger.error("Failed to deploy worker verticle = {}, Cause = {}", name, result.cause());
            } else {
                logger.debug("Deployed worker verticle = " + name);
            }
        });

    }


}