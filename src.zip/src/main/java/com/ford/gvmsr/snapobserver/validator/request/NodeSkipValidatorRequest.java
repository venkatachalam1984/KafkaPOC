package com.ford.gvmsr.snapobserver.validator.request;

import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.modulestate.request.GatewayType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

@Builder
@Data
public class NodeSkipValidatorRequest {

    ModuleSnapshotObserverRequest snapshotObserverRequest;
    ModuleNodeType node;
    PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode;
    AtomicBoolean isF17FDid;
    GatewayType gatewayType;
    Set<String> mandatoryDidList;
    Set<String> strategyDidList;
    Set<String> esnDidList;
    List<String> prevNonConfigDIDList;





}
