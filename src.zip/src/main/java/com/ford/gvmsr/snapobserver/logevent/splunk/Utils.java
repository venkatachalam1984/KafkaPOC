package com.ford.gvmsr.snapobserver.logevent.splunk;

import com.ford.gvmsr.snapobserver.constants.SnapConstants;
import com.ford.gvmsr.snapobserver.constants.VilConstants;
import io.vertx.kafka.client.consumer.KafkaConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;

@Component
public class Utils {

    private final Logger logger = LoggerFactory.getLogger(Utils.class);

    @Autowired
    private SplunkEventSender splunkEventSender;

    @Value("${splunk.hec.call.flag}")
    private boolean splunkHecCallFlag;


    public void prepareSnapObserverToConfirmerLogEvent(String vin, String traceId, String type, String status, String duration,
                                                       String node, String sourcetype, long timestamp, String errorDesc) {
        if(splunkHecCallFlag){
            try {
                AppLogEvent appLogEvent = prepareAppLogEventWithDesc(vin, traceId, type, status, duration, node, timestamp, errorDesc) ;
                splunkEventSender.postToHEC(appLogEvent, VilConstants.SNAP_OBSERVER, sourcetype);
            } catch (Exception ex) {
                logger.error("Error while sending postToHEC Service = {}  Exception = {} ", VilConstants.SNAP_OBSERVER, ex.getMessage());
            }
        } else {
            logger.info("Splunk log is disabled");
        }
    }

    public void prepareSNAPLogEvent(String vin, String node, String traceId, String type, String status, String duration, long timestamp, String errorDesc){
        if(splunkHecCallFlag) {
            try {
                AppLogEvent appLogEvent = prepareAppLogEventWithDesc(vin, traceId, type, status, duration, node, timestamp, errorDesc);
                splunkEventSender.postToHEC(appLogEvent,SnapConstants.SNAP_OBSERVER, SnapConstants.SNP_TRKG_MSG);
            }catch (Exception ex){
                logger.error("Error while sending postToHEC : "+ SnapConstants.SNP_TRKG_MSG);
            }
        }

    }

    public void prepareSYNCLogEvent(String vin, String traceId, String type, String status, String duration, long timestamp){
        if(splunkHecCallFlag) {
            try {
                AppLogEvent appLogEvent = prepareAppLogEvent(vin, traceId, type, status, duration, null, timestamp);
                splunkEventSender.postToHEC(appLogEvent, SnapConstants.SNAP_OBSERVER, SnapConstants.SYNC_TRKG_MSG);
            }catch (Exception ex){
                logger.error("Error while sending postToHEC : "+ SnapConstants.SYNC_TRKG_MSG);
            }
        }
    }

    public void  prepareSnapVINLogEvent(String vin, String traceId, String type, String status, String duration, long timestamp, String errorDesc){
        if(splunkHecCallFlag){
            try {
                AppLogEvent appLogEvent = prepareAppLogEventWithDesc(vin, traceId, type, status, duration, null, timestamp, errorDesc);
                splunkEventSender.postToHEC(appLogEvent, SnapConstants.SNAP_OBSERVER, SnapConstants.SNP_VIN_TRKG_MSG);
            }catch (Exception ex){
                logger.error("Error while sending postToHEC : "+ SnapConstants.SNP_VIN_TRKG_MSG);
            }
        }
    }

    public void postKafkaLogEvent(String vin, KafkaConsumerRecord<String, String> record) {
        if(splunkHecCallFlag){
            try {
                KafkaLogEvent kafkaLogEvent = prepareKafkaLogEvent(vin, record); ;
                splunkEventSender.postToHEC(kafkaLogEvent, VilConstants.SNAP_OBSERVER, SnapConstants.CONSUMER_TRKG_MSG);
            } catch (Exception ex) {
                logger.error("Error while sending postToHEC Service = {}  Exception = {} ", VilConstants.SNAP_OBSERVER, ex.getMessage());
            }
        } else {
            logger.info("Splunk log is disabled");
        }
    }

    private AppLogEvent prepareAppLogEvent(String vin, String traceId, String type, String status, String duration,String node, long timestamp)
    {
        AppLogEvent appLogEvent = new AppLogEvent();
        appLogEvent.setTraceId(traceId);
        appLogEvent.setDuration(duration);
        appLogEvent.setType(type);
        appLogEvent.setStatus(status);
        appLogEvent.setVin(vin);
        appLogEvent.setNode(node);
        appLogEvent.setTimeStamp(timestamp);
        return appLogEvent;
    }

    private AppLogEvent prepareAppLogEventWithDesc(String vin, String traceId, String type, String status, String duration, String node, long timestamp, String errorDesc) {
        AppLogEvent appLogEvent = new AppLogEvent();
        appLogEvent.setTraceId(traceId);
        appLogEvent.setDuration(duration);
        appLogEvent.setType(type);
        appLogEvent.setStatus(status);
        appLogEvent.setVin(vin);
        appLogEvent.setNode(node);
        appLogEvent.setTimeStamp(timestamp);
        appLogEvent.setErrorDesc(errorDesc);
        return appLogEvent;
    }

    private KafkaLogEvent prepareKafkaLogEvent(String vin, KafkaConsumerRecord<String, String> record){
        KafkaLogEvent kafkaLogEvent = KafkaLogEvent.builder().vin(vin)
                .consumedTime(new Timestamp(System.currentTimeMillis()).getTime()).producedTime(record.timestamp())
                .topic(record.topic()).partition(record.partition()).build();
        return kafkaLogEvent;
    }
}
