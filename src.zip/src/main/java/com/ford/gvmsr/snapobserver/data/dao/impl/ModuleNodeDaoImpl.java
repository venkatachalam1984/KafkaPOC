package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.ModuleNodeDao;
import com.ford.gvmsr.snapobserver.data.entity.ModuleNode;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.repository.ModuleNodeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ModuleNodeDaoImpl implements ModuleNodeDao {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ModuleNodeRepository moduleNodeRepository;

    private DataSource dataSource;

    public ModuleNodeDaoImpl(@Qualifier("dataSource") DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void saveModuleNode(ModuleNode moduleNodeEntity) throws Exception {
        long start = System.currentTimeMillis();

        Connection conn = null;
        PreparedStatement preparedStatement = null;
        try {
            //--AL 04 Table Active Flag Changes--
            //Sequence Native Query
            moduleNodeEntity.setModNodeSaKey(moduleNodeRepository.getModuleNodeKey());
            final String INSERT_VEH_NODE_SNAPSHOT = "insert into PGVMS14_MOD_NODE values(?,?,?,?,?,?,?,?,'GVMS',?,'GVMS',?)";
            //STEP 3: Open a connection
            conn = dataSource.getConnection();
            //STEP 4: Execute a query
            preparedStatement = conn.prepareStatement(INSERT_VEH_NODE_SNAPSHOT);
            conn.setAutoCommit(false);
            preparedStatement.setLong(1, moduleNodeEntity.getModNodeSaKey());
            preparedStatement.setString(2, moduleNodeEntity.getIvsProgramId().getProgramCode());
            preparedStatement.setFloat(3, moduleNodeEntity.getIvsProgramId().getSalesModelYear());
            preparedStatement.setString(4, moduleNodeEntity.getNodeAddress());
            preparedStatement.setString(5, moduleNodeEntity.getGwNodeId());
            preparedStatement.setString(6, moduleNodeEntity.getSourceSystem());
            preparedStatement.setString(7, moduleNodeEntity.getModuleCpuType());
            preparedStatement.setString(8, moduleNodeEntity.getGatewayType());
            preparedStatement.setTimestamp(9, new Timestamp(new Date().getTime()));
            preparedStatement.setTimestamp(10, new Timestamp(new Date().getTime()));
            preparedStatement.executeUpdate();
            conn.commit();
            preparedStatement.close();
            conn.close();
        } catch (Exception e) {
            // e.printStackTrace();
            moduleNodeEntity.setModNodeSaKey(null);
        } finally {
            //finally block used to close resources
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } catch (SQLException se2) {
            }// nothing we can do
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                //  se.printStackTrace();
            }//end finally try
        }
        long end = System.currentTimeMillis() - start;
        logger.debug("Time taken to save saveModuleNode:::" + end);
    }

    @Override
    public List<ModuleNode> retrieveModuleNodeList(Vehicle vehicleEntity) throws Exception {
        long start = System.currentTimeMillis();

        List<ModuleNode> moduleNodeList = moduleNodeRepository.findAllByIvsProgramId_ProgramCodeAndIvsProgramId_SalesModelYear(
                vehicleEntity.getIvsProgramId().getProgramCode(),
                new Float(vehicleEntity.getIvsProgramId().getSalesModelYear()));
        logger.debug("retrieveModuleNode : " + vehicleEntity.getIvsProgramId().getProgramCode() + "/" + vehicleEntity.getIvsProgramId().getSalesModelYear() + "/");
        long end = System.currentTimeMillis() - start;
        logger.debug("Time taken retrieveModuleNode::::::" + end);
        return moduleNodeList;
    }

    @Override
    public ModuleNode findModuleNodeBy(String programCode, Float salesModelYear, String nodeAddress, String gwNodeId) throws Exception{
        ModuleNode moduleNode = moduleNodeRepository.findModuleNodeByIvsProgramId_ProgramCodeAndIvsProgramId_SalesModelYearAndNodeAddressAndGwNodeId(programCode, salesModelYear, nodeAddress, gwNodeId);
        return moduleNode;
    }

    //added for taking provisionFlag for previous snap

    @Override
    public Map<String, String> getProvisionFlagForAllNode(int vinHash, String vin, String PAAK_PROVISION_NODES) {
        long start = System.currentTimeMillis();
        Map<String, String> nodeProvisionMap = new HashMap<>();
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        try {
            conn = dataSource.getConnection();
            final String FETCH_PROVISION_FLAG_FOR_ALL_NODE = "SELECT GVM023_NODE_ADRS_C,GVMS04_IS_PROVISIONED_F FROM PGVMS04_VEH_NODE_SNPSHT \n" +
                    "WHERE GVMS10_VIN_HASH_R=?\n" +
                    "AND GVMS10_VIN_R=?\n" +
                    "AND GVM023_NODE_ADRS_C IN(" + convertString(PAAK_PROVISION_NODES) + ")\n" +
                    "AND GVMS04_ACTIVE_F='A'";
            preparedStatement = conn.prepareStatement(FETCH_PROVISION_FLAG_FOR_ALL_NODE);
            preparedStatement.setInt(1, vinHash);
            preparedStatement.setString(2, vin);
            //preparedStatement.setString(3, convertString(PAAK_PROVISION_NODES));
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                nodeProvisionMap.put(resultSet.getString(1), resultSet.getString(2));
            }
            preparedStatement.close();
            conn.close();
            resultSet.close();
        } catch (SQLException se) {
            //Handle errors for JDBC
            logger.error(se.getMessage(), this.getClass().getSimpleName());
        } catch (Exception e) {
            logger.error(e.getMessage(), this.getClass().getSimpleName());
        } finally {
            //finally block used to close resources
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } catch (SQLException se2) {
            }// nothing we can do
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                logger.error(se.getMessage(), this.getClass().getSimpleName());
            }//end finally try
        }
        long end = System.currentTimeMillis() - start;
        logger.debug("Time taken to update all the getProvisionFlagForAllNode :::" + end);
        return nodeProvisionMap;
    }

    public String convertString(String nodes) {
        if (!StringUtils.isEmpty(nodes)) {
            String nodeListStr = "";
            String[] nodeArray = nodes.split(",");
            for (String s : nodeArray) {
                if (!StringUtils.isEmpty(s)) {
                    nodeListStr = nodeListStr + "'" + s + "'" + ",";
                }
            }
            if (!StringUtils.isEmpty(nodeListStr)) {
                return nodeListStr.substring(0, nodeListStr.length() - 1);
            } else {
                return null;
            }
        } else
            return null;
    }
}
