package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDStatus;

import java.sql.Timestamp;
import java.util.List;

public interface VehicleNodeDIDStatusDao {
    void persistVehicleStateList(List<VehicleNodeDIDStatus> vehicleNodeDIDStatusList, Timestamp vinRecordedTimestamp);
    List<VehicleNodeDIDStatus> fetchAllCurrentlyInstalledSoftwares(int vinHash, String vin, String swState);
}
