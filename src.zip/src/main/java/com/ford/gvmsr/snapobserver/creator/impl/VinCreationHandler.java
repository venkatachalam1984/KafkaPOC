package com.ford.gvmsr.snapobserver.creator.impl;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.constants.VilConstants;
import com.ford.gvmsr.snapobserver.creator.VinCreator;
import com.ford.gvmsr.snapobserver.data.dao.VinProgramMapDao;
import com.ford.gvmsr.snapobserver.data.entity.VINProgramMap;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleId;
import com.ford.gvmsr.snapobserver.enums.SnapSource;
import com.ford.gvmsr.snapobserver.exception.GVMSValidationException;
import com.ford.gvmsr.snapobserver.exception.ServiceFault;
import com.ford.gvmsr.snapobserver.exception.ServiceFaultException;
import com.ford.gvmsr.snapobserver.externalservice.ExternalService;
import com.ford.gvmsr.snapobserver.handler.SnapshotSaveHandler;
import com.ford.gvmsr.snapobserver.logevent.LogEventMonitor;
import com.ford.gvmsr.snapobserver.logevent.LogType;
import com.ford.gvmsr.snapobserver.modulestate.request.RoleSourceENUMType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

import static com.ford.gvmsr.snapobserver.constants.SnapConstants.INVALID_INPUT;

@Service
public class VinCreationHandler implements VinCreator {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    ExternalService externalService;

    @Autowired
    SnapshotSaveHandler snapshotSaveHandler;

    @Autowired
    VinProgramMapDao vinProgramMapDao;

    @Autowired
    LogEventMonitor logEventMonitor;


    @Override
    public Vehicle createVin(String vin, RoleSourceENUMType roleSourceENUMType) {
        long start = System.currentTimeMillis();
        Vehicle vehicle = null;
        try {
            int vinHash = ApplicationUtils.getVinHash(vin);
            LOGGER.trace("Checking if VIN={} exist in DB PGVMS10_VEH", vin);
            Optional<Vehicle> optionalVehicle = snapshotSaveHandler.getByVinAndVinHash(vin, vinHash);

            if (optionalVehicle.isPresent()) {
                vehicle = optionalVehicle.get();
            } else {
                LOGGER.debug("VIN ={} not found in PGVMS10_VEH. Creating new Record", vin);
                Optional<Vehicle> vinFromGivis = externalService.getVinFromGivis(vin);
                if (vinFromGivis.isPresent()) {
                    vehicle = vinFromGivis.get();
                }
            }

            if (vehicle == null || (vehicle != null && vehicle.getIvsProgramId() == null)) {
                vehicle = saveNewVehicle(vin, vinHash);
                if (vehicle != null) {
                    vehicle.setSaveFlag(true);
                }
            }
        } catch (GVMSValidationException e) {
            LOGGER.error("EXCEPTION.. NOT ABLE TO Determine PCMY for this VIN {}. Throw Exception ", vin);
            long end = System.currentTimeMillis();
            String duration = CommonUtils.millisecondsToSeconds(end - start);
            logEventMonitor.LogEvent(roleSourceENUMType.name(), vin, null, MDC.get(GVMSModuleUpdateConstants.API_REQUEST_ID), LogType.FATAL,
                    VilConstants.VIN_CREATION_ERROR, duration, CommonUtils.getEventTimeStamp(), e.getMessage());
            String validationErrorMessage = "No available IVS Program base on vin: " + (vin != null ? vin : "");
            throw new ServiceFaultException(validationErrorMessage, new ServiceFault(
                    INVALID_INPUT, validationErrorMessage));
        }

        return vehicle;
    }

    private Vehicle saveNewVehicle(String vin, int vinHash) throws GVMSValidationException {
        Vehicle vehicleEntity = null;
        VINProgramMap vinProgramMap = determineVINProgramMap(vin);
        if (vinProgramMap != null) {
            Vehicle vehicleEnty = new Vehicle();
            VehicleId vehicleId = new VehicleId();
            vehicleId.setVin(vin);
            vehicleId.setVinHashNumber(vinHash);
            vehicleEnty.setVehicleId(vehicleId);
            vehicleEnty.setProgramMapCounter(vinProgramMap.getVinProgramMapId().getProgramMapCounter());
            vehicleEnty.setIvsProgramId(vinProgramMap.getVinProgramMapId().getIvsProgramId());
            vehicleEntity = snapshotSaveHandler.saveVehicle(vehicleEnty);
        } else {
            throw new GVMSValidationException("No available IVS Program base on vin");
        }
        return vehicleEntity;
    }

    private VINProgramMap determineVINProgramMap(String vin) {
        VINProgramMap vinMap = null;
        List<VINProgramMap> vinProgramMaps = vinProgramMapDao.getVinMapExpressionByVin(vin);
        if (!CollectionUtils.isEmpty(vinProgramMaps)) {
            for (VINProgramMap vinProgramMap : vinProgramMaps) {
                if (vin.matches(vinProgramMap.getVinMapExpression())) {
                    vinMap = vinProgramMap;
                    break;
                }
            }
        }
        return vinMap;
    }
}
