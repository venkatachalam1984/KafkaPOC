package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class NetworkNameCheckRule {

    private static final Logger logger = LoggerFactory.getLogger(NetworkNameCheckRule.class);

    public void validateNetworkName(ModuleSnapshotObserverRequest snapshotObserverRequest,
                                    PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode,
                                    ModuleNodeType node){
        logger.debug(" Inside validateNetworkName for Request NetworkName = {}", node.getODLNetwork().getNetworkName());
        String prevNetworkName = previousSnapShotDetailsByNode.getPrevNetworkName();
        String newNetWorkName = node.getODLNetwork().getNetworkName();
        if (newNetWorkName != null && prevNetworkName != null &&
                !prevNetworkName.equalsIgnoreCase(newNetWorkName)) {
            snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.NODE, TrackingType.NETWORK_NAME, true);
        }
    }

}
