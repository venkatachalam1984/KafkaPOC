package com.ford.gvmsr.snapobserver.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by tanbuche on 9/25/2017.
 */
public class GVMSSelfLoggingException extends Exception{


    private static final String NEWLINE = "\n";

    @Autowired
    private ExceptionHandler exceptionHandler;


    public GVMSSelfLoggingException(String className, String methodName, String customMsg){

        super(customMsg);
  /*      super.getMessage();
        super.printStackTrace();*/

    }

    public GVMSSelfLoggingException(String customMsg){

        super(customMsg);

    }


    public GVMSSelfLoggingException(String className, String methodName, String customMsg, String expMsg){

        super.getMessage();
        // super.printStackTrace();
        exceptionHandler.logException(GVMSSelfLoggingException.this,this.getClass().getSimpleName());


    }

    public GVMSSelfLoggingException(String className, String methodName, String customMsg, boolean isLogging){

        this.logException(className,methodName,customMsg);
    }

    public GVMSSelfLoggingException(String className, String methodName, String customMsg, String expMsg, boolean isLogging){

        String newCustomMsg = buildCustomMessage(customMsg, expMsg);

        this.logException(className,methodName,newCustomMsg);

    }

    public GVMSSelfLoggingException(String className, String methodName, String customMsg, Throwable throwable){

        super.getMessage();
        super.printStackTrace();
    }

    public GVMSSelfLoggingException(String className, String methodName, String customMsg, String expMsg, Throwable throwable){

        super.getMessage();
       // super.printStackTrace();
        exceptionHandler.logException(GVMSSelfLoggingException.this,this.getClass().getSimpleName());
    }

    public GVMSSelfLoggingException(String className, String methodName, String customMsg, String expMsg, Throwable throwable, boolean isLogging){

        String newCustomMsg = buildCustomMessage(customMsg, expMsg);

        this.logException(className,methodName,newCustomMsg);

    }


    public void logException(String className,String methodName,String msg)
    {
        // Initialize the logger instance.
        Logger logger = LoggerFactory.getLogger(className);

        // Log the error msg values
        logger.error("Error occured while processing",className,methodName,msg);

    }

    protected String buildCustomMessage(
            String customMsg,
            String expMsg) {

        String newMsg = customMsg;
        if (expMsg != null && expMsg.length() > 0) {
            newMsg = newMsg + NEWLINE + expMsg;
        }

        return newMsg;
    }


}
