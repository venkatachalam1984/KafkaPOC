package com.ford.gvmsr.snapobserver.exception.alarmevents;


public class ExceptionEventConstants {

    public static final String SUCCESS = "SUCCESS";
    public static final String ERROR = "ERROR";
    public static final String APPLICATION = "Application";
    public static final String CLEAR = "CL01";
    public static final String YES = "Y";
    public static final String NO = "N";

    //VIL service exception event code
    public static final String VL01_EVENT_CODE = "VL01"; //Invalid Assembly/Hardware - VIL Service

    public static final String NO_MFR_ECU = "Matching supplier ECU is not found for the ESN";//Changed the string for Alarms2

    public static final String HARDWARE_PART_NULL = "Hardware part is null. ";
    public static final String IMAGE_PART_NULL = "Image part is null. ";
    public static final String STRATEGY_PART_NULL = "Strategy part is null. ";
    public static final String INVALID_STRING = " is invalid. ";
    public static final String INVALID_HARDWARE_PART = "Hardware Part : ";
    public static final String INVALID_IMAGE_PART = "Image Part : ";
    public static final String INVALID_STRATEGY_PART = "Strategy Part : ";
    public static final String DISSOCIATION = "Dissociation is done for the VIN and ESN";
    public static final String VIL = "VIL";

}
