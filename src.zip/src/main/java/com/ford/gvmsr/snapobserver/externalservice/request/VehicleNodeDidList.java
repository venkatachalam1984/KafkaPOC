
package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "programCode",
    "salesModelYear",
    "VehicleNode"
})
public class VehicleNodeDidList {

    /**
     * The Activedatasetpartitionkey Schema.
     * <p>
     * An explanation about the purpose of this instance.
     * (Required)
     * 
     */
    @JsonProperty("programCode")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String programCode = "";
    /**
     * The Ivsxmlinfokey Schema.
     * <p>
     * An explanation about the purpose of this instance.
     * (Required)
     * 
     */
    @JsonProperty("salesModelYear")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private float salesModelYear;

    @JsonProperty("VehicleNode")
    private List<VehicleNode> vehicleNode = null;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * The Activedatasetpartitionkey Schema.
     * <p>
     * An explanation about the purpose of this instance.
     * (Required)
     * 
     */
    @JsonProperty("programCode")
    public String getProgramCode() {
        return programCode;
    }

    /**
     * The Activedatasetpartitionkey Schema.
     * <p>
     * An explanation about the purpose of this instance.
     * (Required)
     * 
     */
    @JsonProperty("programCode")
    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    /**
     * The Ivsxmlinfokey Schema.
     * <p>
     * An explanation about the purpose of this instance.
     * (Required)
     * 
     */

    public float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public List<VehicleNode> getVehicleNode() {
        return vehicleNode;
    }

    public void setVehicleNode(List<VehicleNode> vehicleNode) {
        this.vehicleNode = vehicleNode;
    }

    public Map<String, Object> getAdditionalProperties() {
        return additionalProperties;
    }

    public void setAdditionalProperties(Map<String, Object> additionalProperties) {
        this.additionalProperties = additionalProperties;
    }
}
