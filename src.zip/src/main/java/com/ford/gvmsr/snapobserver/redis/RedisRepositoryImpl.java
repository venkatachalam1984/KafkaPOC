
package com.ford.gvmsr.snapobserver.redis;

/**
 * Created by sjagad13 on 10/26/2017.
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Repository
public class RedisRepositoryImpl implements RedisRepository {

    Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier("strRedisTemplate")
    private RedisTemplate<String, String> strRedisTemplate;

    @Autowired
    private OpsForString opsForString;

    @Override
    public OpsForString opsForString() {
        return this.opsForString;
    }

    /* ================== Beans ================== */
    @Bean
    public OpsForString initOpsForString() {
        return new OpsForStringImpl();
    }

    /* ================== filter operations ================== */
    public boolean incrementIfPresentSetIfAbsent(String key, long duration, TimeUnit timeUnit, int maxCount) {
        try {
            String val = strRedisTemplate.boundValueOps(key).get();
            /*log.info("val = " + val);*/
            if (StringUtils.isEmpty(val)) {
                strRedisTemplate.boundValueOps(key).set("1", duration, timeUnit);
                return true;
            } else if (Integer.valueOf(val) < maxCount) {
                strRedisTemplate.boundValueOps(key).increment(1);
                return true;
            }
        } catch (Exception e) {
            log.error("Redis Error: Error in incrementIfPresentSetIfAbsent || msg: " + e.getMessage());
            /* To prevent request from being rate limited in case any exception occurs. */
            return true;
        }
        return false;
    }

    /* ================== string ops ==================  */
    public class OpsForStringImpl implements RedisRepository.OpsForString {

        @Override
        public boolean setKey(String key, String value) {
            try {
                if (!StringUtils.isEmpty(key) && !StringUtils.isEmpty(value)) {
                    strRedisTemplate.opsForValue().set(key, value);
                    return true;
                }
            } catch (Exception e) {
                log.error("Redis Error: Error in OpsForStringImpl.setKey || msg: " + e.getMessage());
            }
            return false;
        }

        @Override
        public boolean delKey(String key) {
            try {
                if (!StringUtils.isEmpty(key)) {
                    strRedisTemplate.delete(key);
                    return true;
                }
            } catch (Exception e) {
                log.error("Redis Error: Error in OpsForStringImpl.delKey || msg: " + e.getMessage());
            }
            return false;
        }

        @Override
        public String getKey(String key) {
            String value = "";
            try {
                if (!StringUtils.isEmpty(key)) {
                    value = strRedisTemplate.opsForValue().get(key);
                }
            } catch (Exception e) {
                log.error("Redis Error: Error in OpsForStringImpl.getKey || msg: " + e.getMessage());
            }
            return value;
        }

        @Override
        public boolean delMultiKeys(List<String> keyList) {
            try {
                if (keyList != null && !keyList.isEmpty()) {
                    strRedisTemplate.delete(keyList);
                    return true;
                }
            } catch (Exception e) {
                log.error("Redis Error: Error in OpsForStringImpl.delMultiKeys || msg: " + e.getMessage());
            }
            return false;
        }

        @Override
        public void setMultiKeys(Map<String, String> keyValueMap) {
            try {
                if (keyValueMap != null && !keyValueMap.isEmpty()) {
                    strRedisTemplate.opsForValue().multiSet(keyValueMap);
                }
            } catch (Exception e) {
                log.error("Redis Error: Error in OpsForStringImpl.setMultiKeys || msg: " + e.getMessage());
            }
        }

    }

}


