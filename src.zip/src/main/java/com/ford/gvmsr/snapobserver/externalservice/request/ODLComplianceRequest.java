package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.List;

//@JsonTypeInfo(include= JsonTypeInfo.As.WRAPPER_OBJECT, use= JsonTypeInfo.Id.NAME)
public class ODLComplianceRequest {

    private String programCode;
    private float salesModelYear;
    private String vehicleNodeDIDId;
    private String nodeAddress;
    private String network;
    private List<String> complianceDIDList;

    public List<String> getComplianceDIDList() {
        return complianceDIDList;
    }

    public void setComplianceDIDList(List<String> complianceDIDList) {
        this.complianceDIDList = complianceDIDList;
    }

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public String getVehicleNodeDIDId() {
        return vehicleNodeDIDId;
    }

    public void setVehicleNodeDIDId(String vehicleNodeDIDId) {
        this.vehicleNodeDIDId = vehicleNodeDIDId;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getNetwork() {
        return network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }
}
