package com.ford.gvmsr.snapobserver.exception;

public class SnapObserverRuntimeException extends RuntimeException {

    public SnapObserverRuntimeException(String string){
        super(string);
    }
}
