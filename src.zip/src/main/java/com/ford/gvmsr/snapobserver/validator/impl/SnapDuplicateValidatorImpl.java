package com.ford.gvmsr.snapobserver.validator.impl;

import com.ford.gvmsr.snapobserver.constants.SnapConstants;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.exception.ServiceFault;
import com.ford.gvmsr.snapobserver.exception.ServiceFaultException;
import com.ford.gvmsr.snapobserver.handler.CopyDidRuleHandler;
import com.ford.gvmsr.snapobserver.handler.PreviousSnapShotHandler;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleStateRequest;
import com.ford.gvmsr.snapobserver.validator.SnapDuplicateValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class SnapDuplicateValidatorImpl implements SnapDuplicateValidator {

    private static final Logger logger = LoggerFactory.getLogger(SnapDuplicateValidatorImpl.class);

    @Autowired
    private PreviousSnapShotHandler previousSnapShotHandler;

    @Autowired
    CopyDidRuleHandler copyDidRuleHandler;

    @Autowired
    ExceptionHandler exceptionHandler;

    @Override
    public Map<String, NodeAndDIDResponseForNewSnap> validateDidResponseForNodes(ModuleSnapshotObserverRequest snapshotObserverRequest, Vehicle vehicle){
        logger.debug("SnapDupValidator:Start validateDidResponseForNodes for the VIN : "+ snapshotObserverRequest.getVin());
        Map<String, NodeAndDIDResponseForNewSnap> nodeAndDIDResponseForNewSnapMap = new HashMap<>();
        try {
            ModuleStateRequest moduleStateRequest = snapshotObserverRequest.getModuleStateRequest();
            PreviousSnapShotDetails previousSnapShotDetails = previousSnapShotHandler.populatePreviousSnapDetails(moduleStateRequest);
            snapshotObserverRequest.setPreviousSnapShotDetails(previousSnapShotDetails);

            for (ModuleNodeType moduleNodeType : moduleStateRequest.getModuleSnapshot().getNode()) {

                String nodeAddress = moduleNodeType.getAddress();
                PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode = previousSnapShotHandler.getPreviousSnapShotDetailsForNode(nodeAddress, previousSnapShotDetails);

                    NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap = copyDidRuleHandler.compareAndCopyDIDsFromPreviousSnap(snapshotObserverRequest,
                            moduleNodeType, previousSnapShotDetailsByNode);

                    if (nodeAndDIDResponseForNewSnap != null && !nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList().isEmpty()) {
                        nodeAndDIDResponseForNewSnap.setPaakProvisionMap(previousSnapShotDetails.getPaakProvisionMap());
                        nodeAndDIDResponseForNewSnap.setPreviousVehicleNodeStatusList(previousSnapShotDetailsByNode.getPreviousVehicleNodeStatusList());
                        nodeAndDIDResponseForNewSnapMap.put(nodeAddress, nodeAndDIDResponseForNewSnap);
                    }
            }
        }catch(Exception ex){
            ex.printStackTrace();
            logger.error("SnapDupValidator:Exception in validateDuplicateNodes :" + ex.getMessage());
            String validationErrorMessage = "Exception in validateDuplicateNodes : " + ex.getMessage() +" :"+
                    (snapshotObserverRequest.getVin() != null ? snapshotObserverRequest.getVin() : "");
            exceptionHandler.logException(ex, this.getClass().getSimpleName());
            throw new ServiceFaultException(validationErrorMessage, new ServiceFault(
                    SnapConstants.INVALID_INPUT, validationErrorMessage));
        }
        logger.info("SnapDupValidator:End validateDidResponseForNodes for the VIN : "+ snapshotObserverRequest.getVin());
        return nodeAndDIDResponseForNewSnapMap;
    }

}