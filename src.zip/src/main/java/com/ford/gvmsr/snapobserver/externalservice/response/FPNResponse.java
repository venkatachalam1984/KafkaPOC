package com.ford.gvmsr.snapobserver.externalservice.response;

import java.util.Map;

/**
 * Created by MDEVARA3 on 3/9/2018.
 */
public class FPNResponse {

    Map<String,SingleFPNResponse> fpnResponseMap;

    public Map<String, SingleFPNResponse> getFpnResponseMap() {
        return fpnResponseMap;
    }

    public void setFpnResponseMap(Map<String, SingleFPNResponse> fpnResponseMap) {
        this.fpnResponseMap = fpnResponseMap;
    }
}
