package com.ford.gvmsr.snapobserver.constants;

import java.util.Arrays;
import java.util.List;

/**
 * Created by MDEVARA3 on 11/9/2017.
 */

public class GVMSModuleUpdateConstants {
    public static final String NODE_7D0 = "7D0";
    public static final String NODE_754 = "754";
    public static final String SERIAL_F18C = "F18C";
    public static final String SERIAL_F17F = "F17F";
    public static final String SERIAL_F141 = "F141";

    public static final String ASSEMBLY = "Assembly";
    public static final String CORE_ASSEMBLY = "Core Assembly";
    public static final String HARDWARE = "Hardware";
    public static final String IMAGE = "Image";
    public static final String SOFTWARE = "Software";
    public static final String OTA = "OTA";
    public static final String CONSUMER = "CONSUMER";
    public static final String TXN_STAT_COMPLETE = "CMPLT";
    public static final String NODE_731 = "731";
    public static final String NODE_727 = "727";
    public static final String CTR_ACRONYM = "CTR";
    public static final String ALL = "ALL";
    public static final String GC = "GC";
    public static final String SOURCE_SYSTEM_EOL = "EOL";
    public static final String SOURCE_SYSTEM_GVMS = "GVMS";
    public static final String TARGET_SYSTEM_CVFMA = "CVFMA";
    public static final String GET_CURRENT_LITE_INFO_TYPE = "GCL-ALL";
    public static final String GET_CURRENT_INFO_TYPE = "GC";
    public static final String GET_CURRENT_LITE_INFO_TYPE_M3 = "GCL-M3";
    public static final String GET_CURRENT_LITE_INFO_TYPE_M2 = "GCL-M2";
    public static final String STATE_CI = "CI";
    public static final String STATE_CU = "CU";
    public static final String GGDS = "GGDS";
    public static final String GDS = "GDS";
    public static final String ESN_F141 = "F141";
    public static final String ESN_E22X = "E22X";
    public static final String ESN_F18C = "F18C";
    public static final String TCU = "TCU";
    public static final String MODULE_NAME = "moduleupdate";
    public static final String STATUS_SUCCESS = "200";
    public static final String STATUS_FAILURE = "999";
    public static final String API_REQUEST_ID = "apiRequestId";
    public static final String HOST_NAME = "hostName";
    public static final String THREAD_ID = "threadId";
    public static final String ANALYZE_LOG = "ANALYZELOG";
    public static final String ALSND_FTR = "ALSNDFTR";
    public static final String CCPU_LOG = "CCPULOG";
    public static final String BLANK = "BLANK";
    public static final String ROLE_SOURCE_OTA = "OTA";
    public static final String RVCM = "RVCM";
    public static final String FASANALYZELOG = "FASAnalyzeLog";
    public static final String A014_EVENT_CODE = "A014";
    public static final String VIL_LOG = "VILLOG";
    public static final long APP_CODE_GIVIS = 5;
    public static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static final List<String> SW_DID_TYPES = Arrays.asList("Application", "Image", "Calibration", "Strategy", "ECU Configuration", "Signal Configuration");

    public static final String CLEAR = "CL01";
    public static final String ERROR = "ERROR";
    public static final String SUCCESS = "SUCCESS";
    public static final String APPLICATION = "Application";
    public static final String APIM_ERROR = "APIMERROR";
    public static final String APIM = "APIM";

    public static final String OPEN_BRACKET = " (";
    public static final String CLOSING_BRACKET_WITH_SEMI_COLON = ") : ";
    public static final String CLOSING_BRACKET = ") ";
    public static final String DASH = " - ";
    public static final String EMPTY_SPACE = " ";
    public static final String FULL_STOP = ".";
    public static final String COLON = " : ";
    public static final String COMMA = ", ";
    public static final String MODIFIED_RESPONSE = "Modified Response";
    public static final String NODE_ADDRESS = "Node Address";
    //Analyzelog EventCodes
    public static final String A001_EVENT_CODE = "A001";
    public static final String A002_EVENT_CODE = "A002";
    public static final String A003_EVENT_CODE = "A003";
    public static final String A004_EVENT_CODE = "A004";
    public static final String A005_EVENT_CODE = "A005";
    public static final String A006_EVENT_CODE = "A006";
    public static final String A007_EVENT_CODE = "A007";//Currently we don't have this event for GIVIS (Unsupported module)
    public static final String A008_EVENT_CODE = "A008";
    public static final String A009_EVENT_CODE = "A009";
    public static final String A010_EVENT_CODE = "A010";//Currently we don't have this event for GIVIS (Unsupported module)
    public static final String A011_EVENT_CODE = "A011";//
    public static final String A012_EVENT_CODE = "A012";

    public enum SourceType {
        MANUFACTURER
                ("MFR", "Supplier"),
        END_OF_LINE("EOL", "Vehicle Operations End of Line"),
        PTS("PTS", "Dealer Service"),
        PCE("PCE", "Program Code Expression"),
        IVS("IVS", "In-Vehicle Software"),
        VHR("VHR", "Vehicle Health Report"),
        CON("CON", "Consumer"),
        ENG("ENG", "Engineer"),
        FIMCO("FMC", "Fimco"),
        GETAVAILABLE("GAL", "GetAvailable"),
        GETINSTALL("GIP", "GetInstallPackage"),
        TRACE("TRC", "Trace"),
        VSD("VSD", "VSD"),
        EOL("EOL", "EOL");

        private String code;
        private String sourceName;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getSourceName() {
            return sourceName;
        }

        public void setSourceName(String sourceName) {
            this.sourceName = sourceName;
        }

        SourceType(String code, String sourceName) {
            this.code = code;
            this.sourceName = sourceName;
        }

    }

    //Load VIN & VIN Map Expression constants

    public static final String APP_CODE_GVMS = "GVMS";
    public static final String YES = "Y";
    public static final String NO = "N";
    public static final String STATUS_ACTIVE = "A";
    public static final String STATUS_DELETED = "D";
    public static final String RECEIVE_VIN_DATA = "ReceiveVINData";
    public static final String RECEIVE_FTR = "RECVFTR";
    public static final String SEND_FTR = "SENDFTR";
    public static final String RECEIVE_VIN_MAP_EXPR = "ReceiveVINMapExpr";
    public static final String RECEIVE_IVS_XML = "RECDIVSXML";
    public static final String RECEIVE_VIN_BIN = "RECVVINBIN";
    public static final String RECEIVE_M2C_VIN = "RECVVINM2C";

    public static final String TXN_STAT_ERROR = "ERROR";
    public static final String TXN_STAT_SUCCESS = "SUCCESS";

    public static final String ECU = "ECU Configuration";

    public static final String COMPLIANCE_DATA = "getComplianceData";
    public static final String ODL_COMPLIANCE = "getODLCompliance";


    public static final String SYSTEM_ERROR = "Internal System Error";
    public static final String INVALID_INPUT = "Invalid Request";


    //Software Transfer State Constants
    public static final String STRATEGY = "Strategy";
    public static final String CALIBRATION = "Calibration";
    public static final String ECUCONFIGUARTION = "ECU Configuration";
    public static final String CONFIGURATION = "Configuration";

    public static final String CCPU = "CCPU";
    public static final String VMCU = "VMCU";

    public static final String ERR_SRC_IPP = "IPP";
    public static final String ERR_SRC_VIS = "VIS";
    //IVSS Validate Signature Endpoint URL
    public static final String SIG_VALIDATION_ENDPOINT = "https://wwwqa.mgmsec.ford.com/KmsService/ValidateLogSignature.asmx";
    // public static final String SIG_VALIDATION_ENDPOINT = "https://wwwdev.mgmsec.ford.com/adfsendpoint.htm";
    //save
    public static final String RETRY_SAVE = "RETRYSAVE";
    public static final String ERROR_MESSAGE = "Save System Unavailable";
    public static final String SAVE_RETRY_COUNT = "SAVERETRYCNT";
    public static final String ENTERING_METHOD_FORMAT = "Entering method [{}.{}]; VIN: {},Node:{};exec time (ms): {}";
    public static final String EXITING_METHOD_FORMAT = "Exiting method [{}.{}]; VIN:{}; exec time (ms): {}";
    public static final String METHOD_FORMAT = "Exiting method [{}.{}]; exec time (ms): {}";

    public static final String ROLE_SOURCE_PAAK = "PAAK";

    public static final List SERIAL_NUM_DID_LIST = Arrays.asList("F141", "F18C");
    public static final List COPY_PREVIOUS_RESPONSE_DID_LIST = Arrays.asList("F1D0", "F1D1");

    public static final List DEALER_LIST = Arrays.asList("DEALER", "AFTERMARKET");

    public static final List CCPU_DID_TYPE_LIST = Arrays.asList("Application", "Image", "Strategy", "Assembly", "Core Assembly", "Hardware", "Serial Number");

    public static final String SERVICE_NAME = "AL";

    public static final List HARDWARE_TYPE_LIST = Arrays.asList("Core Assembly", "Hardware");

    //RTSA changes

    public static final String VIL_RECEIVED = "RECEIVEDVIL";
    public static final String VIL_PROCESS = "VILPROCESS";

    public static final String CONFIGUPDATEREQUEST_PROCESS = "CONFIGUPDATEREQUESTPROCESS";

    public static final List OTA_UPDATE_NODES = Arrays.asList("7D0","727","754");
    public static final String GCL_HUB_TRAN_RETRY = "GCLHUBRETRY";
    public static final String BLEM_ACRONYM = "BLEM";
	public static final String VIL_ROLE_ID = "VIL-GPH001";

	public static final String VIL_FENIX_DES = "FENIX";

    public static final String AL_SEND_FTR = "ALSNDFTR";
    public static final String AL_SND_FTR_ENTRY = "AL_SND_FTR_ENTRY";	

    public static final String ANALYZELOG = "ANALYZELOG";
    public static final String VILLOG = "VILLOG";
    public static final String CCPULOG_GEN2 = "CCPULGGEN2";
    public static final String CCPULOG_GEN3 = "CCPULGGEN3";

    public static final String GVSKS = "GVSKS";
    public static final String GVSKF = "GVSKF";

    public static final String FORSE = "FORSE";

    public static final List ICCID_DIDs = Arrays.asList("FD11","41AE");


    public static final String AFTERMARKET_VEH_PROFILE_ENTRY = "AFTERMARKET_VP_ENTRY";
    public static final String SEND_VEHICLE_PROFILE = "SNDVEHPROF";

    public static final String DEALER = "DEALER";


    public static String MSG_TYPE_CODE_AL = "AL";
    public static String MSG_TYPE_CODE_CCPU = "CCPU";

    public static final String PROCESS_MKT = "MKT";
    public static final String TRACE_ID = "traceID" ;

    public static final String STATUS_EXCEPTION = "E";

    public static final String VERTX_KAFKA_SYNCUP_DEV = "DEV";
    public static final String VERTX_KAFKA_SYNCUP_QA = "QA";
    public static final String VERTX_KAFKA_SYNCUP_PROD = "PROD";



}

