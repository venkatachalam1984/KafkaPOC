package com.ford.gvmsr.snapobserver.utils;


import com.ford.gvmsr.snapobserver.data.entity.FordPartNumberId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.time.Instant;

public class CommonUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);


    public static String millisecondsToSeconds(long milliseconds) {
        long seconds = (milliseconds / 1000);
        long milliSeconds = (milliseconds % 1000);
        String milliSecondsStr = Long.toString(milliSeconds);
        String milliSecs = "";
        if (milliSecondsStr.length() >= 2) {
            milliSecs = milliSecondsStr.substring(0, 2);
        } else {
            milliSecs = "0" + milliSecondsStr;
        }
        return seconds + "." + milliSecs;
    }

    public static long getEventTimeStamp() {
        Instant instant = Instant.now();
        Timestamp timestamp = Timestamp.from(instant);
        return timestamp.getTime();
    }

    public static FordPartNumberId getFordPartNumberId(String fordPartNumber) {
        String[] partNums = getParsedPartNumber(fordPartNumber);

        if (partNums == null && partNums.length != 3)
            return null;
        FordPartNumberId fpnEntity = new FordPartNumberId();
        fpnEntity.setFordPartNumberPrefix(partNums[0]);
        fpnEntity.setFordPartNumberBase(partNums[1]);
        fpnEntity.setFordPartNumberSuffix(partNums[2]);

        return fpnEntity;
    }

    private static String[] getParsedPartNumber(String fordPartNumber) {
        String[] partnums = null;
        try {
            partnums = fordPartNumber.split("-");
        } catch (Exception e) {
            LOGGER.error("Error while reading Ford Part Number IVSServiceActionHelper.getParsedPartNumber : " + fordPartNumber);
        }
        return partnums;
    }


}
