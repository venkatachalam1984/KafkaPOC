package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name="PGVMS37_MSG_NODE_ERR_TEMP")
public class SnapNodeErrorState implements Serializable {

    @EmbeddedId
    private SnapNodeErrorStateId snapNodeErrorStateId;

    @Column(name = "GVMS37_PRCS_STAT_C")
    private String processStatus;

    @Column(name = "GVMS37_PRCS_STAT_S")
    private Timestamp processTimeStamp;

    @Column(name = "GVMS37_CREATE_USER_C")
    private String createdBy;

    @Column(name = "GVMS37_CREATE_S")
    private Timestamp createdTimeStamp;

    public SnapNodeErrorStateId getSnapNodeErrorStateId() {
        return snapNodeErrorStateId;
    }

    public void setSnapNodeErrorStateId(SnapNodeErrorStateId snapNodeErrorStateId) {
        this.snapNodeErrorStateId = snapNodeErrorStateId;
    }

    public String getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(String processStatus) {
        this.processStatus = processStatus;
    }

    public Timestamp getProcessTimeStamp() {
        return processTimeStamp;
    }

    public void setProcessTimeStamp(Timestamp processTimeStamp) {
        this.processTimeStamp = processTimeStamp;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedTimeStamp() {
        return createdTimeStamp;
    }

    public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
        this.createdTimeStamp = createdTimeStamp;
    }
}
