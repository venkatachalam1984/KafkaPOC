package com.ford.gvmsr.snapobserver.logevent;

import com.ford.gvmsr.snapobserver.logevent.splunk.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SplunkEventLogger implements LogEventMonitor {

    @Autowired
    Utils splunkUtils;

    @Override
    public void LogEvent(String roleSource, String vin, String node, String traceId, LogType type, String status, String duration, long timestamp, String errorDesc) {
        if(node !=null) {
            splunkUtils.prepareSNAPLogEvent(vin, node, traceId, type.getCode(), status, duration, timestamp, errorDesc);
        }else{
            splunkUtils.prepareSnapVINLogEvent(vin, traceId, type.getCode(), status, duration, timestamp, errorDesc);
        }
    }
}
