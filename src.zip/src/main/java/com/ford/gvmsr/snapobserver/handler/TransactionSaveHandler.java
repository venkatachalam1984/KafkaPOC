package com.ford.gvmsr.snapobserver.handler;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.constants.TransactionCodes;
import com.ford.gvmsr.snapobserver.data.dao.TransactionDao;
import com.ford.gvmsr.snapobserver.data.dao.TransactionDetailDao;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.Date;

@Component
public class TransactionSaveHandler {

    @Autowired
    TransactionDao transactionDao;

    @Autowired
    TransactionDetailDao transactionDetailDao;

    public long saveTransaction(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, String status, String appName){

        String serviceName = ApplicationUtils.checkIsVil(moduleSnapshotObserverRequest) ?
                GVMSModuleUpdateConstants.VIL_LOG : GVMSModuleUpdateConstants.ANALYZE_LOG;
        String transactionType = ApplicationUtils.checkIsVil(moduleSnapshotObserverRequest) ?
                TransactionCodes.TransactionType.VILLOG.type() : TransactionCodes.TransactionType.ANALYZELOG.type();

        return transactionDao.save(moduleSnapshotObserverRequest.getTraceId(),status,transactionType,serviceName,appName);
    }

    public long saveTransactionDetail(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, long txnId, String status){

        return transactionDetailDao.save(moduleSnapshotObserverRequest.getVin(),status,txnId,
                GVMSModuleUpdateConstants.SOURCE_SYSTEM_GVMS, new Timestamp(new Date().getTime()),0);
    }
}
