package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDSoftware;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDSoftwareId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VehicleNodeDIDSoftwareRepository extends JpaRepository<VehicleNodeDIDSoftware, VehicleNodeDIDSoftwareId> {
    List<VehicleNodeDIDSoftware> findAllByDidSoftwareId_VehicleNodeDID(VehicleNodeDIDResponse didResponse);
}
