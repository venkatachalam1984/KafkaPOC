
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Programming Management com.ford.cloudnative.gvms.moduleupdate.data of the Programming Order Deviation to control programming order
 * 
 * <p>Java class for PODProgrammingManagementDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PODProgrammingManagementDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;all&gt;
 *         &lt;element name="ProgrammingGroup" type="{urn:ford/Vehicle/Module/Information/v4.0}PODProgrammingGroupType"/&gt;
 *         &lt;element name="ProgrammingOrder" type="{urn:ford/Vehicle/Module/Information/v4.0}PODProgrammingOrderType"/&gt;
 *       &lt;/all&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PODProgrammingManagementDataType", propOrder = {

})
public class PODProgrammingManagementDataType {

    @XmlElement(name = "ProgrammingGroup", required = true)
    protected String programmingGroup;
    @XmlElement(name = "ProgrammingOrder", required = true)
    protected String programmingOrder;

    /**
     * Gets the value of the programmingGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgrammingGroup() {
        return programmingGroup;
    }

    /**
     * Sets the value of the programmingGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgrammingGroup(String value) {
        this.programmingGroup = value;
    }

    /**
     * Gets the value of the programmingOrder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgrammingOrder() {
        return programmingOrder;
    }

    /**
     * Sets the value of the programmingOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgrammingOrder(String value) {
        this.programmingOrder = value;
    }

}
