package com.ford.gvmsr.snapobserver.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class VertxConfiguration {

    @Value("${vertx.kafka.consumer.snapshot.topic}")
    String snapshotConsumerTopic;

    @Value("${vertx.kafka.consumer.snapshot.group}")
    String snapshotConsumerGroup;

    @Value("${vertx.kafka.consumer.snapshot.bootstrap-servers}")
    String snapshotKafkaBrokerEndpoints;

    @Value("${vertx.kafka.consumer.snapshot.protocol-config}")
    String snapshotProtocolConfig;

    @Value("${vertx.kafka.consumer.snapshot.automatic-offset-commit}")
    boolean snapshotAutoCommitOffset;

    @Value("${vertx.kafka.consumer.snapshot.retry-count}")
    Integer snapshotKakfaRetryCount;

    @Value("${vertx.kafka.producer.snapshot.topic}")
    String snapshotProducerTopic;

    @Value("${vertx.kafka.producer.snapshot.bootstrap-servers}")
    String snapshotResponseKafkaBrokerEndpoints;

    @Value("${vertx.configure.worker-verticle-count}")
    Integer workerVerticleCount;

    @Value("${vertx.eventbus.standard.execution-time.secs}")
    Integer vertxEventLoopExecutionTimeInSecs;

    @Value("${vertx.eventbus.worker.execution-time.secs}")
    Integer vertxWorkerExecutionTimeInSecs;

    @Value("${vertx.eventbus.standard.blocked-thread.check-interval}")
    Integer threadBlockedCheckInterval;

    @Value("${vertx.eventbus.common.warning.blocked.interval}")
    Integer vertxThreadExecutionLimit;

    @Value("${vertx.kafka.consumer.snapshot.max.poll.records}")
    Integer maxPollRecordsLimit;

    @Value("${vertx.kafka.consumer.snapshot.max.poll.interval.ms}")
    Integer maxPollRecordsInterval;

    @Value("${vertx.kafka.consumer.snapshot.auto.commit.interval.ms}")
    Integer autoCommitInterval;

    @Value("${vertx.kafka.consumer.snapshot.auto.offset.reset}")
    String autoOffsetReset;

    @Value("${vertx.kafka.producer.snapshot.syncup.topic}")
    String snapshotProducerSyncupTopic;

    @Value("${vertx.kafka.producer.snapshot.syncup.dev.bootstrap-servers}")
    String snapshotProducerSyncupDevEndpoints;

    @Value("${vertx.kafka.producer.snapshot.syncup.qa.bootstrap-servers}")
    String snapshotProducerSyncupQaEndpoints;

    @Value("${vertx.kafka.producer.snapshot.syncup.prod.bootstrap-servers}")
    String snapshotProducerSyncupProdEndpoints;

    @Value("${vertex.kafka.syncup.env}")
    String snapSyncupEnvironment;

    @Value("${vertx.kafka.producer.exception.event.topic}")
    String exceptionEventProducerTopic;

    @Value("${vertx.kafka.producer.exception.event.dev.bootstrap-servers}")
    String exceptionEventProducerDevEndpoints;

    @Value("${vertx.kafka.producer.exception.event.qa.bootstrap-servers}")
    String exceptionEventProducerQaEndpoints;

    @Value("${vertx.kafka.producer.exception.event.prod.bootstrap-servers}")
    String exceptionEventProducerProdEndpoints;

    public String getSnapshotConsumerTopic() {
        return snapshotConsumerTopic;
    }

    public String getSnapshotConsumerGroup() {
        return snapshotConsumerGroup;
    }

    public String getSnapshotKafkaBrokerEndpoints() {
        return snapshotKafkaBrokerEndpoints;
    }

    public String getSnapshotProtocolConfig() {
        return snapshotProtocolConfig;
    }

    public boolean isSnapshotAutoCommitOffset() {
        return snapshotAutoCommitOffset;
    }

    public Integer getSnapshotKakfaRetryCount() {
        return snapshotKakfaRetryCount;
    }

    public Integer getWorkerVerticleCount() {
        return workerVerticleCount;
    }

    public Integer getVertxEventLoopExecutionTimeInSecs() {
        return vertxEventLoopExecutionTimeInSecs;
    }

    public Integer getVertxWorkerExecutionTimeInSecs() {
        return vertxWorkerExecutionTimeInSecs;
    }

    public Integer getThreadBlockedCheckInterval() {
        return threadBlockedCheckInterval;
    }

    public Integer getVertxThreadExecutionLimit() {
        return vertxThreadExecutionLimit;
    }

    public Integer getMaxPollRecordsLimit() {
        return maxPollRecordsLimit;
    }

    public Integer getMaxPollRecordsInterval() {
        return maxPollRecordsInterval;
    }

    public Integer getAutoCommitInterval() {
        return autoCommitInterval;
    }

    public String getAutoOffsetReset() {
        return autoOffsetReset;
    }

    public String getSnapshotProducerTopic() {
        return snapshotProducerTopic;
    }

    public String getSnapshotResponseKafkaBrokerEndpoints() {
        return snapshotResponseKafkaBrokerEndpoints;
    }

    public String getSnapshotProducerSyncupTopic() {
        return snapshotProducerSyncupTopic;
    }

    public String getSnapSyncupEnvironment() {
        return snapSyncupEnvironment;
    }

    public String getSnapshotProducerSyncupDevEndpoints() {
        return snapshotProducerSyncupDevEndpoints;
    }

    public String getSnapshotProducerSyncupQaEndpoints() {
        return snapshotProducerSyncupQaEndpoints;
    }

    public String getSnapshotProducerSyncupProdEndpoints() {
        return snapshotProducerSyncupProdEndpoints;
    }

    public String getExceptionEventProducerTopic() {
        return exceptionEventProducerTopic;
    }

    public String getExceptionEventProducerDevEndpoints() {
        return exceptionEventProducerDevEndpoints;
    }

    public String getExceptionEventProducerQaEndpoints() {
        return exceptionEventProducerQaEndpoints;
    }

    public String getExceptionEventProducerProdEndpoints() {
        return exceptionEventProducerProdEndpoints;
    }
}