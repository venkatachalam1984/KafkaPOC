package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;

import java.sql.SQLException;
import java.util.List;

public interface VehicleNodeDIDResponseDao {

    List<VehicleNodeDIDResponse> save(List<VehicleNodeDIDResponse> vehicleNodeDIDResponseList) throws SQLException;
}
