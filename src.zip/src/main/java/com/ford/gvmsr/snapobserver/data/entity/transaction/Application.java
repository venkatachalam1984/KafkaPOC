package com.ford.gvmsr.snapobserver.data.entity.transaction;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

@Entity
@Table(name="PGVMT09_APPL")
public class Application extends BaseEntity {

    @Id
    @Column(name="GVMT09_APPL_D")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMT09_APPL_D_SQ_GEN")
    @SequenceGenerator(name = "PGVMT09_APPL_D_SQ_GEN", sequenceName = "PGVMT09_APPL_D_SQ", allocationSize = 1)
    private Long  applicationId;

    @Column(name="GVMT09_APPL_C")
    private String applicationCode;

    @Column(name="GVMT09_APPL_N")
    private String applicationName;

    @Column(name="GVMT09_GUID_D")
    private String applicationGUID;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT09_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT09_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT09_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT09_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public Long  getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long  applicationId) {
        this.applicationId = applicationId;
    }

    public String getApplicationCode() {
        return applicationCode;
    }

    public void setApplicationCode(String applicationCode) {
        this.applicationCode = applicationCode;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getApplicationGUID() {
        return applicationGUID;
    }

    public void setApplicationGUID(String applicationGUID) {
        this.applicationGUID = applicationGUID;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }
}
