package com.ford.gvmsr.snapobserver.externalservice.response;

import java.util.List;
import java.util.Map;

public class FASResponse {

    private long infoKey;

    private int paritionKey;

    private Map<String, List<FASNodeDetailResponse>> fasResponseMap;


    public long getInfoKey() {
        return infoKey;
    }

    public void setInfoKey(long infoKey) {
        this.infoKey = infoKey;
    }

    public int getParitionKey() {
        return paritionKey;
    }


    public void setParitionKey(int paritionKey) {
        this.paritionKey = paritionKey;
    }

    public Map<String, List<FASNodeDetailResponse>> getFasResponseMap() {
        return fasResponseMap;
    }

    public void setFasResponseMap(Map<String, List<FASNodeDetailResponse>> fasResponseMap) {
        this.fasResponseMap = fasResponseMap;
    }
}
