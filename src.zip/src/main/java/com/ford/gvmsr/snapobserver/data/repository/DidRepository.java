package com.ford.gvmsr.snapobserver.data.repository;

public interface DidRepository  {
}
