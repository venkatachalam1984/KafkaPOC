package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by VSUBBAR1 on 11/19/2019.
 */
@Embeddable
public class VehicleSnapshotId implements Serializable{

    @Column(name = "GVMS03_VEH_SNPSHT_K")
    private Long vehicleSnapshotKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    public Long getVehicleSnapshotKey() {
        return vehicleSnapshotKey;
    }

    public void setVehicleSnapshotKey(Long vehicleSnapshotKey) {
        this.vehicleSnapshotKey = vehicleSnapshotKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }
}
