package com.ford.gvmsr.snapobserver.externalservice.response;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by mdevara3 on 12/29/2017.
 */
public class ODLResponse {

    private Map<String, List<OdlDiagSpecCategoryAndNetworkDetailsTO>> odlDiagSpecCategoryAndNetworkDetailsMap = new HashMap<>();

    public Map<String, List<OdlDiagSpecCategoryAndNetworkDetailsTO>> getOdlDiagSpecCategoryAndNetworkDetailsMap() {
        return odlDiagSpecCategoryAndNetworkDetailsMap;
    }

    public void setOdlDiagSpecCategoryAndNetworkDetailsMap(Map<String, List<OdlDiagSpecCategoryAndNetworkDetailsTO>> odlDiagSpecCategoryAndNetworkDetailsMap) {
        this.odlDiagSpecCategoryAndNetworkDetailsMap = odlDiagSpecCategoryAndNetworkDetailsMap;
    }
}
