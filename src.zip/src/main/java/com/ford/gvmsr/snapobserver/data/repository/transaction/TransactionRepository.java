package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.Transaction;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Repository
@Transactional
public interface TransactionRepository extends CrudRepository<Transaction, Serializable> {

    public List<Transaction> findAllByTransactionType_TransactionTypeIdAndTransactionStatus_TransctionStatusCode(String transactionType, String transactionStatus);

    @Query("select transaction from Transaction transaction where transaction.transactionType.transactionTypeId = ?1 and transaction.transactionStatus.transctionStatusCode in(?2)")
    public List<Transaction> fetchTransactionList(String transactionType, List<String> statusList);


    @Modifying
    @Query("update Transaction set transactionStatus.transctionStatusCode = ?2,auditColumns.lastUpdatedTimestamp = ?3  where transactionId = ?1")
    public int updateTransactionStatus(long transactionId, String status, Timestamp timestamp);

    @Modifying
    @Query(value = "UPDATE PGVMT01_TXN SET GVMT01_TXN_DESC_X ='CMPLT', GVMT02_TXN_STAT_C='CMPLT', GVMT01_LAST_UPDT_S=sysdate WHERE GVMT01_TRACE_D=:txnId and GVMT01_TXN_DESC_X='KAFKA_FLR'", nativeQuery = true)
    public int updateVilKafkaTransactionStatus(@Param("txnId") String txnId);


    @Transactional
    @Modifying
    @Query("update Transaction set transactionStatus.transctionStatusCode = ?2,auditColumns.lastUpdatedTimestamp = ?3,retryCount=?4  where transactionId = ?1")
    public int updateTransactionStatusForGvmsToGivisRetry(long transactionId, String status, Timestamp timestamp,int retryValue);

}
