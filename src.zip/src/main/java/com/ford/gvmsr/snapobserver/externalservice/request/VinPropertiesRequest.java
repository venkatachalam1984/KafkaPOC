package com.ford.gvmsr.snapobserver.externalservice.request;


import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class VinPropertiesRequest {

    VinProperties vinproperties = new VinProperties();

    public VinProperties getVinproperties() {
        return vinproperties;
    }

    public void setVinproperties(VinProperties vinproperties) {
        this.vinproperties = vinproperties;
    }

}
