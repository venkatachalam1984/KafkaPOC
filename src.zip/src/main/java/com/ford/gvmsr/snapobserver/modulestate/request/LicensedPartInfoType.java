
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for LicensedPartInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LicensedPartInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fordLicensePartNo" type="{urn:ford/productdesign/vis/common/v1.0}FPNType"/&gt;
 *         &lt;element name="fordApplicationMapPartNo" type="{urn:ford/productdesign/vis/common/v1.0}FPNType"/&gt;
 *         &lt;element name="source" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="licenseFulfillmentStatus" type="{urn:ford/Vehicle/Module/Information/v4.0}LicenseFulfillmentStatusType"/&gt;
 *         &lt;element name="licenseFulfillmentDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LicensedPartInfoType", propOrder = {
    "fordLicensePartNo",
    "fordApplicationMapPartNo",
    "source",
    "licenseFulfillmentStatus",
    "licenseFulfillmentDate"
})
public class LicensedPartInfoType {

    @XmlElement(required = true)
    protected String fordLicensePartNo;
    @XmlElement(required = true)
    protected String fordApplicationMapPartNo;
    @XmlElement(required = true)
    protected String source;
    @XmlElement(required = true)
    protected LicenseFulfillmentStatusType licenseFulfillmentStatus;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar licenseFulfillmentDate;

    /**
     * Gets the value of the fordLicensePartNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFordLicensePartNo() {
        return fordLicensePartNo;
    }

    /**
     * Sets the value of the fordLicensePartNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFordLicensePartNo(String value) {
        this.fordLicensePartNo = value;
    }

    /**
     * Gets the value of the fordApplicationMapPartNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFordApplicationMapPartNo() {
        return fordApplicationMapPartNo;
    }

    /**
     * Sets the value of the fordApplicationMapPartNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFordApplicationMapPartNo(String value) {
        this.fordApplicationMapPartNo = value;
    }

    /**
     * Gets the value of the source property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSource(String value) {
        this.source = value;
    }

    /**
     * Gets the value of the licenseFulfillmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseFulfillmentStatusType }
     *     
     */
    public LicenseFulfillmentStatusType getLicenseFulfillmentStatus() {
        return licenseFulfillmentStatus;
    }

    /**
     * Sets the value of the licenseFulfillmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseFulfillmentStatusType }
     *     
     */
    public void setLicenseFulfillmentStatus(LicenseFulfillmentStatusType value) {
        this.licenseFulfillmentStatus = value;
    }

    /**
     * Gets the value of the licenseFulfillmentDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLicenseFulfillmentDate() {
        return licenseFulfillmentDate;
    }

    /**
     * Sets the value of the licenseFulfillmentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLicenseFulfillmentDate(XMLGregorianCalendar value) {
        this.licenseFulfillmentDate = value;
    }

}
