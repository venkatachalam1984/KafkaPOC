
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WrapperDocType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WrapperDocType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OperatingSystem" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="SubOperatingSystem" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Revision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FileDownloadId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="OriginalFileName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FileDateModified" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FileSignature" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="WrapperDocumentLink" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DocumentDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WrapperDocType", propOrder = {
    "operatingSystem",
    "subOperatingSystem",
    "revision",
    "fileDownloadId",
    "originalFileName",
    "fileDateModified",
    "fileSignature",
    "wrapperDocumentLink",
    "documentDescription"
})
public class WrapperDocType {

    @XmlElement(name = "OperatingSystem", required = true)
    protected String operatingSystem;
    @XmlElement(name = "SubOperatingSystem", required = true)
    protected String subOperatingSystem;
    @XmlElement(name = "Revision", required = true)
    protected String revision;
    @XmlElement(name = "FileDownloadId", required = true)
    protected String fileDownloadId;
    @XmlElement(name = "OriginalFileName", required = true)
    protected String originalFileName;
    @XmlElement(name = "FileDateModified", required = true)
    protected String fileDateModified;
    @XmlElement(name = "FileSignature", required = true)
    protected String fileSignature;
    @XmlElement(name = "WrapperDocumentLink", required = true)
    protected String wrapperDocumentLink;
    @XmlElement(name = "DocumentDescription")
    protected String documentDescription;

    /**
     * Gets the value of the operatingSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatingSystem() {
        return operatingSystem;
    }

    /**
     * Sets the value of the operatingSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatingSystem(String value) {
        this.operatingSystem = value;
    }

    /**
     * Gets the value of the subOperatingSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubOperatingSystem() {
        return subOperatingSystem;
    }

    /**
     * Sets the value of the subOperatingSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubOperatingSystem(String value) {
        this.subOperatingSystem = value;
    }

    /**
     * Gets the value of the revision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevision() {
        return revision;
    }

    /**
     * Sets the value of the revision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevision(String value) {
        this.revision = value;
    }

    /**
     * Gets the value of the fileDownloadId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileDownloadId() {
        return fileDownloadId;
    }

    /**
     * Sets the value of the fileDownloadId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileDownloadId(String value) {
        this.fileDownloadId = value;
    }

    /**
     * Gets the value of the originalFileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalFileName() {
        return originalFileName;
    }

    /**
     * Sets the value of the originalFileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalFileName(String value) {
        this.originalFileName = value;
    }

    /**
     * Gets the value of the fileDateModified property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileDateModified() {
        return fileDateModified;
    }

    /**
     * Sets the value of the fileDateModified property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileDateModified(String value) {
        this.fileDateModified = value;
    }

    /**
     * Gets the value of the fileSignature property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileSignature() {
        return fileSignature;
    }

    /**
     * Sets the value of the fileSignature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileSignature(String value) {
        this.fileSignature = value;
    }

    /**
     * Gets the value of the wrapperDocumentLink property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperDocumentLink() {
        return wrapperDocumentLink;
    }

    /**
     * Sets the value of the wrapperDocumentLink property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperDocumentLink(String value) {
        this.wrapperDocumentLink = value;
    }

    /**
     * Gets the value of the documentDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentDescription() {
        return documentDescription;
    }

    /**
     * Sets the value of the documentDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentDescription(String value) {
        this.documentDescription = value;
    }

}
