package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshot;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshotId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Set;

@Repository
@Transactional
public interface VehicleNodeSnapshotRepository extends JpaRepository<VehicleNodeSnapshot, VehicleNodeSnapshotId> {

    @Modifying
    @Query(value = "UPDATE PGVMS04_VEH_NODE_SNPSHT a SET a.GVMS04_ACTIVE_F='D' WHERE a.GVMS10_VIN_HASH_R=:vinhash AND a.GVMS10_VIN_R=:vin AND a.GVM023_NODE_ADRS_C=:node", nativeQuery = true)
    public int deactivateAllExistingVehicleNodeSnapshots(@Param("vinhash") int vinHash, @Param("vin") String vin, @Param("node") String node);

    @Query(value = "SELECT * FROM PGVMS04_VEH_NODE_SNPSHT WHERE GVMS10_VIN_HASH_R =:vinHash AND GVMS04_ACTIVE_F =:activeFlag AND " +
            "GVMS10_VIN_R=:vin AND GVM023_NODE_ADRS_C IN (:nodeList) " +
            "AND GVMS04_LAST_UPDT_S IN (SELECT MAX(GVMS04_LAST_UPDT_S) FROM PGVMS04_VEH_NODE_SNPSHT a   " +
            "WHERE a.GVMS10_VIN_HASH_R =:vinHash AND a.GVMS10_VIN_R=:vin  " +
            " AND a.GVM023_NODE_ADRS_C IN (:nodeList) AND GVMS04_ACTIVE_F =:activeFlag GROUP BY GVM023_NODE_ADRS_C)", nativeQuery = true)
    public Set<VehicleNodeSnapshot> getVehicleNodeSnapshotsByVehicleNodeSnapshotId_VinHashNumberAndVinAndNodeListAndActiveFlag(@Param("vinHash") int vinHash, @Param("vin") String vin, @Param("nodeList") List<String> nodeList, @Param("activeFlag") String activeFlag);

    @Modifying
    @Query(value = "UPDATE PGVMS04_VEH_NODE_SNPSHT a SET a.GVMS04_ACTIVE_F= ?1 where GVMS04_VEH_NODE_SNPSHT_K=?2 and GVMS10_VIN_HASH_R=?3", nativeQuery = true)
    public void updateActiveFlagByVehicleNodeSnapshotKey(String activeFlag, long vehicleNodeSnapshotKey, int vinHash);

}
