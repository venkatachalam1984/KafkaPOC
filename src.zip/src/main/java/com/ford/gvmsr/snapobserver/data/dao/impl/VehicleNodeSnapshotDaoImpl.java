package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeSnapshotDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshot;
import com.ford.gvmsr.snapobserver.data.repository.VehicleNodeSnapshotRepository;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Date;

@Service
public class VehicleNodeSnapshotDaoImpl implements VehicleNodeSnapshotDao {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    VehicleNodeSnapshotRepository vehicleNodeSnapshotRepository;

    @Autowired
    DataSource dataSource;

    @Autowired
    ExceptionHandler exceptionHandler;

    private static final String INSERT_VEH_NODE_SNAPSHOT = "insert into PGVMS04_VEH_NODE_SNPSHT values(?,PGVMS04_VEH_NODE_SNPSHT_K_SQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,'GVMS',?,'GVMS',?,?)";

    @Override
    public void deactivateAllExistingVehicleNodeSnapshots(Integer vinHash, String vin, String node) {
        vehicleNodeSnapshotRepository.deactivateAllExistingVehicleNodeSnapshots(vinHash, vin, node);
    }

    @Override
    public VehicleNodeSnapshot save(VehicleNodeSnapshot vehicleNodeSnapshot) throws SQLException {

        long start = System.currentTimeMillis();
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        try {
            //STEP 1: Open a connection insert
            conn = dataSource.getConnection();
            //STEP 2: Execute a query
            preparedStatement = conn.prepareStatement(INSERT_VEH_NODE_SNAPSHOT, new String[]{"GVMS04_VEH_NODE_SNPSHT_K"});
            conn.setAutoCommit(false);

            preparedStatement.setInt(1, vehicleNodeSnapshot.getVehicleNodeSnapshotId().getVinHashNumber());
            preparedStatement.setLong(2, vehicleNodeSnapshot.getVehicleSnapshot().getVehicleSnapshotKey());
            preparedStatement.setString(3, vehicleNodeSnapshot.getVin());
            preparedStatement.setString(4, vehicleNodeSnapshot.getNodeAddress());
            if (vehicleNodeSnapshot.getFordPartNumber() != null) {
                preparedStatement.setString(5, vehicleNodeSnapshot.getFordPartNumber().getFordPartNumberPrefix());
                preparedStatement.setString(6, vehicleNodeSnapshot.getFordPartNumber().getFordPartNumberBase());
                preparedStatement.setString(7, vehicleNodeSnapshot.getFordPartNumber().getFordPartNumberSuffix());
            } else {
                preparedStatement.setString(5, null);
                preparedStatement.setString(6, null);
                preparedStatement.setString(7, null);
            }
            preparedStatement.setString(8, vehicleNodeSnapshot.getEcuAcronym());
            preparedStatement.setString(9, vehicleNodeSnapshot.getVscsVersionDesc());
            preparedStatement.setTimestamp(10, vehicleNodeSnapshot.getVscsVersionDate());
            preparedStatement.setString(11, vehicleNodeSnapshot.getRoleEventCode());
            preparedStatement.setString(12, vehicleNodeSnapshot.getIsProvisionedFlag());
            preparedStatement.setString(13, vehicleNodeSnapshot.getActiveFlag());
            preparedStatement.setTimestamp(14, new Timestamp(new Date().getTime()));
            preparedStatement.setTimestamp(15, new Timestamp(new Date().getTime()));
            preparedStatement.setTimestamp(16, vehicleNodeSnapshot.getNodeTimeStamp());
            int prepStmt = preparedStatement.executeUpdate();

            if (prepStmt > 0) {
                ResultSet rs = preparedStatement.getGeneratedKeys();
                if (rs != null && rs.next()) {
                    vehicleNodeSnapshot.getVehicleNodeSnapshotId().setVehicleNodeSnapshotKey(rs.getLong(1));
                }
            }
            conn.commit();
            preparedStatement.close();
            conn.setAutoCommit(true);
            conn.close();
        } catch (Exception e) {
            exceptionHandler.logException(e, this.getClass().getSimpleName());
            vehicleNodeSnapshot.setVehicleNodeSnapshotId(null);
            throw e;
        } finally {
            //finally block used to close resources
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                LOGGER.error("SQLException e={}", se);
                exceptionHandler.logException(se, this.getClass().getSimpleName());
            }//end finally try
        }
        String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
        LOGGER.debug("Time taken to save VehicleNodeSnapshot:::" + duration);
        return vehicleNodeSnapshot;
    }

    @Override
    public void update(String flag, Long primaryKey, int vinHash) throws SQLException {
         vehicleNodeSnapshotRepository.updateActiveFlagByVehicleNodeSnapshotKey(flag, primaryKey, vinHash);
    }


}
