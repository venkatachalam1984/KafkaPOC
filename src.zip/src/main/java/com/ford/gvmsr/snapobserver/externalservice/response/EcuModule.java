package com.ford.gvmsr.snapobserver.externalservice.response;

import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import java.io.Serializable;
import java.math.BigInteger;


public class EcuModule extends BaseEntity implements Serializable {

    private Long ecuModuleID;
    private int ecuModuleHashNumber;
    private String nodeAddress;
    private String esn;
    private String imei;
    private BigInteger iccid;
    private String ecuTypeCode;
    private String blueToothMacAddressDesc;
    private String uuid;
    private String beaconID;
    private Long serverMsgID;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMK07_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMK07_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMK07_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMK07_LAST_UPDT_S"))}
    )

    private AuditColumns auditColumns = new AuditColumns();

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }

    public Long getEcuModuleID() {
        return ecuModuleID;
    }

    public void setEcuModuleID(Long ecuModuleID) {
        this.ecuModuleID = ecuModuleID;
    }

    public int getEcuModuleHashNumber() {
        return ecuModuleHashNumber;
    }

    public void setEcuModuleHashNumber(int ecuModuleHashNumber) {
        this.ecuModuleHashNumber = ecuModuleHashNumber;
    }

    public String getNodeAddress() { return nodeAddress; }

    public void setNodeAddress(String nodeAddress) {this.nodeAddress = nodeAddress;}

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public BigInteger getIccid() {
        return iccid;
    }

    public void setIccid(BigInteger iccid) {
        this.iccid = iccid;
    }

    public String getEcuTypeCode() {
        return ecuTypeCode;
    }

    public void setEcuTypeCode(String ecuTypeCode) {
        this.ecuTypeCode = ecuTypeCode;
    }

    public String getBlueToothMacAddressDesc() {
        return blueToothMacAddressDesc;
    }

    public void setBlueToothMacAddressDesc(String blueToothMacAddressDesc) {
        this.blueToothMacAddressDesc = blueToothMacAddressDesc;
    }
    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getBeaconID() {
        return beaconID;
    }

    public void setBeaconID(String beaconID) {
        this.beaconID = beaconID;
    }

    public Long getServerMsgID() {
        return serverMsgID;
    }

    public void setServerMsgID(Long serverMsgID) {
        this.serverMsgID = serverMsgID;
    }

}
