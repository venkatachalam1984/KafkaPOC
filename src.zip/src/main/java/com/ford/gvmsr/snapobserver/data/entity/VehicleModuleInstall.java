
package com.ford.gvmsr.snapobserver.data.entity;

import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;


/**
 * Created by NPOSANI on 11/7/2017.
 */

@Entity
@Table(name="PGVMS21_VEH_MOD_INSTALL")
public class VehicleModuleInstall extends BaseEntity {

    @EmbeddedId
    private VehicleModuleInstallID vehicleModuleInstallID;

    @Column(name="GVM019_ECU_ACRONYM_C")
    private String ecuAcronymCode;

    public VehicleModuleInstallID getVehicleModuleInstallID() {
        return vehicleModuleInstallID;
    }

    public void setVehicleModuleInstallID(VehicleModuleInstallID vehicleModuleInstallID) {
        this.vehicleModuleInstallID = vehicleModuleInstallID;
    }

    @Column(name="GVMS21_MOD_UNINSTALL_S")
    private Timestamp moduleUnInstallTimeStamp;

    public String getEcuAcronymCode() {
        return ecuAcronymCode;
    }

    public void setEcuAcronymCode(String ecuAcronymCode) {
        this.ecuAcronymCode = ecuAcronymCode;
    }

    public Timestamp getModuleUnInstallTimeStamp() {
        return moduleUnInstallTimeStamp;
    }

    public void setModuleUnInstallTimeStamp(Timestamp moduleUnInstallTimeStamp) {
        this.moduleUnInstallTimeStamp = moduleUnInstallTimeStamp;
    }


    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS21_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS21_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS21_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS21_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();


    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }
}
