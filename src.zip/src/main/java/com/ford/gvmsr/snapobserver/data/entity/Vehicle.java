package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/30/2017.
 * An instance of a vehicle in production.
 * Data Source: GIVIS:NMGM001_VEH
 */

@Entity
@Table(name = "PGVMS10_VEH")
public class Vehicle extends BaseEntity {

    @EmbeddedId
    private VehicleId vehicleId;

    @Embedded
    private IVSProgramId ivsProgramId;

    @Column(name = "GVMS10_LOGICAL_VIN_R")
    private String logicalVin;

    @ManyToOne
    @JoinColumn(name = "GVMS11_PLANT_C", referencedColumnName = "GVMS11_PLANT_C")
    private Plant plant;

    @ManyToOne
    @JoinColumn(name = "GVMS13_VIN_TCU_REGION_C", referencedColumnName = "GVMS13_VIN_TCU_REGION_C")
    private VINRegionMap vinRegionMap;

    @Column(name = "GVMS10_NAMEPLATE_N")
    private String nameplateName;

    @Column(name = "GVMS10_BRAND_N")
    private String brandName;

    @Column(name = "GVMS10_MODEL_YEAR_R")
    private Float modelYear;

    @ManyToOne
    @JoinColumn(name = "GVMS12_FUEL_TYPE_C", referencedColumnName = "GVMS12_FUEL_TYPE_C")
    private FuelType fuelType;

    @Column(name = "GVMS10_MFG_MODEL_YEAR_C")
    private Float mfrModelYear;

    @Column(name = "GVMS23_PROG_MAP_CNTR_T")
    private Integer programMapCounter;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS10_CREATE_USER_C", updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS10_CREATE_S", updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS10_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS10_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    @Transient
    private boolean saveFlag;

    public VehicleId getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(VehicleId vehicleId) {
        this.vehicleId = vehicleId;
    }

    public IVSProgramId getIvsProgramId() {
        return ivsProgramId;
    }

    public void setIvsProgramId(IVSProgramId ivsProgramId) {
        this.ivsProgramId = ivsProgramId;
    }

    public String getLogicalVin() {
        return logicalVin;
    }

    public void setLogicalVin(String logicalVin) {
        this.logicalVin = logicalVin;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public Integer getProgramMapCounter() {
        return programMapCounter;
    }

    public void setProgramMapCounter(Integer programMapCounter) {
        this.programMapCounter = programMapCounter;
    }

    public VINRegionMap getVinRegionMap() {
        return vinRegionMap;
    }

    public void setVinRegionMap(VINRegionMap vinRegionMap) {
        this.vinRegionMap = vinRegionMap;
    }

    public String getNameplateName() {
        return nameplateName;
    }

    public void setNameplateName(String nameplateName) {
        this.nameplateName = nameplateName;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public Float getModelYear() {
        return modelYear;
    }

    public void setModelYear(Float modelYear) {
        this.modelYear = modelYear;
    }

    public FuelType getFuelType() {
        return fuelType;
    }

    public void setFuelType(FuelType fuelType) {
        this.fuelType = fuelType;
    }

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public Float getMfrModelYear() {
        return mfrModelYear;
    }

    public void setMfrModelYear(Float mfrModelYear) {
        this.mfrModelYear = mfrModelYear;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }

    public boolean isSaveFlag() {
        return saveFlag;
    }

    public void setSaveFlag(boolean saveFlag) {
        this.saveFlag = saveFlag;
    }
}
