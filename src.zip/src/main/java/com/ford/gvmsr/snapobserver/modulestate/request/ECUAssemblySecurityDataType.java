
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * File security bytes information
 * 
 * <p>Java class for ECUAssemblySecurityDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ECUAssemblySecurityDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence maxOccurs="unbounded"&gt;
 *         &lt;element name="SecurityLevelRef" type="{urn:ford/Vehicle/Module/Information/v4.0}SecurityLevelRefType"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="SecurityBytes" type="{urn:ford/Vehicle/Module/Information/v4.0}SecurityBytesType"/&gt;
 *           &lt;element name="ECUEncryptionInfo" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUEncryptionInfoType"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ECUAssemblySecurityDataType", propOrder = {
    "securityLevelRefAndSecurityBytesOrECUEncryptionInfo"
})
public class ECUAssemblySecurityDataType {

    @XmlElements({
        @XmlElement(name = "SecurityLevelRef", required = true, type = String.class),
        @XmlElement(name = "SecurityBytes", required = true, type = SecurityBytesType.class),
        @XmlElement(name = "ECUEncryptionInfo", required = true, type = ECUEncryptionInfoType.class)
    })
    protected List<Object> securityLevelRefAndSecurityBytesOrECUEncryptionInfo;

    /**
     * Gets the value of the securityLevelRefAndSecurityBytesOrECUEncryptionInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the securityLevelRefAndSecurityBytesOrECUEncryptionInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecurityLevelRefAndSecurityBytesOrECUEncryptionInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * {@link SecurityBytesType }
     * {@link ECUEncryptionInfoType }
     * 
     * 
     */
    public List<Object> getSecurityLevelRefAndSecurityBytesOrECUEncryptionInfo() {
        if (securityLevelRefAndSecurityBytesOrECUEncryptionInfo == null) {
            securityLevelRefAndSecurityBytesOrECUEncryptionInfo = new ArrayList<Object>();
        }
        return this.securityLevelRefAndSecurityBytesOrECUEncryptionInfo;
    }

}
