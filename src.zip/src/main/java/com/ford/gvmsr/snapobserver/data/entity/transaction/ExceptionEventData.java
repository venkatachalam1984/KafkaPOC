package com.ford.gvmsr.snapobserver.data.entity.transaction;

import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by TANBUCHE on 11/20/2019.
 */
@Entity
@Table(name = "PGVMT12_EXCPTN_EVNT_DATA")
public class ExceptionEventData  extends BaseEntity {


    @Id
    @Column(name="GVMT12_EXCPTN_EVNT_DATA_K", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMT12_EXCPTN_EVNT_DATA_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMT12_EXCPTN_EVNT_DATA_K_SQ_GEN", sequenceName = "PGVMT12_EXCPTN_EVNT_DATA_K_SQ", allocationSize = 1)
    private Long exceptionEventDataId;

    @Column(name="GVMT12_EXCPTN_EVNT_DATA_X")
    private String exceptionEventData;


    public String getExceptionEventData() {
        return exceptionEventData;
    }

    public void setExceptionEventData(String exceptionEventData) {
        this.exceptionEventData = exceptionEventData;
    }

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT12_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT12_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT12_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT12_LAST_UPDT_S"))}
    )

    @Override
    public AuditColumns getAuditColumns() {
        return null;
    }
}
