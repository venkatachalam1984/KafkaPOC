package com.ford.gvmsr.snapobserver.externalservice.response;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;

public class EcuParts extends BaseEntity {

    private EcuPartsId ecuPartsId;
    private String partPrefix;
    private String partBase;
    private String partSuffix;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMK05_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMK05_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMK05_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMK05_LAST_UPDT_S"))}
    )

    private AuditColumns auditColumns = new AuditColumns();

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }

    public EcuPartsId getEcuPartsId() {
        return ecuPartsId;
    }

    public void setEcuPartsId(EcuPartsId ecuPartsId) {
        this.ecuPartsId = ecuPartsId;
    }

    public String getPartPrefix() {return partPrefix;}

    public void setPartPrefix(String partPrefix) {this.partPrefix = partPrefix;}

    public String getPartBase() {return partBase;}

    public void setPartBase(String partBase) {this.partBase = partBase;}

    public String getPartSuffix() {return partSuffix;}

    public void setPartSuffix(String partSuffix) {this.partSuffix = partSuffix;}
}
