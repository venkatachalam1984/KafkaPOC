
package com.ford.gvmsr.snapobserver.dto;

public class RequestRole {

    private String role;

    private String roleDescription;

    private String roleId;

    private String roleSource;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleSource() {
        return roleSource;
    }

    public void setRoleSource(String roleSource) {
        this.roleSource = roleSource;
    }

    @Override
    public String toString() {
        return "RequestRole{" +
                "role='" + role + '\'' +
                ", roleDescription='" + roleDescription + '\'' +
                ", roleId='" + roleId + '\'' +
                ", roleSource='" + roleSource + '\'' +
                '}';
    }

}
