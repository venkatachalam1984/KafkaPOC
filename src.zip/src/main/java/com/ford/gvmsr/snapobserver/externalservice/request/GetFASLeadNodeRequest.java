package com.ford.gvmsr.snapobserver.externalservice.request;
import java.util.Map;

/**
 * Created by MDEVARA3 on 1/3/2018.
 */
public class GetFASLeadNodeRequest {

    private long infoKey;
    private int partitionKey;
    private Map<String, NodeAssemblyRequest> nodeAssyFPNMap;

    public long getInfoKey() {
        return infoKey;
    }

    public void setInfoKey(long infoKey) {
        this.infoKey = infoKey;
    }

    public int getPartitionKey() {
        return partitionKey;
    }

    public void setPartitionKey(int partitionKey) {
        this.partitionKey = partitionKey;
    }

    public Map<String, NodeAssemblyRequest> getNodeAssyFPNMap() {
        return nodeAssyFPNMap;
    }

    public void setNodeAssyFPNMap(Map<String, NodeAssemblyRequest> nodeAssyFPNMap) {
        this.nodeAssyFPNMap = nodeAssyFPNMap;
    }
}
