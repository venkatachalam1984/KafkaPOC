package com.ford.gvmsr.snapobserver.externalservice.request;

/**
 * Created by TANBUCHE on 3/12/2020.
 */


public class MessageProperties {


    private String sourceSystem;
    private String givisTraceID;
    private String gvmsTranId;
    private String gvmsTranDtlId;

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getGivisTraceID() {
        return givisTraceID;
    }

    public void setGivisTraceID(String givisTraceID) {
        this.givisTraceID = givisTraceID;
    }


    public String getGvmsTranId() {
        return gvmsTranId;
    }

    public void setGvmsTranId(String gvmsTranId) {
        this.gvmsTranId = gvmsTranId;
    }

    public String getGvmsTranDtlId() {
        return gvmsTranDtlId;
    }

    public void setGvmsTranDtlId(String gvmsTranDtlId) {
        this.gvmsTranDtlId = gvmsTranDtlId;
    }
}
