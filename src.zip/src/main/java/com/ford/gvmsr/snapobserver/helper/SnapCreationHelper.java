package com.ford.gvmsr.snapobserver.helper;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.data.dao.ModuleNodeDao;
import com.ford.gvmsr.snapobserver.data.entity.*;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import com.ford.gvmsr.snapobserver.externalservice.ApplicationInitializer;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.*;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.util.*;

@Component
public class SnapCreationHelper {

    private static final Logger logger = LoggerFactory.getLogger(SnapCreationHelper.class);

    @Autowired
    private ModuleNodeDao moduleNodeDao;

    @Autowired
    ExceptionHandler exceptionHandler;

    public Map<String, ModuleNode> populateModuleNodeType(Vehicle vehicle) throws Exception {
        Map<String, ModuleNode> moduleNodeMap = new HashMap<>();
        long start4 = System.currentTimeMillis();
        List<ModuleNode> moduleNodeList = moduleNodeDao.retrieveModuleNodeList(vehicle);
        moduleNodeList.forEach(moduleNode -> {
            moduleNodeMap.put(moduleNode.getNodeAddress() + "_" + moduleNode.getGwNodeId(), moduleNode);
        });
        long end4 = System.currentTimeMillis() - start4;
        logger.debug("analyzeLogHelper.retrieveModuleNode::::::" + end4);
        return moduleNodeMap;
    }

    public Map<String, ModuleNode> saveModuleNode(Map<String, ModuleNode> moduleNodeMap, Map<String, List<String>> gwNodeIdMap, String nodeAddress, Vehicle vehicle, String roleSource) {

        Map<String, ModuleNode> moduleNodeIdSaKeyMap = new HashMap<>();
        try {
            for (String gateWayNodeId : gwNodeIdMap.keySet()) {
                ModuleNode moduleNodeEntity = null;
                //Check if table PGVMS14_MOD_NODE contains record for NodeAddress/ProgramCode/ModelYr/gatewayNodeId
                String gwNodeId = null;
                String gwType = null;
                if (!CollectionUtils.isEmpty(moduleNodeMap)) {
                    String[] gwNodeIdArray = gateWayNodeId.split("_");
                    if (gwNodeIdArray != null && gwNodeIdArray.length == 2) {
                        gwNodeId = gwNodeIdArray[0];
                        gwType = gwNodeIdArray[1];
                    }
                    moduleNodeEntity = moduleNodeMap.get(nodeAddress + "_" + gwNodeId);
                    if (moduleNodeEntity != null) {
                        for (String did : gwNodeIdMap.get(gateWayNodeId)) {
                            moduleNodeIdSaKeyMap.put(did, moduleNodeEntity);
                        }
                    }
                }
                if (moduleNodeEntity == null) {
                    moduleNodeEntity = persistModuleNode(gwType, gwNodeId, vehicle, nodeAddress, roleSource); // ModuleNode Persiste  - S14 table
                    for (String did : gwNodeIdMap.get(gateWayNodeId)) {
                        moduleNodeIdSaKeyMap.put(did, moduleNodeEntity);
                    }
                }
            }
        } catch (Exception e) {
        }
        return moduleNodeIdSaKeyMap;
    }

    private ModuleNode persistModuleNode(String gatewayType, String gwNodeId, Vehicle vehEntity, String nodeAddress, String src) throws Exception {
        ModuleNode moduleNode = moduleNodeDao.findModuleNodeBy(vehEntity.getIvsProgramId().getProgramCode(), vehEntity.getIvsProgramId().getSalesModelYear(), nodeAddress, gwNodeId);
        if (moduleNode == null) {
            ModuleNode moduleNodeEntity = new ModuleNode();
            moduleNodeEntity.setIvsProgramId(vehEntity.getIvsProgramId());
            moduleNodeEntity.setSourceSystem(src);
            moduleNodeEntity.setNodeAddress(nodeAddress);
            moduleNodeEntity.setModuleCpuType(getModuleCpuType(gatewayType));
            String gatewayTypeEntity = getGatewayType(gatewayType);
            if (gwNodeId == null && gatewayType == null) {
                moduleNodeEntity.setGwNodeId(null);
            } else {
                if ((gatewayTypeEntity.equals("True G/W")) || (gatewayTypeEntity.equals("Transparent") && nodeAddress != null)) {
                    moduleNodeEntity.setGwNodeId(gwNodeId);
                    moduleNodeEntity.setNodeAddress(nodeAddress);
                }
            }
            moduleNodeEntity.setGatewayType(gatewayTypeEntity);
            moduleNodeDao.saveModuleNode(moduleNodeEntity);
            return moduleNodeEntity;
        }
        return moduleNode;
    }

    public void populateVehicleNodeDIDResponse (VehicleNodeDIDResponse vehicleNodeDIDResponse, DIDInfoType
            did, ModuleNodeType moduleNodeType, ModuleSnapshotObserverRequest snapshotObserverRequest, PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode){

        AdditionalProperties additionalProperties = snapshotObserverRequest.getAdditionalProperties(moduleNodeType.getAddress());

        VehicleNodeDIDResponseId vehicleNodeDIDResponseId = new VehicleNodeDIDResponseId();
        vehicleNodeDIDResponseId.setVinHashNumber(ApplicationUtils.getVinHash(snapshotObserverRequest.getVin()));
        vehicleNodeDIDResponse.setVehicleNodeDIDResponseId(vehicleNodeDIDResponseId);
        vehicleNodeDIDResponse.setDidCatalog(did.getDidValue());
        vehicleNodeDIDResponse.setIsConfig(did.isIsConfig()?"Y":"N");
        vehicleNodeDIDResponse.setLastDIDRecordDateTime(new Timestamp(new Date().getTime()));
        vehicleNodeDIDResponse.setIsComplete(did.isIsConfig()?"Y":"N");
        vehicleNodeDIDResponse.setIsOptimizedDID("N");
        vehicleNodeDIDResponse.setDidType(did.getDidType());
      if(ApplicationUtils.checkIsVil(snapshotObserverRequest)){
          if(null != previousSnapShotDetailsByNode.getPreviousSnapRole() &&
                  previousSnapShotDetailsByNode.getPreviousSnapRole().equalsIgnoreCase(RoleENUMType.DEALER.value())){
              VehicleNodeDIDResponse prevVehicleNodeDIDResponse = previousSnapShotDetailsByNode.getPrevNonConfigDidResponseMap().entrySet().
                      stream().findFirst().get().getValue();
              vehicleNodeDIDResponse.setNetworkName(prevVehicleNodeDIDResponse.getNetworkName());
              vehicleNodeDIDResponse.setNetworkProtocol(prevVehicleNodeDIDResponse.getNetworkProtocol());
              vehicleNodeDIDResponse.setNetworkDataRate(prevVehicleNodeDIDResponse.getNetworkDataRate());
          }else{
              vehicleNodeDIDResponse.setNetworkName(null);
              vehicleNodeDIDResponse.setNetworkProtocol(null);
              vehicleNodeDIDResponse.setNetworkDataRate(null);
          }
          if(did.getError() != null || !did.getError().trim().isEmpty()) {
              vehicleNodeDIDResponse.setVilDIDError(did.getError());
          }
      }else {
          if (additionalProperties.getOdlNetworkDetailsForNode() != null) {
              vehicleNodeDIDResponse.setNetworkName(additionalProperties.getOdlNetworkDetailsForNode().getNetwork());
              vehicleNodeDIDResponse.setNetworkProtocol(additionalProperties.getOdlNetworkDetailsForNode().getProtocol());
          }
          vehicleNodeDIDResponse.setNetworkDataRate(moduleNodeType.getODLNetwork().getNetworkDataRate()); // check datarate
      }
        if(moduleNodeType.getSpecificationCategory() != null) {
            vehicleNodeDIDResponse.setDidSpecificationCategory(moduleNodeType.getSpecificationCategory());
        }else{
            String didSpecificationCategory = additionalProperties.getOdlNetworkDetailsForNode().getSpecCategory();
            vehicleNodeDIDResponse.setDidSpecificationCategory(didSpecificationCategory);
        }
        vehicleNodeDIDResponse.setActiveFlag("A");
        vehicleNodeDIDResponse.setDidChildTableNbr(ApplicationUtils.getDIDChildTableValue(did));
        if (!StringUtils.isEmpty(did.getModifiedResponse()) && ApplicationUtils.checkPartNumber(did.getModifiedResponse())) {
            vehicleNodeDIDResponse.setModifiedDidResponse(did.getModifiedResponse().trim().toUpperCase());
        }
    }

    private String getModuleCpuType(String gatewayType) {
        String moduleCpuType = null;
        if ("NONE".equals(gatewayType)) {
            moduleCpuType = "MAIN";
        } else {
            moduleCpuType = "SATELLITE";
        }
        return moduleCpuType;
    }

    private String getGatewayType(String gatewayType) {
        String gatewayTypeEntity = null;
        if (gatewayType == null) {
            gatewayTypeEntity = "NONE";
        } else {
            gatewayTypeEntity = gatewayType;
        }
        return gatewayTypeEntity;
    }

}
