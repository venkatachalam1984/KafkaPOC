package com.ford.gvmsr.snapobserver.handler;

public class SoftwareStateTracker {
}
