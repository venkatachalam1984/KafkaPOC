package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.List;

/**
 * Created by mdevara3 on 12/29/2017.
 */
public class ODLRequest {

    private String programCode;
    private float salesModelYear;
    private List<String> nodeAddressList;

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public List<String> getNodeAddressList() {
        return nodeAddressList;
    }

    public void setNodeAddressList(List<String> nodeAddressList) {
        this.nodeAddressList = nodeAddressList;
    }
}
