package com.ford.gvmsr.snapobserver.dto;

import java.util.Map;

public class SnapshotResponse {

    private String vin;

    private String traceId;

    private Long recordKey;

    private Map<String, NodeStatus> nodeStatusMap;

    private String snapStatus;

    private RequestRole requestRole;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public Map<String, NodeStatus> getNodeStatusMap() {
        return nodeStatusMap;
    }

    public void setNodeStatusMap(Map<String, NodeStatus> nodeStatusMap) {
        this.nodeStatusMap = nodeStatusMap;
    }

    public Long getRecordKey() {
        return recordKey;
    }

    public void setRecordKey(Long recordKey) {
        this.recordKey = recordKey;
    }

    public String getSnapStatus() {
        return snapStatus;
    }

    public void setSnapStatus(String snapStatus) {
        this.snapStatus = snapStatus;
    }

    public RequestRole getRequestRole() {
        return requestRole;
    }

    public void setRequestRole(RequestRole requestRole) {
        this.requestRole = requestRole;
    }

    @Override
    public String toString() {
        return "SnapshotResponse{" +
                "vin='" + vin + '\'' +
                ", traceId='" + traceId + '\'' +
                ", recordKey=" + recordKey +
                ", nodeStatusMap=" + nodeStatusMap +
                ", snapStatus='" + snapStatus + '\'' +
                ", requestRole=" + requestRole +
                '}';
    }
}
