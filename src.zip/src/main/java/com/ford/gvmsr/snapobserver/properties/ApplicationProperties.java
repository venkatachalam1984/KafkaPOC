package com.ford.gvmsr.snapobserver.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class ApplicationProperties {

    @Value("#{'${givis.vin-not-found-nodes}'.split(',')}")
    public String [] givisVinNotFoundNodes;


}
