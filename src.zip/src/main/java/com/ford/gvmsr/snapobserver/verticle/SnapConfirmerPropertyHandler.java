package com.ford.gvmsr.snapobserver.verticle;

import com.ford.gvmsr.snapobserver.constants.VilConstants;
import com.ford.gvmsr.snapobserver.dto.SnapshotResponse;
import com.ford.gvmsr.snapobserver.logevent.LogType;
import com.ford.gvmsr.snapobserver.logevent.splunk.Utils;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import javax.annotation.PostConstruct;


@Component
public class SnapConfirmerPropertyHandler {

    Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${gvmsr.snap.confirmer}")
    private String snapConfirmerEndpoint;

    @Autowired
    Utils splunkUtils;

    private RestTemplate restTemplate = new RestTemplate();

    private URI uri ;

    private HttpHeaders headers = new HttpHeaders();

    @PostConstruct
    public void prepareSnapConfimerProperty() throws URISyntaxException {

        uri = new URI(snapConfirmerEndpoint);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

    }

    public ResponseEntity<String> sendToSnapConfirmer (SnapshotResponse snapshotResponse) {

        ResponseEntity<String> response = null;
        HttpEntity<SnapshotResponse> entity = new HttpEntity<>(snapshotResponse, headers);
        try {
            response = restTemplate.postForEntity(uri, entity, String.class);
            splunkUtils.prepareSnapObserverToConfirmerLogEvent(snapshotResponse.getVin(), snapshotResponse.getTraceId(),
                    LogType.INFO.getCode(), VilConstants.SENT_TO_CNF, null, null,
                    VilConstants.CNF_HANDLER_TRK_M, CommonUtils.getEventTimeStamp(), null);
            logger.info(" Snapshot Response processed " +response.getStatusCodeValue());
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(" Exception while posting Snapshot Response to Snapshot Confirmer " );
            splunkUtils.prepareSnapObserverToConfirmerLogEvent(snapshotResponse.getVin(), snapshotResponse.getTraceId(),
                    LogType.ERROR.getCode(), VilConstants.SENT_TO_CNF_F, null, null,
                    VilConstants.KAFKA_TRK_END, CommonUtils.getEventTimeStamp(), ex.getMessage());
        }
        return response;
    }


}
