package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshotId;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshotVil;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;


@Repository
@Transactional
public interface VehicleSnapshotVilRepository extends JpaRepository<VehicleSnapshotVil, VehicleSnapshotId> {

}
