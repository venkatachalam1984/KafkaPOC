package com.ford.gvmsr.snapobserver.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.PrintWriter;
import java.io.StringWriter;

@Component
public class ExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(ExceptionHandler.class);

    public void logException(Exception e, String className) {

        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        String exceptionAsString = sw.toString();
        try {
            if (exceptionAsString.length() > 175) {
                int classNameIndex = exceptionAsString.indexOf(className);
                int bracesIndex = exceptionAsString.indexOf(')', classNameIndex);
                String tmpExtractedString1 = exceptionAsString.substring(0, bracesIndex + 1);
                String tmpExtractedString2 = tmpExtractedString1.substring(tmpExtractedString1.lastIndexOf("at "), bracesIndex + 1);
                String tmpExtractedString3 = tmpExtractedString1.substring(0, tmpExtractedString1.indexOf("at ") - 1);
                logger.error(tmpExtractedString3 + " " + tmpExtractedString2);
            } else {
                logger.error(exceptionAsString);
            }

        } catch (Exception ex) {

            logger.error("*************  Exception thrown from  class ExceptionHandler Class ************** :"+ex.getMessage());


        }
    }
}