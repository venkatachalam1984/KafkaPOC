package com.ford.gvmsr.snapobserver.externalservice.downstream;


import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleStateRequest;

public interface GivisService {

    void sendToGivis(ModuleStateRequest moduleStateRequest);
}
