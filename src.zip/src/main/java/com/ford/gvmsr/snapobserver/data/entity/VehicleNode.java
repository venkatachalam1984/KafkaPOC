package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/30/2017.
 */
@Entity
@Table(name = "PGVMS15_VEH_NODE")
public class VehicleNode extends BaseEntity {

    @EmbeddedId
    private VehicleNodeId vehicleNodeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "GVMS10_VIN_R", referencedColumnName = "GVMS10_VIN_R",insertable = false,updatable = false),
            @JoinColumn(name = "GVMS10_VIN_HASH_R", referencedColumnName = "GVMS10_VIN_HASH_R",insertable = false,updatable = false)
    })
    private Vehicle vehicle;

    @Column(name = "GVM015_SRC_SYS_C")
    private String sourceSystem;

    @Column (name="GVMS15_PROTOFILE_VER_R")
    private String protoFileVersion;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS15_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS15_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS15_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS15_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public VehicleNodeId getVehicleNodeId() {
        return vehicleNodeId;
    }

    public void setVehicleNodeId(VehicleNodeId vehicleNodeId) {
        this.vehicleNodeId = vehicleNodeId;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getProtoFileVersion() {
        return protoFileVersion;
    }

    public void setProtoFileVersion(String protoFileVersion) {
        this.protoFileVersion = protoFileVersion;
    }

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

}
