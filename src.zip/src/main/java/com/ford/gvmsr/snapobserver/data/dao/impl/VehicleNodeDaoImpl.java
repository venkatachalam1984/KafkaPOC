package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeDao;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNode;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeId;
import com.ford.gvmsr.snapobserver.data.repository.VehicleNodeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class VehicleNodeDaoImpl implements VehicleNodeDao {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    VehicleNodeRepository vehicleNodeRepository;

    @Override
    public VehicleNode save(VehicleNode vehicleNode) {
        return vehicleNodeRepository.save(vehicleNode);
    }

    @Override
    public Map<String, VehicleNodeId> populateVehicleNodeIdMap(String vin, int vinHash){
        Map<String, VehicleNodeId> nodeIdMap = new HashMap<>();
        long start3 = System.currentTimeMillis();
        List<VehicleNode> vehicleNodeList = vehicleNodeRepository.findByVehicle_VehicleId_VinAndAndVehicle_VehicleId_VinHashNumber(vin, vinHash);
        long end3 = System.currentTimeMillis() - start3;
        logger.debug("Time taken populateVehicleNodeIdMap All::::::" + end3);
        vehicleNodeList.forEach(vehicleNode -> {
            nodeIdMap.put(vehicleNode.getVehicleNodeId().getNodeAddress(), vehicleNode.getVehicleNodeId());
        });
        return nodeIdMap;
    }

}
