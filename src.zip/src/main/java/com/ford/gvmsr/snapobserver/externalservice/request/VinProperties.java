package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.List;

/**
 * Created by MDEVARA3 on 11/2/2018.
 */
public class VinProperties {

    private List<String> nodeAddress;

    private String vin;

    private String role;

    private String roleSource;

    private String roleDesc;

    private String roleID;

    private String givisTraceID;

    private String gvmsTransId;

    private String gvmsTransDtlId;

    public String getGvmsTransId() {
        return gvmsTransId;
    }

    public void setGvmsTransId(String gvmsTransId) {
        this.gvmsTransId = gvmsTransId;
    }

    public String getGvmsTransDtlId() {
        return gvmsTransDtlId;
    }

    public void setGvmsTransDtlId(String gvmsTransDtlId) {
        this.gvmsTransDtlId = gvmsTransDtlId;
    }

    public String getGivisTraceID() {
        return givisTraceID;
    }

    public void setGivisTraceID(String givisTraceID) {
        this.givisTraceID = givisTraceID;
    }

    public List<String> getNodeAddress() {
        return nodeAddress;
    }

    public String getRoleSource() {
        return roleSource;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public String getRoleID() {
        return roleID;
    }

    public void setNodeAddress(List<String> nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setRoleSource(String roleSource) {
        this.roleSource = roleSource;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public void setRoleID(String roleID) {
        this.roleID = roleID;
    }


}
