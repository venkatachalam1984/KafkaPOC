package com.ford.gvmsr.snapobserver.data.dao.impl;


import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.data.dao.TransactionDao;
import com.ford.gvmsr.snapobserver.data.entity.transaction.Application;
import com.ford.gvmsr.snapobserver.data.repository.transaction.ApplicationRepository;
import com.ford.gvmsr.snapobserver.exception.ExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Date;

@Component
public class TransactionDaoImpl implements TransactionDao {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    ApplicationRepository applicationRepository;

    @Autowired
    ExceptionHandler exceptionHandler;

    private DataSource dataSource;

    private static final String INSERT_TXN_DTL = "INSERT INTO PGVMT01_TXN(GVMT01_TXN_D,\n" +
            "GVMT02_TXN_STAT_C,\n" +
            "GVMT08_TXN_TYPE_C,\n" +
            "GVMT01_TXN_START_S,\n" +
            "GVMT01_TXN_END_S,\n" +
            "GVMT01_TRACE_D,\n"+
            "GVMT01_MIC_SVC_N,\n" +
            "GVMT01_TXN_DESC_X, \n" +
            "GVMT09_APPL_D,\n" +
            "GVMT01_RETRY_T,\n" +
            "GVMT01_CREATE_USER_C,\n" +
            "GVMT01_CREATE_S,\n" +
            "GVMT01_LAST_UPDT_USER_C,\n" +
            "GVMT01_LAST_UPDT_S)\n" +
            "values(PGVMT01_TXN_D_SQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public TransactionDaoImpl(@Qualifier("dataSource") DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public long save(String traceId, String statusCode,
                     String transType, String serviceName, String appName) {

        long start = System.currentTimeMillis();
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        long txnId = 0;
        try {

            Application application = applicationRepository.findByApplicationCode(appName);

            //STEP 1: Open a connection insert
            conn = dataSource.getConnection();
            //STEP 2: Execute a query
            preparedStatement = conn.prepareStatement(INSERT_TXN_DTL,new String[]{"GVMT01_TXN_D"});
            conn.setAutoCommit(false);

            preparedStatement.setString(1, statusCode);
            preparedStatement.setString(2, transType);
            preparedStatement.setTimestamp(3, new Timestamp(new Date().getTime()));
            preparedStatement.setTimestamp(4,new Timestamp(new Date().getTime()));
            preparedStatement.setString(5,null);
            preparedStatement.setString(6, serviceName);
            preparedStatement.setString(7,traceId);
            preparedStatement.setLong(8, application.getApplicationId());
            preparedStatement.setInt(9, 0);
            preparedStatement.setString(10, GVMSModuleUpdateConstants.APP_CODE_GVMS);
            preparedStatement.setTimestamp(11, new Timestamp(new Date().getTime()));
            preparedStatement.setString(12, GVMSModuleUpdateConstants.APP_CODE_GVMS);
            preparedStatement.setTimestamp(13, new Timestamp(new Date().getTime()));
            int prepStmt = preparedStatement.executeUpdate();

            if(prepStmt > 0 )
            {
                ResultSet rs = preparedStatement.getGeneratedKeys();
                if(rs != null && rs.next()){
                    txnId = rs.getLong(1);
                }
            }
            conn.commit();
            preparedStatement.close();
            conn.setAutoCommit(true);
            conn.close();
        } catch (Exception e) {
            //Handle errors for Class.forName
            exceptionHandler.logException(e, this.getClass().getSimpleName());
        } finally {
            //finally block used to close resources
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                exceptionHandler.logException(se, this.getClass().getSimpleName());
            }//end finally try
        }
        long end = System.currentTimeMillis() - start;
        LOGGER.debug("Time taken to save Txn:::" + end);
        return txnId;
    }
}
