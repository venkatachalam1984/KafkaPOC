package com.ford.gvmsr.snapobserver.data.entity;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/29/2017.
 *
 *  Type of user that initiated a change in the state of software loaded onto a module. Values: CONSUMER, DEALER
    Optional to Software Catalog to preserve 1PP code, no ROLE for EOL or CONTI
    Data Source: GIVIS:NMGM025_REQUESTOR_ROLE
 */
@Entity
@Table(name = "PGVMS01_REQUESTOR_ROLE")
public class RequestorRole extends BaseEntity {

    @Id
    @Column(name = "GVMS01_ROLE_N")
    private String roleName;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS01_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS01_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS01_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS01_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();


    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

}
