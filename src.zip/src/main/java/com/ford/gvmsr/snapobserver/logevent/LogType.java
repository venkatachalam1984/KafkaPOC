package com.ford.gvmsr.snapobserver.logevent;

public enum LogType {
    INFO("info"), ERROR("error"), FATAL("FATAL");

    private String code;

    LogType(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }

    }
