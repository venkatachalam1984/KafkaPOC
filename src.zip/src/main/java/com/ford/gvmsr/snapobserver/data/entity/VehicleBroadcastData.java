package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by VYUVARA6 on 8/30/2017.
 * A table containing vehicle broacast com.ford.cloudnative.gvms.moduleinfo.com.ford.cloudnative.gvms.moduleupdate.data, which is used during assembly of a vehicle.
 Data Source: GIVIS:NMGM061_VEH_BRDCST_DATA
 *
 */

@Entity
@Table(name = "PGVMS05_VEH_BRDCST_DATA")
public class VehicleBroadcastData extends BaseEntity {
    @EmbeddedId
    private VehicleId vehicleId;

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "GVMS10_VIN_R", insertable = false, updatable = false),
            @JoinColumn(name = "GVMS10_VIN_HASH_R", insertable = false, updatable = false)})
    private Vehicle vehicle;

    @Column(name = "GVMS05_LAST_BRDCST_S")
    private Timestamp lastBroadcastTime;

    @Column(name = "GVMS05_BRDCST_X")
    private String broadcastText;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS05_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS05_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS05_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS05_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();


    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Timestamp getLastBroadcastTime() {
        return lastBroadcastTime;
    }

    public void setLastBroadcastTime(Timestamp lastBroadcastTime) {
        this.lastBroadcastTime = lastBroadcastTime;
    }

    public String getBroadcastText() {
        return broadcastText;
    }

    public void setBroadcastText(String broadcastText) {
        this.broadcastText = broadcastText;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public VehicleId getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(VehicleId vehicleId) {
        this.vehicleId = vehicleId;
    }
}
