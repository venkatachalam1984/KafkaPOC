package com.ford.gvmsr.snapobserver.data.entity;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

/**
 * Created by MDEVARA3 on 8/30/2017.
 */
@Entity
@Table(name = "PGVMS04_VEH_NODE_SNPSHT")
//@IdClass(VehicleNodeSnapshotId.class)
public class VehicleNodeSnapshot extends BaseEntity {
/*
    @Id
    @Column(name = "GVMS04_VEH_NODE_SNPSHT_K")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vehicleNodeSnapshotKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;*/
/*
    @Id
    @Column(name = "GVMS04_VEH_NODE_SNPSHT_K")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMS04_VEH_NODE_SNPSHT_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS04_VEH_NODE_SNPSHT_K_SQ_GEN", sequenceName = "PGVMS04_VEH_NODE_SNPSHT_K_SQ", allocationSize = 1)
    private Long vehicleNodeSnapshotKey;

    @Id
    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;*/

    @EmbeddedId
    private VehicleNodeSnapshotId vehicleNodeSnapshotId;

    @Column(name = "GVM019_ECU_ACRONYM_C")
    private String ecuAcronym;

    @Embedded
    private FordPartNumberId fordPartNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GVMS03_VEH_SNPSHT_K", referencedColumnName = "GVMS03_VEH_SNPSHT_K")
    private VehicleSnapshot vehicleSnapshot;

    @Column(name = "GVMS10_VIN_R")
    private String vin;

    @Column(name = "GVM023_NODE_ADRS_C")
    private String nodeAddress;

    @Column(name = "GVMS04_VSCS_VER_X")
    private String vscsVersionDesc;

    @Column(name = "GVMS04_VSCS_VER_S")
    private Timestamp vscsVersionDate;

    @Column(name = "GVMS04_ROLE_EVENT_C")
    private String roleEventCode;

    @Column(name = "GVMS04_IS_PROVISIONED_F")
    private String isProvisionedFlag;

    @Column(name = "GVMS04_ACTIVE_F")
    private String activeFlag;

    // Change for Table 4 column addition GVMS04_RECORD_S

    @Column(name = "GVMS04_RECORD_S")
    private Timestamp nodeTimeStamp;


    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS04_CREATE_USER_C", updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS04_CREATE_S", updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS04_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS04_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();


    public VehicleNodeSnapshotId getVehicleNodeSnapshotId() {
        return vehicleNodeSnapshotId;
    }

    public void setVehicleNodeSnapshotId(VehicleNodeSnapshotId vehicleNodeSnapshotId) {
        this.vehicleNodeSnapshotId = vehicleNodeSnapshotId;
    }

    /*public Long getVehicleNodeSnapshotKey() {
        return this.vehicleNodeSnapshotKey;
    }

    public void setVehicleNodeSnapshotKey(Long vehicleNodeSnapshotKey) {
        this.vehicleNodeSnapshotKey = vehicleNodeSnapshotKey;
    }

    public int getVinHashNumber() {
        return this.vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }*/

    public VehicleSnapshot getVehicleSnapshot() {
        return vehicleSnapshot;
    }

    public void setVehicleSnapshot(VehicleSnapshot vehicleSnapshot) {
        this.vehicleSnapshot = vehicleSnapshot;
    }

    public String getVscsVersionDesc() {
        return vscsVersionDesc;
    }

    public void setVscsVersionDesc(String vscsVersionDesc) {
        this.vscsVersionDesc = vscsVersionDesc;
    }

    public Timestamp getVscsVersionDate() {
        return vscsVersionDate;
    }

    public void setVscsVersionDate(Timestamp vscsVersionDate) {
        this.vscsVersionDate = vscsVersionDate;
    }

    public String getRoleEventCode() {
        return roleEventCode;
    }

    public void setRoleEventCode(String roleEventCode) {
        this.roleEventCode = roleEventCode;
    }

    public FordPartNumberId getFordPartNumber() {
        return fordPartNumber;
    }

    public void setFordPartNumber(FordPartNumberId fordPartNumber) {
        this.fordPartNumber = fordPartNumber;
    }

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

/*    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }*/

    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    public String getIsProvisionedFlag() {
        return isProvisionedFlag;
    }

    public void setIsProvisionedFlag(String isProvisionedFlag) {
        this.isProvisionedFlag = isProvisionedFlag;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    // Change for Table 4 column addition GVMS04_RECORD_S

    public void setNodeTimeStamp(Timestamp nodeTimeStamp) {
        this.nodeTimeStamp = nodeTimeStamp;
    }

    // Change for Table 4 column addition GVMS04_RECORD_S

    public Timestamp getNodeTimeStamp() { return nodeTimeStamp;  }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VehicleNodeSnapshot that = (VehicleNodeSnapshot) o;
        return Objects.equals(nodeAddress, that.nodeAddress);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nodeAddress);
    }
}
