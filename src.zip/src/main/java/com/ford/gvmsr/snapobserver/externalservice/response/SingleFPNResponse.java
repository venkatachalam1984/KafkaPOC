package com.ford.gvmsr.snapobserver.externalservice.response;

/**
 * Created by MDEVARA3 on 3/9/2018.
 */
public class SingleFPNResponse {

    private String softwareCatalogType;
    private String programmingProtectedFlag;
    private String softwareComponentSubtype;
    private String partType;
    private String didValue;

    public String getPartType() {
        return partType;
    }

    public void setPartType(String partType) {
        this.partType = partType;
    }

    public String getSoftwareCatalogType() {
        return softwareCatalogType;
    }

    public void setSoftwareCatalogType(String softwareCatalogType) {
        this.softwareCatalogType = softwareCatalogType;
    }

    public String getProgrammingProtectedFlag() {
        return programmingProtectedFlag;
    }

    public void setProgrammingProtectedFlag(String programmingProtectedFlag) {
        this.programmingProtectedFlag = programmingProtectedFlag;
    }

    public String getSoftwareComponentSubtype() {
        return softwareComponentSubtype;
    }

    public void setSoftwareComponentSubtype(String softwareComponentSubtype) {
        this.softwareComponentSubtype = softwareComponentSubtype;
    }

    public String getDidValue() {
        return didValue;
    }

    public void setDidValue(String didValue) {
        this.didValue = didValue;
    }
}
