package com.ford.gvmsr.snapobserver.exception;

public class ESNDidValidationException extends Exception{

    public ESNDidValidationException(String message) {
        super(message);
    }
}
