package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.List;
import java.util.Map;

/**
 * Created by vm4 on 12/05/2018.
 */

public class PersistNodeAndDidAndFPNRequest {


    private String programCode;

    private Float salesModelYear;

    private String vin;

    private Map<String, List<FPNDIDInfoType>> didInfobyNodeMap;

    private List<NodeAddress> persistNodeList;

    private List<DIDCatalog> pesrsistDidcatalogList;

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public Float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(Float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public Map<String, List<FPNDIDInfoType>> getDidInfobyNodeMap() {
        return didInfobyNodeMap;
    }

    public void setDidInfobyNodeMap(Map<String, List<FPNDIDInfoType>> didInfobyNodeMap) {
        this.didInfobyNodeMap = didInfobyNodeMap;
    }

    public List<NodeAddress> getPersistNodeList() {
        return persistNodeList;
    }

    public void setPersistNodeList(List<NodeAddress> persistNodeList) {
        this.persistNodeList = persistNodeList;
    }

    public List<DIDCatalog> getPesrsistDidcatalogList() {
        return pesrsistDidcatalogList;
    }

    public void setPesrsistDidcatalogList(List<DIDCatalog> pesrsistDidcatalogList) {
        this.pesrsistDidcatalogList = pesrsistDidcatalogList;
    }
}
