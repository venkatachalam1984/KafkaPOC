
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for StateUpdateRoleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StateUpdateRoleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Role" type="{urn:ford/Vehicle/Module/Information/v4.0}RoleENUMType"/&gt;
 *         &lt;element name="RoleSource" type="{urn:ford/Vehicle/Module/Information/v4.0}RoleSourceENUMType" minOccurs="0"/&gt;
 *         &lt;element name="RoleEvent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RoleDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RoleID" type="{urn:ford/Vehicle/Module/Information/v4.0}RoleIDType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StateUpdateRoleType", propOrder = {
    "role",
    "roleSource",
    "roleEvent",
    "roleDesc",
    "roleID"
})
public class StateUpdateRoleType {

    @XmlElement(name = "Role", required = true)
    @XmlSchemaType(name = "string")
    protected RoleENUMType role;
    @XmlElement(name = "RoleSource")
    @XmlSchemaType(name = "string")
    protected RoleSourceENUMType roleSource;
    @XmlElement(name = "RoleEvent")
    protected String roleEvent;
    @XmlElement(name = "RoleDesc")
    protected String roleDesc;
    @XmlElement(name = "RoleID")
    protected String roleID;

    /**
     * Gets the value of the role property.
     * 
     * @return
     *     possible object is
     *     {@link RoleENUMType }
     *     
     */
    public RoleENUMType getRole() {
        return role;
    }

    /**
     * Sets the value of the role property.
     * 
     * @param value
     *     allowed object is
     *     {@link RoleENUMType }
     *     
     */
    public void setRole(RoleENUMType value) {
        this.role = value;
    }

    /**
     * Gets the value of the roleSource property.
     * 
     * @return
     *     possible object is
     *     {@link RoleSourceENUMType }
     *     
     */
    public RoleSourceENUMType getRoleSource() {
        return roleSource;
    }

    /**
     * Sets the value of the roleSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link RoleSourceENUMType }
     *     
     */
    public void setRoleSource(RoleSourceENUMType value) {
        this.roleSource = value;
    }

    /**
     * Gets the value of the roleEvent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleEvent() {
        return roleEvent;
    }

    /**
     * Sets the value of the roleEvent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleEvent(String value) {
        this.roleEvent = value;
    }

    /**
     * Gets the value of the roleDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleDesc() {
        return roleDesc;
    }

    /**
     * Sets the value of the roleDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleDesc(String value) {
        this.roleDesc = value;
    }

    /**
     * Gets the value of the roleID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleID() {
        return roleID;
    }

    /**
     * Sets the value of the roleID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleID(String value) {
        this.roleID = value;
    }

}
