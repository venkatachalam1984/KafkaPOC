package com.ford.gvmsr.snapobserver.redis;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Component
public interface RedisRepository {

    OpsForString opsForString();

    public boolean incrementIfPresentSetIfAbsent(String key, long duration, TimeUnit timeUnit, int maxCount);

    /* ================== String operations ================== */
    interface OpsForString {

        public boolean setKey(String key, String value);

        public boolean delKey(String key);

        public String getKey(String key);

        public boolean delMultiKeys(List<String> keyList);

        public void setMultiKeys(Map<String, String> keyValueMap);

    }

}
