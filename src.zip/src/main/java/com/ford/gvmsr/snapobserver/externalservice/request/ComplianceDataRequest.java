package com.ford.gvmsr.snapobserver.externalservice.request;

/**
 * Created by mdevara3 on 12/29/2017.
 */
//@JsonTypeInfo(include= JsonTypeInfo.As.WRAPPER_OBJECT, use= JsonTypeInfo.Id.NAME)
public class ComplianceDataRequest {

    private String modifiedResponse;
    private String programCode;
    private float salesModelYear;
    private String nodeAddress;
    private String ecuAcronym;

    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    public String getModifiedResponse() {
        return modifiedResponse;
    }

    public void setModifiedResponse(String modifiedResponse) {
        this.modifiedResponse = modifiedResponse;
    }

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }
}
