package com.ford.gvmsr.snapobserver.externalservice.response;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by MDEVARA3 on 1/3/2018.
 */
public class FASGetLeadNodeResponse {

    private int partitionKey;

    private long infoKey;

    private Map<String, LeadNodeResponse> nodeLeadNodeMap = new HashMap<>();

    public long getInfoKey() {
        return infoKey;
    }

    public void setInfoKey(long infoKey) {
        this.infoKey = infoKey;
    }

    public int getPartitionKey() {
        return partitionKey;
    }

    public void setPartitionKey(int partitionKey) {
        this.partitionKey = partitionKey;
    }

    public Map<String, LeadNodeResponse> getNodeLeadNodeMap() {
        return nodeLeadNodeMap;
    }

    public void setNodeLeadNodeMap(Map<String, LeadNodeResponse> nodeLeadNodeMap) {
        this.nodeLeadNodeMap = nodeLeadNodeMap;
    }
}