package com.ford.gvmsr.snapobserver.creator;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;


public interface VehicleSnapshotCreator {

    VehicleSnapshot createVehicleSnapshot(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, Vehicle vehicle);
}
