package com.ford.gvmsr.snapobserver.data.entity.transaction;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="PGVMT07_TXN_MSG")
public class TransactionMessage extends BaseEntity {

    @Id
    @Column (name="GVMT07_TXN_MSG_D")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMT07_TXN_MSG_D_SQ_GEN")
    @SequenceGenerator(name = "PGVMT07_TXN_MSG_D_SQ_GEN", sequenceName = "PGVMT07_TXN_MSG_D_SQ", allocationSize = 1)
    private Long  transactionMessageId;

    @ManyToOne
    @JoinColumn (name="GVMT01_TXN_D", referencedColumnName="GVMT01_TXN_D", updatable=false, insertable=true)
    private Transaction transactionId;

    @ManyToOne
    @JoinColumn (name="GVMT03_TXN_DTL_D", referencedColumnName="GVMT03_TXN_DTL_D", updatable=false, insertable=true)
    private TransactionDetail transactionDetailId;

    @Column(name="GVMT07_MSG_S")
    private Timestamp transactionMessageTime;

    @Column(name="GVMT07_MSG_C")
    private String transactionMessageCode;

    @Column(name="GVMT07_MSG_STRING_X")
    private String transactionMessageDesc;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT07_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT07_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT07_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT07_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public Long  getTransactionMessageId() {
        return transactionMessageId;
    }

    public void setTransactionMessageId(Long  transactionMessageId) {
        this.transactionMessageId = transactionMessageId;
    }

    public Transaction getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Transaction transactionId) {
        this.transactionId = transactionId;
    }

    public TransactionDetail getTransactionDetailId() {
        return transactionDetailId;
    }

    public void setTransactionDetailId(TransactionDetail transactionDetailId) {
        this.transactionDetailId = transactionDetailId;
    }

    public Timestamp getTransactionMessageTime() {
        return transactionMessageTime;
    }

    public void setTransactionMessageTime(Timestamp transactionMessageTime) {
        this.transactionMessageTime = transactionMessageTime;
    }

    public String getTransactionMessageCode() {
        return transactionMessageCode;
    }

    public void setTransactionMessageCode(String transactionMessageCode) {
        this.transactionMessageCode = transactionMessageCode;
    }

    public String getTransactionMessageDesc() {
        return transactionMessageDesc;
    }

    public void setTransactionMessageDesc(String transactionMessageDesc) {
        this.transactionMessageDesc = transactionMessageDesc;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }


}
