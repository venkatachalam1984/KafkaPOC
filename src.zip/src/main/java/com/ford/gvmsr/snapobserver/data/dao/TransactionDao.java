package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.transaction.Transaction;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;

import java.sql.SQLException;

public interface TransactionDao {
    long save(String traceId , String statusCode,
              String transType, String serviceName, String appName);
}
