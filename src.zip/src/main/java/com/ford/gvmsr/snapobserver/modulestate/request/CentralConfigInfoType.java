
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CentralConfigInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CentralConfigInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CentralConfigType" type="{urn:ford/Vehicle/Module/Information/v4.0}CentralConfigTypeType"/&gt;
 *         &lt;element name="CentralConfigBackupStatus" type="{urn:ford/Vehicle/Module/Information/v4.0}CentralConfigBackupStatusType"/&gt;
 *         &lt;element name="CentralConfigSlaveStatus" type="{urn:ford/Vehicle/Module/Information/v4.0}CentralConfigSlaveStatusType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CentralConfigInfoType", propOrder = {
    "centralConfigType",
    "centralConfigBackupStatus",
    "centralConfigSlaveStatus"
})
public class CentralConfigInfoType {

    @XmlElement(name = "CentralConfigType", required = true)
    protected String centralConfigType;
    @XmlElement(name = "CentralConfigBackupStatus", required = true)
    protected String centralConfigBackupStatus;
    @XmlElement(name = "CentralConfigSlaveStatus", required = true)
    protected String centralConfigSlaveStatus;

    /**
     * Gets the value of the centralConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCentralConfigType() {
        return centralConfigType;
    }

    /**
     * Sets the value of the centralConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCentralConfigType(String value) {
        this.centralConfigType = value;
    }

    /**
     * Gets the value of the centralConfigBackupStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCentralConfigBackupStatus() {
        return centralConfigBackupStatus;
    }

    /**
     * Sets the value of the centralConfigBackupStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCentralConfigBackupStatus(String value) {
        this.centralConfigBackupStatus = value;
    }

    /**
     * Gets the value of the centralConfigSlaveStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCentralConfigSlaveStatus() {
        return centralConfigSlaveStatus;
    }

    /**
     * Sets the value of the centralConfigSlaveStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCentralConfigSlaveStatus(String value) {
        this.centralConfigSlaveStatus = value;
    }

}
