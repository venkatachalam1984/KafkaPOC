package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.helper.SnapCreationHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Map;

@Component
public class DefaultDidRule {
    private static final Logger logger = LoggerFactory.getLogger(DefaultDidRule.class);

    @Autowired
    SnapCreationHelper snapCreationHelper;

    public void populateDidEntity(PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode, DIDInfoType did,
                                  NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap, ModuleNodeType node, ModuleSnapshotObserverRequest snapshotObserverRequest) {
        VehicleNodeDIDResponse vehicleNodeDIDResponse = new VehicleNodeDIDResponse();

        //validate did response and compare prevConfig did response
        String didResponse = validateDefaultDidRule(previousSnapShotDetailsByNode.getPrevNonConfigDidResponseMap(), node, did, snapshotObserverRequest);

        // populate the vehicleNodeDIDResponse for 2 table persistence
        vehicleNodeDIDResponse.setDidResponse(didResponse);
        snapCreationHelper.populateVehicleNodeDIDResponse(vehicleNodeDIDResponse, did, node, snapshotObserverRequest, previousSnapShotDetailsByNode);
        nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList().add(vehicleNodeDIDResponse);
    }


    private String validateDefaultDidRule(Map<String, VehicleNodeDIDResponse> prevVehicleNodeDIDResponseMap, ModuleNodeType node, DIDInfoType did, ModuleSnapshotObserverRequest snapshotObserverRequest) {

        String didResponse = ApplicationUtils.toUpperCase(did.getResponse());

        if (!CollectionUtils.isEmpty(prevVehicleNodeDIDResponseMap) && prevVehicleNodeDIDResponseMap.containsKey(did.getDidValue())) {

            String prevDidResponse = prevVehicleNodeDIDResponseMap.get(did.getDidValue()).getDidResponse();

            if (didResponse != null &&
                    !prevDidResponse.equalsIgnoreCase(didResponse)) {
                snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.NON_CONFIG_DID, true);
            }
        }else if(prevVehicleNodeDIDResponseMap.isEmpty() || !prevVehicleNodeDIDResponseMap.containsKey(did.getDidValue())){
            snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.NON_CONFIG_DID, true);
        }
        return didResponse;
    }

}
