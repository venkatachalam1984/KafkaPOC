package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.ModuleNode;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.List;

@Repository
@Transactional
public interface ModuleNodeRepository extends CrudRepository<ModuleNode, Serializable> {

    public ModuleNode findModuleNodeByIvsProgramId_ProgramCodeAndIvsProgramId_SalesModelYearAndNodeAddressAndGwNodeId(String programCode, Float salesModelYear, String nodeAddress, String gwNodeId);

    public List<ModuleNode> findAllByIvsProgramId_ProgramCodeAndIvsProgramId_SalesModelYear(String programCode, Float salesModelYear);

    @Query(value = "SELECT PGVMS14_MOD_NODE_K_SQ.NEXTVAL FROM DUAL", nativeQuery = true)
    public Long getModuleNodeKey();
}
