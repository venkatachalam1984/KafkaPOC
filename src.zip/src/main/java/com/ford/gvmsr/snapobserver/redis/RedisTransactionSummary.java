package com.ford.gvmsr.snapobserver.redis;

public class RedisTransactionSummary {

    private String vin;
    private String nodeAddress;
    private String serviceName;
    private String ProcessName;
    private String redisKey;
    private boolean redisStatus;
    private String programCode;
    private String modelYear;
    private String traceId;
    private String redisResponseTime;

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getProcessName() {
        return ProcessName;
    }

    public void setProcessName(String processName) {
        ProcessName = processName;
    }

    public String getRedisKey() {
        return redisKey;
    }

    public void setRedisKey(String redisKey) {
        this.redisKey = redisKey;
    }

    public boolean isRedisStatus() {
        return redisStatus;
    }

    public void setRedisStatus(boolean redisStatus) {
        this.redisStatus = redisStatus;
    }

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public String getModelYear() {
        return modelYear;
    }

    public void setModelYear(String modelYear) {
        this.modelYear = modelYear;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getRedisResponseTime() {
        return redisResponseTime;
    }

    public void setRedisResponseTime(String redisResponseTime) {
        this.redisResponseTime = redisResponseTime;
    }
}

