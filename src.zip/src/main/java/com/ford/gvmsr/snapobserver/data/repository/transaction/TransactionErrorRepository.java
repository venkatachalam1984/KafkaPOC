package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.TransactionError;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;

public interface TransactionErrorRepository extends CrudRepository<TransactionError, Serializable> {
}
