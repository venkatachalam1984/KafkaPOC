
package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "did",
    "didResp",
    "complainceDid",
    "complainceDidResp"
})
public class DIDInfo implements Comparable<DIDInfo>{

    /**
     * The Did Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("did")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String did = "";
    /**
     * The Didresp Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("didResp")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String didResp = "";
    /**
     * The Complaincedid Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("complainceDid")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String complainceDid = "";
    /**
     * The Complaincedidresp Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("complainceDidResp")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String complainceDidResp = "";


    @JsonProperty("modifiedResponse")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String modifiedResponse;

    @JsonProperty("node")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String node;


    @JsonProperty("ecuAcronym")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String ecuAcronym;


    @JsonProperty("didType")
    @JsonPropertyDescription("An explanation about the purpose of this instance.")
    private String didType;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getModifiedResponse() {
        return modifiedResponse;
    }

    public void setModifiedResponse(String modifiedResponse) {
        this.modifiedResponse = modifiedResponse;
    }


    public String getEcuAcronym() {
        return ecuAcronym;
    }

    public void setEcuAcronym(String ecuAcronym) {
        this.ecuAcronym = ecuAcronym;
    }

    /**
     * The Did Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("did")
    public String getDid() {
        return did;
    }

    /**
     * The Did Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("did")
    public void setDid(String did) {
        this.did = did;
    }

    /**
     * The Didresp Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("didResp")
    public String getDidResp() {
        return didResp;
    }

    /**
     * The Didresp Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("didResp")
    public void setDidResp(String didResp) {
        this.didResp = didResp;
    }

    /**
     * The Complaincedid Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("complainceDid")
    public String getComplainceDid() {
        return complainceDid;
    }

    /**
     * The Complaincedid Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("complainceDid")
    public void setComplainceDid(String complainceDid) {
        this.complainceDid = complainceDid;
    }

    /**
     * The Complaincedidresp Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("complainceDidResp")
    public String getComplainceDidResp() {
        return complainceDidResp;
    }

    /**
     * The Complaincedidresp Schema.
     * <p>
     * An explanation about the purpose of this instance.
     *
     */
    @JsonProperty("complainceDidResp")
    public void setComplainceDidResp(String complainceDidResp) {
        this.complainceDidResp = complainceDidResp;
    }

    @JsonProperty("didType")
    public String getDidType() {
        return didType;
    }

    @JsonProperty("didType")
    public void setDidType(String didType) {
        this.didType = didType;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s", this.did, this.didResp, this.complainceDid, this.complainceDidResp);
    }

    @Override
    public int compareTo(DIDInfo other) {
        return this.toString().compareToIgnoreCase(other.toString());
    }
}
