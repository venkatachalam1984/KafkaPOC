package com.ford.gvmsr.snapobserver.data.entity;


import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by VYUVARA6 on 8/29/2017.
 */

/**
 *"The master list of the WERS Feature that are fetched from SAVE system
 e.g.
 3AGQ4
 978CE
 BSFC
 Data Source: GIVIS:NMGM164_WERS_FTR"
 */

@Entity
@Table(name = "PGVMS17_WERS_FTR")
public class WersFeature extends BaseEntity {

    @Id
    @Column(name = "GVMS17_FTR_FAM_K")
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "PGVMS17_FTR_FAM_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS17_FTR_FAM_K_SQ_GEN", sequenceName = "PGVMS17_FTR_FAM_K_SQ", allocationSize = 1)
    private Long featureFamilySakey;

    @Column(name = "GVMS17_FTR_C")
    private String featureCode;

    @Column(name = "GVMS17_FTR_X")
    private String featureDescription;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS17_CREATE_USER_C",updatable = false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS17_CREATE_S",updatable = false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS17_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS17_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public Long getFeatureFamilySakey() {
        return featureFamilySakey;
    }

    public void setFeatureFamilySakey(Long featureFamilySakey) {
        this.featureFamilySakey = featureFamilySakey;
    }

    public String getFeatureCode() {
        return featureCode;
    }

    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public String getFeatureDescription() {
        return featureDescription;
    }

    public void setFeatureDescription(String featureDescription) {
        this.featureDescription = featureDescription;
    }


    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }
}
