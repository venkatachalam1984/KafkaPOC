package com.ford.gvmsr.snapobserver.data.entity.base;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by VYUVARA6 on 9/4/2017.
 */
public class BaseEntityEventListener {
    @PrePersist
    public void onPreInsert(BaseEntity baseEntity){
        baseEntity.setCreatedUser("GVMS");
        baseEntity.setCreatedTimestamp(new Timestamp(new Date().getTime()));
        baseEntity.setLastUpdatedUser("GVMS");
        baseEntity.setLastUpdatedTimestamp(new Timestamp(new Date().getTime()));
    }

    @PreUpdate
    public void onPreUpdate(BaseEntity baseEntity){
        baseEntity.setCreatedUser("GVMS");
        baseEntity.setCreatedTimestamp(new Timestamp(new Date().getTime()));
        baseEntity.setLastUpdatedUser("GVMS");
        baseEntity.setLastUpdatedTimestamp(new Timestamp(new Date().getTime()));
    }

}
