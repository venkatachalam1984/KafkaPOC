package com.ford.gvmsr.snapobserver.creator.impl;

import com.ford.gvmsr.snapobserver.creator.DidCreator;
import com.ford.gvmsr.snapobserver.creator.AppDidCreator;
import com.ford.gvmsr.snapobserver.data.entity.*;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.handler.SnapshotSaveHandler;
import com.ford.gvmsr.snapobserver.helper.ApplicationDidHelper;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

@Service
public class DidCreationHandler implements DidCreator {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    SnapshotSaveHandler snapshotSaveHandler;

    @Autowired
    AppDidCreator appDidCreator;

    @Autowired
    ApplicationDidHelper applicationDidHelper;

    @Override
    public void persistDid(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, VehicleNodeSnapshot vehicleNodeSnapshot) throws SQLException {

        LOGGER.info("DidCreation:Entering  persistDid");
        NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap = moduleSnapshotObserverRequest.getNodeAndDIDResponseForNewSnapMap().get(vehicleNodeSnapshot.getNodeAddress());
        Map<String, VehicleNodeDIDStatus> applicationSwPartNumberStateMap = new HashMap<>();
        Map<String, VehicleNodeDIDStatus> otherSwPartNumberStateMap = new HashMap();
        Map<String, String> swapMap = new HashMap<>();
        List<VehicleNodeDIDStatus> vehicleNodeDIDStatusListToPersist = new ArrayList<>();
        boolean isESNFoundForAPIM = false;
        AtomicBoolean isESNFoundForTCU = new AtomicBoolean(false);
        Pattern esnFormatPattern = Pattern.compile("[0-9A-Z]{8}");

        if (nodeAndDIDResponseForNewSnap != null) {

            List<VehicleNodeDIDResponse> vehicleNodeDIDResponses = nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList();
            List<VehicleNodeDIDResponse> insertVehicleNodeDIDResponseList = new ArrayList<>();
            List<VehicleNodeConfig> vehicleNodeConfigList = new ArrayList<>();

            if (!vehicleNodeDIDResponses.isEmpty()) {
                for (VehicleNodeDIDResponse vehicleNodeDIDResponse : vehicleNodeDIDResponses) {
                    ModuleNode moduleNode = getModuleNode(nodeAndDIDResponseForNewSnap, vehicleNodeDIDResponse);
                    //Setting 14 table entry
                    vehicleNodeDIDResponse.setModuleNode(moduleNode);
                    //Setting 04 table entry
                    vehicleNodeDIDResponse.setVehicleNodeSnapshot(vehicleNodeSnapshot);
                    insertVehicleNodeDIDResponseList.add(vehicleNodeDIDResponse);
                }// vehicleNodeDIDResponses loop end.
            }

            //insert insertVehicleNodeDIDResponse as a batch into 02 table
            snapshotSaveHandler.saveVehicleNodeDIDResponse(insertVehicleNodeDIDResponseList);
            LOGGER.info("DidCreation:VehicleNodeDIDResponse for VIN=[{}] Node =[{}] Saved  Successfully", moduleSnapshotObserverRequest.getVin(), vehicleNodeSnapshot.getNodeAddress());

            /* Fetching all currently installed softWares from VehicleNodeDIDState Table(20) for NODE
             and set it in applicationSwPartNumberStateMap and otherSwPartNumberStateMap */
            for (VehicleNodeDIDStatus vehicleNodeDIDStatus : nodeAndDIDResponseForNewSnap.getPreviousVehicleNodeStatusList()) {
                if (applicationDidHelper.isApplicationDid(vehicleNodeDIDStatus.getDidCatalog())) {
                    applicationSwPartNumberStateMap.put(vehicleNodeDIDStatus.getPartNumber().toString(), vehicleNodeDIDStatus);
                } else {
                    otherSwPartNumberStateMap.put(vehicleNodeDIDStatus.getDidCatalog(), vehicleNodeDIDStatus);
                }
            }

            //after saving 02 table based on that will persist below tables
            if (!insertVehicleNodeDIDResponseList.isEmpty()){
                for (VehicleNodeDIDResponse vehicleNodeDIDResponse : insertVehicleNodeDIDResponseList) {

                    //populate VehicleNodeConfigList to persist 06 table
                    populateVehicleNodeConfigList(nodeAndDIDResponseForNewSnap, vehicleNodeDIDResponse, vehicleNodeConfigList);

                    //insert software part list into 07 table for application did
                    appDidCreator.persistApplicationDid(moduleSnapshotObserverRequest, vehicleNodeDIDResponse);

                    //populate swapMap to persist 21 table (ESN mapping)
                    applicationDidHelper.populateEsnSwapMap(vehicleNodeDIDResponse, swapMap, isESNFoundForAPIM,isESNFoundForTCU, esnFormatPattern);

                    // populate vehicleNodeDIDStatusList ToBe Persisted for 20 table - Start
                    applicationDidHelper.populateVehicleNodeDIDStatusListToBePersisted(moduleSnapshotObserverRequest,
                            vehicleNodeDIDResponse, applicationSwPartNumberStateMap, otherSwPartNumberStateMap, vehicleNodeDIDStatusListToPersist);
                }
            }

            //insert vehicleNodeConfigList into 06 table
            snapshotSaveHandler.saveVehicleNodeConfig(vehicleNodeConfigList);
            LOGGER.info("DidCreation:VehicleNodeConfig for VIN=[{}] Node =[{}] Saved  Successfully", moduleSnapshotObserverRequest.getVin(), vehicleNodeSnapshot.getNodeAddress());

            //populate other vehicleNodeDIDStatusList from (otherSwPartNumberStateMap, applicationSwPartNumberStateMap)
            applicationDidHelper.populateOtherVehicleNodeDIDStatusListFromExisting(otherSwPartNumberStateMap, applicationSwPartNumberStateMap,
                    vehicleNodeDIDStatusListToPersist, vehicleNodeSnapshot.getEcuAcronym());

            //insert vehicleNodeDIDStatusList into 20 table.
            appDidCreator.persistSoftwareDidState(vehicleNodeDIDStatusListToPersist, vehicleNodeSnapshot.getNodeTimeStamp());

            //swapMap contains value then inserting the ESN mapping into 21 table.
            appDidCreator.performModuleSwapForSyncAndTCU(moduleSnapshotObserverRequest,vehicleNodeSnapshot, swapMap, false);
            
        }
        LOGGER.info("DidCreation:Leaving  persistDid");
    }

    private ModuleNode getModuleNode(NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap, VehicleNodeDIDResponse vehicleNodeDIDResponse) {
        ModuleNode moduleNode = nodeAndDIDResponseForNewSnap.getModuleNodeIdSaKeyMap().get(vehicleNodeDIDResponse.getDidCatalog());
        if (moduleNode == null) {
            moduleNode = nodeAndDIDResponseForNewSnap.getModuleNodeIdSaKeyMap().entrySet().stream().findFirst().get().getValue();
        }
        return moduleNode;
    }

    private void populateVehicleNodeConfigList(NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap, VehicleNodeDIDResponse vehicleNodeDIDResponse,
                                               List<VehicleNodeConfig> vehicleNodeConfigList){

        VehicleNodeConfig vehicleNodeConfig = nodeAndDIDResponseForNewSnap.getVehicleNodeConfigMap().get(vehicleNodeDIDResponse.getDidCatalog());
        if (vehicleNodeConfig != null) {
            VehicleNodeDIDResponseId vehicleNodeDIDResponseId = new VehicleNodeDIDResponseId();
            vehicleNodeDIDResponseId.setVehicleNodeDidReponseKey(vehicleNodeDIDResponse.getVehicleNodeDIDResponseId().getVehicleNodeDidReponseKey());
            vehicleNodeDIDResponseId.setVinHashNumber(vehicleNodeDIDResponse.getVehicleNodeDIDResponseId().getVinHashNumber());
            vehicleNodeConfig.setVehicleNodeDIDResponseId(vehicleNodeDIDResponseId);
            vehicleNodeConfigList.add(vehicleNodeConfig);
        }
    }

}
