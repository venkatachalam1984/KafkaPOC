package com.ford.gvmsr.snapobserver.externalservice.request;

public class AnalyzelogFtrPropertiesRequest {

    AnalyzelogFtrProperties analyzelogFtrProperties = new AnalyzelogFtrProperties();

    public AnalyzelogFtrProperties getAnalyzelogFtrProperties() {
        return analyzelogFtrProperties;
    }

    public void setAnalyzelogFtrProperties(AnalyzelogFtrProperties analyzelogFtrProperties) {
        this.analyzelogFtrProperties = analyzelogFtrProperties;
    }
}
