package com.ford.gvmsr.snapobserver.externalservice.request;

public class NodeAssemblyRequest {

    private String hardware;
    private String assembly;
    private String isFAS;

    public String getAssembly() {
        return assembly;
    }

    public void setAssembly(String assembly) {
        this.assembly = assembly;
    }

    public String getIsFAS() {
        return isFAS;
    }

    public void setIsFAS(String isFAS) {
        this.isFAS = isFAS;
    }

    public String getHardware() {
        return hardware;
    }

    public void setHardware(String hardware) {
        this.hardware = hardware;
    }
}
