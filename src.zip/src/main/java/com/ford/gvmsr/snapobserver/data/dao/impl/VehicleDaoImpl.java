package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VehicleDao;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleId;
import com.ford.gvmsr.snapobserver.data.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class VehicleDaoImpl implements VehicleDao {

    @Autowired
    VehicleRepository vehicleRepository;


    @Override
    public Optional<Vehicle> findOne(VehicleId vehicleId) {

       return vehicleRepository.findById(vehicleId);
    }

    @Override
    public Vehicle save(Vehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }
}
