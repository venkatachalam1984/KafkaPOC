package com.ford.gvmsr.snapobserver.data.entity;




import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/29/2017.
 * Lookup table to store the various fuel types. This table has been added as part of Wifi Hotspot and the initial requirement is that China related VIN will have this information, but the team will look into populating the rest of the VINS also
     Some sample com.ford.cloudnative.gvms.moduleinfo.com.ford.cloudnative.gvms.moduleupdate.data is
     0x00	not configured (invalid)
     0x01	Gasoline
     0x02	Diesel
     0x03	Gas/Electric Hybrid (FHEV)
     0x04	Hydrogen Fuel Cell
     0x05	Diesel/Electric Hybrid
     0x06	Compressed Natural Gas (CNG)
     0x07	Electric Only (BEV)
     0x08	Gas/Plug in Electric Vehicle (pHEV)
     0x09	reserved (Invalid)

     Data Source: GIVIS:NMGM185_FUEL_TYPE
 */
@Entity
@Table(name = "PGVMS12_FUEL_TYPE")
public class FuelType extends BaseEntity {

    @Id
    @Column(name = "GVMS12_FUEL_TYPE_C")
    private String fuelTypeCode;

    @Column(name = "GVMS12_FUEL_TYPE_N")
    private String fuelTypeName;


    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS12_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS12_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS12_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS12_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public String getFuelTypeCode() {
        return fuelTypeCode;
    }

    public void setFuelTypeCode(String fuelTypeCode) {
        this.fuelTypeCode = fuelTypeCode;
    }

    public String getFuelTypeName() {
        return fuelTypeName;
    }

    public void setFuelTypeName(String fuelTypeName) {
        this.fuelTypeName = fuelTypeName;
    }


    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

}


