package com.ford.gvmsr.snapobserver.data.entity;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by MDEVARA3 on 8/29/2017.
 * Data Source: GIVIS:NMGM144_VIN_REGION_MAP
 */

@Entity
@Table(name = "PGVMS13_VIN_REGION_MAP")
public class VINRegionMap extends BaseEntity {

    @Id
    @Column(name = "GVMS13_VIN_TCU_REGION_C")
    private String VINTCURegionCode;

    @Column(name = "GVMS13_REGION_N")
    private String regionName;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS13_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS13_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS13_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS13_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();


    public String getVINTCURegionCode() {
        return VINTCURegionCode;
    }

    public void setVINTCURegionCode(String VINTCURegionCode) {
        this.VINTCURegionCode = VINTCURegionCode;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

}
