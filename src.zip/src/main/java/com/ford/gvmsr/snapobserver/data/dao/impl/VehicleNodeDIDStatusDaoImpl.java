package com.ford.gvmsr.snapobserver.data.dao.impl;

import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeDIDStatusDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDStatus;
import com.ford.gvmsr.snapobserver.data.repository.VehicleNodeDIDStatusRepository;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class VehicleNodeDIDStatusDaoImpl implements VehicleNodeDIDStatusDao {

    @Autowired
    VehicleNodeDIDStatusRepository vehicleNodeDIDStatusRepository;

    @Override
    public void persistVehicleStateList(List<VehicleNodeDIDStatus> vehicleNodeDIDStatusList, Timestamp vinRecordedTimestamp) {
        List<VehicleNodeDIDStatus> saveVehicleStateList = new ArrayList<>();
        List<VehicleNodeDIDStatus> updateVehicleStateList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(vehicleNodeDIDStatusList)) {
            vehicleNodeDIDStatusList.forEach(vehicleNodeDIDStatus -> {
                if (vehicleNodeDIDStatus.getSoftwareStatus().getSoftwareStatusCode().equalsIgnoreCase("CU")
                        && vehicleNodeDIDStatusRepository.findById(vehicleNodeDIDStatus.getVehicleNodeDIDStatusID()).isPresent()) {
                    updateVehicleStateList.add(vehicleNodeDIDStatus);
                } else if (vehicleNodeDIDStatus.getSoftwareStatus().getSoftwareStatusCode().equalsIgnoreCase("CI")) {
                    saveVehicleStateList.add(vehicleNodeDIDStatus);
                }
            });
        }
        if (!CollectionUtils.isEmpty(saveVehicleStateList)) {
            for (VehicleNodeDIDStatus vehicleNodeDIDStatus : saveVehicleStateList) {
                vehicleNodeDIDStatus.setRecordedTime(vinRecordedTimestamp);
                if (vehicleNodeDIDStatus.getPartNumber() != null && ApplicationUtils.checkPartNumber(vehicleNodeDIDStatus.getPartNumber().toString())) {
                    vehicleNodeDIDStatusRepository.insertVehicleState(vehicleNodeDIDStatus.getVehicleNodeDIDStatusID().getVinHashNumber(), vehicleNodeDIDStatus.getVin(), vehicleNodeDIDStatus.getNodeAddress(),
                            vehicleNodeDIDStatus.getDidCatalog(), vehicleNodeDIDStatus.getRecordedTime(), vehicleNodeDIDStatus.getSoftwareStatus().getSoftwareStatusCode(), vehicleNodeDIDStatus.getRoleName().getRoleName(),
                            vehicleNodeDIDStatus.getPartNumber().getFordPartNumberPrefix(), vehicleNodeDIDStatus.getPartNumber().getFordPartNumberBase(), vehicleNodeDIDStatus.getPartNumber().getFordPartNumberSuffix(),
                            vehicleNodeDIDStatus.getEcuAcronym(), vehicleNodeDIDStatus.getRoleSource(), vehicleNodeDIDStatus.getRoleDescription(), "GVMS",
                            new Timestamp(new Date().getTime()), "GVMS", new Timestamp(new Date().getTime()));
                }
            }
        }
        if (!CollectionUtils.isEmpty(updateVehicleStateList)) {
            for (VehicleNodeDIDStatus vehicleNodeDIDStatus : updateVehicleStateList) {
                vehicleNodeDIDStatus.setRecordedTime(vinRecordedTimestamp);
                vehicleNodeDIDStatusRepository.updateVehicleState(vehicleNodeDIDStatus.getSoftwareStatus().getSoftwareStatusCode(),
                        vehicleNodeDIDStatus.getVehicleNodeDIDStatusID().getVinHashNumber(), vehicleNodeDIDStatus.getVin(),
                        vehicleNodeDIDStatus.getNodeAddress(), vehicleNodeDIDStatus.getDidCatalog(),
                        vehicleNodeDIDStatus.getPartNumber().getFordPartNumberPrefix(), vehicleNodeDIDStatus.getPartNumber().getFordPartNumberBase(),
                        vehicleNodeDIDStatus.getPartNumber().getFordPartNumberSuffix(), vehicleNodeDIDStatus.getEcuAcronym(),
                        vehicleNodeDIDStatus.getVehicleNodeDIDStatusID().getVehicleNodeDidStatusKey(), vehicleNodeDIDStatus.getRecordedTime());
            }
        }
    }

    @Override
    public List<VehicleNodeDIDStatus> fetchAllCurrentlyInstalledSoftwares(int vinHash, String vin, String swState) {
        List<VehicleNodeDIDStatus> vehicleNodeDIDStatusList = vehicleNodeDIDStatusRepository.findAllByVehicleNodeDIDStatusID_VinHashNumberAndVinAndSoftwareStatus_SoftwareStatusCode(vinHash, vin, swState);
        return vehicleNodeDIDStatusList;
    }
}
