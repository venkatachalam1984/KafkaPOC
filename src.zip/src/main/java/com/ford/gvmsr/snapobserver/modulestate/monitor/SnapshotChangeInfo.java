package com.ford.gvmsr.snapobserver.modulestate.monitor;

public class SnapshotChangeInfo {

    private boolean configDIDChanged;
    private boolean nonConfigDIDChanged;
    private boolean appDIDChanged;
    private boolean vehicleProfileTrigger;
    private boolean esnDIDChanged;
    private boolean macAddressDIDChanged;
    private boolean iccidDidPresent;
    private boolean ecuAcronymChanged;
    private boolean networkNameChanged;
    private boolean iccidDidChanged;
    private boolean snapskipDidChanged;

    public boolean isSnapskipDidChanged() {
        return snapskipDidChanged;
    }

    public void setSnapskipDidChanged(boolean snapskipDidChanged) {
        this.snapskipDidChanged = snapskipDidChanged;
    }

    public boolean isConfigDIDChanged() {
        return configDIDChanged;
    }

    public void setConfigDIDChanged(boolean configDIDChanged) {
        this.configDIDChanged = configDIDChanged;
    }

    public boolean isNonConfigDIDChanged() {
        return nonConfigDIDChanged;
    }

    public void setNonConfigDIDChanged(boolean nonConfigDIDChanged) {
        this.nonConfigDIDChanged = nonConfigDIDChanged;
    }

    public boolean isAppDIDChanged() {
        return appDIDChanged;
    }

    public void setAppDIDChanged(boolean appDIDChanged) {
        this.appDIDChanged = appDIDChanged;
    }

    public boolean isVehicleProfileTrigger() {
        return vehicleProfileTrigger;
    }

    public void setVehicleProfileTrigger(boolean vehicleProfileTrigger) {
        this.vehicleProfileTrigger = vehicleProfileTrigger;
    }

    public boolean isEsnDIDChanged() {
        return esnDIDChanged;
    }

    public void setEsnDIDChanged(boolean esnDIDChanged) {
        this.esnDIDChanged = esnDIDChanged;
    }

    public boolean isMacAddressDIDChanged() {
        return macAddressDIDChanged;
    }

    public void setMacAddressDIDChanged(boolean macAddressDIDChanged) {
        this.macAddressDIDChanged = macAddressDIDChanged;
    }

    public boolean isIccidDidPresent() {
        return iccidDidPresent;
    }

    public void setIccidDidPresent(boolean iccidDidPresent) {
        this.iccidDidPresent = iccidDidPresent;
    }

    public boolean isEcuAcronymChanged() {
        return ecuAcronymChanged;
    }

    public void setEcuAcronymChanged(boolean ecuAcronymChanged) {
        this.ecuAcronymChanged = ecuAcronymChanged;
    }

    public boolean isNetworkNameChanged() {
        return networkNameChanged;
    }

    public void setNetworkNameChanged(boolean networkNameChanged) {
        this.networkNameChanged = networkNameChanged;
    }

    public boolean isIccidDidChanged() {
        return iccidDidChanged;
    }

    public void setIccidDidChanged(boolean iccidDidChanged) {
        this.iccidDidChanged = iccidDidChanged;
    }
}
