package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by MDEVARA3 on 8/30/2017.
 */
@Embeddable
public class VehicleNodeId implements Serializable{

//    @Column(name = "GVMS10_VIN_R")
//    private String vin;
//
//    @Column(name = "GVMS10_VIN_HASH_R")
//    private int vinHashNumber;

    private VehicleId vehicleId;

    @Column(name = "GVM023_NODE_ADRS_C")
    private String nodeAddress;


    /*public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }*/

    public VehicleId getVehicleId() {
        return this.vehicleId;
    }

    public void setVehicleId(VehicleId vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }
/*
    @ManyToOne
    @PrimaryKeyJoinColumns({
            @PrimaryKeyJoinColumn(name = "GVM005_VIN_R", referencedColumnName = "GVM005_VIN_R"),
            @PrimaryKeyJoinColumn(name = "GVM005_VIN_HASH_R", referencedColumnName = "GVM005_VIN_HASH_R") })
    private Vehicle vehicle;


    @ManyToOne
    @PrimaryKeyJoinColumn(name = "GVM023_NODE_ADRS_C", referencedColumnName = "GVM023_NODE_ADRS_C")
    private NodeAddress nodeAddress;

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public NodeAddress getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(NodeAddress nodeAddress) {
        this.nodeAddress = nodeAddress;
 } */
}
