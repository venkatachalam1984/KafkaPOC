package com.ford.gvmsr.snapobserver.dto;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeConfig;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDStatus;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PreviousSnapShotDetailsByNode {

    private Map<String, VehicleNodeDIDResponse> prevNonConfigDidResponseMap = new HashMap<>();
    private Map<String, VehicleNodeDIDResponse> prevConfigDidTwoTableResponseMap = new HashMap<>();
    private Map<String, VehicleNodeConfig> prevConfigDidSixTableResponseMap = new HashMap<>();
    private String prevNetworkName;
    private String prevEcuAcronym;
    private String previousSnapRole;
    private List<VehicleNodeDIDStatus> previousVehicleNodeStatusList = new ArrayList<>();
    private List<String> previousAppList = new ArrayList<>();
    private VehicleNodeSnapshot prevVehicleNodeSnapshot;

    public Map<String, VehicleNodeDIDResponse> getPrevNonConfigDidResponseMap() {
        return prevNonConfigDidResponseMap;
    }

    public void setPrevNonConfigDidResponseMap(Map<String, VehicleNodeDIDResponse> prevNonConfigDidResponseMap) {
        this.prevNonConfigDidResponseMap = prevNonConfigDidResponseMap;
    }

    public Map<String, VehicleNodeDIDResponse> getPrevConfigDidTwoTableResponseMap() {
        return prevConfigDidTwoTableResponseMap;
    }

    public void setPrevConfigDidTwoTableResponseMap(Map<String, VehicleNodeDIDResponse> prevConfigDidTwoTableResponseMap) {
        this.prevConfigDidTwoTableResponseMap = prevConfigDidTwoTableResponseMap;
    }

    public Map<String, VehicleNodeConfig> getPrevConfigDidSixTableResponseMap() {
        return prevConfigDidSixTableResponseMap;
    }

    public void setPrevConfigDidSixTableResponseMap(Map<String, VehicleNodeConfig> prevConfigDidSixTableResponseMap) {
        this.prevConfigDidSixTableResponseMap = prevConfigDidSixTableResponseMap;
    }

    public String getPrevNetworkName() {
        return prevNetworkName;
    }

    public void setPrevNetworkName(String prevNetworkName) {
        this.prevNetworkName = prevNetworkName;
    }

    public String getPrevEcuAcronym() {
        return prevEcuAcronym;
    }

    public void setPrevEcuAcronym(String prevEcuAcronym) {
        this.prevEcuAcronym = prevEcuAcronym;
    }

    public String getPreviousSnapRole() {
        return previousSnapRole;
    }

    public void setPreviousSnapRole(String previousSnapRole) {
        this.previousSnapRole = previousSnapRole;
    }

    public List<VehicleNodeDIDStatus> getPreviousVehicleNodeStatusList() {
        return previousVehicleNodeStatusList;
    }

    public void setPreviousVehicleNodeStatusList(List<VehicleNodeDIDStatus> previousVehicleNodeStatusList) {
        this.previousVehicleNodeStatusList = previousVehicleNodeStatusList;
    }

    public List<String> getPreviousAppList() {
        return previousAppList;
    }

    public void setPreviousAppList(List<String> previousAppList) {
        this.previousAppList = previousAppList;
    }

    public VehicleNodeSnapshot getPrevVehicleNodeSnapshot() {
        return prevVehicleNodeSnapshot;
    }

    public void setPrevVehicleNodeSnapshot(VehicleNodeSnapshot prevVehicleNodeSnapshot) {
        this.prevVehicleNodeSnapshot = prevVehicleNodeSnapshot;
    }
}
