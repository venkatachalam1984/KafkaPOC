package com.ford.gvmsr.snapobserver.creator.impl;

import com.ford.gvmsr.snapobserver.creator.AppDidCreator;
import com.ford.gvmsr.snapobserver.data.dao.VehicleModuleInstallDao;
import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeDIDStatusDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDSoftware;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDStatus;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshot;
import com.ford.gvmsr.snapobserver.handler.SnapshotSaveHandler;
import com.ford.gvmsr.snapobserver.helper.ApplicationDidHelper;
import com.ford.gvmsr.snapobserver.logevent.LogEventMonitor;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

@Component
public class AppDidCreationHandler implements AppDidCreator {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    ApplicationDidHelper applicationDidHelper;

    @Autowired
    SnapshotSaveHandler snapshotSaveHandler;

    @Autowired
    VehicleNodeDIDStatusDao vehicleNodeDIDStatusDao;

    @Autowired
    VehicleModuleInstallDao vehicleModuleInstallDao;


    @Override
    public void persistApplicationDid(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, VehicleNodeDIDResponse vehicleNodeDIDResponse) {
        if(applicationDidHelper.isApplicationDid(vehicleNodeDIDResponse.getDidCatalog())) {
            try {
                List<VehicleNodeDIDSoftware> didSoftwareList = applicationDidHelper.getApplicationPartList(vehicleNodeDIDResponse.getDidResponse(), vehicleNodeDIDResponse);
                if (!didSoftwareList.isEmpty()) {
                    didSoftwareList = snapshotSaveHandler.saveAllVehicleNodeDIDSoftware(didSoftwareList);
                    vehicleNodeDIDResponse.setVehicleNodeDIDSoftwares(didSoftwareList);
                    logger.info("AppDidCreation:VehicleNodeDIDSoftware for VIN=[{}] Node =[{}] Saved  Successfully", moduleSnapshotObserverRequest.getVin(),
                            vehicleNodeDIDResponse.getVehicleNodeSnapshot().getNodeAddress());
                }
            }catch(Exception ex){
                logger.error("AppDidCreation:Exception while persistApplicationDid : "+ ex.getMessage());
                throw ex;
            }
        }
    }

    @Override
    public void persistSoftwareDidState(List<VehicleNodeDIDStatus> vehicleNodeDIDStatusList,
                                        Timestamp vinRecordedTimestamp) {
        logger.debug("AppDidCreation:Inside persistSoftwareDidState");
        vehicleNodeDIDStatusDao.persistVehicleStateList(vehicleNodeDIDStatusList, vinRecordedTimestamp);
    }

    @Override
    public Map<Boolean, String> performModuleSwapForSyncAndTCU(ModuleSnapshotObserverRequest snapshotObserverRequest, VehicleNodeSnapshot vehicleNodeSnapshot, Map<String, String> swapMap, Boolean ccpuFlag)  {
        logger.debug("AppDidCreation:Inside performModuleSwapForSyncAndTCU");
        long start = System.currentTimeMillis();
        Map<Boolean, String> isDisassociation = null;
        if (!CollectionUtils.isEmpty(swapMap)) {
            try {
                String electronicSerialNum = null;
                logger.debug(swapMap.toString());
                if (swapMap != null && !swapMap.isEmpty()) {
                    for (Map.Entry<String, String> entry : swapMap.entrySet()) {
                        String[] splitedArray = null;
                        if (entry.getKey() != null) {
                            splitedArray = entry.getKey().split("_");
                        }
                        if (splitedArray != null && splitedArray.length == 2) {
                            String nodeAddress = splitedArray[0];
                            String ecuAcronym = splitedArray[1];
                            electronicSerialNum = entry.getValue();
                            isDisassociation = vehicleModuleInstallDao.saveVehicleModuleInstall(snapshotObserverRequest.getVin(),
                                    ApplicationUtils.getVinHash(snapshotObserverRequest.getVin()), nodeAddress, electronicSerialNum, ecuAcronym, vehicleNodeSnapshot.getNodeTimeStamp());

                            /*if (isDisassociation != null && isDisassociation.containsKey(true) && !ccpuFlag) {
                                analyzeLogExceptionEventService.createSuccessEvent(ExceptionEventConstants.A006_EVENT_CODE, ExceptionEventConstants.BundleSourceEnum.PTS.getCode(), ExceptionEventConstants.CLEAR, isDisassociation.get(true) + ";" + "TCU", ExceptionEventConstants.SUCCESS, isDisassociation.get(true));
                                analyzeLogExceptionEventService.createFailureAlarmForA006Event(vin, nodeAddress);
                            }* need to check */

                        }
                    }
                }
            } catch (Exception e) {
                logger.error("AppDidCreation:Exception occurred in performModuleSwapForSyncAndTCU::: " + e.getMessage());
                throw e;
            }
            long duration = (System.currentTimeMillis() - start);
            logger.debug("AppDidCreation:Time taken - performModuleSwapForSyncAndTCU is {}", duration);
            return isDisassociation;
        }
        return isDisassociation;
    }

}
