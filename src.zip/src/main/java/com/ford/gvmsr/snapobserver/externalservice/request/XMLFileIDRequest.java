package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.gvmsr.snapobserver.data.entity.IVSProgramId;

/**
 * Created by KMANI4 on 09-07-2018.
 */
//@JsonTypeInfo(include= JsonTypeInfo.As.WRAPPER_OBJECT, use= JsonTypeInfo.Id.NAME)
public class XMLFileIDRequest {

    @JsonProperty("IvsProgram")
    private IVSProgramId ivsProgramId;

    public IVSProgramId getIvsProgramId() {
        return ivsProgramId;
    }

    public void setIvsProgramId(IVSProgramId ivsProgramId) {
        this.ivsProgramId = ivsProgramId;
    }
}
