
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for NodeNetworkInterfaceDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NodeNetworkInterfaceDetailType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="NetworkInterface"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkConnector"/&gt;
 *                 &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkParameters"/&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NodeAddr" type="{urn:ford/Vehicle/Module/Information/v4.0}NodeAddrType"/&gt;
 *         &lt;element name="Gateway" type="{urn:ford/Vehicle/Module/Information/v4.0}GatewayInfoType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NodeNetworkInterfaceDetailType", propOrder = {
    "networkInterface",
    "nodeAddr",
    "gateway"
})
public class NodeNetworkInterfaceDetailType {

    @XmlElement(name = "NetworkInterface", required = true)
    protected NetworkInterface networkInterface;
    @XmlElement(name = "NodeAddr", required = true)
    protected String nodeAddr;
    @XmlElement(name = "Gateway", required = true)
    protected GatewayInfoType gateway;

    /**
     * Gets the value of the networkInterface property.
     *
     * @return
     *     possible object is
     *     {@link NetworkInterface }
     *
     */
    public NetworkInterface getNetworkInterface() {
        return networkInterface;
    }

    /**
     * Sets the value of the networkInterface property.
     *
     * @param value
     *     allowed object is
     *     {@link NetworkInterface }
     *
     */
    public void setNetworkInterface(NetworkInterface value) {
        this.networkInterface = value;
    }

    /**
     * Gets the value of the nodeAddr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNodeAddr() {
        return nodeAddr;
    }

    /**
     * Sets the value of the nodeAddr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNodeAddr(String value) {
        this.nodeAddr = value;
    }

    /**
     * Gets the value of the gateway property.
     * 
     * @return
     *     possible object is
     *     {@link GatewayInfoType }
     *     
     */
    public GatewayInfoType getGateway() {
        return gateway;
    }

    /**
     * Sets the value of the gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link GatewayInfoType }
     *     
     */
    public void setGateway(GatewayInfoType value) {
        this.gateway = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkConnector"/&gt;
     *       &lt;attGroup ref="{urn:ford/Vehicle/Module/Information/v4.0}NetworkParameters"/&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class NetworkInterface {

        @XmlAttribute(name = "DLCName", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
        protected String dlcName;
        @XmlAttribute(name = "Pins", namespace = "urn:ford/Vehicle/Module/Information/v4.0")
        protected String pins;
        @XmlAttribute(name = "NetworkName", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
        protected String networkName;
        @XmlAttribute(name = "NetworkProtocol", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
        protected String networkProtocol;
        @XmlAttribute(name = "NetworkDataRate", namespace = "urn:ford/Vehicle/Module/Information/v4.0", required = true)
        protected String networkDataRate;

        /**
         * Gets the value of the dlcName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDLCName() {
            return dlcName;
        }

        /**
         * Sets the value of the dlcName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDLCName(String value) {
            this.dlcName = value;
        }

        /**
         * Gets the value of the pins property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPins() {
            return pins;
        }

        /**
         * Sets the value of the pins property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPins(String value) {
            this.pins = value;
        }

        /**
         * Gets the value of the networkName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNetworkName() {
            return networkName;
        }

        /**
         * Sets the value of the networkName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNetworkName(String value) {
            this.networkName = value;
        }

        /**
         * Gets the value of the networkProtocol property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNetworkProtocol() {
            return networkProtocol;
        }

        /**
         * Sets the value of the networkProtocol property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNetworkProtocol(String value) {
            this.networkProtocol = value;
        }

        /**
         * Gets the value of the networkDataRate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNetworkDataRate() {
            return networkDataRate;
        }

        /**
         * Sets the value of the networkDataRate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNetworkDataRate(String value) {
            this.networkDataRate = value;
        }

    }

}
