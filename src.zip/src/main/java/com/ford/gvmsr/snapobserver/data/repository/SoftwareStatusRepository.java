package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.SoftwareStatus;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.io.Serializable;

/**
 * Created by MJAFARUL on 11/28/2017.
 */
@Repository
@Transactional
public interface SoftwareStatusRepository extends CrudRepository<SoftwareStatus, Serializable> {
}
