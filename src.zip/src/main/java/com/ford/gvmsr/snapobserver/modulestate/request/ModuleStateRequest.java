package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ModuleSnapshot" type="{urn:ford/com/productdesign/ipp/ModuleSnapshot/v2.0}ModuleSnapshotType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "moduleSnapshot"
})
@XmlRootElement(name = "ModuleStateRequest", namespace = "urn:ford/com/productdesign/ipp/ModuleState/interface/v2.0")
public class ModuleStateRequest {

    @XmlElement(name = "ModuleSnapshot", namespace = "urn:ford/com/productdesign/ipp/ModuleState/interface/v2.0", required = true)
    protected ModuleSnapshotType moduleSnapshot;

    private String traceID;

    /**
     * Gets the value of the moduleSnapshot property.
     *
     * @return
     *     possible object is
     *     {@link ModuleSnapshotType }
     *
     */
    public ModuleSnapshotType getModuleSnapshot() {
        return moduleSnapshot;
    }

    /**
     * Sets the value of the moduleSnapshot property.
     *
     * @param value
     *     allowed object is
     *     {@link ModuleSnapshotType }
     *
     */
    public void setModuleSnapshot(ModuleSnapshotType value) {
        this.moduleSnapshot = value;
    }


    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }
}
