package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeConfig;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetailsByNode;
import com.ford.gvmsr.snapobserver.enums.TrackingLevel;
import com.ford.gvmsr.snapobserver.enums.TrackingType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.modulestate.request.ModuleNodeType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import com.ford.gvmsr.snapobserver.helper.SnapCreationHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Map;

@Component
public class DefaultConfigDidRule {
    private static final Logger logger = LoggerFactory.getLogger(DefaultConfigDidRule.class);

    @Autowired
    SnapCreationHelper snapCreationHelper;

    public void populateDidEntity(PreviousSnapShotDetailsByNode previousSnapShotDetailsByNode, DIDInfoType did,
                                  NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap, ModuleNodeType node, ModuleSnapshotObserverRequest snapshotObserverRequest) {
        VehicleNodeDIDResponse vehicleNodeDIDResponse = new VehicleNodeDIDResponse();
        VehicleNodeConfig vehicleNodeConfig;

        //validate did response and compare prevConfig did response
        String didResponse = validateConfigDidRule(previousSnapShotDetailsByNode.getPrevConfigDidSixTableResponseMap(), node, did, snapshotObserverRequest);

        // populate the vehicleNodeDIDResponse for 2 table persistence
        snapCreationHelper.populateVehicleNodeDIDResponse(vehicleNodeDIDResponse, did, node, snapshotObserverRequest, previousSnapShotDetailsByNode);
        nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList().add(vehicleNodeDIDResponse);
        //populate the vehicleNodeConfig for 6 table persistence
        vehicleNodeConfig = populateVehicleNodeConfig(did);
        vehicleNodeConfig.setConfigurationData(didResponse);
        nodeAndDIDResponseForNewSnap.getVehicleNodeConfigMap().put(did.getDidValue(), vehicleNodeConfig);
    }


    private String validateConfigDidRule(Map<String, VehicleNodeConfig> prevConfigDidSixTableResponseMap, ModuleNodeType node, DIDInfoType did, ModuleSnapshotObserverRequest snapshotObserverRequest) {

        String didResponse = ApplicationUtils.toUpperCase(did.getResponse());

        if (!CollectionUtils.isEmpty(prevConfigDidSixTableResponseMap) && prevConfigDidSixTableResponseMap.containsKey(did.getDidValue())) {

            String prevConfigDidResponse = prevConfigDidSixTableResponseMap.get(did.getDidValue()).getConfigurationData();

            if (null != didResponse && (GVMSModuleUpdateConstants.BLANK.equalsIgnoreCase(didResponse)
                    || !(ApplicationUtils.isValHexValue(didResponse)))) {
                didResponse = prevConfigDidResponse;
            } else if (didResponse != null &&
                    !prevConfigDidResponse.equalsIgnoreCase(didResponse)) {
                snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.CONFIG_DID, true);
            }
            prevConfigDidSixTableResponseMap.remove(did.getDidValue());

        }else if(prevConfigDidSixTableResponseMap.isEmpty() || !prevConfigDidSixTableResponseMap.containsKey(did.getDidValue())){
            snapshotObserverRequest.getSnapshotChangeMonitor().update(node, TrackingLevel.DID, TrackingType.CONFIG_DID, true);
        }
        return didResponse;
    }

    public VehicleNodeConfig populateVehicleNodeConfig(DIDInfoType didInfoType) {
        VehicleNodeConfig vehicleNodeConfig = new VehicleNodeConfig();
        vehicleNodeConfig.setConfigurationData(didInfoType.getResponse().trim().toUpperCase());
        vehicleNodeConfig.setConfigurationDataType("A");
        vehicleNodeConfig.setConfigurationDelimeterId(didInfoType.getDidValue());

        return vehicleNodeConfig;
    }

    public void copyMissingConfigDIDsFromPreviousSnap(Map<String, VehicleNodeConfig> prevConfigDidSixTableResponseMap,
                                                      Map<String, VehicleNodeDIDResponse> prevConfigDidTwoTableResponseMap,
                                                      NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap){
        if (!CollectionUtils.isEmpty(prevConfigDidSixTableResponseMap)) {
            prevConfigDidSixTableResponseMap.entrySet().stream().forEach(vehicleNodeConfigEntry -> {
                if (prevConfigDidTwoTableResponseMap.containsKey(vehicleNodeConfigEntry.getKey())) {
                    VehicleNodeDIDResponse vehicleNodeDIDResponse = prevConfigDidTwoTableResponseMap.get(vehicleNodeConfigEntry.getKey());
                    nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList().add(vehicleNodeDIDResponse);
                    nodeAndDIDResponseForNewSnap.getVehicleNodeConfigMap().put(vehicleNodeConfigEntry.getKey(), vehicleNodeConfigEntry.getValue());
                }
            });
        }
    }

}
