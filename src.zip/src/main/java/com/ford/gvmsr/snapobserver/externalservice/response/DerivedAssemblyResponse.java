package com.ford.gvmsr.snapobserver.externalservice.response;

import java.util.Map;

public class DerivedAssemblyResponse {

    private Map<String, DerivedAssemblyResponseForNode> derivedAssemblyResponseForNodeMap;

    public Map<String, DerivedAssemblyResponseForNode> getDerivedAssemblyResponseForNodeMap() {
        return derivedAssemblyResponseForNodeMap;
    }

    public void setDerivedAssemblyResponseForNodeMap(Map<String, DerivedAssemblyResponseForNode> derivedAssemblyResponseForNodeMap) {
        this.derivedAssemblyResponseForNodeMap = derivedAssemblyResponseForNodeMap;
    }
}
