package com.ford.gvmsr.snapobserver.modulestate.request;

import java.sql.Timestamp;
import java.util.List;

public class VilHeader {

    private String swumVersion;
    private String campaignId;
    private String deploymentId;
    private String triggerType;
    private String vilReason;
    private String visVersion;
    private String policyTable;
    private String manifestSchema;
    private Timestamp timeStamp;
    private List<String> dtcList;
    private RequestRole requestRole;

    public String getSwumVersion() {
        return swumVersion;
    }

    public void setSwumVersion(String swumVersion) {
        this.swumVersion = swumVersion;
    }

    public String getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(String campaignId) {
        this.campaignId = campaignId;
    }

    public String getDeploymentId() {
        return deploymentId;
    }

    public void setDeploymentId(String deploymentId) {
        this.deploymentId = deploymentId;
    }

    public String getTriggerType() {
        return triggerType;
    }

    public void setTriggerType(String triggerType) {
        this.triggerType = triggerType;
    }

    public String getVilReason() {
        return vilReason;
    }

    public void setVilReason(String vilReason) {
        this.vilReason = vilReason;
    }

    public String getVisVersion() {
        return visVersion;
    }

    public void setVisVersion(String visVersion) {
        this.visVersion = visVersion;
    }

    public String getPolicyTable() {
        return policyTable;
    }

    public void setPolicyTable(String policyTable) {
        this.policyTable = policyTable;
    }

    public String getManifestSchema() {
        return manifestSchema;
    }

    public void setManifestSchema(String manifestSchema) {
        this.manifestSchema = manifestSchema;
    }

    public Timestamp getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Timestamp timeStamp) {
        this.timeStamp = timeStamp;
    }

    public List<String> getDtcList() {
        return dtcList;
    }

    public void setDtcList(List<String> dtcList) {
        this.dtcList = dtcList;
    }

    public RequestRole getRequestRole() {
        return requestRole;
    }

    public void setRequestRole(RequestRole requestRole) {
        this.requestRole = requestRole;
    }
}
