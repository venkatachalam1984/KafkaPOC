
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for FlashActionListType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FlashActionListType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FlashAction" type="{urn:ford/Vehicle/Module/Information/v4.0}FlashActionType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FlashActionListType", propOrder = {
    "flashAction"
})
public class FlashActionListType {

    @XmlElement(name = "FlashAction", required = true)
    protected List<FlashActionType> flashAction;

    /**
     * Gets the value of the flashAction property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the flashAction property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFlashAction().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FlashActionType }
     * 
     * 
     */
    public List<FlashActionType> getFlashAction() {
        if (flashAction == null) {
            flashAction = new ArrayList<FlashActionType>();
        }
        return this.flashAction;
    }

}
