package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="PGVMS36_PAYLOAD_MSG_TEMP")
public class VILPayload {

    @Id
    @Column(name="GVMS36_PAYLOAD_MSG_K", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMS36_PAYLOAD_MSG_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMS36_PAYLOAD_MSG_K_SQ_GEN", sequenceName = "PGVMS36_PAYLOAD_MSG_K_SQ", allocationSize = 1)
    private Long vilPayloadMessageKey;

    @Column(name = "GVMS36_KAFKA_PARTITION_R")
    private Long vilPartition;

    @Column(name = "GVMS36_KAFKA_OFFSET_R")
    private int kafkaOffset;

    @Column(name = "GVMS36_KAFKA_TIMESTAMP_R")
    private Long kafkaTimeStamp;

    @Column(name = "GVMS36_PAYLOAD_L", columnDefinition = "BLOB")
    private byte[] vilPayloadData;

    @Column(name = "GVMS36_CREATE_USER_C")
    private String createdBy;

    @Column(name = "GVMS36_CREATE_S")
    private Timestamp createdTimeStamp;


    public Long getVilPayloadMessageKey() {
        return vilPayloadMessageKey;
    }

    public void setVilPayloadMessageKey(Long vilPayloadMessageKey) {
        this.vilPayloadMessageKey = vilPayloadMessageKey;
    }

    public Long getVilPartition() {
        return vilPartition;
    }

    public void setVilPartition(Long vilPartition) {
        this.vilPartition = vilPartition;
    }

    public int getKafkaOffset() {
        return kafkaOffset;
    }

    public void setKafkaOffset(int kafkaOffset) {
        this.kafkaOffset = kafkaOffset;
    }

    public Long getKafkaTimeStamp() {
        return kafkaTimeStamp;
    }

    public void setKafkaTimeStamp(Long kafkaTimeStamp) {
        this.kafkaTimeStamp = kafkaTimeStamp;
    }

    public byte[] getVilPayloadData() {
        return vilPayloadData;
    }

    public void setVilPayloadData(byte[] vilPayloadData) {
        this.vilPayloadData = vilPayloadData;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedTimeStamp() {
        return createdTimeStamp;
    }

    public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
        this.createdTimeStamp = createdTimeStamp;
    }
}
