package com.ford.gvmsr.snapobserver.enums;

public enum TrackingType {

    CONFIG_DID,
    NON_CONFIG_DID,
    ESN_DID,
    MAC_ADDRESS_DID,
    APPLICATION_DID,
    ICCID_DID_PRESENT,
    ICCID_DID_CHANGED,
    ECU_ACRONYM,
    NETWORK_NAME,
    VEHICLE_PROF_TRIGGER,
    SNAP_SKIP_DID,
    MANDATORY_DID

}
