
package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "VehicleNodeDidList", "ivsXmlInfoKey", "partitionKey"
})
public class DerivedAssemblyRequest {

    @JsonProperty("VehicleNodeDidList")
    private VehicleNodeDidList vehicleNodeDidList;

    @JsonProperty("ivsXmlInfoKey")
    private Long ivsXmlInfoKey;

    @JsonProperty("partitionKey")
    private int partitionKey;


    @JsonProperty("VehicleNodeDidList")
    public VehicleNodeDidList getVehicleNodeDidList() {
        return vehicleNodeDidList;
    }

    @JsonProperty("VehicleNodeDidList")
    public void setVehicleNodeDidList(VehicleNodeDidList vehicleNodeDidList) {
        this.vehicleNodeDidList = vehicleNodeDidList;
    }

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @JsonProperty("ivsXmlInfoKey")
    public Long getIvsXmlInfoKey() {
        return ivsXmlInfoKey;
    }

    @JsonProperty("ivsXmlInfoKey")
    public void setIvsXmlInfoKey(Long ivsXmlInfoKey) {
        this.ivsXmlInfoKey = ivsXmlInfoKey;
    }

    @JsonProperty("partitionKey")
    public int getPartitionKey() {
        return partitionKey;
    }

    @JsonProperty("partitionKey")
    public void setPartitionKey(int partitionKey) {
        this.partitionKey = partitionKey;
    }
}

