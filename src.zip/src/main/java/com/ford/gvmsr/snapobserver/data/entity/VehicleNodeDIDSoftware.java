package com.ford.gvmsr.snapobserver.data.entity;

import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by MJAFARUL on 11/20/2017.
 */
@Entity
@Table(name = "PGVMS07_VEH_NODE_DID_SW")
public class VehicleNodeDIDSoftware extends BaseEntity {

    @EmbeddedId
    private VehicleNodeDIDSoftwareId didSoftwareId;

    @Embedded
    private FordPartNumberId partNumber;

    @Column(name="GVMS07_SW_PART_RSPNS_X")
    private String partResponse;

    @Column(name="GVMS07_SW_PART_INS_UPD_S")
    private Timestamp updatedDate;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMS07_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMS07_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMS07_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMS07_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public VehicleNodeDIDSoftwareId getDidSoftwareId() {
        return didSoftwareId;
    }

    public void setDidSoftwareId(VehicleNodeDIDSoftwareId didSoftwareId) {
        this.didSoftwareId = didSoftwareId;
    }

    public FordPartNumberId getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(FordPartNumberId partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartResponse() {
        return partResponse;
    }

    public void setPartResponse(String partResponse) {
        this.partResponse = partResponse;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }
}
