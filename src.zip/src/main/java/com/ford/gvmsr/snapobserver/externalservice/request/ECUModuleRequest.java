package com.ford.gvmsr.snapobserver.externalservice.request;

/**
 * Created by vm4 on 28/3/2018.
 */
public class ECUModuleRequest {

    private String nodeAddress;
    private String esnNumber;
    private String ecuTypeCode;
    private boolean ispartNumber;

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public String getEsnNumber() {
        return esnNumber;
    }

    public void setEsnNumber(String esnNumber) {
        this.esnNumber = esnNumber;
    }

    public String getEcuTypeCode() {
        return ecuTypeCode;
    }

    public void setEcuTypeCode(String ecuTypeCode) {
        this.ecuTypeCode = ecuTypeCode;
    }

    public boolean isIspartNumber() {
        return ispartNumber;
    }

    public void setIspartNumber(boolean ispartNumber) {
        this.ispartNumber = ispartNumber;
    }
}
