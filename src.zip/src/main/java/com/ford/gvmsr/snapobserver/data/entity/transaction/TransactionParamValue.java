package com.ford.gvmsr.snapobserver.data.entity.transaction;



import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by KMANI4 on 04-04-2018.
 */
@Entity
@Table(name = "PGVMT05_TXN_PARM_VAL")
public class TransactionParamValue extends BaseEntity {

    @Id
    @Column(name = "GVMT05_TXN_PARM_VAL_K")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMT05_TXN_PARM_VAL_K_SQ_GEN")
    @SequenceGenerator(name = "PGVMT05_TXN_PARM_VAL_K_SQ_GEN", sequenceName = "PGVMT05_TXN_PARM_VAL_K_SQ", allocationSize = 1)
    private Long transactionParamId;

    //    @ManyToOne
//    @JoinColumn(name = "GVMT01_TXN_D",referencedColumnName = "GVMT01_TXN_D",updatable = false)
    @Column(name = "GVMT01_TXN_D")
    private Long transactionId;

    //    @ManyToOne
//    @JoinColumn(name = "GVMT04_TXN_PARM_C", referencedColumnName = "GVMT04_TXN_PARM_C",updatable = false)
    @Column(name = "GVMT04_TXN_PARM_C")
    private String transactionParam;

    //    @ManyToOne
//    @JoinColumn(name = "GVMT03_TXN_DTL_D",referencedColumnName = "GVMT03_TXN_DTL_D",updatable = false)
    @Column(name = "GVMT03_TXN_DTL_D")
    private Long transactionDetailId;

    @Column(name = "GVMT05_TXN_PARM_VAL_R")
    private String paramValue;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT05_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT05_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT05_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT05_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();



    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }

    public Long getTransactionParamId() {
        return transactionParamId;
    }

    public void setTransactionParamId(Long transactionParamId) {
        this.transactionParamId = transactionParamId;
    }

    /*public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public TransactionParam getTransactionParam() {
        return transactionParam;
    }

    public void setTransactionParam(TransactionParam transactionParam) {
        this.transactionParam = transactionParam;
    }

    public TransactionDetail getTransactionDetail() {
        return transactionDetail;
    }

    public void setTransactionDetail(TransactionDetail transactionDetail) {
        this.transactionDetail = transactionDetail;
    }*/

    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionParam() {
        return transactionParam;
    }

    public void setTransactionParam(String transactionParam) {
        this.transactionParam = transactionParam;
    }

    public Long getTransactionDetailId() {
        return transactionDetailId;
    }

    public void setTransactionDetailId(Long transactionDetailId) {
        this.transactionDetailId = transactionDetailId;
    }

    public String getParamValue() {
        return paramValue;
    }

    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    public void setAuditColumns(AuditColumns auditColumns) {
        this.auditColumns = auditColumns;
    }
}
