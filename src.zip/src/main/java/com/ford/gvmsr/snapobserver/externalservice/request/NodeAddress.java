package com.ford.gvmsr.snapobserver.externalservice.request;

/**
 * Created by VM4 on 07/19/2018.
 *
 */
public class NodeAddress{

    private String nodeAddress;

    private SourceSystem sourceSystem;

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }

    public SourceSystem getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(SourceSystem sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

}
