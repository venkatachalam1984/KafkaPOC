package com.ford.gvmsr.snapobserver.utils;

import com.ford.gvmsr.snapobserver.constants.SnapConstants;
import com.ford.gvmsr.snapobserver.data.entity.FordPartNumberId;
import com.ford.gvmsr.snapobserver.data.entity.SoftwareStatus;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.DIDInfoType;
import com.ford.gvmsr.snapobserver.modulestate.request.StateUpdateRoleType;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ApplicationUtils {

    public static int getVinHash(String vin) {
        if (vin != null && vin.length() > 2) {
            return Integer.parseInt(vin.substring(vin.length() - 2));
        }
        return 0;
    }

    public static boolean isValHexValue(String value) {
        Pattern pattern = Pattern.compile("[0-9a-fA-F]+");
        return pattern.matcher(value.toUpperCase()).matches();
    }

    public static boolean isValidDidResponse(String value) {
        //Pattern pattern = Pattern.compile("^[-\\w. :]+$");
        Pattern pattern = Pattern.compile("^[A-Z0-9]+$");
        return pattern.matcher(value.toUpperCase()).matches();
    }

    public static boolean isValidMacAddress(String value) {
        Pattern pattern = Pattern.compile("^[-\\w. :]+$");
        // Pattern pattern = Pattern.compile("^[A-Z0-9]+$");
        return pattern.matcher(value.toUpperCase()).matches();
    }

    public static String getDIDChildTableValue(DIDInfoType did) {
        if (did.isIsConfig())
            return "06";
        else
            return "NA";
    }

    public static boolean checkPartNumber(String partnumber) {
        if (partnumber == null || partnumber.equals("")) {
            return false;
        }
        Pattern pattern = Pattern.compile("[0-9A-Z]{4,6}-[0-9A-Z]{4,8}-[0-9A-Z]{2,8}");
        Matcher matcher = pattern.matcher(partnumber);
        return matcher.matches();
    }

    public static String toUpperCase(String str) {
        return !StringUtils.isEmpty(str) ? str.
                trim().toUpperCase() : str;
    }

    public static List<String> getApplicationPartList(String didResponse) {
        String firstStr = null;
        String secondStr = didResponse;
        int noOfBytes = 24;

        List<String> softwareList = new ArrayList<>();
        if (secondStr.contains(",")) {
            String[] appDidRespArray = secondStr.split(",");
            for (String didResp : appDidRespArray) {
                if (!StringUtils.isEmpty(didResp) && didResp.length() > 0) {
                    didResp = didResp.trim();
                    if (checkPartNumber(firstStr)) {
                        softwareList.add(didResp);
                    }
                }
            }
        } else {
            if (secondStr != null)
                while (secondStr.length() > 0) {
                    firstStr = secondStr.substring(0, Math.min(noOfBytes, secondStr.length())).trim();
                    secondStr = secondStr.substring(Math.min(noOfBytes, secondStr.length()));
                    if (checkPartNumber(firstStr)) {
                        softwareList.add(firstStr);
                    }
                }
        }
        return softwareList;
    }

    public static boolean checkIsVil(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest){

        StateUpdateRoleType requestRole = moduleSnapshotObserverRequest.getRequestRole();

        return requestRole.getRole().value().equalsIgnoreCase(SnapConstants.CONSUMER) &&
                requestRole.getRoleSource().value().equalsIgnoreCase(SnapConstants.OTA) &&
                requestRole.getRoleDesc().equalsIgnoreCase(SnapConstants.VIL_SOURCE_DES);
    }


}
