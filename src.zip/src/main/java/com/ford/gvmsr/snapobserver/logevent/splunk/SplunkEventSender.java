package com.ford.gvmsr.snapobserver.logevent.splunk;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.Executor;

@Component
public class SplunkEventSender {

    private final Logger logger = LoggerFactory.getLogger(SplunkEventSender.class);

    @Bean(name = "hecPostExecutor")
    public Executor hecPostExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(15);
        executor.setMaxPoolSize(25);
        executor.setQueueCapacity(1000);
        executor.afterPropertiesSet();
        executor.initialize();
        return executor;
    }
    @Autowired
    @Qualifier("oauthServiceRegistryRestTemplate")
    RestTemplate oauthServiceRegistryRestTemplate;

    @Value("${splunk.hec.token}")
    private String hec_token;

    @Value("${splunk.hec.url}")
    private String hec_qa_url;

    public static String getHost() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Async("hecPostExecutor")
    public void postToHEC(AppLogEvent appLogEvent, String source, String sourcetype) {
        String eventLogToPost = null;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            SplunkLogEvent splunkLogEvent = new SplunkLogEvent();
            splunkLogEvent.setHost(getHost());
            splunkLogEvent.setSource(source);
            splunkLogEvent.setSourcetype(sourcetype);
            splunkLogEvent.setEvent(objectMapper.writeValueAsString(appLogEvent));
            eventLogToPost = objectMapper.writeValueAsString(splunkLogEvent);
            } catch (JsonProcessingException ex) {
                logger.error("Exception while converting eventLogToPost to json : " +ex.getMessage());
            }
        try {
            HttpHeaders headrs = new HttpHeaders();
            headrs.add("Authorization", "Splunk " + hec_token);
            HttpEntity<String> entity = new HttpEntity<>(eventLogToPost, headrs);
            ResponseEntity<String> resp = oauthServiceRegistryRestTemplate.postForEntity(hec_qa_url, entity, String.class);

            JsonNode responseNode = objectMapper.readTree(resp.getBody());
            String resMsg = responseNode.get("text").asText();

            /*if (!resMsg.equalsIgnoreCase(VilConstants.VIL_TO_HEC_SPLUNK_SUCCESS)) {
                logger.info("Splunk HEC Response MSG : " + resMsg + " : " + eventLogToPost);
            }*/

        } catch (Exception ex) {
            logger.error("Exception while posting eventLogToPost to HEC Event Collector: " +
                    "" + ex.getMessage() + " : " + eventLogToPost);
        }

    }

    @Async("hecPostExecutor")
    public void postToHEC(KafkaLogEvent kafkaLogEvent, String source, String sourcetype) {
        String eventLogToPost = null;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            SplunkLogEvent splunkLogEvent = new SplunkLogEvent();
            splunkLogEvent.setHost(getHost());
            splunkLogEvent.setSource(source);
            splunkLogEvent.setSourcetype(sourcetype);
            splunkLogEvent.setEvent(objectMapper.writeValueAsString(kafkaLogEvent));
            eventLogToPost = objectMapper.writeValueAsString(splunkLogEvent);
        } catch (JsonProcessingException ex) {
            logger.error("Exception while converting eventLogToPost to json : " +ex.getMessage());
        }
        try {
            HttpHeaders headrs = new HttpHeaders();
            headrs.add("Authorization", "Splunk " + hec_token);
            HttpEntity<String> entity = new HttpEntity<>(eventLogToPost, headrs);
            ResponseEntity<String> resp = oauthServiceRegistryRestTemplate.postForEntity(hec_qa_url, entity, String.class);

            JsonNode responseNode = objectMapper.readTree(resp.getBody());
            String resMsg = responseNode.get("text").asText();

            /*if (!resMsg.equalsIgnoreCase(VilConstants.VIL_TO_HEC_SPLUNK_SUCCESS)) {
                logger.info("Splunk HEC Response MSG : " + resMsg + " : " + eventLogToPost);
            }*/

        } catch (Exception ex) {
            logger.error("Exception while posting eventLogToPost to HEC Event Collector: " +
                    "" + ex.getMessage() + " : " + eventLogToPost);
        }

    }

}
