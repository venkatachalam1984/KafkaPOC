
package com.ford.gvmsr.snapobserver.externalservice.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonPropertyOrder({
    "feature"
})
public class FeatureListTO{

    @JsonProperty("feature")
    private List<FeatureTO> feature = null;


    @JsonProperty("feature")
    public List<FeatureTO> getfeature() {
        return feature;
    }

    @JsonProperty("feature")
    public void setfeature(List<FeatureTO> feature) {
        this.feature = feature;
    }


}
