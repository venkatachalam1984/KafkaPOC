package com.ford.gvmsr.snapobserver.creator;

public interface ConfigDidCreator {
}
