package com.ford.gvmsr.snapobserver.enums;

public enum TrackingLevel {
    SNAP, NODE, DID
}
