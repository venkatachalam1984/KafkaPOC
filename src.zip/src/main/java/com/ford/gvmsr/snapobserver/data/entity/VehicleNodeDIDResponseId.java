package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by MDEVARA3 on 8/31/2017.
 */
@Embeddable
public class VehicleNodeDIDResponseId implements Serializable {



    /*@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PGVMS02_NODE_DID_RSPNS_K_SQ_GEN")
    @SequenceGenerator(name="PGVMS02_NODE_DID_RSPNS_K_SQ_GEN", sequenceName = "PGVMS02_NODE_DID_RSPNS_K_SQ", allocationSize = 1)*/
    @Column(name="GVMS02_VEH_NODE_DID_RSPNS_K",insertable = false,updatable = false, nullable = false)
    private Long vehicleNodeDidReponseKey;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;


    public Long getVehicleNodeDidReponseKey() {
        return vehicleNodeDidReponseKey;
    }

    public void setVehicleNodeDidReponseKey(Long vehicleNodeDidReponseKey) {
        this.vehicleNodeDidReponseKey = vehicleNodeDidReponseKey;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }
}
