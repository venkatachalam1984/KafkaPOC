package com.ford.gvmsr.snapobserver.externalservice.request;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FASHardwareRequest {

    private Map<String, List<DIDInfo>> nodeHardwareMap = new HashMap<>();

    private String programCode;

    private Float salesModelYear;

    public Map<String, List<DIDInfo>> getNodeHardwareMap() {
        return nodeHardwareMap;
    }

    public void setNodeHardwareMap(Map<String, List<DIDInfo>> nodeHardwareMap) {
        this.nodeHardwareMap = nodeHardwareMap;
    }

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public Float getSalesModelYear() {
        return salesModelYear;
    }

    public void setSalesModelYear(Float salesModelYear) {
        this.salesModelYear = salesModelYear;
    }


}
