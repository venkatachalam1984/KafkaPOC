package com.ford.gvmsr.snapobserver.data.entity.transaction;

import com.ford.gvmsr.snapobserver.data.entity.base.AuditColumns;
import com.ford.gvmsr.snapobserver.data.entity.base.BaseEntity;

import javax.persistence.*;

/**
 * Created by KMANI4 on 04-04-2018.
 */
@Entity
@Table(name = "PGVMT04_TXN_PARM")
public class TransactionParam extends BaseEntity {

    @Id
    @Column(name = "GVMT04_TXN_PARM_C")
    private String paramCode;

    @Column(name = "GVMT04_TXN_PARM_X")
    private String paramDesc;



    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "createdUser", column = @Column(name = "GVMT04_CREATE_USER_C", updatable =false)),
            @AttributeOverride(name = "createdTimestamp", column = @Column(name = "GVMT04_CREATE_S", updatable =false)),
            @AttributeOverride(name = "lastUpdatedUser", column = @Column(name = "GVMT04_LAST_UPDT_USER_C")),
            @AttributeOverride(name = "lastUpdatedTimestamp", column = @Column(name = "GVMT04_LAST_UPDT_S"))}
    )
    private AuditColumns auditColumns = new AuditColumns();

    public String getParamCode() {
        return paramCode;
    }

    public void setParamCode(String paramCode) {
        this.paramCode = paramCode;
    }

    public String getParamDesc() {
        return paramDesc;
    }

    public void setParamDesc(String paramDesc) {
        this.paramDesc = paramDesc;
    }

    @Override
    public AuditColumns getAuditColumns() {
        return auditColumns;
    }
}
