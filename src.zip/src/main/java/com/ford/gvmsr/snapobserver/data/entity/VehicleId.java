package com.ford.gvmsr.snapobserver.data.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by MDEVARA3 on 8/30/2017.
 */
@Embeddable
public class VehicleId implements Serializable {


    @Column(name = "GVMS10_VIN_R")
    private String vin;

    @Column(name = "GVMS10_VIN_HASH_R")
    private int vinHashNumber;

    public VehicleId(String vin, int vinHashNumber) {
        this.vin = vin;
        this.vinHashNumber = vinHashNumber;

    }

    public VehicleId(){
        super();
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public int getVinHashNumber() {
        return vinHashNumber;
    }

    public void setVinHashNumber(int vinHashNumber) {
        this.vinHashNumber = vinHashNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        VehicleId vehicleId = (VehicleId) o;

        if (vinHashNumber != vehicleId.vinHashNumber) return false;
        return vin != null ? vin.equals(vehicleId.vin) : vehicleId.vin == null;
    }

    @Override
    public int hashCode() {
        int result = vin != null ? vin.hashCode() : 0;
        result = 31 * result + vinHashNumber;
        return result;
    }
}
