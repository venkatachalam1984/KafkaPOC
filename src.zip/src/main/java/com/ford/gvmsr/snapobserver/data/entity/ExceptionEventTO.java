package com.ford.gvmsr.snapobserver.data.entity;

import java.sql.Timestamp;
import java.util.List;

/**
 * Created by VYUVARA6 on 12/14/2017.
 */
public class ExceptionEventTO {
    private String processingSourceCode;
    private String exceptionEventCode;
    private String processKey;
    private String subprocessKey;
    private String ntfcnEvntProcStatusCode;
    private Timestamp ntfcnEvntProcStatusTime;
    private Timestamp excptnEvntHdrTime;
    private String programCode;
    private Float modelYear;
    private String vin;
    private String esn;
    private String commentDescription;
    private String plantCode;
    private String autoClear; // to set the auto clear event codes
    private boolean isClobRequired;
    private String sourceSystem;
    private List<ExceptionEventDetailTO> exceptionEventDetailList;

    public ExceptionEventTO(){

    }

    public ExceptionEventTO(String processingSourceCode, String exceptionEventCode, String processKey, String subprocessKey, String vin){
        this.processingSourceCode = processingSourceCode;
        this.exceptionEventCode = exceptionEventCode;
        this.processKey = processKey;
        this.subprocessKey = subprocessKey;
        this.vin = vin;
    }

    public ExceptionEventTO(String processingSourceCode, String exceptionEventCode, String processKey, String subprocessKey, String programCode, Float modelYear, String vin){
        this.processingSourceCode = processingSourceCode;
        this.exceptionEventCode = exceptionEventCode;
        this.processKey = processKey;
        this.subprocessKey = subprocessKey;
        this.programCode = programCode;
        this.modelYear = modelYear;
        this.vin = vin;
    }

    public String getProcessingSourceCode() {
        return processingSourceCode;
    }

    public void setProcessingSourceCode(String processingSourceCode) {
        this.processingSourceCode = processingSourceCode;
    }

    public String getExceptionEventCode() {
        return exceptionEventCode;
    }

    public void setExceptionEventCode(String exceptionEventCode) {
        this.exceptionEventCode = exceptionEventCode;
    }

    public String getProcessKey() {
        return processKey;
    }

    public void setProcessKey(String processKey) {
        this.processKey = processKey;
    }

    public String getSubprocessKey() {
        return subprocessKey;
    }

    public void setSubprocessKey(String subprocessKey) {
        this.subprocessKey = subprocessKey;
    }

    public String getNtfcnEvntProcStatusCode() {
        return ntfcnEvntProcStatusCode;
    }

    public void setNtfcnEvntProcStatusCode(String ntfcnEvntProcStatusCode) {
        this.ntfcnEvntProcStatusCode = ntfcnEvntProcStatusCode;
    }

    public Timestamp getNtfcnEvntProcStatusTime() {
        return ntfcnEvntProcStatusTime;
    }

    public void setNtfcnEvntProcStatusTime(Timestamp ntfcnEvntProcStatusTime) {
        this.ntfcnEvntProcStatusTime = ntfcnEvntProcStatusTime;
    }

    public Timestamp getExcptnEvntHdrTime() {
        return excptnEvntHdrTime;
    }

    public void setExcptnEvntHdrTime(Timestamp excptnEvntHdrTime) {
        this.excptnEvntHdrTime = excptnEvntHdrTime;
    }

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public Float getModelYear() {
        return modelYear;
    }

    public void setModelYear(Float modelYear) {
        this.modelYear = modelYear;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getCommentDescription() {
        return commentDescription;
    }

    public void setCommentDescription(String commentDescription) {
        this.commentDescription = commentDescription;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getAutoClear() {
        return autoClear;
    }

    public void setAutoClear(String autoClear) {
        this.autoClear = autoClear;
    }

    public boolean isClobRequired() {
        return isClobRequired;
    }

    public void setClobRequired(boolean clobRequired) {
        isClobRequired = clobRequired;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public List<ExceptionEventDetailTO> getExceptionEventDetailList() {
        return exceptionEventDetailList;
    }

    public void setExceptionEventDetailList(List<ExceptionEventDetailTO> exceptionEventDetailList) {
        this.exceptionEventDetailList = exceptionEventDetailList;
    }
}
