package com.ford.gvmsr.snapobserver.externalservice.request;

/**
 * Created by VYUVARA6 on 8/29/2017.
 */

public class SourceSystem{

    private String sourceSystemtemCode;

    public String getSourceSystemtemCode() {
        return sourceSystemtemCode;
    }

    public void setSourceSystemtemCode(String sourceSystemtemCode) {
        this.sourceSystemtemCode = sourceSystemtemCode;
    }

}
