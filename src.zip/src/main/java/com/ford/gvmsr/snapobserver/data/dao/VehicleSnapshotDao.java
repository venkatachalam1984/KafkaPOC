package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import org.springframework.data.repository.query.Param;

public interface VehicleSnapshotDao {

   VehicleSnapshot save(VehicleSnapshot vehicleSnapshot);
   String getPreviousRole(long snapShotKey);
}
