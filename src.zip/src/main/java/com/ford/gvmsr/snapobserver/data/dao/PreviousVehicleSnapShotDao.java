package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Component
public interface PreviousVehicleSnapShotDao {
    public Set<VehicleNodeSnapshot> fetchPreviousActiveVehicleNodeSnapshotForAllNode(String vin, List<String> nodeListFromRequest);

    public Map<String, List<VehicleNodeDIDResponse>> fetchPreviousActiveDidResponseForAllNode(String vin, List<Long> vehicleNodeSnapshotKeyList);

    public Map<String, List<VehicleNodeConfig>> fetchPreviousActiveConfigDidResponseForAllNode(String vin, List<Long> vehicleNodeSnapshotKeyList);

    public Map<String, List<VehicleNodeDIDStatus>> findAllVehicleNodeDIDStatusIDForAllNode(String vin, int vinHash, String sofwareState);

    public String getPreviousRole(long snapShotKey);

    public Map<String, String> getProvisionFlagForAllNode(int vinHash,String vin,String PAAK_PROVISION_NODES);

    public Map<String, VehicleNodeId> populateVehicleNodeIdMap(String vin, int vinHash);

}
