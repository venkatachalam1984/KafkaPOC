package com.ford.gvmsr.snapobserver.helper;

import com.ford.gvmsr.snapobserver.constants.GVMSModuleUpdateConstants;
import com.ford.gvmsr.snapobserver.data.entity.*;
import com.ford.gvmsr.snapobserver.externalservice.ApplicationInitializer;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.StateUpdateRoleType;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

@Component
public class ApplicationDidHelper {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    SnapCreationHelper snapCreationHelper;

    @Value("#{'${application.dids}'.split(',')}")
    private Set<String> applicationDids;

    @Value("#{'${application.supported.nodes}'.split(',')}")
    private Set<String> applicationSupportedNodes;

    @Value("#{'${gvms.moduleupdate.vin.esn.tcu.dids}'.split(',')}")
    private List<String> tcuF17FF18Cdids;

    private Map<String,List<String>> applicationSupportedNodeMap = new HashMap<>();


    @PostConstruct
    public void constructApplicationDid(){
        for(String node:applicationSupportedNodes){
            if(!node.contains(":")){
                applicationSupportedNodeMap.put(node,null);
            }
            if(node.contains(":")){
                String REGEX_PATTERN = "[:]";
                List<String> splitNodeAndEcu = Arrays.asList(node.split(REGEX_PATTERN));
                String nodeAddress = splitNodeAndEcu.get(0);
                List<String> ecuList = Arrays.asList(splitNodeAndEcu.get(1).split("#"));
                applicationSupportedNodeMap.put(nodeAddress,ecuList);
            }
        }
    }

    public void populateVehicleNodeDIDStatusListToBePersisted(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, VehicleNodeDIDResponse vehicleNodeDIDResponse, Map<String, VehicleNodeDIDStatus> applicationSwPartNumberStateMap,
                                                              Map<String, VehicleNodeDIDStatus> otherSwPartNumberStateMap, List<VehicleNodeDIDStatus> vehicleNodeDIDStatusListToPersist) {

        String vin = moduleSnapshotObserverRequest.getVin();
        String nodeAddress = vehicleNodeDIDResponse.getVehicleNodeSnapshot().getNodeAddress();
        String ecuAcronym = vehicleNodeDIDResponse.getVehicleNodeSnapshot().getEcuAcronym();
        StateUpdateRoleType requestRole = moduleSnapshotObserverRequest.getRequestRole();

        String complianceDidResponse = null;

        if (isNodeSupportsApplicationDid(nodeAddress, ecuAcronym)
                && vehicleNodeDIDResponse != null) {
            if (GVMSModuleUpdateConstants.SW_DID_TYPES.contains(vehicleNodeDIDResponse.getDidType()) ||
                    isApplicationDid(vehicleNodeDIDResponse.getDidCatalog())) {
                String didResponse;
                String didValue = vehicleNodeDIDResponse.getDidCatalog();
                if (!StringUtils.isEmpty(complianceDidResponse)) {
                    didResponse = complianceDidResponse;
                } else {
                    didResponse = vehicleNodeDIDResponse.getDidResponse();
                }
                if (isApplicationDid(didValue)) {

                    getApplicationPartList(vin, nodeAddress, didValue, didResponse,
                            requestRole, ecuAcronym, true, applicationSwPartNumberStateMap,
                            vehicleNodeDIDStatusListToPersist);
                } else {
                    VehicleNodeDIDStatus existingVehicleNodeStatus = otherSwPartNumberStateMap.get(didValue);
                    //If the Software not exist in table then populate new state entity object and add it to persist list
                    if (existingVehicleNodeStatus == null) {
                        //validate the PartNumber
                        if (ApplicationUtils.checkPartNumber(didResponse)) {
                            //Creating new state entity Object for new software
                            VehicleNodeDIDStatus newAndModifiedVehicleNodeDIDStatus = populateVehicleNodeDIDStatus(vin, didResponse, nodeAddress, didValue,
                                    GVMSModuleUpdateConstants.STATE_CI, requestRole, ecuAcronym);
                            //Adding installable partnumber to persist List
                            vehicleNodeDIDStatusListToPersist.add(newAndModifiedVehicleNodeDIDStatus);
                        }
                    } else {
                        //Change the state of existing partnumber of software and add it to persist list
                        if (!didResponse.equalsIgnoreCase(existingVehicleNodeStatus.getPartNumber().toString())) {
                            //Validate partNumber before persist
                            if (ApplicationUtils.checkPartNumber(didResponse)) {
                                //Creating new state entity Object for new software
                                VehicleNodeDIDStatus newAndModifiedVehicleNodeDIDStatus = populateVehicleNodeDIDStatus(vin, didResponse,
                                        nodeAddress, didValue, GVMSModuleUpdateConstants.STATE_CI, requestRole, ecuAcronym);
                                //Adding installable partnumber to persist List
                                vehicleNodeDIDStatusListToPersist.add(newAndModifiedVehicleNodeDIDStatus);

                                //Change the state of existing partnumber of software and add it to persist list
                                existingVehicleNodeStatus.setSoftwareStatus(ApplicationInitializer.softwareStateMap.get("CU"));
                                //adding uninstallable partnumber to persist list
                                vehicleNodeDIDStatusListToPersist.add(existingVehicleNodeStatus);
                            }
                        } else {
                            otherSwPartNumberStateMap.remove(didValue);
                        }
                    }
                }
            }
        }
    }

    public void populateEsnSwapMap(VehicleNodeDIDResponse vehicleNodeDIDResponse, Map<String, String> swapMap, boolean isESNFoundForAPIM, AtomicBoolean isESNFoundForTCU, Pattern esnFormatPattern) {

        String nodeAddress = vehicleNodeDIDResponse.getVehicleNodeSnapshot().getNodeAddress();
        String ecuAcronym = vehicleNodeDIDResponse.getVehicleNodeSnapshot().getEcuAcronym();
        String didValue = vehicleNodeDIDResponse.getDidCatalog();
        String didSpecificationCategory = vehicleNodeDIDResponse.getDidSpecificationCategory();
        String electronicSerialNum = (vehicleNodeDIDResponse.getDidResponse() != null && vehicleNodeDIDResponse.getDidResponse().length() > 8 ) ?
                vehicleNodeDIDResponse.getDidResponse().substring(0, 8) : vehicleNodeDIDResponse.getDidResponse();

        if (isNodeSupportsApplicationDid(nodeAddress,ecuAcronym)) {
            if (!StringUtils.isEmpty(didSpecificationCategory) && vehicleNodeDIDResponse.getActiveFlag().equalsIgnoreCase("A")) { // consider only "A" ESN

                if (didValue.equals("F17F")) {
                    if (null != electronicSerialNum && esnFormatPattern.matcher(electronicSerialNum).matches()) {
                        swapMap.put(nodeAddress + "_" + ecuAcronym, electronicSerialNum);
                        isESNFoundForAPIM = true;
                    }
                }

                if (!isESNFoundForAPIM && (didValue.equals("F141") && didSpecificationCategory.equals("GGDS")) ||
                        (didValue.equals("E22X") && didSpecificationCategory.equals("GDS"))) {
                    if (null != electronicSerialNum && esnFormatPattern.matcher(electronicSerialNum).matches()) {
                        swapMap.put(nodeAddress + "_" + ecuAcronym, electronicSerialNum);
                        isESNFoundForAPIM = true;
                    }
                }

            }
        }
        //754 - F18C
        if ("A".equalsIgnoreCase(vehicleNodeDIDResponse.getActiveFlag())) {
            if (GVMSModuleUpdateConstants.NODE_754.equals(nodeAddress) && tcuF17FF18Cdids.contains(didValue)) {

                if(GVMSModuleUpdateConstants.SERIAL_F17F.equalsIgnoreCase(didValue)) {

                    electronicSerialNum = vehicleNodeDIDResponse.getDidResponse().length() > 8 ? vehicleNodeDIDResponse.getDidResponse().substring(0, 8) : vehicleNodeDIDResponse.getDidResponse();
                    if (null != electronicSerialNum && esnFormatPattern.matcher(electronicSerialNum).matches()) {
                        swapMap.put(nodeAddress + "_" + ecuAcronym, electronicSerialNum);
                        isESNFoundForTCU.set(true);
                    }
                } else if(isESNFoundForTCU.get()==false && GVMSModuleUpdateConstants.SERIAL_F18C.equalsIgnoreCase(didValue)) {

                    electronicSerialNum = vehicleNodeDIDResponse.getDidResponse().length() > 8 ? vehicleNodeDIDResponse.getDidResponse().substring(0, 8) : vehicleNodeDIDResponse.getDidResponse();
                    if (null != electronicSerialNum && esnFormatPattern.matcher(electronicSerialNum).matches()) {
                        swapMap.put(nodeAddress + "_" + ecuAcronym, electronicSerialNum);
                    }
                }
            }
        }
        //731 - F18C
        if ("A".equalsIgnoreCase(vehicleNodeDIDResponse.getActiveFlag())) {
            if (GVMSModuleUpdateConstants.NODE_731.equals(nodeAddress)&&
                    GVMSModuleUpdateConstants.BLEM_ACRONYM.equalsIgnoreCase(ecuAcronym) && GVMSModuleUpdateConstants.SERIAL_F18C.equalsIgnoreCase(didValue)) {
                if (null != electronicSerialNum && esnFormatPattern.matcher(electronicSerialNum).matches()) {
                    swapMap.put(nodeAddress + "_" + ecuAcronym, electronicSerialNum);
                }
            }
        }
    }

    public List<VehicleNodeDIDSoftware> getApplicationPartList(String didResponse, VehicleNodeDIDResponse didEntity) {

        List<VehicleNodeDIDSoftware> didSWList = new ArrayList<>();
        String firstStr = null;
        String secondStr = didResponse;
        int noOfBytes = 24;
        int tempCount = 0;
        try {
            // changes added for VIL application did
            if(secondStr.contains(",")){
                String[] appDidRespArray = secondStr.split(",");
                for(String didResp :appDidRespArray){
                    if(!StringUtils.isEmpty(didResp) && didResp.length() > 0) {
                        didResp = didResp.trim();
                        VehicleNodeDIDSoftware didSoftware = populateVehicleNodeDidSoftware(getPartInfo(didResp), didResp, tempCount + 1, didEntity);
                        didSWList.add(didSoftware);
                        tempCount += 1;
                    }
                }
            }else {
                while (secondStr.length() > 0) {
                    firstStr = secondStr.substring(0, Math.min(noOfBytes, secondStr.length())).trim();
                    secondStr = secondStr.substring(Math.min(noOfBytes, secondStr.length()));
                    if (firstStr.length() > 0) {
                        VehicleNodeDIDSoftware didSoftware = populateVehicleNodeDidSoftware(getPartInfo(firstStr), firstStr, tempCount + 1, didEntity);
                        didSWList.add(didSoftware);
                    }
                    tempCount += 1;
                }
            }
        } catch (Exception e) {
            logger.error(" Exception at getApplicationPartList : " + e.getStackTrace());
        }
        return didSWList;
    }

    public FordPartNumberId getPartInfo(String applicationPart) {
        FordPartNumberId partNoTo = null;
        if (ApplicationUtils.checkPartNumber(applicationPart)) {
            partNoTo = getFordPartNumberId(applicationPart);
        }
        return partNoTo;
    }

    private FordPartNumberId getFordPartNumberId(String fordPartNumber) {
        String[] partNums = getParsedPartNumber(fordPartNumber);

        if (partNums == null)
            return null;
        FordPartNumberId fpnEntity = new FordPartNumberId();
        fpnEntity.setFordPartNumberPrefix(partNums[0]);
        fpnEntity.setFordPartNumberBase(partNums[1]);
        fpnEntity.setFordPartNumberSuffix(partNums[2]);

        return fpnEntity;
    }

    private String[] getParsedPartNumber(String fordPartNumber) {
        String[] partnums = null;
        try {
            partnums = fordPartNumber.split("-");
        } catch (Exception e) {
            logger.error("Error while reading Ford Part Number IVSServiceActionHelper.getParsedPartNumber : " + fordPartNumber);
        }
        return partnums;
    }

    private VehicleNodeDIDSoftware populateVehicleNodeDidSoftware(FordPartNumberId partNum, String partResponse, int sequence, VehicleNodeDIDResponse didEntity) {

        VehicleNodeDIDSoftware didSoftwareEntity = new VehicleNodeDIDSoftware();
        VehicleNodeDIDSoftwareId id = new VehicleNodeDIDSoftwareId();

        id.setPartSequenceNumber(sequence);
        id.setVehicleNodeDID(didEntity);

        didSoftwareEntity.setPartNumber(partNum);
        didSoftwareEntity.setPartResponse(partResponse);
        didSoftwareEntity.setDidSoftwareId(id);
        didSoftwareEntity.setUpdatedDate(new Timestamp(new Date().getTime()));

        return didSoftwareEntity;
    }

    public void getApplicationPartList(String vin, String nodeAddress, String didType, String didResponse, StateUpdateRoleType requestRole, String ecuAcronym, boolean isFPNModified,
                                       Map<String, VehicleNodeDIDStatus> applicationSwPartNumberStateListMap, List<VehicleNodeDIDStatus> vehicleNodeDIDStatusListToBePersisted) {
        String firstStr = null;
        String secondStr = didResponse;
        int noOfBytes = 24;
        try {
            // changes added for VIL application did
            if(secondStr.contains(",")){
                String[] appDidRespArray = secondStr.split(",");
                for(String didResp :appDidRespArray){
                    if(!StringUtils.isEmpty(didResp) && didResp.length() > 0) {
                        didResp = didResp.trim();
                        if (ApplicationUtils.checkPartNumber(didResp)) {
                            VehicleNodeDIDStatus existingAppvehicleNodeDIDStatus = applicationSwPartNumberStateListMap.get(didResp);
                            if (existingAppvehicleNodeDIDStatus == null) {
                                VehicleNodeDIDStatus newApplicationVehicleNodeDIDStatus = populateVehicleNodeDIDStatus(vin, didResp, nodeAddress, didType, GVMSModuleUpdateConstants.STATE_CI, requestRole, ecuAcronym);
                                vehicleNodeDIDStatusListToBePersisted.add(newApplicationVehicleNodeDIDStatus);
                            } else {
                                applicationSwPartNumberStateListMap.remove(didResp);
                            }
                        }
                    }
                }
            }else {
                while (secondStr.length() > 0) {
                    firstStr = secondStr.substring(0, Math.min(noOfBytes, secondStr.length())).trim();
                    secondStr = secondStr.substring(Math.min(noOfBytes, secondStr.length()));
                    if (firstStr.length() > 0) {
                        if (ApplicationUtils.checkPartNumber(firstStr)) {
                            VehicleNodeDIDStatus existingAppvehicleNodeDIDStatus = applicationSwPartNumberStateListMap.get(firstStr);
                            if (existingAppvehicleNodeDIDStatus == null) {
                                VehicleNodeDIDStatus newApplicationVehicleNodeDIDStatus = populateVehicleNodeDIDStatus(vin, firstStr, nodeAddress, didType, GVMSModuleUpdateConstants.STATE_CI, requestRole, ecuAcronym);
                                vehicleNodeDIDStatusListToBePersisted.add(newApplicationVehicleNodeDIDStatus);
                            } else {
                                applicationSwPartNumberStateListMap.remove(firstStr);
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.error(" Exception at VehicleModuuleInstallHelper.getApplicationPartList : " + ex.getStackTrace());
        }
    }

    public VehicleNodeDIDStatus populateVehicleNodeDIDStatus(String vin, String partNum, String nodeAddr, String didType, String state, StateUpdateRoleType requestRole, String ecuAcronym) {
        if (null != partNum && !partNum.equalsIgnoreCase("BLANK") &&
                ApplicationUtils.checkPartNumber(partNum)) {
            VehicleNodeDIDStatus didStatus = new VehicleNodeDIDStatus();
            SoftwareStatus softwareStatus = ApplicationInitializer.softwareStateMap.get(state);
            didStatus.setSoftwareStatus(softwareStatus);
            didStatus.setVin(vin);
            didStatus.setEcuAcronym(ecuAcronym);
            VehicleNodeDIDStatusID vehicleNodeDIDStatusID = new VehicleNodeDIDStatusID();
            vehicleNodeDIDStatusID.setVinHashNumber(ApplicationUtils.getVinHash(vin));
            didStatus.setVehicleNodeDIDStatusID(vehicleNodeDIDStatusID);
            didStatus.setNodeAddress(nodeAddr);
            didStatus.setDidCatalog(didType);
            didStatus.setRecordedTime(new Timestamp(new Date().getTime()));
            didStatus.setPartNumber(getFordPartNumberId(partNum));
            RequestorRole requestorRole = new RequestorRole();
            requestorRole.setRoleName(requestRole.getRole().value());
            didStatus.setRoleName(requestorRole);
            didStatus.setRoleDescription(requestRole.getRoleDesc());
            didStatus.setRoleSource(requestRole.getRoleSource().value());
            return didStatus;
        } else {
            return null;
        }
    }

    public boolean isApplicationDid(String didValue){
        return didValue!=null && applicationDids.contains(didValue);
    }

    public boolean isNodeSupportsApplicationDid(String nodeAddress, String ecuAcronym){
        if(applicationSupportedNodeMap.containsKey(nodeAddress)){
            if(applicationSupportedNodeMap.get(nodeAddress)==null){
                return true;
            }
            if(applicationSupportedNodeMap.get(nodeAddress).contains(ecuAcronym)){
                return true;
            }
        }
        return false;
    }

    public Map<String, String> getApplicationDidMaps(){
        Map<String, String> applicationDidList = new HashMap<>();
        for(String did:applicationDids) {
            applicationDidList.put(did,"Application");
        }
        return applicationDidList;
    }

    public void populateOtherVehicleNodeDIDStatusListFromExisting(Map<String, VehicleNodeDIDStatus> otherSwPartNumberStateMap,
                                                                   Map<String, VehicleNodeDIDStatus> applicationSwPartNumberStateMap,
                                                                   List<VehicleNodeDIDStatus> vehicleNodeDIDStatusListToPersist, String ecuAcronym){
        if (!otherSwPartNumberStateMap.isEmpty() && otherSwPartNumberStateMap.size() > 0) {
            for (Map.Entry<String, VehicleNodeDIDStatus> vehicleNodeDIDStatusEntry : otherSwPartNumberStateMap.entrySet()) {
                VehicleNodeDIDStatus vehicleNodeDIDStatus = vehicleNodeDIDStatusEntry.getValue();
                vehicleNodeDIDStatus.setSoftwareStatus(ApplicationInitializer.softwareStateMap.get(GVMSModuleUpdateConstants.STATE_CU));
                if (vehicleNodeDIDStatus.getEcuAcronym() == null)
                    vehicleNodeDIDStatus.setEcuAcronym(ecuAcronym);
                vehicleNodeDIDStatusListToPersist.add(vehicleNodeDIDStatus);
            }
        }
        if (!applicationSwPartNumberStateMap.isEmpty() && applicationSwPartNumberStateMap.size() > 0) {
            for (Map.Entry<String, VehicleNodeDIDStatus> vehicleNodeDIDStatusEntry : applicationSwPartNumberStateMap.entrySet()) {

                VehicleNodeDIDStatus vehicleNodeDIDStatus = vehicleNodeDIDStatusEntry.getValue();
                vehicleNodeDIDStatus.setSoftwareStatus(ApplicationInitializer.softwareStateMap.get(GVMSModuleUpdateConstants.STATE_CU));
                vehicleNodeDIDStatusListToPersist.add(vehicleNodeDIDStatus);
            }
        }

    }

}
