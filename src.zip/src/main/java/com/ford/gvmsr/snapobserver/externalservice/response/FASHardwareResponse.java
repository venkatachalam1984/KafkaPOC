package com.ford.gvmsr.snapobserver.externalservice.response;


import com.ford.gvmsr.snapobserver.externalservice.request.DIDInfo;

import java.util.HashMap;
import java.util.Map;

public class FASHardwareResponse {

    Map<String, DIDInfo> nodeHardwareMap = new HashMap<>();

    public Map<String, DIDInfo> getNodeHardwareMap() {
        return nodeHardwareMap;
    }

    public void setNodeHardwareMap(Map<String, DIDInfo> nodeHardwareMap) {
        this.nodeHardwareMap = nodeHardwareMap;
    }
}
