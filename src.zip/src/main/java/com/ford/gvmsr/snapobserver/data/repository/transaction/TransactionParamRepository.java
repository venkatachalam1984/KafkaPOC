package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.TransactionParam;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.List;

@Repository
@Transactional
public interface TransactionParamRepository extends CrudRepository<TransactionParam,Serializable> {

    public List<TransactionParam>  findByParamCode(String paramCode);
}
