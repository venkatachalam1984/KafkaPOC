package com.ford.gvmsr.snapobserver.externalservice.request;

/**
 * Created by vm4 on 12/05/2018.
 */
public class FPNDIDInfoType {

    private String response;
    private Boolean isConfig;
    private String didValue;
    private String didType;
    private String nodeAddress;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Boolean getConfig() {
        return isConfig;
    }

    public void setConfig(Boolean config) {
        isConfig = config;
    }

    public String getDidValue() {
        return didValue;
    }

    public void setDidValue(String didValue) {
        this.didValue = didValue;
    }

    public String getDidType() {
        return didType;
    }

    public void setDidType(String didType) {
        this.didType = didType;
    }

    public String getNodeAddress() {
        return nodeAddress;
    }

    public void setNodeAddress(String nodeAddress) {
        this.nodeAddress = nodeAddress;
    }
}
