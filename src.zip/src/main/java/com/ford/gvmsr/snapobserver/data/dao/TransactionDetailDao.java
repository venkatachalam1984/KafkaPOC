package com.ford.gvmsr.snapobserver.data.dao;

import java.sql.Timestamp;

public interface TransactionDetailDao {
   long save(String vin, String status, long txnId, String sourceSystem,
             Timestamp currentTimestamp, int retryCount);
}
