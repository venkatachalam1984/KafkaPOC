
package com.ford.gvmsr.snapobserver.modulestate.request;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for SoftwareMetaDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SoftwareMetaDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ProgrammingMgmtCompliance" type="{urn:ford/Vehicle/Module/Information/v4.0}PODProgrammingManagementDataType" minOccurs="0"/&gt;
 *         &lt;element name="Checksum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwareURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SupportingSoftware" type="{urn:ford/Vehicle/Module/Information/v4.0}ECUSoftwareType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FileSignature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MappedFeatures" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EULADocumentURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="State" type="{urn:ford/Vehicle/Module/Information/v4.0}SoftwareStateType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="MarketingDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FunctionType" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="WrapperDoc" type="{urn:ford/Vehicle/Module/Information/v4.0}WrapperDocType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LanguageCodes" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SYNCGeneration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="didValue" type="{urn:ford/Vehicle/Module/Information/v4.0}DIDValueType" /&gt;
 *       &lt;attribute name="type" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="version" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="partNumber" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="binaryFileROMSize" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="runTimeSize" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="softwareSize" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="isUnInstallable" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="isProgrammingProtected" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="subType" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="fileFormat" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SoftwareMetaDataType", propOrder = {
    "programmingMgmtCompliance",
    "checksum",
    "softwareURL",
    "supportingSoftware",
    "fileSignature",
    "mappedFeatures",
    "description",
    "eulaDocumentURL",
    "state",
    "marketingDesc",
    "functionType",
    "wrapperDoc",
    "languageCodes",
    "syncGeneration"
})
@XmlSeeAlso({
    ECUSoftwareType.class
})
public class SoftwareMetaDataType {

    @XmlElement(name = "ProgrammingMgmtCompliance")
    protected PODProgrammingManagementDataType programmingMgmtCompliance;
    @XmlElement(name = "Checksum")
    protected String checksum;
    @XmlElement(name = "SoftwareURL")
    protected String softwareURL;
    @XmlElement(name = "SupportingSoftware")
    protected List<ECUSoftwareType> supportingSoftware;
    @XmlElement(name = "FileSignature")
    protected String fileSignature;
    @XmlElement(name = "MappedFeatures")
    protected String mappedFeatures;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "EULADocumentURL")
    protected String eulaDocumentURL;
    @XmlElement(name = "State")
    protected List<SoftwareStateType> state;
    @XmlElement(name = "MarketingDesc")
    protected String marketingDesc;
    @XmlElement(name = "FunctionType")
    protected List<String> functionType;
    @XmlElement(name = "WrapperDoc")
    protected List<WrapperDocType> wrapperDoc;
    @XmlElement(name = "LanguageCodes")
    protected List<String> languageCodes;
    @XmlElement(name = "SYNCGeneration")
    protected String syncGeneration;
    @XmlAttribute(name = "didValue")
    protected String didValue;
    @XmlAttribute(name = "type")
    protected String type;
    @XmlAttribute(name = "version")
    protected String version;
    @XmlAttribute(name = "partNumber")
    protected String partNumber;
    @XmlAttribute(name = "binaryFileROMSize")
    protected Long binaryFileROMSize;
    @XmlAttribute(name = "runTimeSize")
    protected Long runTimeSize;
    @XmlAttribute(name = "softwareSize")
    protected Long softwareSize;
    @XmlAttribute(name = "isUnInstallable")
    protected Boolean isUnInstallable;
    @XmlAttribute(name = "isProgrammingProtected")
    protected Boolean isProgrammingProtected;
    @XmlAttribute(name = "subType")
    protected String subType;
    @XmlAttribute(name = "fileFormat")
    protected String fileFormat;

    /**
     * Gets the value of the programmingMgmtCompliance property.
     * 
     * @return
     *     possible object is
     *     {@link PODProgrammingManagementDataType }
     *     
     */
    public PODProgrammingManagementDataType getProgrammingMgmtCompliance() {
        return programmingMgmtCompliance;
    }

    /**
     * Sets the value of the programmingMgmtCompliance property.
     * 
     * @param value
     *     allowed object is
     *     {@link PODProgrammingManagementDataType }
     *     
     */
    public void setProgrammingMgmtCompliance(PODProgrammingManagementDataType value) {
        this.programmingMgmtCompliance = value;
    }

    /**
     * Gets the value of the checksum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChecksum() {
        return checksum;
    }

    /**
     * Sets the value of the checksum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChecksum(String value) {
        this.checksum = value;
    }

    /**
     * Gets the value of the softwareURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareURL() {
        return softwareURL;
    }

    /**
     * Sets the value of the softwareURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareURL(String value) {
        this.softwareURL = value;
    }

    /**
     * Gets the value of the supportingSoftware property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the supportingSoftware property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSupportingSoftware().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ECUSoftwareType }
     * 
     * 
     */
    public List<ECUSoftwareType> getSupportingSoftware() {
        if (supportingSoftware == null) {
            supportingSoftware = new ArrayList<ECUSoftwareType>();
        }
        return this.supportingSoftware;
    }

    /**
     * Gets the value of the fileSignature property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileSignature() {
        return fileSignature;
    }

    /**
     * Sets the value of the fileSignature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileSignature(String value) {
        this.fileSignature = value;
    }

    /**
     * Gets the value of the mappedFeatures property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMappedFeatures() {
        return mappedFeatures;
    }

    /**
     * Sets the value of the mappedFeatures property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMappedFeatures(String value) {
        this.mappedFeatures = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the eulaDocumentURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEULADocumentURL() {
        return eulaDocumentURL;
    }

    /**
     * Sets the value of the eulaDocumentURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEULADocumentURL(String value) {
        this.eulaDocumentURL = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the state property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getState().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SoftwareStateType }
     * 
     * 
     */
    public List<SoftwareStateType> getState() {
        if (state == null) {
            state = new ArrayList<SoftwareStateType>();
        }
        return this.state;
    }

    /**
     * Gets the value of the marketingDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarketingDesc() {
        return marketingDesc;
    }

    /**
     * Sets the value of the marketingDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarketingDesc(String value) {
        this.marketingDesc = value;
    }

    /**
     * Gets the value of the functionType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the functionType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFunctionType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFunctionType() {
        if (functionType == null) {
            functionType = new ArrayList<String>();
        }
        return this.functionType;
    }

    /**
     * Gets the value of the wrapperDoc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wrapperDoc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWrapperDoc().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WrapperDocType }
     * 
     * 
     */
    public List<WrapperDocType> getWrapperDoc() {
        if (wrapperDoc == null) {
            wrapperDoc = new ArrayList<WrapperDocType>();
        }
        return this.wrapperDoc;
    }

    /**
     * Gets the value of the languageCodes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the languageCodes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLanguageCodes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getLanguageCodes() {
        if (languageCodes == null) {
            languageCodes = new ArrayList<String>();
        }
        return this.languageCodes;
    }

    /**
     * Gets the value of the syncGeneration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSYNCGeneration() {
        return syncGeneration;
    }

    /**
     * Sets the value of the syncGeneration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSYNCGeneration(String value) {
        this.syncGeneration = value;
    }

    /**
     * Gets the value of the didValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDidValue() {
        return didValue;
    }

    /**
     * Sets the value of the didValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDidValue(String value) {
        this.didValue = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * Gets the value of the partNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartNumber() {
        return partNumber;
    }

    /**
     * Sets the value of the partNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartNumber(String value) {
        this.partNumber = value;
    }

    /**
     * Gets the value of the binaryFileROMSize property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBinaryFileROMSize() {
        return binaryFileROMSize;
    }

    /**
     * Sets the value of the binaryFileROMSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBinaryFileROMSize(Long value) {
        this.binaryFileROMSize = value;
    }

    /**
     * Gets the value of the runTimeSize property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRunTimeSize() {
        return runTimeSize;
    }

    /**
     * Sets the value of the runTimeSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRunTimeSize(Long value) {
        this.runTimeSize = value;
    }

    /**
     * Gets the value of the softwareSize property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSoftwareSize() {
        return softwareSize;
    }

    /**
     * Sets the value of the softwareSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSoftwareSize(Long value) {
        this.softwareSize = value;
    }

    /**
     * Gets the value of the isUnInstallable property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUnInstallable() {
        return isUnInstallable;
    }

    /**
     * Sets the value of the isUnInstallable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUnInstallable(Boolean value) {
        this.isUnInstallable = value;
    }

    /**
     * Gets the value of the isProgrammingProtected property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsProgrammingProtected() {
        return isProgrammingProtected;
    }

    /**
     * Sets the value of the isProgrammingProtected property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsProgrammingProtected(Boolean value) {
        this.isProgrammingProtected = value;
    }

    /**
     * Gets the value of the subType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubType() {
        return subType;
    }

    /**
     * Sets the value of the subType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubType(String value) {
        this.subType = value;
    }

    /**
     * Gets the value of the fileFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileFormat() {
        return fileFormat;
    }

    /**
     * Sets the value of the fileFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileFormat(String value) {
        this.fileFormat = value;
    }

}
