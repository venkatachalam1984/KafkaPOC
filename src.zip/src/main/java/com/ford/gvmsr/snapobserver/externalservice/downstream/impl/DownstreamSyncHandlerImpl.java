package com.ford.gvmsr.snapobserver.externalservice.downstream.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gvmsr.snapobserver.config.VertxConfiguration;
import com.ford.gvmsr.snapobserver.data.entity.VehicleId;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeConfig;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.dto.DownStreamSyncUpRequest;
import com.ford.gvmsr.snapobserver.dto.NodeStatus;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.enums.SnapStatus;
import com.ford.gvmsr.snapobserver.externalservice.downstream.DownstreamSyncHandler;
import com.ford.gvmsr.snapobserver.kafka.producer.GVMSRSnapshotSyncupProducer;
import com.ford.gvmsr.snapobserver.logevent.LogEventMonitor;
import com.ford.gvmsr.snapobserver.logevent.LogType;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.monitor.SnapshotNodeMonitor;
import com.ford.gvmsr.snapobserver.modulestate.request.*;
import com.ford.gvmsr.snapobserver.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class DownstreamSyncHandlerImpl implements DownstreamSyncHandler {

    private static final Logger logger = LoggerFactory.getLogger(DownstreamSyncHandlerImpl.class);

    @Autowired
    private VertxConfiguration vertxConfiguration;

    @Autowired
    private GVMSRSnapshotSyncupProducer gvmsrSnapshotSyncupProducer;

    @Autowired
    LogEventMonitor logEventMonitor;

    private Boolean isVehicleProfileTrigger = false;

    @Override
    public void sendToDownstreamSystems(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest, Map<String, NodeStatus> nodeStatusMap,
                                        long transactionId, long transactionDetailId, Timestamp vinRecordedTimestamp, VehicleId vehicleId) {
        logger.info("DownstreamSyncUp:Entering  sendToDownstreamSystems");
        long start = System.currentTimeMillis();
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, NodeAndDIDResponseForNewSnap> nodeAndDIDResponseForNewSnapMap = moduleSnapshotObserverRequest.getNodeAndDIDResponseForNewSnapMap();
        List<String> snapSNodeList = new ArrayList<>();
        List<String> vehPrfModuleNodeStrList = new ArrayList<>();
        try {
            ModuleSnapshotType moduleSnapshotType = populateUpdatedModuleSnapshotType(moduleSnapshotObserverRequest,
                    nodeAndDIDResponseForNewSnapMap, nodeStatusMap, snapSNodeList, vinRecordedTimestamp, vehPrfModuleNodeStrList);

            DownStreamSyncUpRequest downStreamSyncupRequest = populateDownstreamSyncupRequest(moduleSnapshotObserverRequest, moduleSnapshotType,
                    snapSNodeList, transactionId, transactionDetailId, vehPrfModuleNodeStrList, vehicleId);

            //For sync Up to call moduleUpdateService to post sync up data
            logger.info("DownstreamSyncUp:snapshot sync up for VIN={}, with request DownStreamSyncupRequest ={}",
                    moduleSnapshotObserverRequest.getVin(), downStreamSyncupRequest.toString());

            String downStreamSyncupRequestStr = objectMapper.writeValueAsString(downStreamSyncupRequest);
            gvmsrSnapshotSyncupProducer.publishMessage(downStreamSyncupRequestStr, vertxConfiguration.getSnapshotProducerSyncupTopic());

            String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
            logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value(), moduleSnapshotObserverRequest.getVin(), null, moduleSnapshotObserverRequest.getTraceId(),
                    LogType.INFO, SnapStatus.SYNC_SENT_S.getCode(), duration, CommonUtils.getEventTimeStamp(), null);

        } catch (Exception e) {
            logger.error("DownstreamSyncUp:snapshot sync up for VIN =[{}] Error Msg:{}",
                    moduleSnapshotObserverRequest.getVin(), e.getMessage());
            String duration = CommonUtils.millisecondsToSeconds(System.currentTimeMillis() - start);
            logEventMonitor.LogEvent(moduleSnapshotObserverRequest.getRequestRole().getRoleSource().value(), moduleSnapshotObserverRequest.getVin(), null, moduleSnapshotObserverRequest.getTraceId(),
                    LogType.FATAL, SnapStatus.SYNC_SENT_F.getCode(), duration, CommonUtils.getEventTimeStamp(), e.getMessage());
        }

    }

    /**
     *  Method used to populate updated ModuleSnapshotType to sync up VSS and GIVIS
     *
     * @param moduleSnapshotObserverRequest

     * @param nodeAndDIDResponseForNewSnapMap
     * @param snapSNodeList
     */
    public ModuleSnapshotType populateUpdatedModuleSnapshotType(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest,
                                                                Map<String, NodeAndDIDResponseForNewSnap> nodeAndDIDResponseForNewSnapMap, Map<String, NodeStatus> nodeStatusMap,
                                                                List<String> snapSNodeList, Timestamp vinRecordedTimestamp, List<String> vehPrfModuleNodeStrList) {
        {
            logger.info(" DownstreamSyncUp:Entering populateUpdatedModuleSnapshotType for downstream sync up : " + moduleSnapshotObserverRequest.getVin());

            ModuleSnapshotType moduleSnapshotType = moduleSnapshotObserverRequest.getModuleSnapshotType();

            for (ModuleNodeType moduleNodeType : moduleSnapshotType.getNode()) {

                if (nodeStatusMap.containsKey(moduleNodeType.getAddress()) &&
                        nodeStatusMap.get(moduleNodeType.getAddress()).getCode().
                                equalsIgnoreCase(SnapStatus.SUCCESS.getCode())) {
                    snapSNodeList.add(moduleNodeType.getAddress());

                    NodeAndDIDResponseForNewSnap nodeAndDIDResponseForNewSnap = nodeAndDIDResponseForNewSnapMap.get(moduleNodeType.getAddress());
                    if (nodeAndDIDResponseForNewSnap != null) {
                        List<VehicleNodeDIDResponse> vehicleNodeDIDResponseList = nodeAndDIDResponseForNewSnap.getVehicleNodeDIDResponseList();
                        AdditionalProperties additionalProperties = null;
                        for (ECUAcronymType ecuAcronymType : moduleNodeType.getECUAcronym()) {
                            if (moduleSnapshotObserverRequest.getSnapshotObserverRequest().getAdditionalPropertiesMap() != null
                                    && moduleSnapshotObserverRequest.getSnapshotObserverRequest().getAdditionalPropertiesMap().containsKey(moduleNodeType.getAddress())) {
                                additionalProperties = moduleSnapshotObserverRequest.getSnapshotObserverRequest().getAdditionalPropertiesMap().get(moduleNodeType.getAddress());
                            }
                            //FOR VIL we are setting ODL Acronym istead Request Acronym
                            if (additionalProperties != null && !StringUtils.isEmpty(additionalProperties.getOdlNetworkDetailsForNode().getEcuAcronym())) {
                                ecuAcronymType.setName(additionalProperties.getOdlNetworkDetailsForNode().getEcuAcronym());
                            }
                            //SETTING isVehicleProfileTrigger TO DOWNSTREAM SYNC UP
                            SnapshotNodeMonitor snapshotNodeMonitor = moduleSnapshotObserverRequest.getSnapshotChangeMonitor().getSnapshotNodeMonitor(moduleNodeType);
                            if (snapshotNodeMonitor.isVehicleProfileTrigger()) {
                                isVehicleProfileTrigger = true;
                                vehPrfModuleNodeStrList.add(moduleNodeType.getAddress() + ":" + ecuAcronymType.getName());
                            }
                            for (HistoricType historicType : ecuAcronymType.getState()) {
                                for (GatewayType gatewayType : historicType.getGateway()) {
                                    for (DIDInfoType didInfoType : gatewayType.getDID()) {
                                        for (VehicleNodeDIDResponse vehicleNodeDIDResponse : vehicleNodeDIDResponseList) {
                                            //FOR VIL we are setting Dealer snap network details if previous snap role is DEALER
                                            ModuleODLNetworkType moduleODLNetworkType = moduleNodeType.getODLNetwork();
                                            moduleODLNetworkType.setNetworkName(vehicleNodeDIDResponse.getNetworkName());
                                            moduleODLNetworkType.setNetworkProtocol(vehicleNodeDIDResponse.getNetworkProtocol());
                                            moduleODLNetworkType.setNetworkDataRate(vehicleNodeDIDResponse.getNetworkDataRate());

                                            if (vehicleNodeDIDResponse.getDidCatalog().equalsIgnoreCase(didInfoType.getDidValue())) {
                                                if (didInfoType.isIsConfig()) {
                                                    VehicleNodeConfig vehicleNodeConfig = nodeAndDIDResponseForNewSnap.getVehicleNodeConfigMap().get(vehicleNodeDIDResponse.getDidCatalog());
                                                    didInfoType.setResponse(vehicleNodeConfig.getConfigurationData());
                                                    break;
                                                } else {
                                                    didInfoType.setResponse(vehicleNodeDIDResponse.getDidResponse());
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        logger.info("DownstreamSyncUp:vehicleDidResponses null for the VIN=[{}], Node=[{}]", moduleSnapshotObserverRequest.getVin(),
                                moduleNodeType.getAddress());
                    }
                }
                //populate snapShot time in additionalAttributes
                populateSnapshotTimestampInModuleNodeType(moduleNodeType, vinRecordedTimestamp);
            }
            return moduleSnapshotType;
        }
    }

    private DownStreamSyncUpRequest populateDownstreamSyncupRequest(ModuleSnapshotObserverRequest moduleSnapshotObserverRequest,
                                                                    ModuleSnapshotType moduleSnapshotType, List<String> snapSNodeList,
                                                                    long transactionId, long transactionDetailId,
                                                                    List<String> vehPrfModuleNodeStrList,VehicleId vehicleId){

        DownStreamSyncUpRequest downStreamSyncupRequest = new DownStreamSyncUpRequest();
        downStreamSyncupRequest.setVin(moduleSnapshotObserverRequest.getVin());
        downStreamSyncupRequest.setTraceId(moduleSnapshotObserverRequest.getTraceId());
        downStreamSyncupRequest.setModuleSnapshotType(moduleSnapshotType);
        downStreamSyncupRequest.setSnapSNodeList(snapSNodeList);
        downStreamSyncupRequest.setTransactionId(transactionId);
        downStreamSyncupRequest.setTransactionDetailId(transactionDetailId);
        downStreamSyncupRequest.setVehicleProfileTrigger(isVehicleProfileTrigger);
        downStreamSyncupRequest.setVehPrfModuleNodeStrList(vehPrfModuleNodeStrList);
        downStreamSyncupRequest.setVehicleId(vehicleId);
        return downStreamSyncupRequest;
    }

    private void populateSnapshotTimestampInModuleNodeType(ModuleNodeType moduleNodeType, Timestamp timestamp) {
        try {
            logger.debug("DownstreamSyncUp:Node:{} Timestamp:{}", moduleNodeType.getAddress(), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").format(timestamp));
            AdditionalNodePropertiesType additionalNodePropertiesType = new AdditionalNodePropertiesType();
            additionalNodePropertiesType.setSyncData(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(timestamp));
            moduleNodeType.setAdditionalAttributes(additionalNodePropertiesType);
        } catch (Exception ex) {
            logger.error("DownstreamSyncUp:Error while populating Snapshot timestamp for GIVIS; Error:{}", ex.getMessage());
        }
    }

}
