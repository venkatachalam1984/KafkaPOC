package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.ModuleNode;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

public interface ModuleNodeDao {
    void saveModuleNode(ModuleNode moduleNodeEntity) throws Exception;

    List<ModuleNode> retrieveModuleNodeList(Vehicle vehicleEntity) throws Exception;

    ModuleNode findModuleNodeBy(String programCode, Float salesModelYear, String nodeAddress, String gwNodeId) throws Exception;

    Map<String, String> getProvisionFlagForAllNode(int vinHash,String vin,String PAAK_PROVISION_NODES);

}
