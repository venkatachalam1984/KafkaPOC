package com.ford.gvmsr.snapobserver.logevent;

public interface LogEventMonitor {

    void LogEvent(String roleSource, String vin, String node, String traceId, LogType type, String status, String duration, long timestamp, String errorDesc);

}
