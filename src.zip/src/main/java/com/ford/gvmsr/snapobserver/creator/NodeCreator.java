package com.ford.gvmsr.snapobserver.creator;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import com.ford.gvmsr.snapobserver.dto.NodeStatus;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;

import java.util.Map;

public interface NodeCreator {

    Map<String, NodeStatus> persistNode(Vehicle vehicle, VehicleSnapshot vehicleSnapshot, ModuleSnapshotObserverRequest moduleSnapshotObserverRequest);
}
