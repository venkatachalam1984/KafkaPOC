package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNode;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeId;

import java.util.Map;

public interface VehicleNodeDao {

    VehicleNode save(VehicleNode vehicleNode);
    Map<String, VehicleNodeId> populateVehicleNodeIdMap(String vin, int vinHash);
}
