package com.ford.gvmsr.snapobserver.data.repository.transaction;

import com.ford.gvmsr.snapobserver.data.entity.transaction.Application;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;

public interface ApplicationRepository extends CrudRepository<Application, Serializable> {
    Application findByApplicationCode(String applicationCode);
}
