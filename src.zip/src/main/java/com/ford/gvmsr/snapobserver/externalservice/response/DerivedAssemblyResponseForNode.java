package com.ford.gvmsr.snapobserver.externalservice.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class DerivedAssemblyResponseForNode implements Serializable {

    @JsonProperty("partLineageId")
    private long partLineageId;

    @JsonProperty("partNumberForDA")
    private String partNumberForDA;

    @JsonProperty("ruleNo")
    private String ruleNo;
/*
    @JsonProperty("isActualDerivedAssembly")
    private boolean isActualDerivedAssembly;*/

    @JsonProperty("warningText")
    private String warningText;

    @JsonProperty("ivsAssemblyForDA")
    private String ivsAssemblyForDA;

    @JsonProperty("ivsXMLinfoKey")
    private Long ivsXMLinfoKey;

    @JsonProperty("progInSvc")
    private String progInSvc;

    @JsonProperty("replacementModuleIsInOp")
    private String replacementModuleIsInOp;

    public Long getIvsXMLinfoKey() {
        return ivsXMLinfoKey;
    }

    public void setIvsXMLinfoKey(Long ivsXMLinfoKey) {
        this.ivsXMLinfoKey = ivsXMLinfoKey;
    }

    public long getPartLineageId() {
        return partLineageId;
    }

    public void setPartLineageId(long partLineageId) {
        this.partLineageId = partLineageId;
    }

    public String getPartNumberForDA() {
        return partNumberForDA;
    }

    public void setPartNumberForDA(String partNumberForDA) {
        this.partNumberForDA = partNumberForDA;
    }

    public String getRuleNo() {
        return ruleNo;
    }

    public void setRuleNo(String ruleNo) {
        this.ruleNo = ruleNo;
    }

    /*public boolean isActualDerivedAssembly() {
        return isActualDerivedAssembly;
    }

    public void setActualDerivedAssembly(boolean actualDerivedAssembly) {
        isActualDerivedAssembly = actualDerivedAssembly;
    }*/

    public String getWarningText() {
        return warningText;
    }

    public void setWarningText(String warningText) {
        this.warningText = warningText;
    }

    public String getIvsAssemblyForDA() {
        return ivsAssemblyForDA;
    }

    public void setIvsAssemblyForDA(String ivsAssemblyForDA) {
        this.ivsAssemblyForDA = ivsAssemblyForDA;
    }

    public String getProgInSvc() {
        return progInSvc;
    }

    public void setProgInSvc(String progInSvc) {
        this.progInSvc = progInSvc;
    }

    public String getReplacementModuleIsInOp() {
        return replacementModuleIsInOp;
    }

    public void setReplacementModuleIsInOp(String replacementModuleIsInOp) {
        this.replacementModuleIsInOp = replacementModuleIsInOp;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(partLineageId).append("$").append(!partNumberForDA.isEmpty() ? partNumberForDA : " ").append("$").append(!ruleNo.isEmpty() ? ruleNo : " ").append("$").
                append(!progInSvc.isEmpty() ? progInSvc : " ").append("$").append(!replacementModuleIsInOp.isEmpty() ? replacementModuleIsInOp : " ").append("$").
                append(!warningText.isEmpty() ? warningText : " ");
        return stringBuilder.toString();
    }


}
