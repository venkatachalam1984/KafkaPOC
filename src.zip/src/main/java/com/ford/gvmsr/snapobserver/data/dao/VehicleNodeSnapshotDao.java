package com.ford.gvmsr.snapobserver.data.dao;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshot;

import java.sql.SQLException;

public interface VehicleNodeSnapshotDao {

    void deactivateAllExistingVehicleNodeSnapshots(Integer vinHash, String vin, String node);

    VehicleNodeSnapshot save(VehicleNodeSnapshot vehicleNodeSnapshot) throws SQLException;

    void update(String flag, Long primaryKey, int vinHash) throws SQLException;
}
