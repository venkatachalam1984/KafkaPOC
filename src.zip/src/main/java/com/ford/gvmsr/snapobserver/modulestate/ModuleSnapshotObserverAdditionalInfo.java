package com.ford.gvmsr.snapobserver.modulestate;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.dto.PreviousSnapShotDetails;
import com.ford.gvmsr.snapobserver.dto.NodeAndDIDResponseForNewSnap;
import com.ford.gvmsr.snapobserver.modulestate.monitor.SnapshotChangeMonitor;
import com.ford.gvmsr.snapobserver.modulestate.request.SnapshotObserverRequest;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

public class ModuleSnapshotObserverAdditionalInfo {

    protected SnapshotChangeMonitor snapshotChangeMonitor;
    protected Map<String, NodeAndDIDResponseForNewSnap> nodeAndDIDResponseForNewSnapMap;
    protected PreviousSnapShotDetails previousSnapShotDetails;
    protected Vehicle vehicle;
    protected Timestamp vinRecordedTimestamp;

    public ModuleSnapshotObserverAdditionalInfo(SnapshotObserverRequest snapshotObserverRequest) {
        nodeAndDIDResponseForNewSnapMap = new HashMap<>();
        attachSnapshotChangeMonitor(snapshotObserverRequest);
    }

    protected void attachSnapshotChangeMonitor(SnapshotObserverRequest snapshotObserverRequest) {
        this.snapshotChangeMonitor = new SnapshotChangeMonitor(snapshotObserverRequest);
    }

    public SnapshotChangeMonitor getSnapshotChangeMonitor() {
        return snapshotChangeMonitor;
    }


    public Map<String, NodeAndDIDResponseForNewSnap> getNodeAndDIDResponseForNewSnapMap() {
        return nodeAndDIDResponseForNewSnapMap;
    }

    public void setNodeAndDIDResponseForNewSnapMap(Map<String, NodeAndDIDResponseForNewSnap> nodeAndDIDResponseForNewSnapMap) {
        this.nodeAndDIDResponseForNewSnapMap = nodeAndDIDResponseForNewSnapMap;
    }

    public PreviousSnapShotDetails getPreviousSnapShotDetails() {
        return previousSnapShotDetails;
    }

    public void setPreviousSnapShotDetails(PreviousSnapShotDetails previousSnapShotDetails) {
        this.previousSnapShotDetails = previousSnapShotDetails;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Timestamp getVinRecordedTimestamp() {
        return vinRecordedTimestamp;
    }

    public void setVinRecordedTimestamp(Timestamp vinRecordedTimestamp) {
        this.vinRecordedTimestamp = vinRecordedTimestamp;
    }
}
