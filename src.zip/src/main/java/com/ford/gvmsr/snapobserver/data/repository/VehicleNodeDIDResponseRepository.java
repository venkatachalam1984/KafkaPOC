package com.ford.gvmsr.snapobserver.data.repository;

import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by VYUVARA6 on 8/31/2017.
 */
@Repository
@Transactional
public interface VehicleNodeDIDResponseRepository extends CrudRepository<VehicleNodeDIDResponse, Serializable> {

    @Query(value = "SELECT * FROM PGVMS02_VEH_NODE_DID_RSPNS " +
            "  WHERE GVMS10_VIN_HASH_R=:vinHash and GVMS04_VEH_NODE_SNPSHT_K IN (:04keyList) ", nativeQuery = true)
    List<VehicleNodeDIDResponse> fetchAllDidResponseByVehicleNodeSnapshotKey(@Param("vinHash")int vinHash,@Param("04keyList") List<Long> vehicleNodeSnapshotList);

}

