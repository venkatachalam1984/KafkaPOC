package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.data.dao.PreviousVehicleSnapShotDao;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeConfig;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeDIDResponse;
import com.ford.gvmsr.snapobserver.data.entity.VehicleNodeSnapshot;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PreviousSnapCreationServiceTest {

    @Autowired
    PreviousVehicleSnapShotDao previousVehicleSnapShotDao;

    @Test
    public void test_getPreviousActiveNodeShotDetails(){
        String vin = "1TKAM8FF0J4599831";
        List<String> nodeListFromRequest = new ArrayList<>();
        nodeListFromRequest.add("754");
        Set<VehicleNodeSnapshot> previousActiveVehicleNodeSnapshotForAllNode = previousVehicleSnapShotDao.fetchPreviousActiveVehicleNodeSnapshotForAllNode(vin, nodeListFromRequest);
        Assert.assertNotNull(previousActiveVehicleNodeSnapshotForAllNode);
    }

    @Test
    public void test_getPreviousActiveDidResponseForAllNode(){
        String vin = "1TKAM8FF0J4599831";
        List<Long> vehicleNodeSnapshotKeyList = new ArrayList<>();
        vehicleNodeSnapshotKeyList.add(219327252L);
        Map<String, List<VehicleNodeDIDResponse>> previousActiveDidResponseForAllNode = previousVehicleSnapShotDao.fetchPreviousActiveDidResponseForAllNode(vin, vehicleNodeSnapshotKeyList);
        Assert.assertNotNull(previousActiveDidResponseForAllNode);
    }

    @Test
    public void test_getPreviousActiveConfigDidResponseForAllNode(){
        String vin = "1TKAM8FF0J4599831";
        List<Long> vehicleNodeSnapshotKeyList = new ArrayList<>();
        vehicleNodeSnapshotKeyList.add(219327252L);
        Map<String, List<VehicleNodeConfig>> previousActiveConfigDidResponseForAllNode = previousVehicleSnapShotDao.fetchPreviousActiveConfigDidResponseForAllNode(vin, vehicleNodeSnapshotKeyList);
        Assert.assertNotNull(previousActiveConfigDidResponseForAllNode);
    }

    @Test
    public void test_getPreviousSnapRole(){
        long snapShotKey = 36596392L;
      //  String previousSnapRole = previousVehicleSnapShotDao.getPreviousSnapRole(snapShotKey);
       // Assert.assertNotNull(previousSnapRole);
    }

}
