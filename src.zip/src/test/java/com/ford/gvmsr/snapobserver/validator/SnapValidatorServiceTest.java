package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.modulestate.request.*;
import com.ford.gvmsr.snapobserver.redis.CacheKeyHelper;
import com.ford.gvmsr.snapobserver.redisTest.TestRedisConfiguration;
import com.ford.gvmsr.snapobserver.validator.SnapValidator;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestRedisConfiguration.class)
public class SnapValidatorServiceTest {

    @Test
    public void contextLoads() {
    }

    @Autowired
    private CacheKeyHelper cacheKeyHelper;

    @Autowired
    private SnapValidator snapValidator;

    @Test
    public void test_GenerateKey() {
        String key = cacheKeyHelper.generateSnapInProgressCacheKey("1TKAM8FF0J4599831","7D0");
        Assert.assertNotNull(key);
        System.out.println("Result : "+key);
    }

    @Test
    public void test_setAndGetSnapInProgressFlagInRedis() {
        String key = "SNAP:1TKAM8FF0J4599831:7D0";
        cacheKeyHelper.setSnapInProgressFlagInRedis(key, "ON");
        String snapInProgressFlag  = cacheKeyHelper.getSnapInProgressFlagFromRedis(key);
        Assert.assertNotNull(snapInProgressFlag);
        Assert.assertEquals("ON", snapInProgressFlag);
        System.out.println("Result : "+snapInProgressFlag);
    }

    @Test
    public void test_checkAnySnapIsInProgressForVin(){
        boolean isSnapProgress = false;
        String key = "SNAP:1TKAM8FF0J4599831:7D0";
        cacheKeyHelper.setSnapInProgressFlagInRedis(key, "ON");
        String vin ="1TKAM8FF0J4599831";
        /*ModuleSnapshotType moduleSnapshotType = new ModuleSnapshotType();
        moduleSnapshotType.setVIN("1TKAM8FF0J4599831");
        moduleSnapshotType.setModuleName(ModuleNameENUMType.ECU);
        StateUpdateRoleType stateUpdateRoleType = new StateUpdateRoleType();
        stateUpdateRoleType.setRole(RoleENUMType.CONSUMER);
        stateUpdateRoleType.setRoleSource(RoleSourceENUMType.OTA);
        stateUpdateRoleType.setRoleDesc("FENIX");
        stateUpdateRoleType.setRoleID("VIL-GPH001");
        moduleSnapshotType.setRequestRole(stateUpdateRoleType);
        List<ModuleNodeType> nodeDetailList = new ArrayList<>();*/
        ModuleNodeType nodeDetail = new ModuleNodeType();
        nodeDetail.setAddress("7D0");
        nodeDetail.setIsFlashed(true);
        /*nodeDetailList.add(nodeDetail);
        ModuleNodeType nodeDetail1 = new ModuleNodeType();
        nodeDetail1.setAddress("726");
        nodeDetail1.setIsFlashed(true);
        nodeDetailList.add(nodeDetail1);
        moduleSnapshotType.setNode(nodeDetailList);*/
        isSnapProgress = snapValidator.checkAnySnapIsInProgressForVin(vin, nodeDetail.getAddress());
        Assert.assertTrue(isSnapProgress);
        System.out.println("Boolean result :" +isSnapProgress);
    }

}
