package com.ford.gvmsr.snapobserver.utils;

import org.junit.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class ApplicationUtilsTest {

    @Test
    public void whenVinIsValid_thenReturnVinHash(){
        assertThat(ApplicationUtils.getVinHash("1RRTP8FF0J1151212")).isEqualTo(12);
    }

    @Test
    public void whenVinIsNull_thenReturnZero(){
        assertThat(ApplicationUtils.getVinHash(null)).isEqualTo(0);
    }

    @Test
    public void whenVinLengthIsLessThanTwo_thenReturnZero(){
        assertThat(ApplicationUtils.getVinHash("2")).isEqualTo(0);
    }

}
