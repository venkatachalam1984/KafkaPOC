package com.ford.gvmsr.snapobserver.creator;

import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeDao;
import com.ford.gvmsr.snapobserver.data.dao.VehicleNodeSnapshotDao;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleId;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import com.ford.gvmsr.snapobserver.dto.NodeStatus;
import com.ford.gvmsr.snapobserver.enums.SnapSource;
import com.ford.gvmsr.snapobserver.enums.SnapStatus;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.*;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NodeCreatorTest {


    @Autowired
    NodeCreator nodeCreator;

    @MockBean
    VehicleNodeDao vehicleNodeDao;

    @MockBean
    VehicleNodeSnapshotDao vehicleNodeSnapshotDao;

    @Test
    public void whenNodeIsDuplicate_thenDoNotPersistAndReturnDuplicateStatus() {
        Vehicle vehicle = new Vehicle();
        VehicleSnapshot vehicleSnapshot = new VehicleSnapshot();

        NodeStatus nodeStatus = new NodeStatus();
        nodeStatus.setCode(SnapStatus.DUPLICATE.getCode());
        ModuleSnapshotObserverRequest moduleSnapshotObserverRequest = getModuleSnapshotObserverRequest(nodeStatus);

        Map<String, NodeStatus> nodeStatusMap = nodeCreator.persistNode(vehicle, vehicleSnapshot, moduleSnapshotObserverRequest);

        Assertions.assertFalse(nodeStatusMap.isEmpty());
        Assertions.assertNotNull(nodeStatusMap.get("7D0"));
        Assertions.assertEquals(SnapStatus.DUPLICATE, nodeStatusMap.get("7D0").getCode());
    }

    @Test
    public void whenNodeIsNotDuplicate_thenPersistAndReturnSuccessStatus() {
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(new VehicleId());
        VehicleSnapshot vehicleSnapshot = new VehicleSnapshot();

        NodeStatus nodeStatus = new NodeStatus();
        nodeStatus.setCode(SnapStatus.CREATE_SNAP.getCode());

        ModuleSnapshotObserverRequest moduleSnapshotObserverRequest = getModuleSnapshotObserverRequest(nodeStatus);

        Map<String, NodeStatus> nodeStatusMap = nodeCreator.persistNode(vehicle, vehicleSnapshot, moduleSnapshotObserverRequest);
        Assertions.assertFalse(nodeStatusMap.isEmpty());
        Assertions.assertNotNull(nodeStatusMap.get("7D0"));
        Assertions.assertEquals(SnapStatus.SUCCESS, nodeStatusMap.get("7D0").getCode());
    }

    @Test
    public void whenNodeNodeCreationFailure_thenDoNotPersistAndReturnFailure() {
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(new VehicleId());
        VehicleSnapshot vehicleSnapshot = new VehicleSnapshot();

        NodeStatus nodeStatus = new NodeStatus();
        nodeStatus.setCode(SnapStatus.CREATE_SNAP.getCode());

        ModuleSnapshotObserverRequest moduleSnapshotObserverRequest = getModuleSnapshotObserverRequest(nodeStatus);
        moduleSnapshotObserverRequest.getSnapshotObserverRequest().setAdditionalPropertiesMap(null);

        Map<String, NodeStatus> nodeStatusMap = nodeCreator.persistNode(vehicle, vehicleSnapshot, moduleSnapshotObserverRequest);
        Assertions.assertFalse(nodeStatusMap.isEmpty());
        Assertions.assertNotNull(nodeStatusMap.get("7D0"));
        Assertions.assertEquals(SnapStatus.FAILURE, nodeStatusMap.get("7D0").getCode());
    }

    public ModuleSnapshotObserverRequest getModuleSnapshotObserverRequest(NodeStatus nodeStatus) {

        SnapshotObserverRequest snapshotObserverRequest = new SnapshotObserverRequest();

        ModuleStateRequest moduleStateRequest = new ModuleStateRequest();
        ModuleSnapshotType moduleSnapshotType = new ModuleSnapshotType();

        moduleSnapshotType.setVIN("TESTVIN123456789");
        ModuleNodeType moduleNodeType = new ModuleNodeType();
        moduleNodeType.setAddress("7D0");
        moduleSnapshotType.setNode(new ArrayList<>(Arrays.asList(moduleNodeType)));

        StateUpdateRoleType stateUpdateRoleType = new StateUpdateRoleType();
        stateUpdateRoleType.setRoleSource(RoleSourceENUMType.OTA);
        moduleSnapshotType.setRequestRole(stateUpdateRoleType);

        moduleStateRequest.setModuleSnapshot(moduleSnapshotType);

        AdditionalProperties additionalProperties = new AdditionalProperties();
        DerivedAssemblyResponseForNode derivedAssemblyResponseForNode = new DerivedAssemblyResponseForNode();
        additionalProperties.setDerivedAssemblyResponseForNode(derivedAssemblyResponseForNode);
        snapshotObserverRequest.setAdditionalPropertiesMap(new HashMap<>());
        snapshotObserverRequest.getAdditionalPropertiesMap().put(moduleNodeType.getAddress(), additionalProperties);

        snapshotObserverRequest.setModuleStateRequest(moduleStateRequest);

        ModuleSnapshotObserverRequest moduleSnapshotObserverRequest = new ModuleSnapshotObserverRequest(snapshotObserverRequest);
        // moduleSnapshotObserverRequest.updateNodeStatus(moduleNodeType.getAddress(), nodeStatus);

        return moduleSnapshotObserverRequest;
    }


}