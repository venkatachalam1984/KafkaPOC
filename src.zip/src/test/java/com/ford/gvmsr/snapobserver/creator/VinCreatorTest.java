package com.ford.gvmsr.snapobserver.creator;

import com.ford.gvmsr.snapobserver.data.entity.*;
import com.ford.gvmsr.snapobserver.data.repository.VehicleRepository;
import com.ford.gvmsr.snapobserver.data.repository.VinProgramMapRepository;
import com.ford.gvmsr.snapobserver.exception.ServiceFaultException;
import com.ford.gvmsr.snapobserver.externalservice.ModuleInfoService;
import com.ford.gvmsr.snapobserver.modulestate.request.*;
import com.ford.gvmsr.snapobserver.utils.ApplicationUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RunWith(SpringRunner.class)
@SpringBootTest
public class VinCreatorTest {

    private static final String MOCK_VIN = "1RRTP8FF0J1151212";

    @Autowired
    VinCreator vinCreator;

    @MockBean
    VehicleRepository vehicleRepository;

    @MockBean
    VinProgramMapRepository vinProgramMapRepository;

    @MockBean
    ModuleInfoService moduleInfoService;

    @Before
    public void before() {

    }

    @Test
    public void whenVinExistsInDB_thenReturnVehicle() {
        //Mock Data
        Vehicle mockVehicle = getMockVin(MOCK_VIN);
        Mockito.when(vehicleRepository.findById(ArgumentMatchers.eq(mockVehicle.getVehicleId()))).thenReturn(Optional.of(mockVehicle));

        Vehicle vehicle = vinCreator.createVin(MOCK_VIN, RoleSourceENUMType.OTA);
        Assert.assertEquals(mockVehicle, vehicle);
    }

    @Test
    public void whenVinNotExistInDb_thenCreateNewVehicle() {
        //Mock Data
        Vehicle mockVehicle = getMockVin(MOCK_VIN);
        Mockito.when(moduleInfoService.getVin(ArgumentMatchers.anyString(), ArgumentMatchers.anyList())).thenReturn(Optional.of(mockVehicle));

        Vehicle vehicle = vinCreator.createVin(MOCK_VIN, RoleSourceENUMType.OTA);
        Assert.assertEquals(mockVehicle, vehicle);
    }

    @Test
    public void whenVinNotExistButExistInGivis_thenCreateNewVehicle() {
        //Mock Data
        Vehicle mockVehicle = getMockVin(MOCK_VIN);
        Mockito.when(moduleInfoService.getVin(ArgumentMatchers.anyString(), ArgumentMatchers.anyList())).thenReturn(Optional.of(mockVehicle));

        Vehicle vehicle = vinCreator.createVin(MOCK_VIN, RoleSourceENUMType.OTA);
        Assert.assertEquals(mockVehicle, vehicle);
    }

    @Test
    public void whenVinNotExistInDBAndNotExistInGivisAndVinMapExpressionExist_thenCreateNewVehicle() {

        //Mock Data
        Vehicle mockVehicle = getMockVin(MOCK_VIN);
        Mockito.when(moduleInfoService.getVin(ArgumentMatchers.anyString(), ArgumentMatchers.anyList())).thenReturn(Optional.ofNullable(null));

        List<VINProgramMap> vinProgramMaps = new ArrayList<>();
        VINProgramMap vinProgramMap = new VINProgramMap();
        vinProgramMap.setVinMapExpression("(.*)" + MOCK_VIN.substring(0, 3) + "(.*)");
        vinProgramMap.setVinProgramMapId(new VINProgramMapId());
        vinProgramMaps.add(vinProgramMap);
        Mockito.when(vinProgramMapRepository.getVINMapExpressionByVIN(MOCK_VIN)).thenReturn(vinProgramMaps);
        Mockito.when(vehicleRepository.save(ArgumentMatchers.any())).thenReturn(mockVehicle);

        Vehicle vehicle = vinCreator.createVin(MOCK_VIN, RoleSourceENUMType.OTA);
    }

    @Test(expected = ServiceFaultException.class)
    public void whenVinNotExistInDBAndNotExistInGivisAndVinMapExpressionNotExist_thenCreateNewVehicle() {

        //Mock Data
        Vehicle mockVehicle = getMockVin(MOCK_VIN);
        Mockito.when(moduleInfoService.getVin(ArgumentMatchers.anyString(), ArgumentMatchers.anyList())).thenReturn(Optional.ofNullable(null));

        List<VINProgramMap> vinProgramMaps = new ArrayList<>();
        VINProgramMap vinProgramMap = new VINProgramMap();
        vinProgramMap.setVinMapExpression("TEST");
        vinProgramMap.setVinProgramMapId(new VINProgramMapId());
        vinProgramMaps.add(vinProgramMap);
        Mockito.when(vinProgramMapRepository.getVINMapExpressionByVIN(MOCK_VIN)).thenReturn(vinProgramMaps);
        Mockito.when(vehicleRepository.save(ArgumentMatchers.any())).thenReturn(mockVehicle);

        Vehicle vehicle = vinCreator.createVin(MOCK_VIN, RoleSourceENUMType.OTA);
    }

    @Test(expected = ServiceFaultException.class)
    public void whenVinNotExistInDBAndNotExistInGivisAndNoVinMapExpression_thenThrowServiceFaultException() {

        Mockito.when(moduleInfoService.getVin(ArgumentMatchers.anyString(), ArgumentMatchers.anyList())).thenReturn(Optional.ofNullable(null));

        Vehicle vehicle = vinCreator.createVin(MOCK_VIN, RoleSourceENUMType.OTA);
    }


    private Vehicle getMockVin(String vin) {
        Vehicle mockVehicle = new Vehicle();
        VehicleId vehicleId = new VehicleId(vin, ApplicationUtils.getVinHash(vin));
        mockVehicle.setVehicleId(vehicleId);
        mockVehicle.setBrandName("FORD");
        mockVehicle.setModelYear(2010f);
        mockVehicle.setIvsProgramId(new IVSProgramId());
        return mockVehicle;
    }

}
