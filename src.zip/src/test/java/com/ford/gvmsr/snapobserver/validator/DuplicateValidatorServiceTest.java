package com.ford.gvmsr.snapobserver.validator;

import com.ford.gvmsr.snapobserver.creator.VinCreator;
import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
//import com.ford.gvmsr.snapobserver.dto.VehicleDidResponses;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.*;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DuplicateValidatorServiceTest {

    @Autowired
    SnapDuplicateValidator snapDuplicateValidator;

    @Autowired
    VinCreator vinCreator;

    @Test
    public void test_validateDuplicateNodes(){
        SnapshotObserverRequest snapshotObserverRequest = new SnapshotObserverRequest();
        snapshotObserverRequest.setInfoKey(75206L);
        snapshotObserverRequest.setPartitionKey("87866");
        snapshotObserverRequest.setRecordKey(16730);
        ModuleStateRequest moduleStateRequest = new ModuleStateRequest();
        moduleStateRequest.setTraceID("4d507c9e-c8cf-4809-a4a8-2780b51ff782");
        ModuleSnapshotType moduleSnapshotType = new ModuleSnapshotType();
        moduleSnapshotType.setVIN("1RRHM73R09G008066");
        moduleSnapshotType.setModuleName(ModuleNameENUMType.ECU);
        StateUpdateRoleType stateUpdateRoleType = new StateUpdateRoleType();
        stateUpdateRoleType.setRole(RoleENUMType.CONSUMER);
        stateUpdateRoleType.setRoleSource(RoleSourceENUMType.OTA);
        stateUpdateRoleType.setRoleDesc("FENIX");
        stateUpdateRoleType.setRoleID("VIL-GPH001");
        moduleSnapshotType.setRequestRole(stateUpdateRoleType);
        List<ModuleNodeType> nodeDetailList = new ArrayList<>();

        ModuleNodeType nodeDetail = new ModuleNodeType();
        nodeDetail.setAddress("727");
        nodeDetail.setIsFlashed(false);
        nodeDetail.setSpecificationCategory("GGDS");

        List<ECUAcronymType> ecuAcronymTypes = new ArrayList<>();
        ECUAcronymType ecuAcronymType = new ECUAcronymType();
        ecuAcronymType.setName("APIM");
        ecuAcronymTypes.add(ecuAcronymType);

        HistoricType historicType = new HistoricType();
        GatewayType gatewayType = new GatewayType();
        gatewayType.setGatewayType("NONE");

        List<DIDInfoType> didInfoTypes = new ArrayList<>();

        DIDInfoType didInfoType = new DIDInfoType();
        didInfoType.setDidValue("F188");
        didInfoType.setResponse("LT4T-14G195-CA");
        didInfoType.setIsConfig(false);

        DIDInfoType didInfoType1 = new DIDInfoType();
        didInfoType1.setDidValue("DE00");
        didInfoType1.setResponse("010120202");
        didInfoType1.setIsConfig(true);

        DIDInfoType didInfoType2 = new DIDInfoType();
        didInfoType2.setDidValue("DE01");
        didInfoType2.setResponse("010120203");
        didInfoType2.setIsConfig(true);

        DIDInfoType didInfoType3 = new DIDInfoType();
        didInfoType3.setDidValue("F111");
        didInfoType3.setResponse("LT4T-14G201-DA");
        didInfoType3.setIsConfig(false);

        gatewayType.setDid(didInfoTypes);
        historicType.getGateway().add(gatewayType);

        ecuAcronymType.getState().add(historicType);

        nodeDetail.setEcuAcronym(ecuAcronymTypes);

        nodeDetailList.add(nodeDetail);
        moduleSnapshotType.setNode(nodeDetailList);
        moduleStateRequest.setModuleSnapshot(moduleSnapshotType);
        snapshotObserverRequest.setModuleStateRequest(moduleStateRequest);
        ModuleSnapshotObserverRequest moduleSnapshotObserverRequest = new ModuleSnapshotObserverRequest(snapshotObserverRequest);

        Vehicle vehicle = vinCreator.createVin(moduleSnapshotObserverRequest.getVin(), moduleSnapshotObserverRequest.getRequestRole().getRoleSource());

        //Map<String, VehicleDidResponses> vehicleDidResponsesMap = snapDuplicateValidator.validateDidResponseForNodes(moduleSnapshotObserverRequest,vehicle);

        /*Assert.assertNotNull(vehicleDidResponsesMap);
        System.out.println("vehicleDidResponsesMap >> "+ vehicleDidResponsesMap.toString());*/

    }
}
