package com.ford.gvmsr.snapobserver.creator;

import com.ford.gvmsr.snapobserver.data.entity.Vehicle;
import com.ford.gvmsr.snapobserver.data.entity.VehicleSnapshot;
import com.ford.gvmsr.snapobserver.data.repository.VehicleSnapshotRepository;
import com.ford.gvmsr.snapobserver.exception.ServiceFaultException;
import com.ford.gvmsr.snapobserver.modulestate.ModuleSnapshotObserverRequest;
import com.ford.gvmsr.snapobserver.modulestate.request.*;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import javax.persistence.EntityNotFoundException;

@RunWith(SpringRunner.class)
@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class VehicleSnapshotCreatorTest {
    @MockBean
    VehicleSnapshotRepository vehicleSnapshotRepository;

    @Autowired
    VehicleSnapshotCreator vehicleSnapshotCreator;

    @Test
    public void whenModuleStateResponseIsNull_thenReturnNull() {
        Vehicle vehicle = new Vehicle();
        VehicleSnapshot vehicleSnapshot = vehicleSnapshotCreator.createVehicleSnapshot(null, vehicle);
        Assertions.assertNull(vehicleSnapshot);
    }

    @Test
    public void whenModuleStateResponseIsValid_thenCreateNewVehicleSnapshot() {

        VehicleSnapshot mockVehicleSnapshot = new VehicleSnapshot();
        mockVehicleSnapshot.setVehicleSnapshotKey(1234L);
        Mockito.when(vehicleSnapshotRepository.save(ArgumentMatchers.any())).thenReturn(mockVehicleSnapshot);

        Vehicle vehicle = new Vehicle();
        ModuleSnapshotObserverRequest moduleSnapshotObserverRequest = new ModuleSnapshotObserverRequest(getSnapshotObserverRequest());

        VehicleSnapshot vehicleSnapshot = vehicleSnapshotCreator.createVehicleSnapshot(moduleSnapshotObserverRequest, vehicle);
        Assertions.assertNotNull(vehicleSnapshot);
        Assertions.assertEquals(mockVehicleSnapshot.getVehicleSnapshotKey(), vehicleSnapshot.getVehicleSnapshotKey());

        ArgumentCaptor<VehicleSnapshot> argument = ArgumentCaptor.forClass(VehicleSnapshot.class);
        Mockito.verify(vehicleSnapshotRepository).save(argument.capture());

    }

    @Test(expected = ServiceFaultException.class)
    public void whenExceptionHappenedWhileCreatingVehicleSnapshot_thenThrowServiceFaultException() {
        Mockito.when(vehicleSnapshotRepository.save(ArgumentMatchers.any())).thenThrow(new EntityNotFoundException());

        ModuleSnapshotObserverRequest moduleSnapshotObserverRequest = new ModuleSnapshotObserverRequest(getSnapshotObserverRequest());
        vehicleSnapshotCreator.createVehicleSnapshot(moduleSnapshotObserverRequest, null);
    }

    public SnapshotObserverRequest getSnapshotObserverRequest() {
        SnapshotObserverRequest snapshotObserverRequest = new SnapshotObserverRequest();
        ModuleStateRequest moduleStateRequest = new ModuleStateRequest();
        ModuleSnapshotType moduleSnapshotType = new ModuleSnapshotType();

        StateUpdateRoleType stateUpdateRoleType = new StateUpdateRoleType();
        stateUpdateRoleType.setRoleSource(RoleSourceENUMType.OTA);
        moduleSnapshotType.setRequestRole(stateUpdateRoleType);

        moduleStateRequest.setModuleSnapshot(moduleSnapshotType);
        snapshotObserverRequest.setModuleStateRequest(moduleStateRequest);
        return snapshotObserverRequest;
    }



}
